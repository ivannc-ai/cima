/** Parametric part / assembly templates: proven models instantiated from a few values. */
import type { CadModel, Parameter } from '../model/schema'

export type TemplateValue = number | boolean | string

export interface TemplateParam {
  /** Identifier (also the model parameter name for numeric parameters). */
  name: string
  /** Spanish label for the UI. */
  label: string
  /** English description for the LLM. */
  description: string
  kind: 'length' | 'angle' | 'count' | 'bool' | 'enum'
  default: TemplateValue
  min?: number
  max?: number
  step?: number
  options?: string[]
  /** Structural parameters (bool / enum / some counts) are fixed at instantiation, not sliders. */
  structural?: boolean
}

export interface CadTemplate {
  id: string
  /** Spanish title for the UI. */
  title: string
  category: 'Piezas' | 'Chapa y placas' | 'Ejes y revolución' | 'Carcasas' | 'Ensamblajes'
  /** English description for the LLM: what it is and when to use it. */
  description: string
  /** Search keywords (Spanish and English). */
  keywords: string[]
  params: TemplateParam[]
  build(values: Readonly<Record<string, TemplateValue>>, name: string): CadModel
}

/** Builds a model parameter from a numeric template parameter and its value. */
export function modelParam(p: TemplateParam, value: number, overrides: Partial<Parameter> = {}): Parameter {
  const unit = p.kind === 'length' ? 'mm' : p.kind === 'angle' ? 'deg' : 'none'
  const out: Parameter = { name: p.name, value, unit, description: p.label }
  if (p.min !== undefined) out.min = Math.min(p.min, value)
  if (p.max !== undefined) out.max = Math.max(p.max, value)
  if (p.step !== undefined) out.step = p.step
  return { ...out, ...overrides }
}

/** Numeric (slider) parameters of a template, in order, as model parameters. */
export function sliderParams(t: CadTemplate, v: Readonly<Record<string, TemplateValue>>, skip: string[] = []): Parameter[] {
  return t.params
    .filter((p) => !p.structural && (p.kind === 'length' || p.kind === 'angle' || p.kind === 'count') && !skip.includes(p.name))
    .map((p) => modelParam(p, Number(v[p.name])))
}
