/**
 * Built-in template library. Every template produces a complete, parametric CIMA model whose numeric
 * template parameters become model parameters (sliders in the app, user parameters in CATIA).
 * Each template is covered by tests that build it at default and extreme values.
 */
import type { CadModel, Feature } from '../model/schema'
import { sliderParams, type CadTemplate, type TemplateValue } from './types'

type V = Readonly<Record<string, TemplateValue>>
const num = (v: V, k: string) => Number(v[k])
const bool = (v: V, k: string) => v[k] === true || v[k] === 'true'

function part(id: string, name: string, material: string, color: string, parameters: CadModel['parameters'], features: Feature[]): CadModel['parts'][number] {
  return { id, name, material, color, parameters, features }
}

function single(name: string, description: string, p: CadModel['parts'][number]): CadModel {
  return { schemaVersion: 1, name, description, units: 'mm', kind: 'part', parameters: [], parts: [p] }
}

/** Positions of `count` holes evenly spread between ±half (centered when count = 1), as expressions. */
const spread = (countName: string, halfExpr: string) => ({
  start: `-(${halfExpr}) * min(${countName} - 1, 1)`,
  step: `2 * (${halfExpr}) / max(${countName} - 1, 1)`,
})

// ---------------------------------------------------------------------------

const flange: CadTemplate = {
  id: 'flange',
  title: 'Brida circular',
  category: 'Piezas',
  description: 'Circular flange: disc with central bore, bolt holes on a pitch circle, optional raised hub and rounded outer edges.',
  keywords: ['brida', 'flange', 'disco', 'taladros en círculo', 'bolt circle', 'tapa circular'],
  params: [
    { name: 'outer_d', label: 'Diámetro exterior', description: 'Outer diameter', kind: 'length', default: 160, min: 40, max: 800, step: 1 },
    { name: 'thickness', label: 'Espesor', description: 'Disc thickness', kind: 'length', default: 16, min: 3, max: 80, step: 0.5 },
    { name: 'bore_d', label: 'Diámetro interior', description: 'Central bore diameter', kind: 'length', default: 60, min: 5, max: 700, step: 0.5 },
    { name: 'bolt_count', label: 'Número de taladros', description: 'Number of bolt holes', kind: 'count', default: 6, min: 2, max: 48, step: 1 },
    { name: 'bolt_d', label: 'Diámetro de taladro', description: 'Bolt hole diameter', kind: 'length', default: 13.5, min: 2, max: 60, step: 0.5 },
    { name: 'pcd', label: 'Diámetro primitivo', description: 'Bolt pitch circle diameter (0 = midway between bore and outer edge)', kind: 'length', default: 0, min: 0, max: 780, step: 1 },
    { name: 'hub', label: 'Cubo central', description: 'Add a raised hub around the bore', kind: 'bool', default: false, structural: true },
    { name: 'hub_d', label: 'Diámetro del cubo', description: 'Hub outer diameter (when hub = true)', kind: 'length', default: 90, min: 10, max: 700, step: 1 },
    { name: 'hub_h', label: 'Altura del cubo', description: 'Hub height above the disc (when hub = true)', kind: 'length', default: 20, min: 2, max: 200, step: 1 },
    { name: 'edge_r', label: 'Redondeo exterior', description: 'Outer edge fillet radius (0 = none)', kind: 'length', default: 2, min: 0, max: 20, step: 0.5 },
  ],
  build(v, name) {
    const hub = bool(v, 'hub')
    const skip = ['pcd', ...(hub ? [] : ['hub_d', 'hub_h']), ...(num(v, 'edge_r') > 0 ? [] : ['edge_r'])]
    const parameters = sliderParams(this, v, skip)
    parameters.push(
      num(v, 'pcd') > 0
        ? { name: 'pcd', value: num(v, 'pcd'), unit: 'mm', min: 10, max: 780, step: 1, description: 'Diámetro primitivo' }
        : { name: 'pcd', value: 0, unit: 'mm', description: 'Diámetro primitivo', expression: hub ? '(outer_d + hub_d) / 2' : '(outer_d + bore_d) / 2' },
    )
    const top = hub ? 'thickness + hub_h' : 'thickness'
    const features: Feature[] = [
      { id: 'disc', name: 'Disco', type: 'pad', sketch: { plane: { type: 'origin', base: 'XY' }, profiles: [{ type: 'circle', center: [0, 0], diameter: 'outer_d' }] }, length: 'thickness' },
    ]
    if (hub) {
      features.push({
        id: 'hub',
        name: 'Cubo',
        type: 'pad',
        sketch: { plane: { type: 'origin', base: 'XY', offset: 'thickness' }, profiles: [{ type: 'circle', center: [0, 0], diameter: 'hub_d' }] },
        length: 'hub_h',
      })
    }
    features.push(
      {
        id: 'bore',
        name: 'Agujero central',
        type: 'pocket',
        sketch: { plane: { type: 'origin', base: 'XY', offset: top }, profiles: [{ type: 'circle', center: [0, 0], diameter: 'bore_d' }] },
        throughAll: true,
      },
      {
        id: 'bolt_holes',
        name: 'Taladros',
        type: 'hole',
        plane: { type: 'origin', base: 'XY', offset: 'thickness' },
        positions: [['pcd/2', 0]],
        repeat: { type: 'circular', count: 'bolt_count', center: [0, 0] },
        diameter: 'bolt_d',
        throughAll: true,
      },
    )
    if (num(v, 'edge_r') > 0) {
      features.push({ id: 'outer_round', name: 'Redondeo exterior', type: 'fillet', edges: { curve: 'circle', radius: 'outer_d/2' }, radius: 'edge_r' })
    }
    return single(name, 'Brida circular generada desde plantilla.', part('flange', name, 'Acero S275', '#8fa3b8', parameters, features))
  },
}

const plate: CadTemplate = {
  id: 'plate_holes',
  title: 'Placa con taladros',
  category: 'Chapa y placas',
  description: 'Rectangular plate with rounded corners and a grid of holes (simple, countersunk or counterbored).',
  keywords: ['placa', 'plate', 'pletina', 'chapa', 'base', 'taladros', 'rejilla de taladros'],
  params: [
    { name: 'L', label: 'Largo (X)', description: 'Length along X', kind: 'length', default: 200, min: 20, max: 2000, step: 1 },
    { name: 'W', label: 'Ancho (Y)', description: 'Width along Y', kind: 'length', default: 120, min: 20, max: 2000, step: 1 },
    { name: 'T', label: 'Espesor', description: 'Thickness', kind: 'length', default: 10, min: 1, max: 100, step: 0.5 },
    { name: 'corner_r', label: 'Radio de esquina', description: 'Corner radius (0 = sharp)', kind: 'length', default: 8, min: 0, max: 100, step: 0.5 },
    { name: 'nx', label: 'Taladros en X', description: 'Number of holes along X', kind: 'count', default: 3, min: 1, max: 30, step: 1 },
    { name: 'ny', label: 'Taladros en Y', description: 'Number of holes along Y', kind: 'count', default: 2, min: 1, max: 30, step: 1 },
    { name: 'hole_d', label: 'Diámetro de taladro', description: 'Hole diameter', kind: 'length', default: 9, min: 1, max: 80, step: 0.5 },
    { name: 'margin', label: 'Distancia al borde', description: 'Distance from the plate edge to the hole centers', kind: 'length', default: 20, min: 3, max: 300, step: 1 },
    { name: 'hole_kind', label: 'Tipo de taladro', description: 'simple | countersunk | counterbored', kind: 'enum', default: 'simple', options: ['simple', 'countersunk', 'counterbored'], structural: true },
  ],
  build(v, name) {
    const kind = String(v.hole_kind) as 'simple' | 'countersunk' | 'counterbored'
    const sx = spread('nx', 'L/2 - margin')
    const sy = spread('ny', 'W/2 - margin')
    const hole: Feature = {
      id: 'holes',
      name: 'Taladros',
      type: 'hole',
      plane: { type: 'origin', base: 'XY', offset: 'T' },
      positions: [[sx.start, sy.start]],
      repeat: { type: 'linear', count: 'nx', step: [sx.step, 0], count2: 'ny', step2: [0, sy.step] },
      diameter: 'hole_d',
      throughAll: true,
      ...(kind === 'countersunk' ? { kind, headDiameter: 'hole_d * 2', headAngle: 90 } : {}),
      ...(kind === 'counterbored' ? { kind, headDiameter: 'hole_d * 1.7', headDepth: 'min(T * 0.5, hole_d * 0.6)' } : {}),
    }
    const profile =
      num(v, 'corner_r') > 0
        ? { type: 'rectangle' as const, center: [0, 0], width: 'L', height: 'W', cornerRadius: 'corner_r' }
        : { type: 'rectangle' as const, center: [0, 0], width: 'L', height: 'W' }
    const parameters = sliderParams(this, v, num(v, 'corner_r') > 0 ? [] : ['corner_r'])
    return single(
      name,
      'Placa con rejilla de taladros generada desde plantilla.',
      part('plate', name, 'Aluminio 5083', '#9aa7b6', parameters, [
        { id: 'plate', name: 'Placa', type: 'pad', sketch: { plane: { type: 'origin', base: 'XY' }, profiles: [profile] }, length: 'T' },
        hole,
      ]),
    )
  },
}

const lBracket: CadTemplate = {
  id: 'l_bracket',
  title: 'Escuadra en L',
  category: 'Chapa y placas',
  description: 'L-shaped bracket (base along X, wall along Z, width along Y) with inner bend radius, holes in both legs and an optional stiffening rib.',
  keywords: ['escuadra', 'soporte en L', 'angular', 'bracket', 'angle bracket', 'cartela', 'nervio'],
  params: [
    { name: 'length', label: 'Longitud base (X)', description: 'Base leg length along X', kind: 'length', default: 80, min: 20, max: 600, step: 1 },
    { name: 'height', label: 'Altura ala (Z)', description: 'Wall leg height along Z', kind: 'length', default: 60, min: 20, max: 600, step: 1 },
    { name: 'width', label: 'Anchura (Y)', description: 'Width along Y', kind: 'length', default: 40, min: 10, max: 600, step: 1 },
    { name: 't', label: 'Espesor', description: 'Material thickness', kind: 'length', default: 6, min: 1, max: 40, step: 0.5 },
    { name: 'inner_r', label: 'Radio interior', description: 'Inner bend fillet radius', kind: 'length', default: 4, min: 0.5, max: 40, step: 0.5 },
    { name: 'hole_d', label: 'Diámetro de taladro', description: 'Hole diameter', kind: 'length', default: 6.6, min: 2, max: 40, step: 0.1 },
    { name: 'hole_edge', label: 'Distancia taladro-borde', description: 'Distance from leg ends/sides to hole centers', kind: 'length', default: 12, min: 4, max: 100, step: 0.5 },
    { name: 'base_holes', label: 'Taladros en base', description: 'Number of holes in the base leg (across the width)', kind: 'count', default: 2, min: 1, max: 10, step: 1 },
    { name: 'wall_holes', label: 'Taladros en ala', description: 'Number of holes in the wall leg (across the width)', kind: 'count', default: 1, min: 1, max: 10, step: 1 },
    { name: 'rib', label: 'Nervio', description: 'Add a central triangular stiffening rib', kind: 'bool', default: true, structural: true },
    { name: 'rib_t', label: 'Espesor del nervio', description: 'Rib thickness (when rib = true)', kind: 'length', default: 5, min: 1, max: 40, step: 0.5 },
  ],
  build(v, name) {
    const rib = bool(v, 'rib')
    const sy = spread('base_holes', 'width/2 - hole_edge')
    const sw = spread('wall_holes', 'width/2 - hole_edge')
    const features: Feature[] = [
      {
        id: 'profile_L',
        name: 'Perfil L',
        type: 'pad',
        sketch: {
          plane: { type: 'origin', base: 'ZX' },
          profiles: [{ type: 'polygon', points: [[0, 0], [0, 'length'], ['t', 'length'], ['t', 't'], ['height', 't'], ['height', 0]] }],
        },
        length: 'width',
      },
      {
        id: 'inner_bend',
        name: 'Radio interior',
        type: 'fillet',
        edges: { direction: 'Y', inBox: { min: ['t - 0.01', -1, 't - 0.01'], max: ['t + 0.01', 'width + 1', 't + 0.01'] } },
        radius: 'inner_r',
      },
    ]
    if (rib) {
      features.push({
        id: 'rib',
        name: 'Nervio',
        type: 'pad',
        sketch: {
          plane: { type: 'origin', base: 'ZX', offset: 'width/2' },
          profiles: [{ type: 'polygon', points: [['t', 't'], ['t', 'min(length - hole_edge*2.2, (height + length)/2*0.6)'], ['min(height - hole_edge*2.2, (height + length)/2*0.6)', 't']] }],
        },
        length: 'rib_t',
        direction: 'symmetric',
      })
    }
    // Holes avoid the rib: with a rib, they are spread across the width as given (rib sits in the middle).
    features.push(
      {
        id: 'base_holes',
        name: 'Taladros base',
        type: 'hole',
        plane: { type: 'origin', base: 'XY', offset: 't' },
        positions: [['length - hole_edge', `width/2 + ${sy.start}`]],
        repeat: { type: 'linear', count: 'base_holes', step: [0, sy.step] },
        diameter: 'hole_d',
        throughAll: true,
      },
      {
        id: 'wall_holes',
        name: 'Taladros ala',
        type: 'hole',
        plane: { type: 'origin', base: 'YZ' },
        positions: [[`width/2 + ${sw.start}`, 'height - hole_edge']],
        repeat: { type: 'linear', count: 'wall_holes', step: [sw.step, 0] },
        diameter: 'hole_d',
        throughAll: true,
        reverse: true,
      },
    )
    const parameters = sliderParams(this, v, rib ? [] : ['rib_t'])
    return single(name, 'Escuadra en L generada desde plantilla.', part('bracket', name, 'Aluminio 6061-T6', '#c0c6cc', parameters, features))
  },
}

const steppedShaft: CadTemplate = {
  id: 'stepped_shaft',
  title: 'Eje escalonado',
  category: 'Ejes y revolución',
  description: 'Shaft along +Z made of 1 to 3 cylindrical sections, with end chamfers, optional keyway on the second section (or the first if only one) and optional retaining-ring groove near the far end.',
  keywords: ['eje', 'árbol', 'shaft', 'escalonado', 'chavetero', 'keyway', 'ranura', 'circlip'],
  params: [
    { name: 'sections', label: 'Número de tramos', description: 'Number of cylindrical sections (1-3)', kind: 'enum', default: '2', options: ['1', '2', '3'], structural: true },
    { name: 'd1', label: 'Diámetro tramo 1', description: 'Diameter of section 1 (starts at z = 0)', kind: 'length', default: 20, min: 2, max: 400, step: 0.5 },
    { name: 'l1', label: 'Longitud tramo 1', description: 'Length of section 1', kind: 'length', default: 40, min: 2, max: 2000, step: 1 },
    { name: 'd2', label: 'Diámetro tramo 2', description: 'Diameter of section 2', kind: 'length', default: 30, min: 2, max: 400, step: 0.5 },
    { name: 'l2', label: 'Longitud tramo 2', description: 'Length of section 2', kind: 'length', default: 60, min: 2, max: 2000, step: 1 },
    { name: 'd3', label: 'Diámetro tramo 3', description: 'Diameter of section 3', kind: 'length', default: 25, min: 2, max: 400, step: 0.5 },
    { name: 'l3', label: 'Longitud tramo 3', description: 'Length of section 3', kind: 'length', default: 30, min: 2, max: 2000, step: 1 },
    { name: 'chamfer', label: 'Chaflán extremos', description: 'End chamfer size', kind: 'length', default: 1, min: 0.2, max: 10, step: 0.1 },
    { name: 'keyway', label: 'Chavetero', description: 'Add a keyway', kind: 'bool', default: true, structural: true },
    { name: 'key_w', label: 'Ancho chaveta', description: 'Keyway width', kind: 'length', default: 8, min: 1, max: 60, step: 0.5 },
    { name: 'key_depth', label: 'Profundidad chavetero', description: 'Keyway depth', kind: 'length', default: 4, min: 0.5, max: 30, step: 0.5 },
    { name: 'key_len', label: 'Longitud chavetero', description: 'Keyway length (must be shorter than its section)', kind: 'length', default: 36, min: 5, max: 1000, step: 1 },
    { name: 'groove', label: 'Ranura anillo elástico', description: 'Add a retaining-ring groove near the far end', kind: 'bool', default: false, structural: true },
    { name: 'groove_w', label: 'Ancho ranura', description: 'Groove width', kind: 'length', default: 1.6, min: 0.5, max: 10, step: 0.1 },
    { name: 'groove_depth', label: 'Profundidad ranura', description: 'Groove depth', kind: 'length', default: 1, min: 0.2, max: 10, step: 0.1 },
  ],
  build(v, name) {
    const n = Math.max(1, Math.min(3, Number(v.sections) || 2))
    const keyway = bool(v, 'keyway')
    const groove = bool(v, 'groove')
    const ds = ['d1', 'd2', 'd3'].slice(0, n)
    const ls = ['l1', 'l2', 'l3'].slice(0, n)
    const total = ls.join(' + ')
    // Half profile in the ZX plane (u = Z along the axis, v = X radius).
    const pts: Array<[string | number, string | number]> = [[0, 0]]
    let z = '0'
    ds.forEach((d, i) => {
      pts.push([z, `${d}/2`])
      z = i === 0 ? ls[0]! : `${z} + ${ls[i]!}`
      pts.push([z, `${d}/2`])
    })
    pts.push([total, 0])
    const features: Feature[] = [
      { id: 'body', name: 'Cuerpo', type: 'shaft', sketch: { plane: { type: 'origin', base: 'ZX' }, profiles: [{ type: 'polygon', points: pts }] }, axis: 'u' },
    ]
    if (keyway) {
      const k = n >= 2 ? 1 : 0
      const z0 = k === 0 ? '0' : ls.slice(0, k).join(' + ')
      const d = ds[k]!
      const l = ls[k]!
      features.push({
        id: 'keyway',
        name: 'Chavetero',
        type: 'pocket',
        sketch: {
          plane: { type: 'origin', base: 'YZ', offset: `${d}/2` },
          profiles: [{ type: 'slot', start: [0, `${z0} + (${l} - key_len)/2 + key_w/2`], end: [0, `${z0} + (${l} + key_len)/2 - key_w/2`], width: 'key_w' }],
        },
        depth: 'key_depth',
      })
    }
    if (groove) {
      const dl = ds[n - 1]!
      features.push({
        id: 'groove',
        name: 'Ranura anillo',
        type: 'groove',
        sketch: {
          plane: { type: 'origin', base: 'ZX' },
          profiles: [{ type: 'rectangle', center: [`${total} - max(groove_w * 4, 6)`, `${dl}/2 - groove_depth/2 + 0.5`], width: 'groove_w', height: 'groove_depth + 1' }],
        },
        axis: 'u',
      })
    }
    features.push(
      { id: 'chamfer_start', name: 'Chaflán inicio', type: 'chamfer', edges: { curve: 'circle', onPlane: { axis: 'Z', at: 0 } }, distance: 'chamfer' },
      { id: 'chamfer_end', name: 'Chaflán final', type: 'chamfer', edges: { curve: 'circle', onPlane: { axis: 'Z', at: total } }, distance: 'chamfer' },
    )
    const unused = [...['d2', 'l2', 'd3', 'l3'].filter((p) => Number(p[1]) > n), ...(keyway ? [] : ['key_w', 'key_depth', 'key_len']), ...(groove ? [] : ['groove_w', 'groove_depth'])]
    return single(name, 'Eje escalonado generado desde plantilla.', part('shaft', name, 'Acero C45', '#9aa0a6', sliderParams(this, v, unused), features))
  },
}

const enclosure: CadTemplate = {
  id: 'enclosure',
  title: 'Caja / carcasa',
  category: 'Carcasas',
  description: 'Rectangular box with rounded vertical corners, rounded bottom edges, open top (shelled) and optional internal mounting bosses with pilot holes.',
  keywords: ['caja', 'carcasa', 'envolvente', 'enclosure', 'box', 'housing', 'vaciado', 'torretas'],
  params: [
    { name: 'L', label: 'Largo (X)', description: 'Outer length', kind: 'length', default: 120, min: 20, max: 1000, step: 1 },
    { name: 'W', label: 'Ancho (Y)', description: 'Outer width', kind: 'length', default: 80, min: 20, max: 1000, step: 1 },
    { name: 'H', label: 'Alto (Z)', description: 'Outer height', kind: 'length', default: 40, min: 10, max: 600, step: 1 },
    { name: 'wall', label: 'Espesor de pared', description: 'Wall and floor thickness', kind: 'length', default: 2.5, min: 0.8, max: 20, step: 0.1 },
    { name: 'corner_r', label: 'Radio de esquina', description: 'Vertical corner radius (must exceed wall)', kind: 'length', default: 8, min: 1, max: 100, step: 0.5 },
    { name: 'bottom_r', label: 'Redondeo inferior', description: 'Bottom outer edge radius (smaller than wall + corner)', kind: 'length', default: 3, min: 0.5, max: 30, step: 0.5 },
    { name: 'bosses', label: 'Torretas de fijación', description: 'Add 4 internal mounting bosses', kind: 'bool', default: true, structural: true },
    { name: 'boss_d', label: 'Diámetro torreta', description: 'Boss diameter', kind: 'length', default: 8, min: 3, max: 40, step: 0.5 },
    { name: 'boss_hole', label: 'Taladro torreta', description: 'Pilot hole diameter in the bosses', kind: 'length', default: 2.5, min: 1, max: 20, step: 0.1 },
  ],
  build(v, name) {
    const bosses = bool(v, 'bosses')
    const features: Feature[] = [
      { id: 'block', name: 'Bloque', type: 'pad', sketch: { plane: { type: 'origin', base: 'XY' }, profiles: [{ type: 'rectangle', center: [0, 0], width: 'L', height: 'W', cornerRadius: 'corner_r' }] }, length: 'H' },
      // The shell offsets this fillet inwards by `wall`: its radius must stay larger than the wall.
      { id: 'bottom_round', name: 'Redondeo inferior', type: 'fillet', edges: { onPlane: { axis: 'Z', at: 0 } }, radius: 'max(bottom_r, wall + 0.5)' },
      { id: 'hollow', name: 'Vaciado', type: 'shell', thickness: 'wall', openFaces: { normal: '+Z', onPlane: { axis: 'Z', at: 'H' } } },
    ]
    if (bosses) {
      const ix = 'L/2 - wall - boss_d/2 - max(corner_r - wall, 0) * 0.6'
      const iy = 'W/2 - wall - boss_d/2 - max(corner_r - wall, 0) * 0.6'
      features.push(
        {
          id: 'bosses',
          name: 'Torretas',
          type: 'pad',
          sketch: {
            plane: { type: 'origin', base: 'XY', offset: 'wall' },
            profiles: [{ type: 'circle', center: [`-(${ix})`, `-(${iy})`], diameter: 'boss_d', repeat: { type: 'linear', count: 2, step: [`2*(${ix})`, 0], count2: 2, step2: [0, `2*(${iy})`] } }],
          },
          length: 'H - wall - 3',
        },
        {
          id: 'boss_holes',
          name: 'Taladros torretas',
          type: 'hole',
          plane: { type: 'origin', base: 'XY', offset: 'H - 3' },
          positions: [[`-(${ix})`, `-(${iy})`]],
          repeat: { type: 'linear', count: 2, step: [`2*(${ix})`, 0], count2: 2, step2: [0, `2*(${iy})`] },
          diameter: 'boss_hole',
          depth: 'min(H - wall - 4, 12)',
        },
      )
    }
    return single(name, 'Caja vaciada generada desde plantilla.', part('box', name, 'ABS', '#5b8def', sliderParams(this, v, bosses ? [] : ['boss_d', 'boss_hole']), features))
  },
}

const pillowBlock: CadTemplate = {
  id: 'pillow_block',
  title: 'Soporte de rodamiento',
  category: 'Piezas',
  description: 'Pillow block / bearing support: bolted base plate, web, cylindrical housing with bore along Y, side ribs and counterbored anchor holes.',
  keywords: ['soporte', 'rodamiento', 'chumacera', 'pillow block', 'bearing housing', 'alojamiento'],
  params: [
    { name: 'base_L', label: 'Longitud base (X)', description: 'Base length along X', kind: 'length', default: 140, min: 60, max: 600, step: 1 },
    { name: 'base_W', label: 'Anchura base (Y)', description: 'Base width along Y', kind: 'length', default: 50, min: 20, max: 300, step: 1 },
    { name: 'base_T', label: 'Espesor base', description: 'Base thickness', kind: 'length', default: 12, min: 4, max: 60, step: 0.5 },
    { name: 'axis_h', label: 'Altura del eje', description: 'Bore axis height above the bottom', kind: 'length', default: 55, min: 20, max: 400, step: 1 },
    { name: 'housing_d', label: 'Diámetro alojamiento', description: 'Housing outer diameter', kind: 'length', default: 62, min: 15, max: 500, step: 1 },
    { name: 'housing_w', label: 'Anchura alojamiento', description: 'Housing width along Y (<= base width)', kind: 'length', default: 36, min: 8, max: 300, step: 1 },
    { name: 'bore_d', label: 'Diámetro agujero', description: 'Bearing bore diameter', kind: 'length', default: 35, min: 5, max: 450, step: 0.5 },
    { name: 'bolt_d', label: 'Diámetro taladros', description: 'Anchor hole diameter', kind: 'length', default: 11, min: 3, max: 40, step: 0.5 },
    { name: 'bolt_inset', label: 'Distancia taladro-extremo', description: 'Distance from base ends to anchor holes', kind: 'length', default: 16, min: 5, max: 100, step: 0.5 },
    { name: 'ribs', label: 'Nervios', description: 'Add side ribs', kind: 'bool', default: true, structural: true },
    { name: 'rib_t', label: 'Espesor nervios', description: 'Rib thickness', kind: 'length', default: 8, min: 2, max: 40, step: 0.5 },
  ],
  build(v, name) {
    const ribs = bool(v, 'ribs')
    const features: Feature[] = [
      { id: 'base', name: 'Base', type: 'pad', sketch: { plane: { type: 'origin', base: 'XY' }, profiles: [{ type: 'rectangle', center: [0, 0], width: 'base_L', height: 'base_W', cornerRadius: 'min(6, base_W/4)' }] }, length: 'base_T' },
      { id: 'web', name: 'Alma', type: 'pad', sketch: { plane: { type: 'origin', base: 'ZX' }, profiles: [{ type: 'rectangle', center: ['(base_T + axis_h)/2', 0], width: 'axis_h - base_T', height: 'housing_d' }] }, length: 'housing_w', direction: 'symmetric' },
      { id: 'housing', name: 'Alojamiento', type: 'pad', sketch: { plane: { type: 'origin', base: 'ZX' }, profiles: [{ type: 'circle', center: ['axis_h', 0], diameter: 'housing_d' }] }, length: 'housing_w', direction: 'symmetric' },
    ]
    if (ribs) {
      features.push({
        id: 'ribs',
        name: 'Nervios',
        type: 'pad',
        sketch: {
          plane: { type: 'origin', base: 'YZ' },
          profiles: [
            { type: 'polygon', points: [['housing_w/2', 'base_T'], ['base_W/2', 'base_T'], ['housing_w/2', 'axis_h - housing_d*0.1']] },
            { type: 'polygon', points: [['-housing_w/2', 'base_T'], ['-housing_w/2', 'axis_h - housing_d*0.1'], ['-base_W/2', 'base_T']] },
          ],
        },
        length: 'rib_t',
        direction: 'symmetric',
      })
    }
    features.push(
      { id: 'bore', name: 'Agujero rodamiento', type: 'pocket', sketch: { plane: { type: 'origin', base: 'ZX' }, profiles: [{ type: 'circle', center: ['axis_h', 0], diameter: 'bore_d' }] }, throughAll: true, direction: 'symmetric' },
      {
        id: 'anchor_holes',
        name: 'Taladros de anclaje',
        type: 'hole',
        plane: { type: 'origin', base: 'XY', offset: 'base_T' },
        positions: [['-(base_L/2 - bolt_inset)', 0], ['base_L/2 - bolt_inset', 0]],
        diameter: 'bolt_d',
        throughAll: true,
        kind: 'counterbored',
        headDiameter: 'bolt_d * 1.6',
        headDepth: 'min(base_T*0.35, 5)',
      },
      { id: 'bore_chamfer', name: 'Chaflán agujero', type: 'chamfer', edges: { curve: 'circle', radius: 'bore_d/2' }, distance: 'min(1, bore_d*0.03)' },
    )
    return single(name, 'Soporte de rodamiento generado desde plantilla.', part('pillow_block', name, 'Aluminio 6082-T6', '#7fa7d9', sliderParams(this, v, ribs ? [] : ['rib_t']), features))
  },
}

const spacer: CadTemplate = {
  id: 'spacer',
  title: 'Casquillo / separador',
  category: 'Ejes y revolución',
  description: 'Cylindrical tube, bushing or spacer along Z with chamfered outer and inner edges.',
  keywords: ['casquillo', 'separador', 'distanciador', 'tubo', 'arandela', 'bushing', 'spacer', 'sleeve', 'washer'],
  params: [
    { name: 'od', label: 'Diámetro exterior', description: 'Outer diameter', kind: 'length', default: 20, min: 2, max: 600, step: 0.5 },
    { name: 'id', label: 'Diámetro interior', description: 'Inner diameter (< outer diameter)', kind: 'length', default: 10.5, min: 0.5, max: 590, step: 0.5 },
    { name: 'length', label: 'Longitud', description: 'Length along Z', kind: 'length', default: 25, min: 0.5, max: 2000, step: 0.5 },
    { name: 'chamfer', label: 'Chaflán', description: 'Edge chamfer (smaller than the wall)', kind: 'length', default: 0.5, min: 0.1, max: 10, step: 0.1 },
  ],
  build(v, name) {
    return single(
      name,
      'Casquillo generado desde plantilla.',
      part('spacer', name, 'Acero inoxidable 1.4301', '#b9c2cc', sliderParams(this, v), [
        { id: 'tube', name: 'Tubo', type: 'pad', sketch: { plane: { type: 'origin', base: 'XY' }, profiles: [{ type: 'circle', center: [0, 0], diameter: 'od' }, { type: 'circle', center: [0, 0], diameter: 'id' }] }, length: 'length' },
        { id: 'edges', name: 'Chaflanes', type: 'chamfer', edges: { curve: 'circle' }, distance: 'chamfer' },
      ]),
    )
  },
}

const standoff: CadTemplate = {
  id: 'hex_standoff',
  title: 'Separador hexagonal',
  category: 'Piezas',
  description: 'Hexagonal standoff along Z with tapped pilot holes at both ends (or a through hole).',
  keywords: ['separador hexagonal', 'columna hexagonal', 'standoff', 'hex', 'espárrago', 'distanciador'],
  params: [
    { name: 'af', label: 'Entrecaras', description: 'Across-flats size of the hexagon', kind: 'length', default: 8, min: 3, max: 100, step: 0.5 },
    { name: 'length', label: 'Longitud', description: 'Length along Z', kind: 'length', default: 20, min: 3, max: 500, step: 0.5 },
    { name: 'tap_d', label: 'Taladro de rosca', description: 'Tap drill diameter (e.g. 4.2 for M5)', kind: 'length', default: 4.2, min: 1, max: 60, step: 0.1 },
    { name: 'tap_depth', label: 'Profundidad roscada', description: 'Thread depth at each end', kind: 'length', default: 7, min: 1, max: 200, step: 0.5 },
    { name: 'through', label: 'Taladro pasante', description: 'Use a single through hole instead of two blind holes', kind: 'bool', default: false, structural: true },
  ],
  build(v, name) {
    const through = bool(v, 'through')
    const features: Feature[] = [
      { id: 'hex', name: 'Hexágono', type: 'pad', sketch: { plane: { type: 'origin', base: 'XY' }, profiles: [{ type: 'regularPolygon', center: [0, 0], sides: 6, diameter: 'af / cos(30)', angle: 30 }] }, length: 'length' },
    ]
    if (through) {
      features.push({ id: 'hole', name: 'Taladro pasante', type: 'hole', plane: { type: 'origin', base: 'XY', offset: 'length' }, positions: [[0, 0]], diameter: 'tap_d', throughAll: true })
    } else {
      features.push(
        { id: 'top_hole', name: 'Taladro superior', type: 'hole', plane: { type: 'origin', base: 'XY', offset: 'length' }, positions: [[0, 0]], diameter: 'tap_d', depth: 'min(tap_depth, length/2 - 0.5)' },
        { id: 'bottom_hole', name: 'Taladro inferior', type: 'hole', plane: { type: 'origin', base: 'XY' }, positions: [[0, 0]], diameter: 'tap_d', depth: 'min(tap_depth, length/2 - 0.5)', reverse: true },
      )
    }
    return single(name, 'Separador hexagonal generado desde plantilla.', part('standoff', name, 'Latón CW614N', '#d4b46a', sliderParams(this, v, through ? ['tap_depth'] : []), features))
  },
}

const plateColumns: CadTemplate = {
  id: 'plate_columns',
  title: 'Placas con columnas (ensamblaje)',
  category: 'Ensamblajes',
  description: 'Assembly: base plate and top plate joined by 4 cylindrical columns at the corners (inset), plates with holes at the column positions.',
  keywords: ['ensamblaje', 'assembly', 'mesa', 'columnas', 'placas', 'bastidor', 'estructura', 'pilares'],
  params: [
    { name: 'plate_L', label: 'Largo placas', description: 'Plate length along X', kind: 'length', default: 200, min: 60, max: 2000, step: 5 },
    { name: 'plate_W', label: 'Ancho placas', description: 'Plate width along Y', kind: 'length', default: 140, min: 60, max: 2000, step: 5 },
    { name: 'plate_t', label: 'Espesor placas', description: 'Plate thickness', kind: 'length', default: 10, min: 3, max: 60, step: 1 },
    { name: 'col_h', label: 'Altura columnas', description: 'Column height between plates', kind: 'length', default: 120, min: 10, max: 2000, step: 5 },
    { name: 'col_d', label: 'Diámetro columnas', description: 'Column diameter', kind: 'length', default: 20, min: 5, max: 200, step: 1 },
    { name: 'inset', label: 'Distancia al borde', description: 'Distance from plate edges to column axes', kind: 'length', default: 20, min: 8, max: 300, step: 1 },
    { name: 'hole_d', label: 'Taladro de fijación', description: 'Fixing hole diameter through the plates', kind: 'length', default: 8.5, min: 2, max: 60, step: 0.5 },
  ],
  build(v, name) {
    const holes: Feature = {
      id: 'col_holes',
      name: 'Taladros columnas',
      type: 'hole',
      plane: { type: 'origin', base: 'XY', offset: 'plate_t' },
      positions: [['-plate_L/2 + inset', '-plate_W/2 + inset']],
      repeat: { type: 'linear', count: 2, step: ['plate_L - 2*inset', 0], count2: 2, step2: [0, 'plate_W - 2*inset'] },
      diameter: 'hole_d',
      throughAll: true,
    }
    return {
      schemaVersion: 1,
      name,
      description: 'Ensamblaje de placas con columnas generado desde plantilla.',
      units: 'mm',
      kind: 'assembly',
      parameters: sliderParams(this, v),
      parts: [
        part('plate', 'Placa', 'Aluminio 5083', '#8fa3b8', [], [
          { id: 'plate_body', name: 'Placa', type: 'pad', sketch: { plane: { type: 'origin', base: 'XY' }, profiles: [{ type: 'rectangle', center: [0, 0], width: 'plate_L', height: 'plate_W', cornerRadius: 'min(6, inset/2)' }] }, length: 'plate_t' },
          holes,
        ]),
        part('column', 'Columna', 'Acero S235', '#d0a85c', [], [
          { id: 'col_body', name: 'Columna', type: 'pad', sketch: { plane: { type: 'origin', base: 'XY' }, profiles: [{ type: 'circle', center: [0, 0], diameter: 'col_d' }] }, length: 'col_h' },
          { id: 'col_chamfer', name: 'Chaflanes', type: 'chamfer', edges: { curve: 'circle', radius: 'col_d/2' }, distance: 'min(1, col_d*0.05)' },
        ]),
      ],
      instances: [
        { id: 'base', part: 'plate', name: 'Placa base', position: [0, 0, 0], fixed: true },
        { id: 'col_1', part: 'column', name: 'Columna 1', position: ['-plate_L/2 + inset', '-plate_W/2 + inset', 'plate_t'] },
        { id: 'col_2', part: 'column', name: 'Columna 2', position: ['plate_L/2 - inset', '-plate_W/2 + inset', 'plate_t'] },
        { id: 'col_3', part: 'column', name: 'Columna 3', position: ['plate_L/2 - inset', 'plate_W/2 - inset', 'plate_t'] },
        { id: 'col_4', part: 'column', name: 'Columna 4', position: ['-plate_L/2 + inset', 'plate_W/2 - inset', 'plate_t'] },
        { id: 'top', part: 'plate', name: 'Placa superior', position: [0, 0, 'plate_t + col_h'] },
      ],
    }
  },
}

export const TEMPLATES: ReadonlyArray<CadTemplate> = [flange, plate, lBracket, steppedShaft, enclosure, pillowBlock, spacer, standoff, plateColumns]
