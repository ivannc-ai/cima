/** Template lookup, instantiation (with value coercion) and the compact catalog shown to the LLM. */
import type { CadModel } from '../model/schema'
import { TEMPLATES } from './catalog'
import type { CadTemplate, TemplateParam, TemplateValue } from './types'

export { TEMPLATES }
export type { CadTemplate, TemplateParam, TemplateValue }

/** Name of the LLM tool that instantiates a template. */
export const TEMPLATE_TOOL_NAME = 'use_cad_template'

export function findTemplate(id: string): CadTemplate | undefined {
  const k = id.trim().toLowerCase()
  return TEMPLATES.find((t) => t.id === k)
}

export interface TemplateInstance {
  model?: CadModel
  /** Values actually used (after defaults, coercion and clamping). */
  values: Record<string, TemplateValue>
  /** Adjustments made (clamped values, unknown names...). Shown to the user and the LLM. */
  warnings: string[]
  /** Fatal problems (unknown template...). */
  errors: string[]
}

type RawParams = ReadonlyArray<{ name: string; value: unknown }> | Readonly<Record<string, unknown>> | undefined

function toEntries(raw: RawParams): Array<[string, unknown]> {
  if (!raw) return []
  if (Array.isArray(raw)) return raw.filter((e) => e && typeof e.name === 'string').map((e) => [e.name, e.value])
  return Object.entries(raw as Record<string, unknown>)
}

function coerce(p: TemplateParam, raw: unknown, warnings: string[]): TemplateValue {
  if (p.kind === 'bool') {
    if (typeof raw === 'boolean') return raw
    const s = String(raw).trim().toLowerCase()
    if (['true', '1', 'yes', 'si', 'sí', 'on'].includes(s)) return true
    if (['false', '0', 'no', 'off'].includes(s)) return false
    warnings.push(`${p.name}: "${String(raw)}" is not a boolean, default ${String(p.default)} used`)
    return p.default
  }
  if (p.kind === 'enum') {
    const s = String(raw).trim()
    if (p.options?.includes(s)) return s
    warnings.push(`${p.name}: "${s}" is not one of ${p.options?.join(', ')}, default "${String(p.default)}" used`)
    return p.default
  }
  let n = typeof raw === 'number' ? raw : Number(String(raw).replace(',', '.').replace(/[^\d.eE+-]/g, ''))
  if (!Number.isFinite(n)) {
    warnings.push(`${p.name}: "${String(raw)}" is not a number, default ${String(p.default)} used`)
    return p.default
  }
  if (p.kind === 'count' && !Number.isInteger(n)) {
    warnings.push(`${p.name}: rounded ${n} to ${Math.round(n)}`)
    n = Math.round(n)
  }
  if (p.min !== undefined && n < p.min) {
    warnings.push(`${p.name}: ${n} is below the minimum, ${p.min} used`)
    n = p.min
  }
  if (p.max !== undefined && n > p.max) {
    warnings.push(`${p.name}: ${n} is above the maximum, ${p.max} used`)
    n = p.max
  }
  return n
}

/** Instantiates a template. Missing values take defaults; out-of-range values are clamped (with a warning). */
export function instantiateTemplate(id: string, raw: RawParams, name?: string): TemplateInstance {
  const t = findTemplate(id)
  const warnings: string[] = []
  if (!t) {
    return { values: {}, warnings, errors: [`unknown template "${id}". Available: ${TEMPLATES.map((x) => x.id).join(', ')}`] }
  }
  const given = new Map(toEntries(raw).map(([k, v]) => [k.trim(), v]))
  const values: Record<string, TemplateValue> = {}
  for (const p of t.params) {
    values[p.name] = given.has(p.name) ? coerce(p, given.get(p.name), warnings) : p.default
    given.delete(p.name)
  }
  for (const k of given.keys()) warnings.push(`unknown parameter "${k}" ignored (template ${t.id})`)
  const modelName = (name ?? '').trim() || t.title.replace(/[^\p{L}\p{N}]+/gu, '_')
  try {
    return { model: t.build(values, modelName), values, warnings, errors: [] }
  } catch (e) {
    return { values, warnings, errors: [`template ${t.id} failed: ${(e as Error).message}`] }
  }
}

/** Compact template catalog for the system prompt (English, one block per template). */
export function templateCatalogText(): string {
  return TEMPLATES.map((t) => {
    const ps = t.params
      .map((p) => {
        const range = p.kind === 'enum' ? ` one of ${p.options?.join('|')}` : p.kind === 'bool' ? ' true|false' : p.min !== undefined ? ` ${p.min}..${p.max}` : ''
        const unit = p.kind === 'length' ? ' mm' : p.kind === 'angle' ? ' deg' : ''
        return `  - ${p.name} (${p.kind}${range}${unit}, default ${String(p.default)}): ${p.description}`
      })
      .join('\n')
    return `* ${t.id}: ${t.description}\n${ps}`
  }).join('\n')
}
