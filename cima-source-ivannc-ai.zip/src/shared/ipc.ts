/**
 * Typed bridge between the renderer and the main process, exposed as `window.cima` by the preload
 * script. Every method maps 1:1 to an ipcMain.handle channel listed in IPC_CHANNELS.
 */
import type { ChatRequest, ChatStreamEvent } from './ai/types'
import type {
  CatiaInspection,
  CatiaJobEvent,
  CatiaJobResult,
  CatiaPushRequest,
  CatiaScriptRequest,
  CatiaSetParametersRequest,
  CatiaStartModel,
  CatiaStatus,
} from './catia/types'
import type { CimaProject } from './project'
import type { AppSettings, SettingsPatch } from './settings'

export interface AppInfo {
  name: string
  version: string
  platform: NodeJS.Platform | string
  isPackaged: boolean
  electron: string
  userDataPath: string
}

export interface FileFilter {
  name: string
  extensions: string[]
}

export interface SaveResult {
  ok: boolean
  path?: string
  canceled?: boolean
  error?: string
}

export interface ProviderTestResult {
  ok: boolean
  message: string
  latencyMs?: number
}

export interface StartModelCatalogView {
  models: CatiaStartModel[]
  /** Automatic discovery: DLNames file of the program and its MMaterial folder (when readable). */
  dlNamesFile?: string
  mmaterialDir?: string
  /** Reason when there are no models (no MODLOCAL/DLNames, share without access...). No fallback. */
  error?: string
}

export interface CimaApi {
  app: {
    info(): Promise<AppInfo>
    openExternal(url: string): Promise<void>
    /** Shows a file in the OS file explorer. */
    showItemInFolder(path: string): Promise<void>
    /** Opens the logs folder (<userData>/logs). */
    openLogsFolder(): Promise<void>
    /** Fire-and-forget sink for renderer errors (written to the daily log file). */
    clientLog(level: 'info' | 'warn' | 'error', scope: string, message: string): Promise<void>
  }
  settings: {
    get(): Promise<AppSettings>
    update(patch: SettingsPatch): Promise<AppSettings>
    /** Stores (encrypted) or removes (null) the API key of a provider. */
    setApiKey(providerId: string, apiKey: string | null): Promise<AppSettings>
    /** Lets the user pick a folder (e.g. CATIA save directory). */
    chooseDirectory(title?: string): Promise<string | null>
  }
  ai: {
    /** Starts a streamed chat turn. Resolves when the stream has finished (events arrive via onEvent). */
    chat(request: ChatRequest): Promise<void>
    cancel(requestId: string): Promise<void>
    onEvent(listener: (event: ChatStreamEvent) => void): () => void
    testProvider(providerId: string): Promise<ProviderTestResult>
  }
  catia: {
    status(): Promise<CatiaStatus>
    /** Generates the script for the request without running it (for preview). */
    generateScript(request: CatiaScriptRequest): Promise<string>
    /** Generates and runs the script with cscript.exe; progress arrives via onEvent. */
    push(request: CatiaPushRequest): Promise<CatiaJobResult>
    cancel(jobId: string): Promise<void>
    onEvent(listener: (event: CatiaJobEvent) => void): () => void
    /** Saves the macro (.catvbs or .vbs according to request.options.flavor). */
    exportMacro(request: CatiaScriptRequest, suggestedName: string): Promise<SaveResult>
    /** Reads name, type and parameters of the active CATIA document. */
    inspect(): Promise<CatiaInspection>
    /** Sets parameters of the active CATIA document by name and updates it. */
    setParameters(request: CatiaSetParametersRequest): Promise<CatiaJobResult>
    /** Start models (Documents.NewFrom) discovered from the program's MODLOCAL DLNames (MMaterial). No fallback. */
    listStartModels(program?: string | null, release?: string | number | null): Promise<StartModelCatalogView>
  }
  files: {
    openProject(): Promise<{ path: string; project: CimaProject } | null>
    saveProject(project: CimaProject, options?: { path?: string; saveAs?: boolean }): Promise<SaveResult>
    /** Generic "save as" for exports. `data` is text or binary. */
    saveFile(request: {
      title?: string
      defaultName: string
      filters: FileFilter[]
      data: string | Uint8Array
    }): Promise<SaveResult>
  }
}

export const IPC_CHANNELS = {
  appInfo: 'cima:app:info',
  appOpenExternal: 'cima:app:openExternal',
  appShowItemInFolder: 'cima:app:showItemInFolder',
  appOpenLogsFolder: 'cima:app:openLogsFolder',
  appClientLog: 'cima:app:clientLog',
  settingsGet: 'cima:settings:get',
  settingsUpdate: 'cima:settings:update',
  settingsSetApiKey: 'cima:settings:setApiKey',
  settingsChooseDirectory: 'cima:settings:chooseDirectory',
  aiChat: 'cima:ai:chat',
  aiCancel: 'cima:ai:cancel',
  aiEvent: 'cima:ai:event',
  aiTestProvider: 'cima:ai:testProvider',
  catiaStatus: 'cima:catia:status',
  catiaGenerateScript: 'cima:catia:generateScript',
  catiaPush: 'cima:catia:push',
  catiaCancel: 'cima:catia:cancel',
  catiaEvent: 'cima:catia:event',
  catiaExportMacro: 'cima:catia:exportMacro',
  catiaInspect: 'cima:catia:inspect',
  catiaSetParameters: 'cima:catia:setParameters',
  catiaListStartModels: 'cima:catia:listStartModels',
  filesOpenProject: 'cima:files:openProject',
  filesSaveProject: 'cima:files:saveProject',
  filesSaveFile: 'cima:files:saveFile',
} as const

declare global {
  interface Window {
    cima: CimaApi
  }
}
