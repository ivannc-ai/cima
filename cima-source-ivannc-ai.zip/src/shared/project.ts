/** .cima project file format. */
import type { ChatMessage } from './ai/types'
import type { ParamOverrides } from './model/evaluate'
import type { CadModel } from './model/schema'

export const PROJECT_FORMAT = 'cima-project' as const
export const PROJECT_VERSION = 1 as const
export const PROJECT_EXTENSION = 'cima'

export interface ModelVersion {
  id: string
  createdAt: string
  source: 'ai' | 'user' | 'example' | 'import'
  /** Prompt that produced this version (AI versions). */
  prompt?: string
  model: CadModel
}

export interface CimaProject {
  format: typeof PROJECT_FORMAT
  version: typeof PROJECT_VERSION
  name: string
  createdAt: string
  updatedAt: string
  /** Current model (null for an empty project). */
  model: CadModel | null
  /** Slider values that differ from the model defaults. */
  overrides: ParamOverrides
  /** Every model version produced in this project, oldest first. */
  history: ModelVersion[]
  /** Conversation with the AI provider. */
  chat: ChatMessage[]
}

export function isCimaProject(x: unknown): x is CimaProject {
  return (
    !!x &&
    typeof x === 'object' &&
    (x as { format?: unknown }).format === PROJECT_FORMAT &&
    (x as { version?: unknown }).version === PROJECT_VERSION
  )
}
