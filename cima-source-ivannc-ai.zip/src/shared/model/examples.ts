/**
 * Reference models. Used for: demo mode (no API key), unit tests of every backend, and few-shot
 * examples in the LLM system prompt. Every example must validate without errors.
 */
import type { CadModel } from './schema'

export const EXAMPLE_FLANGE: CadModel = {
  schemaVersion: 1,
  name: 'Brida_DN50',
  description: 'Brida circular con agujero central, 6 taladros en círculo y bordes redondeados.',
  units: 'mm',
  kind: 'part',
  parameters: [],
  parts: [
    {
      id: 'flange',
      name: 'Brida_DN50',
      material: 'Acero S275',
      color: '#8fa3b8',
      parameters: [
        { name: 'outer_d', value: 160, unit: 'mm', min: 80, max: 300, step: 1, description: 'Diámetro exterior' },
        { name: 'thickness', value: 16, unit: 'mm', min: 6, max: 40, step: 0.5, description: 'Espesor' },
        { name: 'bore_d', value: 60, unit: 'mm', min: 10, max: 150, step: 1, description: 'Diámetro del agujero central' },
        { name: 'bolt_count', value: 6, unit: 'none', min: 3, max: 16, step: 1, description: 'Número de taladros' },
        { name: 'bolt_d', value: 13.5, unit: 'mm', min: 4, max: 30, step: 0.5, description: 'Diámetro de taladro' },
        { name: 'pcd', value: 0, unit: 'mm', description: 'Diámetro del círculo de taladros', expression: '(outer_d + bore_d) / 2' },
        { name: 'edge_r', value: 2, unit: 'mm', min: 0.5, max: 5, step: 0.5, description: 'Radio de redondeo' },
      ],
      features: [
        {
          id: 'disc',
          name: 'Disco',
          type: 'pad',
          sketch: {
            plane: { type: 'origin', base: 'XY' },
            profiles: [
              { type: 'circle', center: [0, 0], diameter: 'outer_d' },
              { type: 'circle', center: [0, 0], diameter: 'bore_d' },
            ],
          },
          length: 'thickness',
        },
        {
          id: 'bolt_holes',
          name: 'Taladros',
          type: 'hole',
          plane: { type: 'origin', base: 'XY', offset: 'thickness' },
          positions: [['pcd/2', 0]],
          repeat: { type: 'circular', count: 'bolt_count', center: [0, 0] },
          diameter: 'bolt_d',
          throughAll: true,
        },
        {
          id: 'outer_round',
          name: 'Redondeo exterior',
          type: 'fillet',
          edges: { curve: 'circle', radius: 'outer_d/2' },
          radius: 'edge_r',
        },
      ],
    },
  ],
}

export const EXAMPLE_BRACKET: CadModel = {
  schemaVersion: 1,
  name: 'Escuadra_L',
  description: 'Escuadra en L con dos taladros avellanados en la base y uno pasante en el ala.',
  units: 'mm',
  kind: 'part',
  parameters: [],
  parts: [
    {
      id: 'bracket',
      name: 'Escuadra_L',
      material: 'Aluminio 6061-T6',
      color: '#c0c6cc',
      parameters: [
        { name: 'length', value: 80, unit: 'mm', min: 40, max: 200, step: 1, description: 'Longitud de la base (X)' },
        { name: 'height', value: 60, unit: 'mm', min: 30, max: 150, step: 1, description: 'Altura del ala (Z)' },
        { name: 'width', value: 40, unit: 'mm', min: 20, max: 120, step: 1, description: 'Anchura (Y)' },
        { name: 't', value: 6, unit: 'mm', min: 3, max: 15, step: 0.5, description: 'Espesor de chapa' },
        { name: 'hole_d', value: 6.6, unit: 'mm', min: 3, max: 12, step: 0.1, description: 'Diámetro de taladro' },
        { name: 'inner_r', value: 4, unit: 'mm', min: 1, max: 10, step: 0.5, description: 'Radio interior del pliegue' },
      ],
      features: [
        {
          id: 'profile_L',
          name: 'Perfil L',
          type: 'pad',
          // Sketch on ZX (u = Z, v = X), extruded along +Y.
          sketch: {
            plane: { type: 'origin', base: 'ZX' },
            profiles: [
              {
                type: 'polygon',
                points: [
                  [0, 0],
                  [0, 'length'],
                  ['t', 'length'],
                  ['t', 't'],
                  ['height', 't'],
                  ['height', 0],
                ],
              },
            ],
          },
          length: 'width',
        },
        {
          id: 'inner_fillet',
          name: 'Redondeo interior',
          type: 'fillet',
          edges: { direction: 'Y', inBox: { min: ['t - 0.01', -1, 't - 0.01'], max: ['t + 0.01', 'width + 1', 't + 0.01'] } },
          radius: 'inner_r',
        },
        {
          id: 'base_holes',
          name: 'Taladros base',
          type: 'hole',
          plane: { type: 'origin', base: 'XY', offset: 't' },
          positions: [
            ['length - 15', 'width/2 - 10'],
            ['length - 15', 'width/2 + 10'],
          ],
          diameter: 'hole_d',
          throughAll: true,
          kind: 'countersunk',
          headDiameter: 'hole_d * 2',
          headAngle: 90,
        },
        {
          id: 'wall_hole',
          name: 'Taladro ala',
          type: 'hole',
          plane: { type: 'origin', base: 'YZ' },
          positions: [['width/2', 'height - 15']],
          diameter: 'hole_d',
          throughAll: true,
          reverse: true,
        },
      ],
    },
  ],
}

export const EXAMPLE_SHAFT: CadModel = {
  schemaVersion: 1,
  name: 'Eje_escalonado',
  description: 'Eje escalonado por revolución alrededor de Z con ranura para anillo elástico y chaflanes.',
  units: 'mm',
  kind: 'part',
  parameters: [],
  parts: [
    {
      id: 'shaft',
      name: 'Eje_escalonado',
      material: 'Acero C45',
      color: '#9aa0a6',
      parameters: [
        { name: 'd1', value: 20, unit: 'mm', min: 8, max: 60, step: 0.5, description: 'Diámetro tramo 1' },
        { name: 'l1', value: 40, unit: 'mm', min: 10, max: 150, step: 1, description: 'Longitud tramo 1' },
        { name: 'd2', value: 30, unit: 'mm', min: 10, max: 80, step: 0.5, description: 'Diámetro tramo 2' },
        { name: 'l2', value: 60, unit: 'mm', min: 10, max: 200, step: 1, description: 'Longitud tramo 2' },
        { name: 'groove_w', value: 1.6, unit: 'mm', min: 0.5, max: 5, step: 0.1, description: 'Ancho de ranura' },
        { name: 'groove_depth', value: 1, unit: 'mm', min: 0.3, max: 3, step: 0.1, description: 'Profundidad de ranura' },
        { name: 'chamfer', value: 1, unit: 'mm', min: 0.2, max: 3, step: 0.1, description: 'Chaflán de extremos' },
      ],
      features: [
        {
          id: 'body',
          name: 'Cuerpo',
          type: 'shaft',
          // ZX plane: u = Z (axis of the shaft), v = X (radius).
          sketch: {
            plane: { type: 'origin', base: 'ZX' },
            profiles: [
              {
                type: 'polygon',
                points: [
                  [0, 0],
                  [0, 'd1/2'],
                  ['l1', 'd1/2'],
                  ['l1', 'd2/2'],
                  ['l1 + l2', 'd2/2'],
                  ['l1 + l2', 0],
                ],
              },
            ],
          },
          axis: 'u',
        },
        {
          id: 'retaining_groove',
          name: 'Ranura anillo',
          type: 'groove',
          sketch: {
            plane: { type: 'origin', base: 'ZX' },
            profiles: [
              {
                type: 'rectangle',
                center: ['l1 + l2 - 10', 'd2/2 - groove_depth/2 + 0.5'],
                width: 'groove_w',
                height: 'groove_depth + 1',
              },
            ],
          },
          axis: 'u',
        },
        {
          id: 'end_chamfers',
          name: 'Chaflanes',
          type: 'chamfer',
          edges: { curve: 'circle', inBox: { min: ['-d2', '-d2', -0.01], max: ['d2', 'd2', 0.01] } },
          distance: 'chamfer',
        },
        {
          id: 'end_chamfers_2',
          name: 'Chaflanes extremo 2',
          type: 'chamfer',
          edges: { curve: 'circle', onPlane: { axis: 'Z', at: 'l1 + l2' } },
          distance: 'chamfer',
        },
      ],
    },
  ],
}

export const EXAMPLE_BOX: CadModel = {
  schemaVersion: 1,
  name: 'Caja_vaciada',
  description: 'Caja rectangular con esquinas redondeadas, vaciada con la cara superior abierta.',
  units: 'mm',
  kind: 'part',
  parameters: [],
  parts: [
    {
      id: 'box',
      name: 'Caja_vaciada',
      material: 'ABS',
      color: '#5b8def',
      parameters: [
        { name: 'L', value: 120, unit: 'mm', min: 40, max: 300, step: 1, description: 'Largo' },
        { name: 'W', value: 80, unit: 'mm', min: 30, max: 200, step: 1, description: 'Ancho' },
        { name: 'H', value: 40, unit: 'mm', min: 10, max: 150, step: 1, description: 'Alto' },
        { name: 'wall', value: 2.5, unit: 'mm', min: 1, max: 8, step: 0.1, description: 'Espesor de pared' },
        { name: 'corner_r', value: 8, unit: 'mm', min: 3, max: 20, step: 0.5, description: 'Radio de esquina' },
      ],
      features: [
        {
          id: 'block',
          name: 'Bloque',
          type: 'pad',
          sketch: {
            plane: { type: 'origin', base: 'XY' },
            profiles: [{ type: 'rectangle', center: [0, 0], width: 'L', height: 'W', cornerRadius: 'corner_r' }],
          },
          length: 'H',
        },
        {
          id: 'bottom_round',
          name: 'Redondeo inferior',
          type: 'fillet',
          edges: { onPlane: { axis: 'Z', at: 0 } },
          radius: 3,
        },
        {
          id: 'hollow',
          name: 'Vaciado',
          type: 'shell',
          thickness: 'wall',
          openFaces: { normal: '+Z', onPlane: { axis: 'Z', at: 'H' } },
        },
      ],
    },
  ],
}

export const EXAMPLE_ASSEMBLY: CadModel = {
  schemaVersion: 1,
  name: 'Mesa_columnas',
  description: 'Placa base con cuatro columnas cilíndricas y placa superior.',
  units: 'mm',
  kind: 'assembly',
  parameters: [
    { name: 'plate_L', value: 200, unit: 'mm', min: 100, max: 400, step: 5, description: 'Largo de placas' },
    { name: 'plate_W', value: 140, unit: 'mm', min: 80, max: 300, step: 5, description: 'Ancho de placas' },
    { name: 'plate_t', value: 10, unit: 'mm', min: 5, max: 25, step: 1, description: 'Espesor de placas' },
    { name: 'col_h', value: 120, unit: 'mm', min: 40, max: 300, step: 5, description: 'Altura de columnas' },
    { name: 'col_d', value: 20, unit: 'mm', min: 10, max: 40, step: 1, description: 'Diámetro de columnas' },
    { name: 'inset', value: 20, unit: 'mm', min: 10, max: 50, step: 1, description: 'Distancia de columnas al borde' },
  ],
  parts: [
    {
      id: 'plate',
      name: 'Placa',
      color: '#8fa3b8',
      parameters: [],
      features: [
        {
          id: 'plate_body',
          type: 'pad',
          sketch: {
            plane: { type: 'origin', base: 'XY' },
            profiles: [{ type: 'rectangle', center: [0, 0], width: 'plate_L', height: 'plate_W', cornerRadius: 6 }],
          },
          length: 'plate_t',
        },
        {
          id: 'col_holes',
          type: 'hole',
          plane: { type: 'origin', base: 'XY', offset: 'plate_t' },
          positions: [['-plate_L/2 + inset', '-plate_W/2 + inset']],
          repeat: { type: 'linear', count: 2, step: ['plate_L - 2*inset', 0], count2: 2, step2: [0, 'plate_W - 2*inset'] },
          diameter: 8.5,
          throughAll: true,
        },
      ],
    },
    {
      id: 'column',
      name: 'Columna',
      color: '#d0a85c',
      parameters: [],
      features: [
        {
          id: 'col_body',
          type: 'pad',
          sketch: {
            plane: { type: 'origin', base: 'XY' },
            profiles: [{ type: 'circle', center: [0, 0], diameter: 'col_d' }],
          },
          length: 'col_h',
        },
        {
          id: 'col_chamfer',
          type: 'chamfer',
          edges: { curve: 'circle' },
          distance: 1,
        },
      ],
    },
  ],
  instances: [
    { id: 'base', part: 'plate', name: 'Placa base', position: [0, 0, 0], fixed: true },
    { id: 'col_1', part: 'column', position: ['-plate_L/2 + inset', '-plate_W/2 + inset', 'plate_t'] },
    { id: 'col_2', part: 'column', position: ['plate_L/2 - inset', '-plate_W/2 + inset', 'plate_t'] },
    { id: 'col_3', part: 'column', position: ['plate_L/2 - inset', 'plate_W/2 - inset', 'plate_t'] },
    { id: 'col_4', part: 'column', position: ['-plate_L/2 + inset', 'plate_W/2 - inset', 'plate_t'] },
    { id: 'top', part: 'plate', name: 'Placa superior', position: [0, 0, 'plate_t + col_h'] },
  ],
}

export const EXAMPLES: ReadonlyArray<{ id: string; title: string; prompt: string; model: CadModel }> = [
  { id: 'flange', title: 'Brida con taladros', prompt: 'Brida DN50 de 160 mm con 6 taladros de 13.5 mm en círculo', model: EXAMPLE_FLANGE },
  { id: 'bracket', title: 'Escuadra en L', prompt: 'Escuadra en L de aluminio con taladros avellanados', model: EXAMPLE_BRACKET },
  { id: 'shaft', title: 'Eje escalonado', prompt: 'Eje escalonado Ø20/Ø30 con ranura para anillo elástico', model: EXAMPLE_SHAFT },
  { id: 'box', title: 'Caja vaciada', prompt: 'Caja de 120x80x40 vaciada con pared de 2.5 mm', model: EXAMPLE_BOX },
  { id: 'assembly', title: 'Mesa con columnas', prompt: 'Ensamblaje de dos placas unidas por cuatro columnas', model: EXAMPLE_ASSEMBLY },
]
