/**
 * Parameter resolution and expression evaluation contexts.
 *
 * Scopes: model-level parameters are visible everywhere; part-level parameters are visible inside their
 * part only (they may reference model-level ones). Overrides (from UI sliders) are keyed by
 * "name" for model-level parameters and "partId.name" for part-level parameters.
 */
import type { CadModel, Expr, Parameter, Part } from './schema'
import { ExprError, evaluateExpr } from './expr'

export type ParamUnit = Parameter['unit']
export type ParamOverrides = Readonly<Record<string, number>>

export interface ResolvedParameter {
  /** Override key: "name" (model-level) or "partId.name" (part-level). */
  key: string
  name: string
  scope: 'model' | 'part'
  partId?: string
  value: number
  unit: ParamUnit
  derived: boolean
  def: Parameter
}

export function paramKey(name: string, partId?: string): string {
  return partId ? `${partId}.${name}` : name
}

/** Evaluation context: resolves expressions against a fixed set of parameter values. */
export class EvalContext {
  constructor(
    private readonly values: ReadonlyMap<string, number>,
    private readonly units: ReadonlyMap<string, ParamUnit>,
  ) {}

  has(name: string): boolean {
    return this.values.has(name)
  }
  get(name: string): number | undefined {
    return this.values.get(name)
  }
  unitOf(name: string): ParamUnit | undefined {
    return this.units.get(name)
  }
  names(): string[] {
    return [...this.values.keys()]
  }

  /** Evaluates an expression; `what` is a human-readable location used in error messages. */
  n(expr: Expr, what = 'value'): number {
    try {
      return evaluateExpr(expr, (name) => this.values.get(name))
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e)
      throw new ExprError(`${what}: ${msg} (expression ${JSON.stringify(expr)})`)
    }
  }

  /** Like n() but returns undefined for undefined input. */
  opt(expr: Expr | undefined, what = 'value'): number | undefined {
    return expr === undefined ? undefined : this.n(expr, what)
  }

  /** Strictly positive number. */
  pos(expr: Expr, what = 'value'): number {
    const v = this.n(expr, what)
    if (!(v > 0)) throw new ExprError(`${what} must be > 0 (got ${v})`)
    return v
  }

  /** Integer >= min (values within 1e-6 of an integer are accepted and rounded). */
  int(expr: Expr, what = 'count', min = 1): number {
    const v = this.n(expr, what)
    const r = Math.round(v)
    if (Math.abs(v - r) > 1e-6) throw new ExprError(`${what} must be an integer (got ${v})`)
    if (r < min) throw new ExprError(`${what} must be >= ${min} (got ${r})`)
    return r
  }

  vec2(v: ReadonlyArray<Expr>, what = 'point'): [number, number] {
    if (v.length !== 2) throw new ExprError(`${what} must have 2 components`)
    return [this.n(v[0]!, `${what}[0]`), this.n(v[1]!, `${what}[1]`)]
  }

  vec3(v: ReadonlyArray<Expr>, what = 'point'): [number, number, number] {
    if (v.length !== 3) throw new ExprError(`${what} must have 3 components`)
    return [this.n(v[0]!, `${what}[0]`), this.n(v[1]!, `${what}[1]`), this.n(v[2]!, `${what}[2]`)]
  }
}

interface ScopeResolution {
  values: Map<string, number>
  errors: string[]
}

function resolveScope(
  defs: ReadonlyArray<Parameter>,
  parent: (name: string) => number | undefined,
  override: (name: string) => number | undefined,
  label: string,
): ScopeResolution {
  const byName = new Map(defs.map((p) => [p.name, p] as const))
  const values = new Map<string, number>()
  const state = new Map<string, 'visiting' | 'done'>()
  const errors: string[] = []

  const lookup = (name: string): number | undefined => {
    if (byName.has(name)) {
      resolve(name)
      return values.get(name)
    }
    return parent(name)
  }

  const resolve = (name: string): void => {
    const st = state.get(name)
    if (st === 'done') return
    if (st === 'visiting') throw new ExprError(`circular dependency involving parameter "${name}"`)
    state.set(name, 'visiting')
    const p = byName.get(name)!
    let v: number
    if (p.expression !== undefined && p.expression.trim() !== '') {
      v = evaluateExpr(p.expression, lookup)
    } else {
      const o = override(name)
      v = o !== undefined && Number.isFinite(o) ? o : p.value
    }
    values.set(name, v)
    state.set(name, 'done')
  }

  for (const p of defs) {
    if (state.get(p.name) === 'done') continue
    try {
      resolve(p.name)
    } catch (e) {
      errors.push(`${label} parameter "${p.name}": ${e instanceof Error ? e.message : String(e)}`)
      // Unblock every parameter left half-resolved by the failure: fall back to stored defaults.
      for (const [n, s] of state) {
        if (s === 'visiting') {
          values.set(n, byName.get(n)!.value)
          state.set(n, 'done')
        }
      }
    }
  }
  return { values, errors }
}

export interface ModelParameterResolution {
  /** Model-level values. */
  modelValues: Map<string, number>
  /** Per part: merged values (model + part). */
  partValues: Map<string, Map<string, number>>
  params: ResolvedParameter[]
  errors: string[]
}

/** Resolves every parameter of the model (defaults + overrides, derived expressions, cycles). */
export function resolveModelParameters(model: CadModel, overrides: ParamOverrides = {}): ModelParameterResolution {
  const params: ResolvedParameter[] = []
  const errors: string[] = []

  const modelRes = resolveScope(
    model.parameters,
    () => undefined,
    (name) => overrides[paramKey(name)],
    'Model',
  )
  errors.push(...modelRes.errors)
  for (const p of model.parameters) {
    params.push({
      key: paramKey(p.name),
      name: p.name,
      scope: 'model',
      value: modelRes.values.get(p.name) ?? p.value,
      unit: p.unit,
      derived: !!p.expression,
      def: p,
    })
  }

  const partValues = new Map<string, Map<string, number>>()
  for (const part of model.parts) {
    const res = resolveScope(
      part.parameters,
      (name) => modelRes.values.get(name),
      (name) => overrides[paramKey(name, part.id)],
      `Part "${part.id}"`,
    )
    errors.push(...res.errors)
    const merged = new Map(modelRes.values)
    for (const [k, v] of res.values) merged.set(k, v)
    partValues.set(part.id, merged)
    for (const p of part.parameters) {
      params.push({
        key: paramKey(p.name, part.id),
        name: p.name,
        scope: 'part',
        partId: part.id,
        value: res.values.get(p.name) ?? p.value,
        unit: p.unit,
        derived: !!p.expression,
        def: p,
      })
    }
  }

  return { modelValues: modelRes.values, partValues, params, errors }
}

function unitsFor(model: CadModel, part?: Part): Map<string, ParamUnit> {
  const units = new Map<string, ParamUnit>()
  for (const p of model.parameters) units.set(p.name, p.unit)
  if (part) for (const p of part.parameters) units.set(p.name, p.unit)
  return units
}

/** Context for expressions inside a part. */
export function partContext(model: CadModel, partId: string, resolution: ModelParameterResolution): EvalContext {
  const part = model.parts.find((p) => p.id === partId)
  if (!part) throw new Error(`Unknown part "${partId}"`)
  return new EvalContext(resolution.partValues.get(partId) ?? new Map(), unitsFor(model, part))
}

/** Context for model-level expressions (instance placements). */
export function modelContext(model: CadModel, resolution: ModelParameterResolution): EvalContext {
  return new EvalContext(resolution.modelValues, unitsFor(model))
}

/** Returns a copy of the model where non-derived parameter defaults are replaced by the given overrides. */
export function applyOverridesAsDefaults(model: CadModel, overrides: ParamOverrides): CadModel {
  const copy = structuredClone(model) as CadModel
  for (const p of copy.parameters) {
    const o = overrides[paramKey(p.name)]
    if (o !== undefined && !p.expression) p.value = o
  }
  for (const part of copy.parts) {
    for (const p of part.parameters) {
      const o = overrides[paramKey(p.name, part.id)]
      if (o !== undefined && !p.expression) p.value = o
    }
  }
  return copy
}
