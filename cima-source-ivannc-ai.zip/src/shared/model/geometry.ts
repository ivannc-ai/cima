/**
 * Backend-independent geometry resolution shared by the preview kernel and the CATIA translators.
 *
 * Every high-level profile (rectangle, slot, polygon, path...) is reduced here to explicit loops of
 * lines and arcs with numeric coordinates, so that all backends draw exactly the same geometry.
 */
import type { EvalContext } from './evaluate'
import type {
  EdgeSelector,
  FaceSelector,
  Instance,
  Plane,
  Profile,
  ProfileRepeat,
  Sketch,
  Vec2,
} from './schema'
import { ExprError } from './expr'

export type V2 = [number, number]
export type V3 = [number, number, number]

export const EPS = 1e-9
/** Default geometric tolerance (mm) used when matching edges / faces. */
export const MATCH_TOL = 1e-3

// ---------------------------------------------------------------------------
// Vector helpers
// ---------------------------------------------------------------------------

export const v3 = {
  add: (a: V3, b: V3): V3 => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
  sub: (a: V3, b: V3): V3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
  scale: (a: V3, s: number): V3 => [a[0] * s, a[1] * s, a[2] * s],
  dot: (a: V3, b: V3): number => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
  cross: (a: V3, b: V3): V3 => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
  len: (a: V3): number => Math.hypot(a[0], a[1], a[2]),
  norm: (a: V3): V3 => {
    const l = Math.hypot(a[0], a[1], a[2])
    if (l < EPS) throw new ExprError('zero-length direction vector')
    return [a[0] / l, a[1] / l, a[2] / l]
  },
}

export const AXIS_VECTORS: Record<'X' | 'Y' | 'Z', V3> = { X: [1, 0, 0], Y: [0, 1, 0], Z: [0, 0, 1] }
export const AXIS_INDEX: Record<'X' | 'Y' | 'Z', 0 | 1 | 2> = { X: 0, Y: 1, Z: 2 }

// ---------------------------------------------------------------------------
// Planes / frames
// ---------------------------------------------------------------------------

/** Orthonormal sketch frame: world = origin + u * a + v * b; n = u x v. */
export interface Frame {
  origin: V3
  u: V3
  v: V3
  n: V3
}

export const ORIGIN_FRAMES: Record<'XY' | 'YZ' | 'ZX', { u: V3; v: V3; n: V3 }> = {
  XY: { u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1] },
  YZ: { u: [0, 1, 0], v: [0, 0, 1], n: [1, 0, 0] },
  ZX: { u: [0, 0, 1], v: [1, 0, 0], n: [0, 1, 0] },
}

export function planeFrame(plane: Plane, ctx: EvalContext, what = 'plane'): Frame {
  if (plane.type === 'origin') {
    const f = ORIGIN_FRAMES[plane.base]
    const off = plane.offset === undefined ? 0 : ctx.n(plane.offset, `${what}.offset`)
    return { origin: v3.scale(f.n, off), u: f.u, v: f.v, n: f.n }
  }
  const n = v3.norm(plane.normal as V3)
  const uRaw = plane.uDir as V3
  const uOrtho = v3.sub(uRaw, v3.scale(n, v3.dot(uRaw, n)))
  if (v3.len(uOrtho) < 1e-6) throw new ExprError(`${what}: uDir must not be parallel to the normal`)
  const u = v3.norm(uOrtho)
  const v = v3.cross(n, u)
  return { origin: ctx.vec3(plane.origin, `${what}.origin`), u, v, n }
}

export function toWorld(f: Frame, p: V2): V3 {
  return [
    f.origin[0] + f.u[0] * p[0] + f.v[0] * p[1],
    f.origin[1] + f.u[1] * p[0] + f.v[1] * p[1],
    f.origin[2] + f.u[2] * p[0] + f.v[2] * p[1],
  ]
}

export function toWorldDir(f: Frame, d: V2): V3 {
  return [f.u[0] * d[0] + f.v[0] * d[1], f.u[1] * d[0] + f.v[1] * d[1], f.u[2] * d[0] + f.v[2] * d[1]]
}

// ---------------------------------------------------------------------------
// Loops
// ---------------------------------------------------------------------------

export type LoopSegment =
  | { kind: 'line'; from: V2; to: V2 }
  | {
      kind: 'arc'
      from: V2
      to: V2
      /** A point on the arc between from and to. */
      mid: V2
      center: V2
      radius: number
      /** true if the arc runs counter-clockwise (in sketch u,v axes) from `from` to `to`. */
      ccw: boolean
      /** Angles (radians, atan2 convention) of from / to around the center. */
      startAngle: number
      endAngle: number
    }

export interface LoopSource {
  profileIndex: number
  copyIndex: number
  profile: Profile
}

export type Loop =
  | { kind: 'circle'; center: V2; radius: number; source: LoopSource }
  | { kind: 'segments'; segments: LoopSegment[]; source: LoopSource }

const rot2 = (p: V2, c: V2, ang: number): V2 => {
  const s = Math.sin(ang)
  const co = Math.cos(ang)
  const x = p[0] - c[0]
  const y = p[1] - c[1]
  return [c[0] + x * co - y * s, c[1] + x * s + y * co]
}

const dist2 = (a: V2, b: V2) => Math.hypot(a[0] - b[0], a[1] - b[1])

/** Builds a 3-point arc segment; throws if the points are collinear or coincident. */
export function arcThrough(from: V2, mid: V2, to: V2): LoopSegment {
  const [ax, ay] = from
  const [bx, by] = mid
  const [cx, cy] = to
  const d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
  if (Math.abs(d) < 1e-12) throw new ExprError('arc points are collinear')
  const a2 = ax * ax + ay * ay
  const b2 = bx * bx + by * by
  const c2 = cx * cx + cy * cy
  const ux = (a2 * (by - cy) + b2 * (cy - ay) + c2 * (ay - by)) / d
  const uy = (a2 * (cx - bx) + b2 * (ax - cx) + c2 * (bx - ax)) / d
  const center: V2 = [ux, uy]
  const radius = dist2(center, from)
  // Orientation of (from, mid, to): positive cross => counter-clockwise.
  const cross = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
  return {
    kind: 'arc',
    from,
    to,
    mid,
    center,
    radius,
    ccw: cross > 0,
    startAngle: Math.atan2(ay - uy, ax - ux),
    endAngle: Math.atan2(cy - uy, cx - ux),
  }
}

/** Arc of given center from `from` to `to` going ccw or cw (mid point computed). */
export function arcAround(center: V2, from: V2, to: V2, ccw: boolean): LoopSegment {
  const r = dist2(center, from)
  const a0 = Math.atan2(from[1] - center[1], from[0] - center[0])
  let a1 = Math.atan2(to[1] - center[1], to[0] - center[0])
  if (ccw) {
    while (a1 <= a0 + 1e-12) a1 += 2 * Math.PI
  } else {
    while (a1 >= a0 - 1e-12) a1 -= 2 * Math.PI
  }
  const am = (a0 + a1) / 2
  const mid: V2 = [center[0] + r * Math.cos(am), center[1] + r * Math.sin(am)]
  return { kind: 'arc', from, to, mid, center, radius: r, ccw, startAngle: a0, endAngle: Math.atan2(to[1] - center[1], to[0] - center[0]) }
}

function transformSegment(s: LoopSegment, f: (p: V2) => V2): LoopSegment {
  if (s.kind === 'line') return { kind: 'line', from: f(s.from), to: f(s.to) }
  return arcThrough(f(s.from), f(s.mid), f(s.to))
}

function transformLoop(l: Loop, f: (p: V2) => V2, copyIndex: number): Loop {
  const source = { ...l.source, copyIndex }
  if (l.kind === 'circle') return { kind: 'circle', center: f(l.center), radius: l.radius, source }
  return { kind: 'segments', segments: l.segments.map((s) => transformSegment(s, f)), source }
}

/** Transforms (translation / rotation in the sketch plane) generated by a repeat; the identity comes first. */
export function repeatTransforms(rep: ProfileRepeat | undefined, ctx: EvalContext, what: string): Array<(p: V2) => V2> {
  if (!rep) return [(p) => p]
  if (rep.type === 'linear') {
    const c1 = ctx.int(rep.count, `${what}.repeat.count`)
    const s1 = ctx.vec2(rep.step, `${what}.repeat.step`)
    const c2 = rep.count2 === undefined ? 1 : ctx.int(rep.count2, `${what}.repeat.count2`)
    const s2: V2 = rep.step2 === undefined ? [0, 0] : ctx.vec2(rep.step2, `${what}.repeat.step2`)
    const out: Array<(p: V2) => V2> = []
    for (let j = 0; j < c2; j++) {
      for (let i = 0; i < c1; i++) {
        const dx = i * s1[0] + j * s2[0]
        const dy = i * s1[1] + j * s2[1]
        out.push((p) => [p[0] + dx, p[1] + dy])
      }
    }
    return out
  }
  const count = ctx.int(rep.count, `${what}.repeat.count`)
  const center = ctx.vec2(rep.center, `${what}.repeat.center`)
  const total = rep.totalAngle === undefined ? 360 : ctx.n(rep.totalAngle, `${what}.repeat.totalAngle`)
  const full = Math.abs(Math.abs(total) - 360) < 1e-9
  const stepDeg = count <= 1 ? 0 : full ? total / count : total / (count - 1)
  const out: Array<(p: V2) => V2> = []
  for (let k = 0; k < count; k++) {
    const ang = (k * stepDeg * Math.PI) / 180
    out.push((p) => rot2(p, center, ang))
  }
  return out
}

/** Reduces one profile (without its repeat) to a single loop. */
export function profileBaseLoop(profile: Profile, ctx: EvalContext, what: string, profileIndex: number): Loop {
  const source: LoopSource = { profileIndex, copyIndex: 0, profile }
  switch (profile.type) {
    case 'circle': {
      const c = ctx.vec2(profile.center, `${what}.center`)
      const d = ctx.pos(profile.diameter, `${what}.diameter`)
      return { kind: 'circle', center: c, radius: d / 2, source }
    }
    case 'rectangle': {
      const c = ctx.vec2(profile.center, `${what}.center`)
      const w = ctx.pos(profile.width, `${what}.width`)
      const h = ctx.pos(profile.height, `${what}.height`)
      const r = profile.cornerRadius === undefined ? 0 : ctx.n(profile.cornerRadius, `${what}.cornerRadius`)
      const ang = profile.angle === undefined ? 0 : (ctx.n(profile.angle, `${what}.angle`) * Math.PI) / 180
      if (r < 0) throw new ExprError(`${what}.cornerRadius must be >= 0`)
      if (r > Math.min(w, h) / 2 + 1e-9) throw new ExprError(`${what}.cornerRadius (${r}) exceeds half of the smallest side`)
      const x0 = c[0] - w / 2
      const x1 = c[0] + w / 2
      const y0 = c[1] - h / 2
      const y1 = c[1] + h / 2
      const segs: LoopSegment[] = []
      if (r <= 1e-9) {
        const pts: V2[] = [
          [x0, y0],
          [x1, y0],
          [x1, y1],
          [x0, y1],
        ]
        for (let i = 0; i < 4; i++) segs.push({ kind: 'line', from: pts[i]!, to: pts[(i + 1) % 4]! })
      } else {
        const pushLine = (a: V2, b: V2) => {
          if (dist2(a, b) > 1e-9) segs.push({ kind: 'line', from: a, to: b })
        }
        // Counter-clockwise, starting at the bottom edge.
        pushLine([x0 + r, y0], [x1 - r, y0])
        segs.push(arcAround([x1 - r, y0 + r], [x1 - r, y0], [x1, y0 + r], true))
        pushLine([x1, y0 + r], [x1, y1 - r])
        segs.push(arcAround([x1 - r, y1 - r], [x1, y1 - r], [x1 - r, y1], true))
        pushLine([x1 - r, y1], [x0 + r, y1])
        segs.push(arcAround([x0 + r, y1 - r], [x0 + r, y1], [x0, y1 - r], true))
        pushLine([x0, y1 - r], [x0, y0 + r])
        segs.push(arcAround([x0 + r, y0 + r], [x0, y0 + r], [x0 + r, y0], true))
      }
      const loop: Loop = { kind: 'segments', segments: segs, source }
      return Math.abs(ang) > 1e-12 ? { ...transformLoop(loop, (p) => rot2(p, c, ang), 0) } : loop
    }
    case 'polygon': {
      const pts = profile.points.map((p, i) => ctx.vec2(p, `${what}.points[${i}]`))
      if (pts.length < 3) throw new ExprError(`${what} needs at least 3 points`)
      const segs: LoopSegment[] = []
      for (let i = 0; i < pts.length; i++) {
        const a = pts[i]!
        const b = pts[(i + 1) % pts.length]!
        if (dist2(a, b) > 1e-9) segs.push({ kind: 'line', from: a, to: b })
      }
      if (segs.length < 3) throw new ExprError(`${what} is degenerate`)
      return { kind: 'segments', segments: segs, source }
    }
    case 'regularPolygon': {
      const c = ctx.vec2(profile.center, `${what}.center`)
      const d = ctx.pos(profile.diameter, `${what}.diameter`)
      const a0 = profile.angle === undefined ? 0 : (ctx.n(profile.angle, `${what}.angle`) * Math.PI) / 180
      const n = profile.sides
      const pts: V2[] = []
      for (let k = 0; k < n; k++) {
        const a = a0 + (2 * Math.PI * k) / n
        pts.push([c[0] + (d / 2) * Math.cos(a), c[1] + (d / 2) * Math.sin(a)])
      }
      return {
        kind: 'segments',
        segments: pts.map((p, i) => ({ kind: 'line' as const, from: p, to: pts[(i + 1) % n]! })),
        source,
      }
    }
    case 'slot': {
      const s = ctx.vec2(profile.start, `${what}.start`)
      const e = ctx.vec2(profile.end, `${what}.end`)
      const w = ctx.pos(profile.width, `${what}.width`)
      const L = dist2(s, e)
      if (L < 1e-9) return { kind: 'circle', center: s, radius: w / 2, source }
      const d: V2 = [(e[0] - s[0]) / L, (e[1] - s[1]) / L]
      const p: V2 = [(-d[1] * w) / 2, (d[0] * w) / 2]
      const sP: V2 = [s[0] + p[0], s[1] + p[1]]
      const sM: V2 = [s[0] - p[0], s[1] - p[1]]
      const eP: V2 = [e[0] + p[0], e[1] + p[1]]
      const eM: V2 = [e[0] - p[0], e[1] - p[1]]
      return {
        kind: 'segments',
        segments: [
          { kind: 'line', from: sM, to: eM },
          arcThrough(eM, [e[0] + (d[0] * w) / 2, e[1] + (d[1] * w) / 2], eP),
          { kind: 'line', from: eP, to: sP },
          arcThrough(sP, [s[0] - (d[0] * w) / 2, s[1] - (d[1] * w) / 2], sM),
        ],
        source,
      }
    }
    case 'path': {
      const start = ctx.vec2(profile.start, `${what}.start`)
      let cur = start
      const segs: LoopSegment[] = []
      profile.segments.forEach((seg, i) => {
        const to = ctx.vec2(seg.to, `${what}.segments[${i}].to`)
        if (dist2(cur, to) < 1e-9) throw new ExprError(`${what}.segments[${i}] has zero length`)
        if (seg.type === 'line') segs.push({ kind: 'line', from: cur, to })
        else segs.push(arcThrough(cur, ctx.vec2(seg.via, `${what}.segments[${i}].via`), to))
        cur = to
      })
      if (dist2(cur, start) > 1e-9) segs.push({ kind: 'line', from: cur, to: start })
      if (segs.length < 2) throw new ExprError(`${what} must enclose an area`)
      return { kind: 'segments', segments: segs, source }
    }
  }
}

/** All loops of a profile, including repeated copies. */
export function profileLoops(profile: Profile, ctx: EvalContext, what: string, profileIndex: number): Loop[] {
  const base = profileBaseLoop(profile, ctx, what, profileIndex)
  return repeatTransforms(profile.repeat, ctx, what).map((t, i) => (i === 0 ? base : transformLoop(base, t, i)))
}

export interface ResolvedSketch {
  frame: Frame
  loops: Loop[]
}

export function resolveSketch(sketch: Sketch, ctx: EvalContext, what = 'sketch'): ResolvedSketch {
  const frame = planeFrame(sketch.plane, ctx, `${what}.plane`)
  const loops: Loop[] = []
  sketch.profiles.forEach((p, i) => loops.push(...profileLoops(p, ctx, `${what}.profiles[${i}]`, i)))
  return { frame, loops }
}

/** Resolved hole centers (sketch coordinates) including the repeat pattern. */
export function resolvePositions(positions: ReadonlyArray<Vec2>, rep: ProfileRepeat | undefined, ctx: EvalContext, what: string): V2[] {
  const base = positions.map((p, i) => ctx.vec2(p, `${what}.positions[${i}]`))
  const ts = repeatTransforms(rep, ctx, what)
  const out: V2[] = []
  for (const t of ts) for (const p of base) out.push(t(p))
  return out
}

/** Signed area (shoelace, polyline approximation for arcs) — positive = counter-clockwise. */
export function loopSignedArea(loop: Loop): number {
  if (loop.kind === 'circle') return Math.PI * loop.radius * loop.radius
  const pts: V2[] = []
  for (const s of loop.segments) {
    pts.push(s.from)
    if (s.kind === 'arc') pts.push(s.mid)
  }
  let a = 0
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i]!
    const q = pts[(i + 1) % pts.length]!
    a += p[0] * q[1] - q[0] * p[1]
  }
  return a / 2
}

/** Axis-aligned 2D bounding box of a loop (arcs approximated by their 3 points plus extremes). */
export function loopBounds(loop: Loop): { min: V2; max: V2 } {
  if (loop.kind === 'circle') {
    return {
      min: [loop.center[0] - loop.radius, loop.center[1] - loop.radius],
      max: [loop.center[0] + loop.radius, loop.center[1] + loop.radius],
    }
  }
  const min: V2 = [Infinity, Infinity]
  const max: V2 = [-Infinity, -Infinity]
  const add = (p: V2) => {
    min[0] = Math.min(min[0], p[0])
    min[1] = Math.min(min[1], p[1])
    max[0] = Math.max(max[0], p[0])
    max[1] = Math.max(max[1], p[1])
  }
  for (const s of loop.segments) {
    add(s.from)
    add(s.to)
    if (s.kind === 'arc') {
      add(s.mid)
      // Include axis extremes swept by the arc.
      for (const a of [0, Math.PI / 2, Math.PI, -Math.PI / 2]) {
        if (angleOnArc(s, a)) add([s.center[0] + s.radius * Math.cos(a), s.center[1] + s.radius * Math.sin(a)])
      }
    }
  }
  return { min, max }
}

function angleOnArc(s: Extract<LoopSegment, { kind: 'arc' }>, a: number): boolean {
  const norm = (x: number) => ((x % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI)
  const start = norm(s.startAngle)
  const end = norm(s.endAngle)
  const t = norm(a)
  if (s.ccw) return start <= end ? t >= start && t <= end : t >= start || t <= end
  return start >= end ? t <= start && t >= end : t <= start || t >= end
}

// ---------------------------------------------------------------------------
// Instances (assembly placement)
// ---------------------------------------------------------------------------

/** Row-major 3x3 rotation + translation: world = R * local + t. */
export interface RigidTransform {
  R: [number, number, number, number, number, number, number, number, number]
  t: V3
}

function axisRotation(axis: 'X' | 'Y' | 'Z', deg: number): RigidTransform['R'] {
  const a = (deg * Math.PI) / 180
  const c = Math.cos(a)
  const s = Math.sin(a)
  const clean = (x: number) => (Math.abs(x) < 1e-15 ? 0 : x)
  switch (axis) {
    case 'X':
      return [1, 0, 0, 0, clean(c), clean(-s), 0, clean(s), clean(c)]
    case 'Y':
      return [clean(c), 0, clean(s), 0, 1, 0, clean(-s), 0, clean(c)]
    case 'Z':
      return [clean(c), clean(-s), 0, clean(s), clean(c), 0, 0, 0, 1]
  }
}

export function mul3(a: RigidTransform['R'], b: RigidTransform['R']): RigidTransform['R'] {
  const r = new Array(9).fill(0) as RigidTransform['R']
  for (let i = 0; i < 3; i++)
    for (let j = 0; j < 3; j++) {
      let s = 0
      for (let k = 0; k < 3; k++) s += a[i * 3 + k]! * b[k * 3 + j]!
      r[i * 3 + j] = s
    }
  return r
}

export function instanceTransform(inst: Instance, ctx: EvalContext): RigidTransform {
  let R: RigidTransform['R'] = [1, 0, 0, 0, 1, 0, 0, 0, 1]
  ;(inst.rotations ?? []).forEach((r, i) => {
    // Applied in order about global axes: R_total = R_i * ... * R_1
    R = mul3(axisRotation(r.axis, ctx.n(r.angle, `instances.${inst.id}.rotations[${i}].angle`)), R)
  })
  return { R, t: ctx.vec3(inst.position, `instances.${inst.id}.position`) }
}

export function applyTransform(T: RigidTransform, p: V3): V3 {
  const R = T.R
  return [
    R[0] * p[0] + R[1] * p[1] + R[2] * p[2] + T.t[0],
    R[3] * p[0] + R[4] * p[1] + R[5] * p[2] + T.t[1],
    R[6] * p[0] + R[7] * p[1] + R[8] * p[2] + T.t[2],
  ]
}

// ---------------------------------------------------------------------------
// Topology selectors: resolution + reference matching semantics
// ---------------------------------------------------------------------------

export interface ResolvedEdgeSelector {
  all: boolean
  direction?: 'X' | 'Y' | 'Z'
  curve?: 'line' | 'circle'
  onPlane?: { axis: 'X' | 'Y' | 'Z'; at: number }
  inBox?: { min: V3; max: V3 }
  radius?: number
}

export function resolveEdgeSelector(sel: EdgeSelector, ctx: EvalContext, what = 'edges'): ResolvedEdgeSelector {
  const r: ResolvedEdgeSelector = { all: !!sel.all }
  if (sel.direction) r.direction = sel.direction
  if (sel.curve) r.curve = sel.curve
  if (sel.onPlane) r.onPlane = { axis: sel.onPlane.axis, at: ctx.n(sel.onPlane.at, `${what}.onPlane.at`) }
  if (sel.inBox) {
    const a = ctx.vec3(sel.inBox.min, `${what}.inBox.min`)
    const b = ctx.vec3(sel.inBox.max, `${what}.inBox.max`)
    r.inBox = {
      min: [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.min(a[2], b[2])],
      max: [Math.max(a[0], b[0]), Math.max(a[1], b[1]), Math.max(a[2], b[2])],
    }
  }
  if (sel.radius !== undefined) r.radius = ctx.pos(sel.radius, `${what}.radius`)
  if (!r.all && !r.direction && !r.curve && !r.onPlane && !r.inBox && r.radius === undefined) {
    throw new ExprError(`${what}: the edge selector needs at least one criterion`)
  }
  return r
}

/** Geometric summary of an edge, built by each backend from its own topology. */
export interface EdgeInfo {
  curve: 'line' | 'circle' | 'other'
  /** Sample points along the edge (at least start, middle, end). */
  points: V3[]
  /** Unit direction for straight edges. */
  direction?: V3
  /** Radius for circular edges. */
  radius?: number
}

/** Reference semantics of an edge selector (backends must reproduce exactly this logic). */
export function edgeMatches(e: EdgeInfo, s: ResolvedEdgeSelector, tol = MATCH_TOL): boolean {
  if (s.curve && e.curve !== s.curve) return false
  if (s.direction) {
    if (e.curve !== 'line' || !e.direction) return false
    const a = AXIS_VECTORS[s.direction]
    if (Math.abs(Math.abs(v3.dot(v3.norm(e.direction), a)) - 1) > 1e-6) return false
  }
  if (s.radius !== undefined) {
    if (e.curve !== 'circle' || e.radius === undefined || Math.abs(e.radius - s.radius) > tol) return false
  }
  if (s.onPlane) {
    const i = AXIS_INDEX[s.onPlane.axis]
    if (!e.points.every((p) => Math.abs(p[i] - s.onPlane!.at) <= tol)) return false
  }
  if (s.inBox) {
    const { min, max } = s.inBox
    const inside = (p: V3) => p.every((c, i) => c >= min[i]! - tol && c <= max[i]! + tol)
    if (!e.points.every(inside)) return false
  }
  return true
}

export interface ResolvedFaceSelector {
  normal?: '+X' | '-X' | '+Y' | '-Y' | '+Z' | '-Z'
  onPlane?: { axis: 'X' | 'Y' | 'Z'; at: number }
  surface?: 'plane' | 'cylinder'
}

export function resolveFaceSelector(sel: FaceSelector, ctx: EvalContext, what = 'faces'): ResolvedFaceSelector {
  const r: ResolvedFaceSelector = {}
  if (sel.normal) r.normal = sel.normal
  if (sel.surface) r.surface = sel.surface
  if (sel.onPlane) r.onPlane = { axis: sel.onPlane.axis, at: ctx.n(sel.onPlane.at, `${what}.onPlane.at`) }
  if (!r.normal && !r.onPlane && !r.surface) throw new ExprError(`${what}: the face selector needs at least one criterion`)
  return r
}

export interface FaceInfo {
  surface: 'plane' | 'cylinder' | 'other'
  /** Outward unit normal for planar faces. */
  normal?: V3
  /** Sample points on the face (center + boundary samples). */
  points: V3[]
}

export function faceMatches(f: FaceInfo, s: ResolvedFaceSelector, tol = MATCH_TOL): boolean {
  if (s.surface && f.surface !== s.surface) return false
  if (s.normal) {
    if (f.surface !== 'plane' || !f.normal) return false
    const sign = s.normal[0] === '+' ? 1 : -1
    const a = v3.scale(AXIS_VECTORS[s.normal[1] as 'X' | 'Y' | 'Z'], sign)
    if (v3.dot(v3.norm(f.normal), a) < 1 - 1e-6) return false
  }
  if (s.onPlane) {
    if (f.surface !== 'plane') return false
    const i = AXIS_INDEX[s.onPlane.axis]
    if (!f.points.every((p) => Math.abs(p[i] - s.onPlane!.at) <= tol)) return false
  }
  return true
}
