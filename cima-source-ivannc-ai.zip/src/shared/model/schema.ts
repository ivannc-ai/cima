/**
 * CIMA parametric CAD model — the central contract of the application.
 *
 * The same JSON document is:
 *  - produced by the LLM (through a tool call whose input schema is derived from these Zod schemas),
 *  - evaluated and previewed by the geometry kernel (replicad / OpenCascade),
 *  - translated into native CATIA features (sketches, pads, pockets, holes, fillets, parameters + formulas),
 *  - stored in .cima project files.
 *
 * Conventions (must be respected by every backend):
 *  - Units: millimetres for lengths, degrees for angles.
 *  - Sketch planes and their local 2D axes (u, v) — right-handed, u x v = normal:
 *      XY: u = +X, v = +Y, normal = +Z
 *      YZ: u = +Y, v = +Z, normal = +X
 *      ZX: u = +Z, v = +X, normal = +Y
 *    An `offset` moves the plane along its normal (XY offset 20 = plane z = 20).
 *  - Features are applied in order to a single solid body (like a CATIA PartBody).
 *  - Pad extrudes along +normal by default; pocket and hole cut along -normal by default
 *    (sketch on the "top" plane, material below).
 *  - The schema is intentionally NOT recursive (LLM strict-mode tool schemas do not support recursion).
 */
import { z } from 'zod'

export const SCHEMA_VERSION = 1 as const

/** Identifier usable in expressions and as a CATIA parameter name. */
export const IDENT_RE = /^[A-Za-z_][A-Za-z0-9_]*$/
export const HEX_COLOR_RE = /^#[0-9a-fA-F]{6}$/

// ---------------------------------------------------------------------------
// Primitives
// ---------------------------------------------------------------------------

export const ExprSchema = z
  .union([z.number(), z.string().min(1)])
  .describe(
    'A number or an arithmetic expression over parameter names, e.g. 25, "width/2", "2*wall + 5". ' +
      'Lengths are mm, angles are degrees. Operators: + - * / ^ ( ). Functions: sin cos tan asin acos atan atan2 sqrt abs min max round floor ceil. ' +
      'Constant: pi. Trigonometric functions take and return degrees.',
  )
export type Expr = z.infer<typeof ExprSchema>

export const Vec2Schema = z.array(ExprSchema).length(2).describe('[u, v] coordinates in the sketch plane (mm).')
export type Vec2 = z.infer<typeof Vec2Schema>

export const Vec3Schema = z.array(ExprSchema).length(3).describe('[x, y, z] coordinates (mm).')
export type Vec3 = z.infer<typeof Vec3Schema>

export const Dir3Schema = z
  .array(z.number())
  .length(3)
  .describe('Direction vector [x, y, z]. Does not need to be unit length, must not be zero.')
export type Dir3 = z.infer<typeof Dir3Schema>

export const AxisSchema = z.enum(['X', 'Y', 'Z'])
export type Axis = z.infer<typeof AxisSchema>

// ---------------------------------------------------------------------------
// Parameters
// ---------------------------------------------------------------------------

export const ParameterSchema = z
  .object({
    name: z
      .string()
      .regex(IDENT_RE)
      .describe('Identifier used in expressions, e.g. "width", "hole_d". Letters, digits and _ only; must not start with a digit.'),
    value: z.number().describe('Default value: mm for lengths, degrees for angles, plain number otherwise.'),
    unit: z.enum(['mm', 'deg', 'none']).describe('mm = length, deg = angle, none = count or ratio.'),
    min: z.number().optional().describe('Lower bound for the UI slider.'),
    max: z.number().optional().describe('Upper bound for the UI slider.'),
    step: z.number().optional().describe('Slider step.'),
    description: z.string().optional().describe('Short human description (shown as tooltip and as CATIA comment).'),
    expression: z
      .string()
      .optional()
      .describe('Optional. If set, the parameter is derived from other parameters (e.g. "outer_d/2 - 10") and is not directly editable.'),
  })
  .describe('A named design parameter. Users edit parameters with sliders; in CATIA they become user parameters driving formulas.')
export type Parameter = z.infer<typeof ParameterSchema>

// ---------------------------------------------------------------------------
// Planes
// ---------------------------------------------------------------------------

export const OriginPlaneSchema = z
  .object({
    type: z.literal('origin'),
    base: z
      .enum(['XY', 'YZ', 'ZX'])
      .describe('Origin plane. XY: u=+X, v=+Y, normal=+Z. YZ: u=+Y, v=+Z, normal=+X. ZX: u=+Z, v=+X, normal=+Y.'),
    offset: ExprSchema.optional().describe('Signed offset along the plane normal (mm). XY with offset 20 is the plane z = 20. Default 0.'),
  })
  .describe('An origin plane, optionally offset along its normal.')

export const CustomPlaneSchema = z
  .object({
    type: z.literal('custom'),
    origin: Vec3Schema.describe('Origin of the sketch (u = v = 0) in part coordinates.'),
    normal: Dir3Schema.describe('Plane normal. Pads extrude along it by default.'),
    uDir: Dir3Schema.describe('Direction of the sketch u axis; must be perpendicular to the normal. v = normal x u.'),
  })
  .describe('An arbitrary plane. Prefer origin planes with offsets whenever possible.')

export const PlaneSchema = z.discriminatedUnion('type', [OriginPlaneSchema, CustomPlaneSchema])
export type Plane = z.infer<typeof PlaneSchema>

// ---------------------------------------------------------------------------
// 2D profiles (closed loops in sketch coordinates)
// ---------------------------------------------------------------------------

export const ProfileRepeatSchema = z
  .discriminatedUnion('type', [
    z.object({
      type: z.literal('linear'),
      count: ExprSchema.describe('Total number of copies including the original (integer >= 1).'),
      step: Vec2Schema.describe('Offset [du, dv] between consecutive copies.'),
      count2: ExprSchema.optional().describe('Optional second direction: number of rows (integer >= 1).'),
      step2: Vec2Schema.optional().describe('Offset [du, dv] between rows.'),
    }),
    z.object({
      type: z.literal('circular'),
      count: ExprSchema.describe('Total number of copies including the original (integer >= 1).'),
      center: Vec2Schema.describe('Center of rotation [u, v].'),
      totalAngle: ExprSchema.optional().describe('Angular span in degrees. Default 360 = evenly spaced on a full circle.'),
    }),
  ])
  .describe('Repeats a profile (or hole position) inside the same sketch.')
export type ProfileRepeat = z.infer<typeof ProfileRepeatSchema>

const repeatField = ProfileRepeatSchema.optional().describe('Optional pattern of copies of this profile within the sketch.')

export const RectangleProfileSchema = z.object({
  type: z.literal('rectangle'),
  center: Vec2Schema.describe('Center [u, v].'),
  width: ExprSchema.describe('Size along u (mm).'),
  height: ExprSchema.describe('Size along v (mm).'),
  cornerRadius: ExprSchema.optional().describe('Optional radius of the four corners (mm).'),
  angle: ExprSchema.optional().describe('Optional counter-clockwise rotation in degrees.'),
  repeat: repeatField,
})

export const CircleProfileSchema = z.object({
  type: z.literal('circle'),
  center: Vec2Schema.describe('Center [u, v].'),
  diameter: ExprSchema.describe('Diameter (mm).'),
  repeat: repeatField,
})

export const PolygonProfileSchema = z.object({
  type: z.literal('polygon'),
  points: z.array(Vec2Schema).min(3).describe('Vertices [u, v] in order; the polygon is closed automatically. No self-intersections.'),
  repeat: repeatField,
})

export const RegularPolygonProfileSchema = z.object({
  type: z.literal('regularPolygon'),
  center: Vec2Schema.describe('Center [u, v].'),
  sides: z.number().int().min(3).describe('Number of sides.'),
  diameter: ExprSchema.describe('Circumscribed diameter (mm). For a hexagon with across-flats AF use AF / cos(30).'),
  angle: ExprSchema.optional().describe('Rotation in degrees; 0 puts a vertex on the +u axis.'),
  repeat: repeatField,
})

export const SlotProfileSchema = z.object({
  type: z.literal('slot'),
  start: Vec2Schema.describe('Center of the first rounded end [u, v].'),
  end: Vec2Schema.describe('Center of the second rounded end [u, v].'),
  width: ExprSchema.describe('Slot width = diameter of the rounded ends (mm).'),
  repeat: repeatField,
})

export const PathSegmentSchema = z.discriminatedUnion('type', [
  z.object({
    type: z.literal('line'),
    to: Vec2Schema.describe('End point [u, v].'),
  }),
  z.object({
    type: z.literal('arc'),
    to: Vec2Schema.describe('End point [u, v].'),
    via: Vec2Schema.describe('Any point on the arc strictly between the current point and "to" (three-point arc).'),
  }),
])
export type PathSegment = z.infer<typeof PathSegmentSchema>

export const PathProfileSchema = z.object({
  type: z.literal('path'),
  start: Vec2Schema.describe('Start point [u, v].'),
  segments: z
    .array(PathSegmentSchema)
    .min(1)
    .describe('Consecutive line/arc segments. If the last segment does not end at "start", a straight line closes the loop.'),
  repeat: repeatField,
})

export const ProfileSchema = z
  .discriminatedUnion('type', [
    RectangleProfileSchema,
    CircleProfileSchema,
    PolygonProfileSchema,
    RegularPolygonProfileSchema,
    SlotProfileSchema,
    PathProfileSchema,
  ])
  .describe('A closed 2D loop in sketch coordinates.')
export type Profile = z.infer<typeof ProfileSchema>

export const SketchSchema = z
  .object({
    plane: PlaneSchema,
    profiles: z
      .array(ProfileSchema)
      .min(1)
      .describe('Closed profiles. A profile located inside another profile becomes a hole (inner loop). Profiles must not intersect or touch each other.'),
  })
  .describe('A planar sketch made of closed profiles.')
export type Sketch = z.infer<typeof SketchSchema>

// ---------------------------------------------------------------------------
// Topology selectors (for fillet, chamfer, shell)
// ---------------------------------------------------------------------------

export const OnPlaneSchema = z
  .object({
    axis: AxisSchema,
    at: ExprSchema.describe('Coordinate value along the axis (mm).'),
  })
  .describe('The plane where coordinate <axis> equals <at>, e.g. {axis:"Z", at:"height"} is the plane z = height.')

export const EdgeSelectorSchema = z
  .object({
    all: z.boolean().optional().describe('true = every edge of the solid. Use only for simple blocks.'),
    direction: AxisSchema.optional().describe('Only straight edges parallel to this axis.'),
    curve: z.enum(['line', 'circle']).optional().describe('Only straight edges (line) or circular edges/arcs (circle).'),
    onPlane: OnPlaneSchema.optional().describe('Only edges lying entirely in this plane (e.g. the edges of the top face).'),
    inBox: z
      .object({ min: Vec3Schema, max: Vec3Schema })
      .optional()
      .describe('Only edges lying entirely inside this axis-aligned box.'),
    radius: ExprSchema.optional().describe('Only circular edges with this radius (mm).'),
  })
  .describe('Selects edges of the solid built so far. Every criterion given must match (logical AND). Give at least one criterion.')
export type EdgeSelector = z.infer<typeof EdgeSelectorSchema>

export const FaceSelectorSchema = z
  .object({
    normal: z
      .enum(['+X', '-X', '+Y', '-Y', '+Z', '-Z'])
      .optional()
      .describe('Only planar faces whose outward normal points this way.'),
    onPlane: OnPlaneSchema.optional().describe('Only planar faces lying in this plane.'),
    surface: z.enum(['plane', 'cylinder']).optional().describe('Only faces of this surface type.'),
  })
  .describe('Selects faces of the solid built so far (logical AND of the criteria). Give at least one criterion.')
export type FaceSelector = z.infer<typeof FaceSelectorSchema>

// ---------------------------------------------------------------------------
// Features
// ---------------------------------------------------------------------------

const featureBase = {
  id: z.string().regex(IDENT_RE).describe('Unique feature id inside the part, e.g. "base_plate", "bolt_holes".'),
  name: z.string().optional().describe('Optional human readable name (used as CATIA feature name).'),
  suppressed: z.boolean().optional().describe('If true the feature is skipped.'),
}

export const ExtrudeDirectionSchema = z.enum(['normal', 'reverse', 'symmetric'])

export const PadFeatureSchema = z
  .object({
    ...featureBase,
    type: z.literal('pad'),
    sketch: SketchSchema,
    length: ExprSchema.describe('Extrusion length (mm). For "symmetric" it is the total length, split half on each side.'),
    direction: ExtrudeDirectionSchema.optional().describe('normal (default) = along +plane normal; reverse = along -normal; symmetric = both sides.'),
    length2: ExprSchema.optional().describe('Optional extra length on the opposite side (not with symmetric).'),
  })
  .describe('Pad (extrusion) that ADDS material.')

export const PocketFeatureSchema = z
  .object({
    ...featureBase,
    type: z.literal('pocket'),
    sketch: SketchSchema,
    depth: ExprSchema.optional().describe('Cut depth (mm). Required unless throughAll is true.'),
    throughAll: z.boolean().optional().describe('Cut through the whole solid.'),
    direction: ExtrudeDirectionSchema.optional().describe('reverse (default) = cut along -plane normal (into material under a top plane); normal = along +normal; symmetric = both sides.'),
  })
  .describe('Pocket (extruded cut) that REMOVES material.')

export const RevolveAxisSchema = z
  .enum(['u', 'v'])
  .describe('Revolution axis: the sketch u axis or v axis through the sketch origin. Example: to revolve around global Z use plane ZX (u = Z) with axis "u".')

export const ShaftFeatureSchema = z
  .object({
    ...featureBase,
    type: z.literal('shaft'),
    sketch: SketchSchema.describe('Half cross-section on one side of the axis; must not cross the axis.'),
    axis: RevolveAxisSchema,
    angle: ExprSchema.optional().describe('Revolution angle in degrees, default 360.'),
  })
  .describe('Shaft (revolve) that ADDS material.')

export const GrooveFeatureSchema = z
  .object({
    ...featureBase,
    type: z.literal('groove'),
    sketch: SketchSchema.describe('Cross-section of the groove on one side of the axis; must not cross the axis.'),
    axis: RevolveAxisSchema,
    angle: ExprSchema.optional().describe('Revolution angle in degrees, default 360.'),
  })
  .describe('Groove (revolved cut) that REMOVES material.')

export const HoleFeatureSchema = z
  .object({
    ...featureBase,
    type: z.literal('hole'),
    plane: PlaneSchema.describe('Plane of the entry face of the hole. The hole is drilled along -normal (or +normal if reverse).'),
    positions: z.array(Vec2Schema).min(1).describe('Hole centers [u, v] in the plane coordinates.'),
    repeat: ProfileRepeatSchema.optional().describe('Optional pattern applied to every position (e.g. a bolt circle).'),
    diameter: ExprSchema.describe('Drill diameter (mm). For threaded holes the tap-drill diameter.'),
    depth: ExprSchema.optional().describe('Depth (mm). Required unless throughAll is true.'),
    throughAll: z.boolean().optional(),
    reverse: z.boolean().optional().describe('Drill along +normal instead of -normal.'),
    kind: z.enum(['simple', 'counterbored', 'countersunk']).optional().describe('Default simple.'),
    headDiameter: ExprSchema.optional().describe('Counterbore / countersink diameter (mm).'),
    headDepth: ExprSchema.optional().describe('Counterbore depth (mm).'),
    headAngle: ExprSchema.optional().describe('Countersink included angle in degrees, default 90.'),
    thread: z
      .object({
        size: z.string().describe('Thread designation, e.g. "M8".'),
        depth: ExprSchema.optional().describe('Thread depth (mm); default full hole depth.'),
      })
      .optional()
      .describe('Optional cosmetic thread specification.'),
  })
  .describe('Hole feature(s) drilled into the solid.')

export const FilletFeatureSchema = z
  .object({
    ...featureBase,
    type: z.literal('fillet'),
    edges: EdgeSelectorSchema,
    radius: ExprSchema.describe('Fillet radius (mm). Must be smaller than the adjacent face sizes.'),
  })
  .describe('Constant radius edge fillet.')

export const ChamferFeatureSchema = z
  .object({
    ...featureBase,
    type: z.literal('chamfer'),
    edges: EdgeSelectorSchema,
    distance: ExprSchema.describe('Chamfer length (mm), 45 degrees.'),
  })
  .describe('45-degree edge chamfer.')

export const ShellFeatureSchema = z
  .object({
    ...featureBase,
    type: z.literal('shell'),
    thickness: ExprSchema.describe('Wall thickness (mm), material kept inside the original outer surface.'),
    openFaces: FaceSelectorSchema.describe('Faces removed to open the shell (e.g. the top face of a box).'),
  })
  .describe('Shell (hollow out) the solid.')

export const MirrorFeatureSchema = z
  .object({
    ...featureBase,
    type: z.literal('mirror'),
    plane: z.enum(['XY', 'YZ', 'ZX']).describe('Origin plane used as mirror.'),
  })
  .describe('Mirrors the whole solid built so far and fuses the copy with it.')

export const LinearPatternFeatureSchema = z
  .object({
    ...featureBase,
    type: z.literal('linearPattern'),
    features: z.array(z.string()).min(1).describe('Ids of earlier pad/pocket/hole/shaft/groove features to repeat.'),
    direction: Dir3Schema.describe('First direction.'),
    count: ExprSchema.describe('Number of instances in the first direction including the original (integer >= 1).'),
    spacing: ExprSchema.describe('Distance between instances in the first direction (mm).'),
    direction2: Dir3Schema.optional(),
    count2: ExprSchema.optional(),
    spacing2: ExprSchema.optional(),
  })
  .describe('Rectangular pattern of earlier features.')

export const CircularPatternFeatureSchema = z
  .object({
    ...featureBase,
    type: z.literal('circularPattern'),
    features: z.array(z.string()).min(1).describe('Ids of earlier pad/pocket/hole/shaft/groove features to repeat.'),
    axis: AxisSchema.describe('Rotation axis (global X, Y or Z through "center").'),
    center: Vec3Schema.optional().describe('A point on the rotation axis, default [0,0,0].'),
    count: ExprSchema.describe('Number of instances including the original (integer >= 1).'),
    totalAngle: ExprSchema.optional().describe('Angular span in degrees, default 360 (evenly spaced).'),
  })
  .describe('Circular pattern of earlier features around a global axis.')

export const FeatureSchema = z.discriminatedUnion('type', [
  PadFeatureSchema,
  PocketFeatureSchema,
  ShaftFeatureSchema,
  GrooveFeatureSchema,
  HoleFeatureSchema,
  FilletFeatureSchema,
  ChamferFeatureSchema,
  ShellFeatureSchema,
  MirrorFeatureSchema,
  LinearPatternFeatureSchema,
  CircularPatternFeatureSchema,
])
export type Feature = z.infer<typeof FeatureSchema>
export type FeatureType = Feature['type']
export type PadFeature = z.infer<typeof PadFeatureSchema>
export type PocketFeature = z.infer<typeof PocketFeatureSchema>
export type ShaftFeature = z.infer<typeof ShaftFeatureSchema>
export type GrooveFeature = z.infer<typeof GrooveFeatureSchema>
export type HoleFeature = z.infer<typeof HoleFeatureSchema>
export type FilletFeature = z.infer<typeof FilletFeatureSchema>
export type ChamferFeature = z.infer<typeof ChamferFeatureSchema>
export type ShellFeature = z.infer<typeof ShellFeatureSchema>
export type MirrorFeature = z.infer<typeof MirrorFeatureSchema>
export type LinearPatternFeature = z.infer<typeof LinearPatternFeatureSchema>
export type CircularPatternFeature = z.infer<typeof CircularPatternFeatureSchema>

/** Features whose tool body can be repeated by a pattern. */
export const PATTERNABLE_TYPES: ReadonlyArray<FeatureType> = ['pad', 'pocket', 'hole', 'shaft', 'groove']

// ---------------------------------------------------------------------------
// Parts, instances, model
// ---------------------------------------------------------------------------

export const PartSchema = z
  .object({
    id: z.string().regex(IDENT_RE).describe('Unique part id, e.g. "base_plate".'),
    name: z.string().min(1).describe('Part number / display name (used as CATIA PartNumber).'),
    description: z.string().optional(),
    material: z.string().optional().describe('Informative material name, e.g. "Aluminium 6061-T6".'),
    color: z.string().regex(HEX_COLOR_RE).optional().describe('Display color "#RRGGBB".'),
    parameters: z.array(ParameterSchema).describe('Parameters local to this part.'),
    features: z.array(FeatureSchema).min(1).describe('Ordered feature tree. The first solid feature must be a pad or a shaft.'),
  })
  .describe('A part: parameters + ordered feature tree building one solid.')
export type Part = z.infer<typeof PartSchema>

export const RotationStepSchema = z.object({
  axis: AxisSchema.describe('Global axis.'),
  angle: ExprSchema.describe('Angle in degrees (right-hand rule).'),
})
export type RotationStep = z.infer<typeof RotationStepSchema>

export const InstanceSchema = z
  .object({
    id: z.string().regex(IDENT_RE).describe('Unique instance id.'),
    part: z.string().describe('Id of the part definition to place.'),
    name: z.string().optional().describe('Instance name.'),
    position: Vec3Schema.describe('Translation of the part origin in assembly coordinates (mm), applied after the rotations.'),
    rotations: z
      .array(RotationStepSchema)
      .optional()
      .describe('Rotations about global axes through the part origin, applied in order, before the translation.'),
    color: z.string().regex(HEX_COLOR_RE).optional(),
    fixed: z.boolean().optional().describe('Fix this instance in space (CATIA fix constraint).'),
  })
  .describe('A placed occurrence of a part inside an assembly.')
export type Instance = z.infer<typeof InstanceSchema>

export const CadModelSchema = z
  .object({
    schemaVersion: z.literal(SCHEMA_VERSION),
    name: z.string().min(1).describe('Model name (CATIA product / part number).'),
    description: z.string().optional(),
    units: z.literal('mm'),
    kind: z.enum(['part', 'assembly']),
    parameters: z
      .array(ParameterSchema)
      .describe('Model-level parameters, visible to every part and instance. For a single part you may leave this empty and use the part parameters.'),
    parts: z.array(PartSchema).min(1).describe('Part definitions. kind="part" requires exactly one.'),
    instances: z
      .array(InstanceSchema)
      .optional()
      .describe('Assembly placements (required for kind="assembly", omitted for kind="part").'),
  })
  .describe('A CIMA parametric CAD model: a single part or an assembly of parts.')
export type CadModel = z.infer<typeof CadModelSchema>
