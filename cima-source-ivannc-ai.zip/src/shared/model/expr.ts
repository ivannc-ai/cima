/**
 * Safe arithmetic expression language used by CIMA parameters and feature dimensions.
 *
 *   expr    := sum
 *   sum     := product (('+' | '-') product)*
 *   product := unary (('*' | '/') unary)*
 *   unary   := ('-' | '+') unary | power
 *   power   := primary ('^' unary)?          (right associative, binds tighter than unary minus: -2^2 = -4)
 *   primary := number | ident | ident '(' args ')' | '(' expr ')'
 *
 * Trigonometric functions take and return DEGREES (CAD convention, same as CATIA formulas with deg units).
 * No `eval` is ever used.
 */

export type ExprNode =
  | { kind: 'num'; value: number }
  | { kind: 'ident'; name: string }
  | { kind: 'unary'; op: '-' | '+'; arg: ExprNode }
  | { kind: 'binary'; op: '+' | '-' | '*' | '/' | '^'; left: ExprNode; right: ExprNode }
  | { kind: 'call'; fn: string; args: ExprNode[] }

export class ExprError extends Error {
  constructor(
    message: string,
    public readonly source?: string,
    public readonly position?: number,
  ) {
    super(message)
    this.name = 'ExprError'
  }
}

const DEG = Math.PI / 180

interface FnSpec {
  minArgs: number
  maxArgs: number
  impl: (...a: number[]) => number
}

export const EXPR_FUNCTIONS: Readonly<Record<string, FnSpec>> = {
  sin: { minArgs: 1, maxArgs: 1, impl: (a) => Math.sin(a * DEG) },
  cos: { minArgs: 1, maxArgs: 1, impl: (a) => Math.cos(a * DEG) },
  tan: { minArgs: 1, maxArgs: 1, impl: (a) => Math.tan(a * DEG) },
  asin: { minArgs: 1, maxArgs: 1, impl: (a) => Math.asin(a) / DEG },
  acos: { minArgs: 1, maxArgs: 1, impl: (a) => Math.acos(a) / DEG },
  atan: { minArgs: 1, maxArgs: 1, impl: (a) => Math.atan(a) / DEG },
  atan2: { minArgs: 2, maxArgs: 2, impl: (y, x) => Math.atan2(y, x) / DEG },
  sqrt: { minArgs: 1, maxArgs: 1, impl: (a) => Math.sqrt(a) },
  abs: { minArgs: 1, maxArgs: 1, impl: (a) => Math.abs(a) },
  min: { minArgs: 1, maxArgs: 64, impl: (...a) => Math.min(...a) },
  max: { minArgs: 1, maxArgs: 64, impl: (...a) => Math.max(...a) },
  round: { minArgs: 1, maxArgs: 1, impl: (a) => Math.round(a) },
  floor: { minArgs: 1, maxArgs: 1, impl: (a) => Math.floor(a) },
  ceil: { minArgs: 1, maxArgs: 1, impl: (a) => Math.ceil(a) },
}

export const EXPR_CONSTANTS: Readonly<Record<string, number>> = { pi: Math.PI }

/** Names that cannot be used as parameter names. */
export const RESERVED_NAMES: ReadonlySet<string> = new Set([
  ...Object.keys(EXPR_FUNCTIONS),
  ...Object.keys(EXPR_CONSTANTS),
  'PI',
  'true',
  'false',
])

// ---------------------------------------------------------------------------
// Tokenizer
// ---------------------------------------------------------------------------

type Token =
  | { t: 'num'; v: number; pos: number }
  | { t: 'ident'; v: string; pos: number }
  | { t: 'op'; v: '+' | '-' | '*' | '/' | '^' | '(' | ')' | ','; pos: number }
  | { t: 'end'; pos: number }

function tokenize(src: string): Token[] {
  const out: Token[] = []
  let i = 0
  while (i < src.length) {
    const c = src[i]!
    if (c === ' ' || c === '\t' || c === '\n' || c === '\r') {
      i++
      continue
    }
    if ((c >= '0' && c <= '9') || (c === '.' && /[0-9]/.test(src[i + 1] ?? ''))) {
      const m = /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(src.slice(i))
      if (!m) throw new ExprError(`Invalid number at position ${i}`, src, i)
      out.push({ t: 'num', v: Number(m[0]), pos: i })
      i += m[0].length
      continue
    }
    if (/[A-Za-z_]/.test(c)) {
      const m = /^[A-Za-z_][A-Za-z0-9_]*/.exec(src.slice(i))!
      out.push({ t: 'ident', v: m[0], pos: i })
      i += m[0].length
      continue
    }
    if (c === '*' && src[i + 1] === '*') {
      out.push({ t: 'op', v: '^', pos: i })
      i += 2
      continue
    }
    if ('+-*/^(),'.includes(c)) {
      out.push({ t: 'op', v: c as '+' | '-' | '*' | '/' | '^' | '(' | ')' | ',', pos: i })
      i++
      continue
    }
    throw new ExprError(`Unexpected character "${c}" at position ${i}`, src, i)
  }
  out.push({ t: 'end', pos: src.length })
  return out
}

// ---------------------------------------------------------------------------
// Parser
// ---------------------------------------------------------------------------

class Parser {
  private i = 0
  constructor(
    private readonly toks: Token[],
    private readonly src: string,
  ) {}

  private peek(): Token {
    return this.toks[this.i]!
  }
  private next(): Token {
    return this.toks[this.i++]!
  }
  private isOp(v: string): boolean {
    const t = this.peek()
    return t.t === 'op' && t.v === v
  }
  private expectOp(v: string): void {
    const t = this.next()
    if (t.t !== 'op' || t.v !== v) {
      throw new ExprError(`Expected "${v}" at position ${t.pos}`, this.src, t.pos)
    }
  }

  parse(): ExprNode {
    const node = this.sum()
    const t = this.peek()
    if (t.t !== 'end') throw new ExprError(`Unexpected token at position ${t.pos}`, this.src, t.pos)
    return node
  }

  private sum(): ExprNode {
    let left = this.product()
    while (this.isOp('+') || this.isOp('-')) {
      const op = (this.next() as { v: '+' | '-' }).v
      left = { kind: 'binary', op, left, right: this.product() }
    }
    return left
  }

  private product(): ExprNode {
    let left = this.unary()
    while (this.isOp('*') || this.isOp('/')) {
      const op = (this.next() as { v: '*' | '/' }).v
      left = { kind: 'binary', op, left, right: this.unary() }
    }
    return left
  }

  private unary(): ExprNode {
    if (this.isOp('-') || this.isOp('+')) {
      const op = (this.next() as { v: '-' | '+' }).v
      return { kind: 'unary', op, arg: this.unary() }
    }
    return this.power()
  }

  private power(): ExprNode {
    const base = this.primary()
    if (this.isOp('^')) {
      this.next()
      return { kind: 'binary', op: '^', left: base, right: this.unary() }
    }
    return base
  }

  private primary(): ExprNode {
    const t = this.next()
    if (t.t === 'num') return { kind: 'num', value: t.v }
    if (t.t === 'ident') {
      if (this.isOp('(')) {
        this.next()
        const args: ExprNode[] = []
        if (!this.isOp(')')) {
          args.push(this.sum())
          while (this.isOp(',')) {
            this.next()
            args.push(this.sum())
          }
        }
        this.expectOp(')')
        const fn = t.v.toLowerCase()
        const spec = EXPR_FUNCTIONS[fn]
        if (!spec) throw new ExprError(`Unknown function "${t.v}"`, this.src, t.pos)
        if (args.length < spec.minArgs || args.length > spec.maxArgs) {
          throw new ExprError(`Function "${fn}" expects ${spec.minArgs === spec.maxArgs ? spec.minArgs : `${spec.minArgs}..${spec.maxArgs}`} argument(s), got ${args.length}`, this.src, t.pos)
        }
        return { kind: 'call', fn, args }
      }
      return { kind: 'ident', name: t.v }
    }
    if (t.t === 'op' && t.v === '(') {
      const inner = this.sum()
      this.expectOp(')')
      return inner
    }
    throw new ExprError(`Unexpected ${t.t === 'end' ? 'end of expression' : `token at position ${t.pos}`}`, this.src, t.pos)
  }
}

const parseCache = new Map<string, ExprNode>()

/** Parses an expression string. Results are cached (the AST must be treated as immutable). */
export function parseExpr(src: string): ExprNode {
  const cached = parseCache.get(src)
  if (cached) return cached
  const trimmed = src.trim()
  if (!trimmed) throw new ExprError('Empty expression', src, 0)
  const node = new Parser(tokenize(trimmed), trimmed).parse()
  if (parseCache.size > 5000) parseCache.clear()
  parseCache.set(src, node)
  return node
}

// ---------------------------------------------------------------------------
// Analysis & evaluation
// ---------------------------------------------------------------------------

export function identifiersOf(node: ExprNode, into: Set<string> = new Set()): Set<string> {
  switch (node.kind) {
    case 'ident':
      if (!(node.name in EXPR_CONSTANTS) && node.name !== 'PI') into.add(node.name)
      break
    case 'unary':
      identifiersOf(node.arg, into)
      break
    case 'binary':
      identifiersOf(node.left, into)
      identifiersOf(node.right, into)
      break
    case 'call':
      node.args.forEach((a) => identifiersOf(a, into))
      break
  }
  return into
}

export type Scope = (name: string) => number | undefined

export function evalNode(node: ExprNode, scope: Scope): number {
  switch (node.kind) {
    case 'num':
      return node.value
    case 'ident': {
      const v = scope(node.name)
      if (v !== undefined) return v
      if (node.name === 'pi' || node.name === 'PI') return Math.PI
      throw new ExprError(`Unknown parameter "${node.name}"`)
    }
    case 'unary': {
      const a = evalNode(node.arg, scope)
      return node.op === '-' ? -a : a
    }
    case 'binary': {
      const a = evalNode(node.left, scope)
      const b = evalNode(node.right, scope)
      switch (node.op) {
        case '+':
          return a + b
        case '-':
          return a - b
        case '*':
          return a * b
        case '/':
          if (b === 0) throw new ExprError('Division by zero')
          return a / b
        case '^':
          return Math.pow(a, b)
      }
    }
    // eslint-disable-next-line no-fallthrough
    case 'call': {
      const spec = EXPR_FUNCTIONS[node.fn]
      if (!spec) throw new ExprError(`Unknown function "${node.fn}"`)
      return spec.impl(...node.args.map((a) => evalNode(a, scope)))
    }
  }
}

/** Evaluates a number or expression string. Throws ExprError on any problem (unknown names, NaN, infinity). */
export function evaluateExpr(expr: number | string, scope: Scope): number {
  const v = typeof expr === 'number' ? expr : evalNode(parseExpr(expr), scope)
  if (!Number.isFinite(v)) {
    throw new ExprError(`Expression ${JSON.stringify(expr)} does not evaluate to a finite number`)
  }
  return v
}

export function isConstantNode(node: ExprNode): boolean {
  return identifiersOf(node).size === 0
}

/** Replaces every identifier-free subtree by its numeric value. */
export function foldConstants(node: ExprNode): ExprNode {
  if (isConstantNode(node)) {
    try {
      const v = evalNode(node, () => undefined)
      if (Number.isFinite(v)) return { kind: 'num', value: v }
    } catch {
      /* keep the original subtree */
    }
    return node
  }
  switch (node.kind) {
    case 'unary':
      return { ...node, arg: foldConstants(node.arg) }
    case 'binary':
      return { ...node, left: foldConstants(node.left), right: foldConstants(node.right) }
    case 'call':
      return { ...node, args: node.args.map(foldConstants) }
    default:
      return node
  }
}

const PREC: Record<string, number> = { '+': 1, '-': 1, '*': 2, '/': 2, '^': 4 }

/** Canonical, minimal-parentheses rendering in CIMA syntax. */
export function formatExpr(node: ExprNode): string {
  const fmt = (n: ExprNode, parentPrec: number, rightSide: boolean): string => {
    switch (n.kind) {
      case 'num':
        return formatNumber(n.value)
      case 'ident':
        return n.name
      case 'call':
        return `${n.fn}(${n.args.map((a) => fmt(a, 0, false)).join(', ')})`
      case 'unary': {
        const s = `${n.op}${fmt(n.arg, 3, false)}`
        return parentPrec > 3 ? `(${s})` : s
      }
      case 'binary': {
        const p = PREC[n.op]!
        const rightAssoc = n.op === '^'
        const l = fmt(n.left, rightAssoc ? p + 1 : p, false)
        const r = fmt(n.right, rightAssoc ? p : p + 1, true)
        const s = `${l} ${n.op} ${r}`
        return p < parentPrec || (p === parentPrec && rightSide && !rightAssoc) ? `(${s})` : s
      }
    }
  }
  return fmt(node, 0, false)
}

export function formatNumber(v: number): string {
  if (Number.isInteger(v)) return String(v)
  const s = Number(v.toPrecision(12)).toString()
  return s.includes('e') ? v.toFixed(12).replace(/0+$/, '').replace(/\.$/, '') : s
}

// ---------------------------------------------------------------------------
// Dimensional rendering (for CAD formula languages such as CATIA knowledgeware)
// ---------------------------------------------------------------------------

/** Physical dimension of an expression: Length, Angle, None (dimensionless), or unknown literal. */
export type Dim = 'L' | 'A' | 'N'

export interface FormulaRenderOptions {
  /** Dimension of each parameter referenced by the expression. */
  dimOf: (name: string) => Dim | undefined
  /** Renders a parameter reference (e.g. quoting). */
  ident?: (name: string) => string
  /** Renders a numeric literal that must carry the given dimension (e.g. 5 + L -> "5mm"). */
  literal?: (value: number, dim: Dim) => string
  /** Function name mapping; return null when the target language lacks the function (rendering then fails). */
  fn?: (name: string) => string | null
  /** Power operator token, default "^". */
  power?: string
  /** Rendering of the pi constant, default "PI". */
  pi?: string
}

/**
 * Renders an expression in a dimension-aware formula language: numeric literals get units
 * inferred from their context (lengths "mm", angles "deg"); scale factors stay unit-less.
 * Returns null if the expression cannot be represented (unknown function, inconsistent units).
 */
export function renderFormula(src: number | string, target: Dim, opts: FormulaRenderOptions): string | null {
  const root = typeof src === 'number' ? ({ kind: 'num', value: src } as ExprNode) : foldConstants(parseExpr(src))
  const ident = opts.ident ?? ((n: string) => n)
  const literal =
    opts.literal ?? ((v: number, d: Dim) => (d === 'L' ? `${formatNumber(v)}mm` : d === 'A' ? `${formatNumber(v)}deg` : formatNumber(v)))
  const power = opts.power ?? '^'
  const pi = opts.pi ?? 'PI'
  let failed = false

  /** Best-effort dimension of a subtree; undefined = free literal / unknown. */
  const dimOf = (n: ExprNode): Dim | undefined => {
    switch (n.kind) {
      case 'num':
        return undefined
      case 'ident':
        if (n.name === 'pi' || n.name === 'PI') return 'N'
        return opts.dimOf(n.name)
      case 'unary':
        return dimOf(n.arg)
      case 'binary': {
        const l = dimOf(n.left)
        const r = dimOf(n.right)
        if (n.op === '+' || n.op === '-') return l ?? r
        if (n.op === '*') {
          if (l === undefined) return r === 'N' ? undefined : r
          if (r === undefined) return l === 'N' ? undefined : l
          if (l === 'N') return r
          if (r === 'N') return l
          return undefined // L*L etc. — not representable as a simple dimension
        }
        if (n.op === '/') {
          if (l !== undefined && l === r) return 'N'
          if (r === 'N' || r === undefined) return l
          return undefined
        }
        return 'N'
      }
      case 'call':
        if (['sin', 'cos', 'tan'].includes(n.fn)) return 'N'
        if (['asin', 'acos', 'atan', 'atan2'].includes(n.fn)) return 'A'
        if (n.fn === 'sqrt') return 'N'
        return n.args.map(dimOf).find((d) => d !== undefined)
    }
  }

  const wrap = (s: string) => `(${s})`

  const render = (n: ExprNode, expected: Dim): string => {
    switch (n.kind) {
      case 'num':
        return n.value < 0 ? wrap(literal(n.value, expected)) : literal(n.value, expected)
      case 'ident':
        if (n.name === 'pi' || n.name === 'PI') return pi
        return ident(n.name)
      case 'unary':
        return n.op === '-' ? `-${wrapIfBinary(n.arg, expected)}` : render(n.arg, expected)
      case 'binary': {
        const l = dimOf(n.left)
        const r = dimOf(n.right)
        if (n.op === '+' || n.op === '-') {
          const d = l ?? r ?? expected
          return wrap(`${render(n.left, d)} ${n.op} ${render(n.right, d)}`)
        }
        if (n.op === '*') {
          // A free side (literal, or a dimensionless sub-expression containing a literal) carries the
          // expected dimension only when the other side is dimensionless; otherwise it is a scale factor.
          let dl: Dim
          let dr: Dim
          if (l !== undefined && r !== undefined) {
            dl = l
            dr = r
          } else if (l === undefined && r !== undefined) {
            dl = r === 'N' ? expected : 'N'
            dr = r
          } else if (l !== undefined && r === undefined) {
            dl = l
            dr = l === 'N' ? expected : 'N'
          } else {
            dl = expected
            dr = 'N'
          }
          return wrap(`${render(n.left, dl)} * ${render(n.right, dr)}`)
        }
        if (n.op === '/') {
          const dr: Dim = r ?? 'N'
          let dl: Dim
          if (l !== undefined) dl = l
          else if (dr === 'N') dl = expected
          else if (expected === 'N') dl = dr
          else dl = 'N'
          return wrap(`${render(n.left, dl)} / ${render(n.right, dr)}`)
        }
        // power: both dimensionless
        return wrap(`${render(n.left, 'N')} ${power} ${render(n.right, 'N')}`)
      }
      case 'call': {
        const name = opts.fn ? opts.fn(n.fn) : n.fn
        if (name === null) {
          failed = true
          return ''
        }
        let argDim: Dim = expected
        if (['sin', 'cos', 'tan'].includes(n.fn)) argDim = 'A'
        else if (['asin', 'acos', 'atan', 'atan2', 'sqrt'].includes(n.fn)) argDim = 'N'
        if (n.fn === 'atan2') {
          const d = n.args.map(dimOf).find((x) => x !== undefined) ?? 'N'
          argDim = d
        }
        return `${name}(${n.args.map((a) => render(a, argDim)).join(', ')})`
      }
    }
  }

  const wrapIfBinary = (n: ExprNode, expected: Dim): string => {
    const s = render(n, expected)
    return n.kind === 'binary' && !s.startsWith('(') ? wrap(s) : s
  }

  const rootDim = dimOf(root)
  if (rootDim !== undefined && rootDim !== target) {
    // e.g. assigning an angle expression to a length — refuse, caller falls back to a plain value.
    return null
  }
  const out = render(root, target)
  if (failed) return null
  // Strip one redundant outer pair of parentheses.
  return out.startsWith('(') && matchingParen(out, 0) === out.length - 1 ? out.slice(1, -1) : out
}

function matchingParen(s: string, open: number): number {
  let depth = 0
  for (let i = open; i < s.length; i++) {
    if (s[i] === '(') depth++
    else if (s[i] === ')') {
      depth--
      if (depth === 0) return i
    }
  }
  return -1
}
