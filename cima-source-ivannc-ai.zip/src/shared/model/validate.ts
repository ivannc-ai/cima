/**
 * Validation of CIMA models: schema (Zod) + semantic checks + evaluation of every expression.
 * Issue messages are in English because they are fed back to the LLM in repair loops.
 */
import type { ZodError } from 'zod'
import { CadModelSchema, PATTERNABLE_TYPES, type CadModel, type Feature, type Part } from './schema'
import { RESERVED_NAMES, identifiersOf, parseExpr, ExprError } from './expr'
import { modelContext, partContext, resolveModelParameters, type EvalContext } from './evaluate'
import {
  instanceTransform,
  planeFrame,
  resolveEdgeSelector,
  resolveFaceSelector,
  resolvePositions,
  resolveSketch,
} from './geometry'

export interface Issue {
  severity: 'error' | 'warning'
  path: string
  message: string
}

export interface ValidationResult {
  ok: boolean
  model?: CadModel
  issues: Issue[]
}

/** Recursively converts null to undefined (strict-mode LLM outputs use null for "absent"). */
export function stripNulls<T>(value: T): T {
  if (value === null) return undefined as T
  if (Array.isArray(value)) return value.map((v) => stripNulls(v)) as T
  if (typeof value === 'object' && value !== undefined) {
    const out: Record<string, unknown> = {}
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (v === null || v === undefined) continue
      out[k] = stripNulls(v)
    }
    return out as T
  }
  return value
}

function zodIssues(err: ZodError): Issue[] {
  return err.issues.map((i) => ({
    severity: 'error' as const,
    path: i.path.map(String).join('.') || '(root)',
    message: i.message,
  }))
}

/** Parses and fully validates an unknown value (object or JSON string) as a CadModel. */
export function validateModel(input: unknown): ValidationResult {
  let raw = input
  if (typeof raw === 'string') {
    try {
      raw = JSON.parse(raw)
    } catch (e) {
      return { ok: false, issues: [{ severity: 'error', path: '(root)', message: `Invalid JSON: ${(e as Error).message}` }] }
    }
  }
  const parsed = CadModelSchema.safeParse(stripNulls(raw))
  if (!parsed.success) return { ok: false, issues: zodIssues(parsed.error) }
  const model = parsed.data
  const issues = semanticIssues(model)
  return { ok: !issues.some((i) => i.severity === 'error'), model, issues }
}

/** Keys whose values are expressions (or arrays / arrays of arrays of expressions). */
const EXPR_KEYS = new Set([
  'offset', 'origin', 'center', 'width', 'height', 'cornerRadius', 'angle', 'diameter', 'points', 'start', 'end',
  'to', 'via', 'count', 'step', 'count2', 'step2', 'totalAngle', 'length', 'length2', 'depth', 'positions',
  'headDiameter', 'headDepth', 'headAngle', 'radius', 'distance', 'thickness', 'spacing', 'spacing2', 'at',
  'min', 'max', 'position',
])

/** Calls cb for every expression string found under an expression key. */
function forEachExprString(node: unknown, path: string, cb: (expr: string, path: string) => void, key?: string): void {
  if (typeof node === 'string') {
    if (key !== undefined && EXPR_KEYS.has(key)) cb(node, path)
    return
  }
  if (Array.isArray(node)) {
    node.forEach((v, i) => forEachExprString(v, `${path}[${i}]`, cb, key))
    return
  }
  if (node && typeof node === 'object') {
    for (const [k, v] of Object.entries(node)) forEachExprString(v, path ? `${path}.${k}` : k, cb, k)
  }
}

export function semanticIssues(model: CadModel): Issue[] {
  const issues: Issue[] = []
  const err = (path: string, message: string) => issues.push({ severity: 'error', path, message })
  const warn = (path: string, message: string) => issues.push({ severity: 'warning', path, message })

  // --- kind / structure ---------------------------------------------------
  if (model.kind === 'part') {
    if (model.parts.length !== 1) err('parts', `kind "part" requires exactly one part (found ${model.parts.length}). Use kind "assembly" for several parts.`)
    if (model.instances && model.instances.length > 0) warn('instances', 'instances are ignored for kind "part".')
  } else {
    if (!model.instances || model.instances.length === 0) err('instances', 'kind "assembly" requires at least one instance.')
  }

  // --- parameters -----------------------------------------------------------
  const modelNames = new Set<string>()
  model.parameters.forEach((p, i) => {
    const path = `parameters[${i}]`
    if (RESERVED_NAMES.has(p.name)) err(`${path}.name`, `"${p.name}" is a reserved name.`)
    if (modelNames.has(p.name)) err(`${path}.name`, `duplicate parameter "${p.name}".`)
    modelNames.add(p.name)
    if (p.min !== undefined && p.max !== undefined && p.min > p.max) warn(path, 'min is greater than max.')
    if (!p.expression && ((p.min !== undefined && p.value < p.min) || (p.max !== undefined && p.value > p.max))) {
      warn(path, `value ${p.value} is outside [${p.min ?? '-inf'}, ${p.max ?? 'inf'}].`)
    }
  })

  // --- ids ------------------------------------------------------------------------
  const partIds = new Set<string>()
  model.parts.forEach((part, pi) => {
    if (partIds.has(part.id)) err(`parts[${pi}].id`, `duplicate part id "${part.id}".`)
    partIds.add(part.id)
  })

  // --- parameter resolution (derived expressions, cycles) ------------------------------
  const resolution = resolveModelParameters(model)
  resolution.errors.forEach((m) => err('parameters', m))

  // --- parts -----------------------------------------------------------------------
  model.parts.forEach((part, pi) => partIssues(model, part, `parts[${pi}]`, modelNames, resolution, err, warn))

  // --- instances ----------------------------------------------------------------------
  if (model.kind === 'assembly' && model.instances) {
    const ids = new Set<string>()
    const used = new Set<string>()
    const mctx = modelContext(model, resolution)
    model.instances.forEach((inst, ii) => {
      const path = `instances[${ii}]`
      if (ids.has(inst.id)) err(`${path}.id`, `duplicate instance id "${inst.id}".`)
      ids.add(inst.id)
      if (!partIds.has(inst.part)) err(`${path}.part`, `unknown part "${inst.part}". Known parts: ${[...partIds].join(', ')}.`)
      used.add(inst.part)
      checkExprs(inst, path, mctx, err)
      try {
        instanceTransform(inst, mctx)
      } catch (e) {
        err(path, (e as Error).message)
      }
    })
    model.parts.forEach((p, pi) => {
      if (!used.has(p.id)) warn(`parts[${pi}]`, `part "${p.id}" is not used by any instance.`)
    })
  }

  return issues
}

function checkExprs(node: unknown, path: string, ctx: EvalContext, err: (p: string, m: string) => void): void {
  forEachExprString(node, path, (expr, p) => {
    try {
      const ast = parseExpr(expr)
      for (const id of identifiersOf(ast)) {
        if (!ctx.has(id)) err(p, `unknown parameter "${id}" in expression "${expr}". Available: ${ctx.names().join(', ') || '(none)'}.`)
      }
    } catch (e) {
      err(p, `invalid expression "${expr}": ${(e as Error).message}`)
    }
  })
}

function partIssues(
  model: CadModel,
  part: Part,
  base: string,
  modelNames: Set<string>,
  resolution: ReturnType<typeof resolveModelParameters>,
  err: (p: string, m: string) => void,
  warn: (p: string, m: string) => void,
): void {
  const names = new Set<string>()
  part.parameters.forEach((p, i) => {
    const path = `${base}.parameters[${i}]`
    if (RESERVED_NAMES.has(p.name)) err(`${path}.name`, `"${p.name}" is a reserved name.`)
    if (names.has(p.name)) err(`${path}.name`, `duplicate parameter "${p.name}" in part "${part.id}".`)
    if (modelNames.has(p.name)) err(`${path}.name`, `parameter "${p.name}" is already defined at model level.`)
    names.add(p.name)
  })

  const ctx = partContext(model, part.id, resolution)
  const featureIds = new Map<string, { index: number; feature: Feature }>()
  let sawSolid = false

  part.features.forEach((f, fi) => {
    const path = `${base}.features[${fi}]`
    if (featureIds.has(f.id)) err(`${path}.id`, `duplicate feature id "${f.id}" in part "${part.id}".`)
    featureIds.set(f.id, { index: fi, feature: f })
    checkExprs(f, path, ctx, err)
    if (f.suppressed) return

    if (!sawSolid) {
      if (f.type === 'pad' || f.type === 'shaft') sawSolid = true
      else err(path, `the first active feature must be a pad or a shaft (found "${f.type}").`)
    }

    // Geometry-level checks with default parameter values.
    try {
      switch (f.type) {
        case 'pad':
          resolveSketch(f.sketch, ctx, `${path}.sketch`)
          ctx.pos(f.length, `${path}.length`)
          if (f.length2 !== undefined) {
            if (f.direction === 'symmetric') warn(`${path}.length2`, 'length2 is ignored with direction "symmetric".')
            ctx.n(f.length2, `${path}.length2`)
          }
          break
        case 'pocket':
          resolveSketch(f.sketch, ctx, `${path}.sketch`)
          if (!f.throughAll && f.depth === undefined) err(path, 'pocket needs "depth" or "throughAll": true.')
          if (f.depth !== undefined && !f.throughAll) ctx.pos(f.depth, `${path}.depth`)
          break
        case 'shaft':
        case 'groove': {
          const sk = resolveSketch(f.sketch, ctx, `${path}.sketch`)
          if (f.angle !== undefined) {
            const a = ctx.n(f.angle, `${path}.angle`)
            if (!(a > 0 && a <= 360)) err(`${path}.angle`, `angle must be in (0, 360] (got ${a}).`)
          }
          // The profile must stay on one side of the revolution axis.
          const idx = f.axis === 'u' ? 1 : 0
          let pos = false
          let neg = false
          for (const loop of sk.loops) {
            const pts = loop.kind === 'circle'
              ? [[loop.center[0] - loop.radius, loop.center[1] - loop.radius], [loop.center[0] + loop.radius, loop.center[1] + loop.radius]]
              : loop.segments.flatMap((s) => (s.kind === 'arc' ? [s.from, s.mid, s.to] : [s.from, s.to]))
            for (const p of pts) {
              if (p[idx]! > 1e-6) pos = true
              if (p[idx]! < -1e-6) neg = true
            }
          }
          if (pos && neg) err(`${path}.sketch`, `the profile crosses the revolution axis "${f.axis}"; keep it on one side (e.g. all ${f.axis === 'u' ? 'v' : 'u'} >= 0).`)
          break
        }
        case 'hole': {
          planeFrame(f.plane, ctx, `${path}.plane`)
          resolvePositions(f.positions, f.repeat, ctx, path)
          const d = ctx.pos(f.diameter, `${path}.diameter`)
          if (!f.throughAll && f.depth === undefined) err(path, 'hole needs "depth" or "throughAll": true.')
          if (f.depth !== undefined && !f.throughAll) ctx.pos(f.depth, `${path}.depth`)
          const kind = f.kind ?? 'simple'
          if (kind !== 'simple') {
            if (f.headDiameter === undefined) err(path, `${kind} hole needs "headDiameter".`)
            else if (ctx.pos(f.headDiameter, `${path}.headDiameter`) <= d) err(`${path}.headDiameter`, 'headDiameter must be larger than diameter.')
            if (kind === 'counterbored') {
              if (f.headDepth === undefined) err(path, 'counterbored hole needs "headDepth".')
              else ctx.pos(f.headDepth, `${path}.headDepth`)
            }
          }
          break
        }
        case 'fillet':
          resolveEdgeSelector(f.edges, ctx, `${path}.edges`)
          ctx.pos(f.radius, `${path}.radius`)
          break
        case 'chamfer':
          resolveEdgeSelector(f.edges, ctx, `${path}.edges`)
          ctx.pos(f.distance, `${path}.distance`)
          break
        case 'shell':
          resolveFaceSelector(f.openFaces, ctx, `${path}.openFaces`)
          ctx.pos(f.thickness, `${path}.thickness`)
          break
        case 'mirror':
          break
        case 'linearPattern':
        case 'circularPattern': {
          for (const ref of f.features) {
            const target = featureIds.get(ref)
            if (!target) err(`${path}.features`, `"${ref}" must be the id of an earlier feature.`)
            else if (!PATTERNABLE_TYPES.includes(target.feature.type)) {
              err(`${path}.features`, `"${ref}" is a ${target.feature.type}; only ${PATTERNABLE_TYPES.join('/')} features can be patterned.`)
            } else if (target.feature.suppressed) warn(`${path}.features`, `"${ref}" is suppressed.`)
          }
          ctx.int(f.count, `${path}.count`)
          if (f.type === 'linearPattern') {
            ctx.n(f.spacing, `${path}.spacing`)
            if (f.direction.every((c) => Math.abs(c) < 1e-12)) err(`${path}.direction`, 'direction must not be zero.')
            const has2 = [f.direction2, f.count2, f.spacing2].filter((x) => x !== undefined).length
            if (has2 > 0 && has2 < 3) err(path, 'direction2, count2 and spacing2 must be given together.')
            if (f.count2 !== undefined) ctx.int(f.count2, `${path}.count2`)
          } else if (f.totalAngle !== undefined) {
            ctx.n(f.totalAngle, `${path}.totalAngle`)
          }
          break
        }
      }
    } catch (e) {
      if (e instanceof ExprError || e instanceof Error) err(path, e.message)
    }
  })

  if (!sawSolid) err(`${base}.features`, `part "${part.id}" has no active pad or shaft.`)
}
