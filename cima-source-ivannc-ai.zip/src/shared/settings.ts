/** Application settings (public view — API keys are stored encrypted in the main process only). */
import type { Effort, ProviderConfig } from './ai/types'
import type { CatiaTarget } from './catia/types'

export interface AiSettings {
  /** Reasoning effort for providers that support it (Anthropic). */
  effort: Effort
  /** Automatic repair rounds when the generated model is invalid or fails to build. */
  maxRepairAttempts: number
  /** Enable Anthropic server-side refusal fallbacks (only used with models that support them). */
  refusalFallback: boolean
  /** Show summarized reasoning in the chat when the provider returns it. */
  showThinking: boolean
  /** Offer the parametric template library to the AI (tool use_cad_template). */
  templates: boolean
  /** Audit generated models against the request (dimensions, holes...) and geometric sanity. */
  audit: boolean
}

export interface CatiaSettings {
  /** 'auto' = detect the running CATIA. */
  target: CatiaTarget | 'auto'
  connect: 'attach' | 'launch'
  createParameters: boolean
  createFormulas: boolean
  applyColors: boolean
  saveDirectory: string
  exportStep: boolean
  timeoutSec: number
}

export interface ViewerSettings {
  showEdges: boolean
  showGrid: boolean
  showAxes: boolean
}

export interface AppSettings {
  language: 'es' | 'en'
  activeProviderId: string
  providers: ProviderConfig[]
  ai: AiSettings
  catia: CatiaSettings
  viewer: ViewerSettings
}

export type SettingsPatch = {
  language?: AppSettings['language']
  activeProviderId?: string
  /** Partial updates of existing providers (matched by id) or new custom providers. */
  providers?: Array<Partial<ProviderConfig> & { id: string }>
  /** Remove custom providers by id. */
  removeProviders?: string[]
  ai?: Partial<AiSettings>
  catia?: Partial<CatiaSettings>
  viewer?: Partial<ViewerSettings>
}

export const DEFAULT_PROVIDERS: ProviderConfig[] = [
  {
    id: 'anthropic',
    kind: 'anthropic',
    label: 'Anthropic Claude',
    model: 'claude-opus-5-5',
    models: ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-5-5', 'claude-fable-5-2'],
    hasApiKey: false,
    requiresApiKey: true,
    enabled: true,
  },
  {
    id: 'openai',
    kind: 'openai',
    label: 'OpenAI',
    model: 'gpt-5.1',
    models: ['gpt-5.1', 'gpt-5-mini'],
    hasApiKey: false,
    requiresApiKey: true,
    enabled: true,
  },
  {
    id: 'gemini',
    kind: 'gemini',
    label: 'Google Gemini',
    baseURL: 'https://generativelanguage.googleapis.com/v1beta/openai/',
    model: 'gemini-2.5-pro',
    models: ['gemini-2.5-pro', 'gemini-2.5-flash'],
    hasApiKey: false,
    requiresApiKey: true,
    enabled: true,
  },
  {
    id: 'ollama',
    kind: 'ollama',
    label: 'Ollama (local)',
    baseURL: 'http://localhost:11434/v1',
    model: 'qwen3:32b',
    models: ['qwen3:32b', 'llama3.3:70b', 'gpt-oss:20b'],
    hasApiKey: false,
    requiresApiKey: false,
    enabled: true,
  },
]

export const DEFAULT_SETTINGS: AppSettings = {
  language: 'es',
  activeProviderId: 'anthropic',
  providers: DEFAULT_PROVIDERS,
  ai: { effort: 'high', maxRepairAttempts: 3, refusalFallback: true, showThinking: true, templates: true, audit: true },
  catia: {
    target: 'auto',
    connect: 'attach',
    createParameters: true,
    createFormulas: true,
    applyColors: true,
    saveDirectory: '',
    exportStep: false,
    timeoutSec: 600,
  },
  viewer: { showEdges: true, showGrid: true, showAxes: true },
}
