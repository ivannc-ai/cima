/**
 * Contracts of the CATIA connectors (V5 and 3DEXPERIENCE).
 *
 * Flow: renderer -> main (CatiaPushRequest) -> script generator (shared, pure TS) -> cscript.exe
 * -> CATIA COM automation. The generated script reports progress on stdout using lines that start
 * with CATIA_LINE_PREFIX followed by a JSON payload (CatiaScriptEvent).
 */
import type { CadModel } from '../model/schema'
import type { ParamOverrides } from '../model/evaluate'

export type CatiaTarget = 'v5' | '3dx'

/** Local start model (Documents.NewFrom template) listed in the CATIA tab. */
export interface CatiaStartModel {
  /** File name without extension (shown in the UI). */
  name: string
  /** Absolute path of the template file. */
  path: string
  type: 'part' | 'product'
}

export interface CatiaScriptOptions {
  target: CatiaTarget
  /** 'vbs' = external script run by cscript (attaches via COM); 'catscript' = macro run inside CATIA. */
  flavor: 'vbs' | 'catscript'
  /** External scripts only: attach to a running CATIA, or start one if none is running. */
  connect: 'attach' | 'launch'
  /** Create CATIA user parameters for the model parameters. */
  createParameters: boolean
  /** Drive feature dimensions with formulas referencing the user parameters. */
  createFormulas: boolean
  /** Apply part colors. */
  applyColors: boolean
  /** If set, save the documents (CATPart / CATProduct) into this folder (V5 only). */
  saveDirectory?: string
  /** If set together with saveDirectory, also export a STEP file of the root document. */
  exportStep?: boolean
  /** V5 only: path of a local .CATPart / .CATProduct start model, opened with Documents.NewFrom instead of an empty document. */
  startModel?: string
  /** V5 only: custom name for the Part/Product created from the start model; overrides the model's part name (PartNumber, saved file name). */
  startModelName?: string
}

export interface CatiaScriptRequest {
  model: CadModel
  overrides: ParamOverrides
  options: CatiaScriptOptions
}

export interface CatiaPushRequest extends CatiaScriptRequest {
  jobId: string
  /** Kill cscript after this many milliseconds (default 10 minutes). */
  timeoutMs?: number
}

/** Prefix of machine-readable stdout lines emitted by generated scripts. */
export const CATIA_LINE_PREFIX = '@@CIMA@@'

/** Payload of a machine-readable line (JSON after the prefix). */
export type CatiaScriptEvent =
  | { t: 'start'; target: CatiaTarget; version?: string }
  | { t: 'log'; level: 'info' | 'warn' | 'error'; msg: string }
  | { t: 'part'; part: string; status: 'start' | 'ok' | 'error'; msg?: string }
  | { t: 'feature'; part: string; feature: string; status: 'ok' | 'error' | 'skipped'; msg?: string }
  | { t: 'saved'; path: string }
  | { t: 'end'; ok: boolean; errors: number; warnings: number }

export type CatiaJobEvent =
  | { jobId: string; type: 'script'; event: CatiaScriptEvent }
  | { jobId: string; type: 'stdout'; line: string }
  | { jobId: string; type: 'stderr'; line: string }

export interface CatiaFeatureResult {
  part: string
  feature: string
  status: 'ok' | 'error' | 'skipped'
  msg?: string
}

export interface CatiaJobResult {
  jobId: string
  ok: boolean
  exitCode: number | null
  cancelled: boolean
  timedOut: boolean
  durationMs: number
  features: CatiaFeatureResult[]
  errors: string[]
  warnings: string[]
  savedFiles: string[]
  /** Path of the script that was executed (kept for troubleshooting). */
  scriptPath?: string
}

export interface CatiaStatus {
  /** CATIA automation is only possible on Windows. */
  platformSupported: boolean
  cscriptAvailable: boolean
  /** True if a CATIA session answered on COM. */
  running: boolean
  target?: CatiaTarget
  /** Human readable version, e.g. "V5-6R2022 SP3" or "3DEXPERIENCE R2024x". */
  version?: string
  activeDocument?: { name: string; type: string }
  /** Full path of the active document, when available (V5). */
  docPath?: string
  /** Session context from the CATIA window caption: program code (e.g. DERIVAIR), department and user. */
  program?: string
  department?: string
  user?: string
  host?: string
  error?: string
}

export interface CatiaParameterInfo {
  name: string
  value: string
  /** Numeric value in model units (mm / deg) when the parameter is numeric. */
  numeric?: number
  kind?: string
  userParameter: boolean
}

export interface CatiaInspection {
  ok: boolean
  documentName?: string
  documentType?: string
  parameters: CatiaParameterInfo[]
  error?: string
}

export interface CatiaSetParametersRequest {
  values: Array<{ name: string; value: number }>
}
