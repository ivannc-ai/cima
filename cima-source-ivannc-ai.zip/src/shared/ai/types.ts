/**
 * Provider-neutral chat types shared by the renderer (conversation / agent loop) and the
 * main process (provider adapters). API keys never leave the main process.
 */

export type ProviderKind = 'anthropic' | 'openai' | 'gemini' | 'ollama' | 'openai-compatible'

export type Effort = 'low' | 'medium' | 'high' | 'xhigh' | 'max'

/** Public view of a provider configuration (no secrets). */
export interface ProviderConfig {
  /** Stable id: "anthropic", "openai", "gemini", "ollama" or "custom-<n>". */
  id: string
  kind: ProviderKind
  label: string
  /** Endpoint override (required for ollama / openai-compatible). */
  baseURL?: string
  /** HTTP proxy for this provider: http(s)://[user:pass@]host:port (OpenAI-compatible only). */
  proxy?: string
  /** CA certificate to trust this endpoint's TLS chain: PEM content or a path to a .pem/.crt file (OpenAI-compatible only). */
  caCertificate?: string
  /** Default model id for this provider. */
  model: string
  /** Suggested model ids shown in the UI (free text is also allowed). */
  models: string[]
  /** True when an API key is stored (encrypted) in the main process. */
  hasApiKey: boolean
  /** Whether the provider needs an API key at all (ollama does not). */
  requiresApiKey: boolean
  enabled: boolean
}

export type ImageMediaType = 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif'

export type ChatContentPart =
  | { type: 'text'; text: string }
  | { type: 'image'; mediaType: ImageMediaType; /** base64 without data: prefix */ data: string; name?: string }

export interface ToolCall {
  id: string
  name: string
  input: unknown
}

export interface ToolResult {
  toolCallId: string
  /** Text returned to the model (validation errors, build report...). */
  content: string
  isError: boolean
}

/**
 * Provider-native content of an assistant turn. Replayed verbatim when the next request goes to the
 * same provider kind + model family, so that provider-specific blocks (e.g. Anthropic thinking /
 * fallback blocks, which must be passed back unchanged) survive the round trip.
 */
export interface ProviderRaw {
  providerKind: ProviderKind
  model: string
  content: unknown
}

export interface UserMessage {
  role: 'user'
  content: ChatContentPart[]
  /** Results for the tool calls of the previous assistant message (must come first when present). */
  toolResults?: ToolResult[]
}

export interface AssistantMessage {
  role: 'assistant'
  text: string
  /** Summarized reasoning, when the provider returns it. Display only. */
  thinking?: string
  toolCalls?: ToolCall[]
  raw?: ProviderRaw
}

export type ChatMessage = UserMessage | AssistantMessage

export interface ChatRequest {
  requestId: string
  providerId: string
  /** Model override; defaults to the provider's configured model. */
  model?: string
  messages: ChatMessage[]
}

export interface TokenUsage {
  inputTokens?: number
  outputTokens?: number
  cacheReadTokens?: number
  cacheWriteTokens?: number
}

export type StopReason = 'end_turn' | 'tool_use' | 'max_tokens' | 'refusal' | 'cancelled' | 'other'

export type ChatStreamEvent =
  | { requestId: string; type: 'start'; model: string }
  | { requestId: string; type: 'text_delta'; text: string }
  | { requestId: string; type: 'thinking_delta'; text: string }
  /** Emitted while a tool call's JSON input streams in (bytes received so far). */
  | { requestId: string; type: 'tool_progress'; name?: string; bytes: number }
  | { requestId: string; type: 'done'; message: AssistantMessage; stopReason: StopReason; usage?: TokenUsage }
  | { requestId: string; type: 'error'; error: { message: string; code?: string; retryable?: boolean } }

/** Name of the single tool through which the LLM emits a CIMA model. */
export const CAD_TOOL_NAME = 'emit_cad_model'

/**
 * Automatic follow-up sent by the renderer when the model described a design but did not call the
 * tool. Providers that support it force the tool call on the request whose last user message is this text.
 */
export const TOOL_NUDGE_TEXT =
  `You described the design but did not call ${CAD_TOOL_NAME}. Call ${CAD_TOOL_NAME} now with the COMPLETE model ` +
  '(all parameters, parts and features). Do not answer with text only.'
