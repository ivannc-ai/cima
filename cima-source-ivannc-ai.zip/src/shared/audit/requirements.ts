/**
 * Extracts checkable requirements from the user's request (Spanish or English): overall dimensions
 * ("120x80x40"), hole counts ("6 taladros"), diameters ("Ø35", "diámetro 60") and thicknesses
 * ("pared de 2.5", "espesor 10"). Deliberately conservative: only explicit, unambiguous numbers.
 */

export interface Requirements {
  /** Overall dimensions as written (2 or 3 values, mm). */
  dims?: number[]
  /** Total number of holes requested. */
  holeCount?: number
  diameters: number[]
  thicknesses: number[]
}

const NUM = '(\\d+(?:[.,]\\d+)?)'
const toNum = (s: string) => Number(s.replace(',', '.'))

const WORDS: Record<string, number> = {
  un: 1, uno: 1, una: 1, dos: 2, tres: 3, cuatro: 4, cinco: 5, seis: 6, siete: 7, ocho: 8, nueve: 9, diez: 10, doce: 12,
  one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, twelve: 12,
}

export function extractRequirements(text: string): Requirements {
  const t = text.toLowerCase()
  const req: Requirements = { diameters: [], thicknesses: [] }

  const dm = new RegExp(`${NUM}\\s*(?:mm)?\\s*[x×*]\\s*${NUM}(?:\\s*(?:mm)?\\s*[x×*]\\s*${NUM})?`).exec(t)
  if (dm) req.dims = [dm[1], dm[2], dm[3]].filter((x): x is string => !!x).map(toNum)

  const holeRe = new RegExp(`(\\d+|${Object.keys(WORDS).join('|')})\\s+(?:taladros?|agujeros?|orificios?|holes?|tornillos?|bolts?)\\b`, 'g')
  let total = 0
  let found = false
  for (const m of t.matchAll(holeRe)) {
    const n = /^\d+$/.test(m[1]!) ? Number(m[1]) : WORDS[m[1]!]
    if (n) {
      total += n
      found = true
    }
  }
  if (found) req.holeCount = total

  const diaRe = new RegExp(`(?:ø|⌀|di[aá]metro(?:\\s+(?:exterior|interior|de\\s+\\w+))?|diameter|\\bdia\\.?)\\s*(?:de\\s*|of\\s*|=\\s*)?${NUM}`, 'g')
  for (const m of t.matchAll(diaRe)) req.diameters.push(toNum(m[1]!))

  const thRe = new RegExp(`(?:espesor|grosor|pared|thickness|wall)(?:\\s+(?:de|del|of))?(?:\\s+\\w+)?\\s*(?:de\\s*|=\\s*)?${NUM}`, 'g')
  for (const m of t.matchAll(thRe)) req.thicknesses.push(toNum(m[1]!))

  return req
}

/** True if `value` matches `target` within a relative tolerance (and 0.05 mm absolute). */
export function near(value: number, target: number, rel = 0.01): boolean {
  return Math.abs(value - target) <= Math.max(0.05, Math.abs(target) * rel)
}
