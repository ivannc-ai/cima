/**
 * Generation audit: checks a built model against the user's request and basic geometric sanity.
 * Findings with `fix: true` are sent back to the LLM for an automatic correction round; the others
 * are only shown to the user.
 */
import { measureDistanceBetween, measureVolume, type Shape3D } from 'replicad'
import type { CadModel } from '../shared/model/schema'
import { evaluateExpr } from '../shared/model/expr'
import { partContext } from '../shared/model/evaluate'
import { resolvePositions } from '../shared/model/geometry'
import { extractRequirements, near, type Requirements } from '../shared/audit/requirements'
import { placeShape, type ModelBuildResult } from './builder'

export interface AuditFinding {
  severity: 'error' | 'warning' | 'info'
  code: 'dims' | 'holes' | 'diameter' | 'thickness' | 'disconnected' | 'no_effect' | 'interference' | 'floating' | 'skipped'
  /** Spanish message for the user. */
  message: string
  /** English message for the LLM. */
  llm: string
  /** Whether the LLM should be asked to fix it automatically. */
  fix: boolean
  part?: string
}

const fmt = (n: number) => String(Math.round(n * 100) / 100)

/** Every number the model mentions: parameter values and every evaluable dimension in its features. */
function modelNumbers(model: CadModel, built: ModelBuildResult): number[] {
  const out: number[] = []
  for (const p of built.resolution.params) out.push(p.value)
  for (const part of model.parts) {
    const values = built.resolution.partValues.get(part.id)
    const scope = (n: string) => values?.get(n)
    const walk = (node: unknown, key?: string) => {
      if (typeof node === 'number') out.push(node)
      else if (typeof node === 'string' && key !== 'id' && key !== 'name' && key !== 'type') {
        try {
          out.push(evaluateExpr(node, scope))
        } catch {
          /* not an expression */
        }
      } else if (Array.isArray(node)) node.forEach((n) => walk(n, key))
      else if (node && typeof node === 'object') for (const [k, v] of Object.entries(node)) walk(v, k)
    }
    walk(part.features)
  }
  return out
}

function holeCount(model: CadModel, built: ModelBuildResult): number {
  let n = 0
  const instancesOf = (partId: string) => (model.kind === 'assembly' ? (model.instances ?? []).filter((i) => i.part === partId).length : 1)
  for (const part of model.parts) {
    const ctx = partContext(model, part.id, built.resolution)
    let perPart = 0
    for (const f of part.features) {
      if (f.type !== 'hole' || f.suppressed) continue
      try {
        perPart += resolvePositions(f.positions, f.repeat, ctx, f.id).length
      } catch {
        /* reported elsewhere */
      }
    }
    n += perPart * instancesOf(part.id)
  }
  return n
}

export function auditModel(model: CadModel, built: ModelBuildResult, request?: string): AuditFinding[] {
  const findings: AuditFinding[] = []
  const byId = new Map(built.parts.map((p) => [p.partId, p]))

  // --- geometric sanity per part ---------------------------------------------------------
  for (const p of built.parts) {
    if (!p.shape) continue
    if ((p.solidCount ?? 1) > 1) {
      findings.push({
        severity: 'error',
        code: 'disconnected',
        part: p.partId,
        fix: true,
        message: `La pieza «${p.partId}» está formada por ${p.solidCount} sólidos separados (alguna operación no toca al resto).`,
        llm: `Part "${p.partId}" consists of ${p.solidCount} disconnected solids: some pad/shaft does not touch the rest of the part. Make every added feature overlap or touch the existing solid.`,
      })
    }
    for (const f of p.features) {
      if ((f.type === 'pad' || f.type === 'shaft') && f.status === 'ok' && f.volumeDelta !== undefined && Math.abs(f.volumeDelta) < 1e-3) {
        findings.push({
          severity: 'error',
          code: 'no_effect',
          part: p.partId,
          fix: true,
          message: `La operación «${f.name ?? f.id}» de «${p.partId}» no añade material (queda dentro del sólido existente).`,
          llm: `Feature "${f.id}" (${f.type}) of part "${p.partId}" adds no material: it lies completely inside the existing solid. Fix its sketch, plane or length, or remove it.`,
        })
      }
    }
  }

  // --- requirements from the request --------------------------------------------------------
  const req: Requirements | null = request ? extractRequirements(request) : null
  if (req) {
    const singlePart = model.kind === 'part' || (model.instances?.length ?? 0) <= 1
    if (req.dims && singlePart) {
      const shape = byId.get(model.parts[0]!.id)?.shape
      if (shape) {
        const [[x0, y0, z0], [x1, y1, z1]] = shape.boundingBox.bounds
        const actual = [x1 - x0, y1 - y0, z1 - z0].sort((a, b) => b - a)
        const wanted = [...req.dims].sort((a, b) => b - a)
        const compare = actual.slice(0, wanted.length)
        if (!wanted.every((w, i) => near(compare[i]!, w))) {
          findings.push({
            severity: 'error',
            code: 'dims',
            fix: true,
            message: `Medidas pedidas ${req.dims.map(fmt).join(' × ')} mm, pero la pieza mide ${[x1 - x0, y1 - y0, z1 - z0].map(fmt).join(' × ')} mm (X × Y × Z).`,
            llm: `The user asked for overall dimensions ${req.dims.map(fmt).join(' x ')} mm but the built part measures ${[x1 - x0, y1 - y0, z1 - z0].map(fmt).join(' x ')} mm (X x Y x Z bounding box). Adjust the model so its overall size matches the request.`,
          })
        }
      }
    }
    if (req.holeCount !== undefined) {
      const n = holeCount(model, built)
      if (n !== req.holeCount) {
        findings.push({
          severity: 'error',
          code: 'holes',
          fix: true,
          message: `Se pidieron ${req.holeCount} taladros y el modelo tiene ${n}.`,
          llm: `The user asked for ${req.holeCount} holes but the model has ${n} hole positions (hole features, including repeats and instances). Use hole features so the count matches.`,
        })
      }
    }
    const nums = req.diameters.length || req.thicknesses.length ? modelNumbers(model, built) : []
    for (const d of req.diameters) {
      // A radius of d/2 (fillet / selector / profile) also satisfies a diameter request.
      if (!nums.some((n) => near(n, d) || near(n * 2, d))) {
        findings.push({
          severity: 'warning',
          code: 'diameter',
          fix: true,
          message: `Se pidió un diámetro de ${fmt(d)} mm y no aparece en el modelo.`,
          llm: `The user asked for a diameter of ${fmt(d)} mm but no parameter or feature dimension of the model has that value. Check that the requested diameter is used.`,
        })
      }
    }
    for (const t of req.thicknesses) {
      if (!nums.some((n) => near(n, t))) {
        findings.push({
          severity: 'warning',
          code: 'thickness',
          fix: true,
          message: `Se pidió un espesor de ${fmt(t)} mm y no aparece en el modelo.`,
          llm: `The user asked for a thickness/wall of ${fmt(t)} mm but no parameter or feature dimension has that value. Check that the requested thickness is used.`,
        })
      }
    }
  }

  // --- assemblies: interference and floating instances --------------------------------
  if (model.kind === 'assembly' && built.placements.length > 1) {
    if (built.placements.length > 12) {
      findings.push({ severity: 'info', code: 'skipped', fix: false, message: 'Ensamblaje con más de 12 instancias: no se comprueban interferencias.', llm: '' })
    } else {
      const placed: Array<{ id: string; name: string; shape: Shape3D; volume: number }> = []
      for (const pl of built.placements) {
        const s = byId.get(pl.partId)?.shape
        if (!s) continue
        try {
          const shape = placeShape(s, pl.transform)
          placed.push({ id: pl.instanceId, name: pl.name, shape, volume: measureVolume(shape) })
        } catch {
          /* ignore */
        }
      }
      const touches = new Map(placed.map((p) => [p.id, false]))
      for (let i = 0; i < placed.length; i++) {
        for (let j = i + 1; j < placed.length; j++) {
          const a = placed[i]!
          const b = placed[j]!
          let dist = Infinity
          try {
            dist = measureDistanceBetween(a.shape, b.shape)
          } catch {
            continue
          }
          if (dist <= 0.05) {
            touches.set(a.id, true)
            touches.set(b.id, true)
          }
          if (dist > 1e-6) continue
          let common = 0
          try {
            common = measureVolume(a.shape.clone().intersect(b.shape.clone()) as Shape3D)
          } catch {
            common = 0
          }
          if (common > Math.max(1, 0.002 * Math.min(a.volume, b.volume))) {
            findings.push({
              severity: 'error',
              code: 'interference',
              fix: true,
              message: `«${a.name}» y «${b.name}» se interpenetran (${fmt(common)} mm³ en común).`,
              llm: `Instances "${a.id}" and "${b.id}" interfere: they share ${fmt(common)} mm3 of material. Fix their positions/rotations or the part dimensions so they only touch.`,
            })
          }
        }
      }
      for (const p of placed) {
        if (!touches.get(p.id)) {
          findings.push({
            severity: 'error',
            code: 'floating',
            fix: true,
            message: `«${p.name}» no toca ninguna otra pieza del ensamblaje (queda flotando).`,
            llm: `Instance "${p.id}" does not touch any other instance (it floats in space). Fix its position so it rests against the parts it should be mounted on.`,
          })
        }
      }
    }
  }
  return findings
}

/** Formats findings for the LLM tool result ("AUDIT" block). */
export function auditText(findings: AuditFinding[]): string {
  return findings
    .filter((f) => f.llm)
    .map((f) => `- [${f.code}] ${f.llm}`)
    .join('\n')
}
