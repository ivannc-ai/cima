/**
 * CIMA model -> replicad (OpenCascade) solids.
 *
 * Environment independent: works in the renderer Web Worker and in Node (tests). The caller must
 * have initialised OpenCascade with replicad's setOC() before calling these functions.
 */
import {
  draw,
  drawCircle,
  exportSTEP,
  EdgeFinder,
  FaceFinder,
  measureVolume,
  Plane,
  type AnyShape,
  type Drawing,
  type Edge,
  type Face,
  type Shape3D,
} from 'replicad'
import type { CadModel, Feature, Part } from '../shared/model/schema'
import {
  partContext,
  modelContext,
  resolveModelParameters,
  type EvalContext,
  type ModelParameterResolution,
  type ParamOverrides,
} from '../shared/model/evaluate'
import {
  edgeMatches,
  faceMatches,
  instanceTransform,
  loopBounds,
  loopSignedArea,
  planeFrame,
  resolveEdgeSelector,
  resolveFaceSelector,
  resolvePositions,
  resolveSketch,
  toWorld,
  v3,
  AXIS_VECTORS,
  type EdgeInfo,
  type FaceInfo,
  type Frame,
  type Loop,
  type RigidTransform,
  type V2,
  type V3,
} from '../shared/model/geometry'

export type FeatureBuildStatus = 'ok' | 'error' | 'suppressed' | 'skipped'

export interface FeatureBuildResult {
  id: string
  type: Feature['type']
  name?: string
  status: FeatureBuildStatus
  message?: string
  /** Volume change produced by the feature (mm3), when measurable. */
  volumeDelta?: number
}

export interface PartBuildResult {
  partId: string
  shape: Shape3D | null
  features: FeatureBuildResult[]
  /** Volume in mm3 (null when the part failed). */
  volume: number | null
  /** Number of separate solids in the final shape (1 for a healthy part). */
  solidCount?: number
  error?: string
}

const safeVolume = (s: Shape3D | null): number | null => {
  if (!s) return 0
  try {
    return measureVolume(s)
  } catch {
    return null
  }
}

export interface ModelBuildResult {
  parts: PartBuildResult[]
  resolution: ModelParameterResolution
  /** Placement of every instance (assemblies) or a single identity placement (parts). */
  placements: Array<{ instanceId: string; partId: string; name: string; transform: RigidTransform; color?: string }>
  errors: string[]
}

/** Converts anything thrown by OpenCascade/replicad (often a WebAssembly.Exception) to a message. */
export function errorMessage(e: unknown): string {
  if (e instanceof Error) return e.message
  if (typeof e === 'string') return e
  if (e && typeof e === 'object' && 'message' in e && typeof (e as { message: unknown }).message === 'string') {
    return (e as { message: string }).message
  }
  return 'geometry kernel error (the operation is not geometrically possible with these values)'
}

const tuple = (v: { x: number; y: number; z: number }): V3 => [v.x, v.y, v.z]

// ---------------------------------------------------------------------------
// 2D
// ---------------------------------------------------------------------------

function loopDrawing(loop: Loop): Drawing {
  if (loop.kind === 'circle') return drawCircle(loop.radius).translate(loop.center[0], loop.center[1])
  const segs = loop.segments
  let pen = draw(segs[0]!.from)
  for (const s of segs) {
    pen = s.kind === 'line' ? pen.lineTo(s.to) : pen.threePointsArcTo(s.to, s.mid)
  }
  return pen.close()
}

/** A representative point strictly inside a loop (used for nesting tests). */
function samplePoint(loop: Loop): V2 {
  if (loop.kind === 'circle') return loop.center
  const s = loop.segments[0]!
  // Midpoint of the first segment, nudged inwards along the left normal (CCW) / right normal (CW).
  const mid: V2 = s.kind === 'line' ? [(s.from[0] + s.to[0]) / 2, (s.from[1] + s.to[1]) / 2] : s.mid
  const dir: V2 = s.kind === 'line' ? [s.to[0] - s.from[0], s.to[1] - s.from[1]] : [s.to[0] - s.from[0], s.to[1] - s.from[1]]
  const len = Math.hypot(dir[0], dir[1]) || 1
  const sign = loopSignedArea(loop) >= 0 ? 1 : -1
  const eps = 1e-4
  return [mid[0] - (dir[1] / len) * eps * sign, mid[1] + (dir[0] / len) * eps * sign]
}

function polyline(loop: Loop): V2[] {
  if (loop.kind === 'circle') {
    const pts: V2[] = []
    for (let i = 0; i < 64; i++) {
      const a = (i / 64) * Math.PI * 2
      pts.push([loop.center[0] + loop.radius * Math.cos(a), loop.center[1] + loop.radius * Math.sin(a)])
    }
    return pts
  }
  const pts: V2[] = []
  for (const s of loop.segments) {
    pts.push(s.from)
    if (s.kind === 'arc') {
      const n = 16
      let a0 = s.startAngle
      let a1 = s.endAngle
      if (s.ccw) while (a1 <= a0) a1 += Math.PI * 2
      else while (a1 >= a0) a1 -= Math.PI * 2
      for (let i = 1; i < n; i++) {
        const a = a0 + ((a1 - a0) * i) / n
        pts.push([s.center[0] + s.radius * Math.cos(a), s.center[1] + s.radius * Math.sin(a)])
      }
    }
  }
  return pts
}

function pointInPolygon(p: V2, poly: V2[]): boolean {
  let inside = false
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i]!
    const b = poly[j]!
    if (a[1] > p[1] !== b[1] > p[1] && p[0] < ((b[0] - a[0]) * (p[1] - a[1])) / (b[1] - a[1]) + a[0]) inside = !inside
  }
  return inside
}

/** Builds the 2D region of a sketch: nested loops alternate between material and holes. */
export function sketchDrawing(loops: Loop[]): Drawing {
  const items = loops
    .map((loop) => ({ loop, area: Math.abs(loopSignedArea(loop)), poly: polyline(loop), bounds: loopBounds(loop) }))
    .sort((a, b) => b.area - a.area)
  let result: Drawing | null = null
  items.forEach((it, i) => {
    const p = samplePoint(it.loop)
    let depth = 0
    for (let j = 0; j < i; j++) {
      const other = items[j]!
      if (other.area > it.area && pointInPolygon(p, other.poly)) depth++
    }
    const d = loopDrawing(it.loop)
    if (result === null) result = d
    else result = depth % 2 === 0 ? result.fuse(d) : result.cut(d)
  })
  if (!result) throw new Error('empty sketch')
  return result
}

function framePlane(f: Frame, originShift: V3 = [0, 0, 0]): Plane {
  return new Plane(v3.add(f.origin, originShift), f.u, f.n)
}

type Extrudable = { extrude: (d: number) => unknown; revolve: (axis?: V3, cfg?: { origin?: V3; angle?: number }) => unknown }

function sketchOn(drawing: Drawing, plane: Plane): Extrudable {
  return drawing.sketchOnPlane(plane) as unknown as Extrudable
}

// ---------------------------------------------------------------------------
// Topology info for selectors
// ---------------------------------------------------------------------------

function circumradius(a: V3, b: V3, c: V3): number {
  const ab = v3.len(v3.sub(a, b))
  const bc = v3.len(v3.sub(b, c))
  const ca = v3.len(v3.sub(c, a))
  const area2 = v3.len(v3.cross(v3.sub(b, a), v3.sub(c, a)))
  return area2 < 1e-12 ? Infinity : (ab * bc * ca) / (2 * area2)
}

export function edgeInfoOf(e: Edge): EdgeInfo {
  const type = e.geomType
  const pts = [0, 0.25, 0.5, 0.75, 1].map((t) => tuple(e.pointAt(t)))
  const info: EdgeInfo = { curve: type === 'LINE' ? 'line' : type === 'CIRCLE' ? 'circle' : 'other', points: pts }
  if (info.curve === 'line') {
    const d = v3.sub(pts[4]!, pts[0]!)
    if (v3.len(d) > 1e-12) info.direction = v3.norm(d)
  } else if (info.curve === 'circle') {
    info.radius = circumradius(pts[0]!, pts[1]!, pts[2]!)
  }
  return info
}

export function faceInfoOf(f: Face, normal?: { x: number; y: number; z: number }): FaceInfo {
  const type = f.geomType
  const info: FaceInfo = {
    surface: type === 'PLANE' ? 'plane' : type === 'CYLINDRE' ? 'cylinder' : 'other',
    points: [tuple(f.center)],
  }
  // Note: Face.outerWire() invalidates the face wrapper in replicad, so sample through UV instead.
  try {
    const b = f.UVBounds as unknown as { uMin: number; uMax: number; vMin: number; vMax: number }
    for (const [u, v] of [
      [b.uMin, b.vMin],
      [b.uMax, b.vMin],
      [b.uMax, b.vMax],
      [b.uMin, b.vMax],
    ] as const) {
      info.points.push(tuple(f.pointOnSurface(u, v)))
    }
  } catch {
    /* center only */
  }
  if (info.surface === 'plane') {
    const n = normal ?? f.normalAt()
    info.normal = v3.norm(tuple(n))
  }
  return info
}

// ---------------------------------------------------------------------------
// Features
// ---------------------------------------------------------------------------

interface ToolRecord {
  op: 'fuse' | 'cut'
  tool: Shape3D
}

interface BuildState {
  shape: Shape3D | null
  tools: Map<string, ToolRecord>
}

function bigLength(state: BuildState, frame: Frame): number {
  let size = 1000
  if (state.shape) {
    const [[x0, y0, z0], [x1, y1, z1]] = state.shape.boundingBox.bounds
    size = Math.hypot(x1 - x0, y1 - y0, z1 - z0)
    const o = frame.origin
    size += Math.hypot(o[0] - (x0 + x1) / 2, o[1] - (y0 + y1) / 2, o[2] - (z0 + z1) / 2)
  }
  return size * 2 + 10
}

/** Extrusion of a sketch between signed distances a < b along the frame normal. */
function extrudeBetween(drawing: Drawing, frame: Frame, a: number, b: number): Shape3D {
  const plane = framePlane(frame, v3.scale(frame.n, a))
  return sketchOn(drawing, plane).extrude(b - a) as Shape3D
}

function padTool(f: Extract<Feature, { type: 'pad' }>, ctx: EvalContext, path: string): Shape3D {
  const sk = resolveSketch(f.sketch, ctx, `${path}.sketch`)
  const L = ctx.pos(f.length, `${path}.length`)
  const L2 = f.length2 === undefined ? 0 : ctx.n(f.length2, `${path}.length2`)
  const dr = sketchDrawing(sk.loops)
  switch (f.direction ?? 'normal') {
    case 'normal':
      return extrudeBetween(dr, sk.frame, -L2, L)
    case 'reverse':
      return extrudeBetween(dr, sk.frame, -L, L2)
    case 'symmetric':
      return extrudeBetween(dr, sk.frame, -L / 2, L / 2)
  }
}

function pocketTool(f: Extract<Feature, { type: 'pocket' }>, ctx: EvalContext, path: string, state: BuildState): Shape3D {
  const sk = resolveSketch(f.sketch, ctx, `${path}.sketch`)
  const D = f.throughAll ? bigLength(state, sk.frame) : ctx.pos(f.depth ?? 0, `${path}.depth`)
  const dr = sketchDrawing(sk.loops)
  switch (f.direction ?? 'reverse') {
    case 'reverse':
      return extrudeBetween(dr, sk.frame, -D, 0)
    case 'normal':
      return extrudeBetween(dr, sk.frame, 0, D)
    case 'symmetric':
      return f.throughAll ? extrudeBetween(dr, sk.frame, -D, D) : extrudeBetween(dr, sk.frame, -D / 2, D / 2)
  }
}

function revolveTool(f: Extract<Feature, { type: 'shaft' | 'groove' }>, ctx: EvalContext, path: string): Shape3D {
  const sk = resolveSketch(f.sketch, ctx, `${path}.sketch`)
  const angle = f.angle === undefined ? 360 : ctx.n(f.angle, `${path}.angle`)
  const axis = f.axis === 'u' ? sk.frame.u : sk.frame.v
  const dr = sketchDrawing(sk.loops)
  return sketchOn(dr, framePlane(sk.frame)).revolve(axis, { origin: sk.frame.origin, angle }) as Shape3D
}

function holeTool(f: Extract<Feature, { type: 'hole' }>, ctx: EvalContext, path: string, state: BuildState): Shape3D {
  const frame = planeFrame(f.plane, ctx, `${path}.plane`)
  const centers = resolvePositions(f.positions, f.repeat, ctx, path)
  const r = ctx.pos(f.diameter, `${path}.diameter`) / 2
  const D = f.throughAll ? bigLength(state, frame) : ctx.pos(f.depth ?? 0, `${path}.depth`)
  const kind = f.kind ?? 'simple'
  const axisDir: V3 = f.reverse ? frame.n : v3.scale(frame.n, -1) // drilling direction
  const lift = 0.01 // start slightly above the entry plane to avoid coplanar booleans
  // Profile in (radial, depth) coordinates; depth positive along the drilling direction.
  const prof: V2[] = []
  if (kind === 'counterbored') {
    const R = ctx.pos(f.headDiameter ?? 0, `${path}.headDiameter`) / 2
    const hd = ctx.pos(f.headDepth ?? 0, `${path}.headDepth`)
    prof.push([0, -lift], [R, -lift], [R, hd], [r, hd], [r, D], [0, D])
  } else if (kind === 'countersunk') {
    const R = ctx.pos(f.headDiameter ?? 0, `${path}.headDiameter`) / 2
    const ang = f.headAngle === undefined ? 90 : ctx.n(f.headAngle, `${path}.headAngle`)
    const hd = (R - r) / Math.tan(((ang / 2) * Math.PI) / 180)
    prof.push([0, -lift], [R, -lift], [R, 0], [r, hd], [r, D], [0, D])
  } else {
    prof.push([0, -lift], [r, -lift], [r, D], [0, D])
  }
  let tool: Shape3D | null = null
  for (const c of centers) {
    const origin = toWorld(frame, c)
    // Local plane: x = radial (frame.u), y = drilling direction.
    const plane = new Plane(origin, frame.u, v3.cross(frame.u, axisDir))
    let pen = draw(prof[0]!)
    for (let i = 1; i < prof.length; i++) pen = pen.lineTo(prof[i]!)
    const solid = (pen.close().sketchOnPlane(plane) as unknown as Extrudable).revolve(axisDir, { origin }) as Shape3D
    tool = tool ? tool.fuse(solid) : solid
  }
  if (!tool) throw new Error('hole without positions')
  return tool
}

function applyTool(state: BuildState, rec: ToolRecord): void {
  // Tools are kept for later patterns, so booleans always work on a copy.
  const tool = rec.tool.clone() as Shape3D
  if (!state.shape) {
    if (rec.op === 'cut') throw new Error('nothing to cut: the first feature must add material')
    state.shape = tool
    return
  }
  state.shape = rec.op === 'fuse' ? state.shape.fuse(tool) : state.shape.cut(tool)
}

function selectEdges(shape: Shape3D, sel: ReturnType<typeof resolveEdgeSelector>): (f: EdgeFinder) => EdgeFinder {
  return (finder) => finder.when(({ element }) => edgeMatches(edgeInfoOf(element as Edge), sel))
}

function buildFeature(f: Feature, ctx: EvalContext, path: string, state: BuildState): void {
  switch (f.type) {
    case 'pad':
    case 'shaft': {
      const tool = f.type === 'pad' ? padTool(f, ctx, path) : revolveTool(f, ctx, path)
      const rec: ToolRecord = { op: 'fuse', tool }
      state.tools.set(f.id, rec)
      applyTool(state, rec)
      return
    }
    case 'pocket':
    case 'groove':
    case 'hole': {
      const tool =
        f.type === 'pocket' ? pocketTool(f, ctx, path, state) : f.type === 'groove' ? revolveTool(f, ctx, path) : holeTool(f, ctx, path, state)
      const rec: ToolRecord = { op: 'cut', tool }
      state.tools.set(f.id, rec)
      const before = state.shape ? measureVolume(state.shape) : 0
      applyTool(state, rec)
      if (state.shape && Math.abs(measureVolume(state.shape) - before) < 1e-6) {
        throw new Error(`${f.type} "${f.id}" did not remove any material (check its plane, position and direction)`)
      }
      return
    }
    case 'fillet':
    case 'chamfer': {
      if (!state.shape) throw new Error('no solid to modify')
      const sel = resolveEdgeSelector(f.edges, ctx, `${path}.edges`)
      const shape = state.shape
      const count = selectEdges(shape, sel)(new EdgeFinder()).find(shape).length
      if (count === 0) throw new Error(`the edge selector of "${f.id}" matched no edge`)
      state.shape =
        f.type === 'fillet'
          ? shape.fillet(ctx.pos(f.radius, `${path}.radius`), selectEdges(shape, sel))
          : shape.chamfer(ctx.pos(f.distance, `${path}.distance`), selectEdges(shape, sel))
      return
    }
    case 'shell': {
      if (!state.shape) throw new Error('no solid to modify')
      const sel = resolveFaceSelector(f.openFaces, ctx, `${path}.openFaces`)
      const shape = state.shape
      const filter = (finder: FaceFinder) =>
        finder.when(({ element, normal }) => faceMatches(faceInfoOf(element as Face, normal ?? undefined), sel))
      const count = filter(new FaceFinder()).find(shape).length
      if (count === 0) throw new Error(`the face selector of "${f.id}" matched no face`)
      state.shape = shape.shell(ctx.pos(f.thickness, `${path}.thickness`), filter)
      return
    }
    case 'mirror': {
      if (!state.shape) throw new Error('no solid to mirror')
      state.shape = state.shape.fuse(state.shape.clone().mirror(f.plane, [0, 0, 0]) as Shape3D)
      return
    }
    case 'linearPattern':
    case 'circularPattern': {
      const count = ctx.int(f.count, `${path}.count`)
      const transforms: Array<(s: Shape3D) => Shape3D> = []
      if (f.type === 'linearPattern') {
        const d1 = v3.norm(f.direction as V3)
        const s1 = ctx.n(f.spacing, `${path}.spacing`)
        const c2 = f.count2 === undefined ? 1 : ctx.int(f.count2, `${path}.count2`)
        const d2 = f.direction2 ? v3.norm(f.direction2 as V3) : ([0, 0, 0] as V3)
        const s2 = f.spacing2 === undefined ? 0 : ctx.n(f.spacing2, `${path}.spacing2`)
        for (let j = 0; j < c2; j++)
          for (let i = 0; i < count; i++) {
            if (i === 0 && j === 0) continue
            const t = v3.add(v3.scale(d1, i * s1), v3.scale(d2, j * s2))
            transforms.push((s) => s.clone().translate(t[0], t[1], t[2]) as Shape3D)
          }
      } else {
        const total = f.totalAngle === undefined ? 360 : ctx.n(f.totalAngle, `${path}.totalAngle`)
        const full = Math.abs(Math.abs(total) - 360) < 1e-9
        const step = count <= 1 ? 0 : full ? total / count : total / (count - 1)
        const center = f.center ? ctx.vec3(f.center, `${path}.center`) : ([0, 0, 0] as V3)
        for (let k = 1; k < count; k++) {
          transforms.push((s) => s.clone().rotate(k * step, center, AXIS_VECTORS[f.axis]) as Shape3D)
        }
      }
      for (const ref of f.features) {
        const rec = state.tools.get(ref)
        if (!rec) throw new Error(`pattern source "${ref}" has no geometry (failed or not built)`)
        for (const t of transforms) applyTool(state, { op: rec.op, tool: t(rec.tool) })
      }
      return
    }
  }
}

// ---------------------------------------------------------------------------
// Parts and models
// ---------------------------------------------------------------------------

export function buildPart(model: CadModel, part: Part, resolution: ModelParameterResolution): PartBuildResult {
  const ctx = partContext(model, part.id, resolution)
  const state: BuildState = { shape: null, tools: new Map() }
  const features: FeatureBuildResult[] = []
  part.features.forEach((f, i) => {
    const base = { id: f.id, type: f.type, name: f.name }
    if (f.suppressed) {
      features.push({ ...base, status: 'suppressed' })
      return
    }
    // replicad operations may invalidate their inputs: keep a private copy to roll back on failure.
    const snapshot = state.shape ? (state.shape.clone() as Shape3D) : null
    const before = safeVolume(snapshot)
    try {
      buildFeature(f, ctx, `parts.${part.id}.features[${i}] (${f.id})`, state)
      const after = safeVolume(state.shape)
      features.push({ ...base, status: 'ok', ...(before !== null && after !== null ? { volumeDelta: after - before } : {}) })
    } catch (e) {
      state.shape = snapshot // keep building from the last valid solid
      features.push({ ...base, status: 'error', message: errorMessage(e) })
    }
  })
  let volume: number | null = null
  let solidCount: number | undefined
  if (state.shape) {
    try {
      volume = measureVolume(state.shape)
    } catch {
      volume = null
    }
    try {
      solidCount = (state.shape as unknown as { solids: unknown[] }).solids.length
    } catch {
      solidCount = undefined
    }
  }
  return {
    partId: part.id,
    shape: state.shape,
    solidCount,
    features,
    volume,
    error: state.shape ? undefined : 'the part produced no solid',
  }
}

export function buildModel(model: CadModel, overrides: ParamOverrides = {}): ModelBuildResult {
  const resolution = resolveModelParameters(model, overrides)
  const errors = [...resolution.errors]
  const parts = model.parts.map((p) => buildPart(model, p, resolution))
  const placements: ModelBuildResult['placements'] = []
  if (model.kind === 'assembly' && model.instances?.length) {
    const mctx = modelContext(model, resolution)
    for (const inst of model.instances) {
      try {
        const part = model.parts.find((p) => p.id === inst.part)
        if (!part) throw new Error(`unknown part "${inst.part}"`)
        placements.push({
          instanceId: inst.id,
          partId: inst.part,
          name: inst.name ?? inst.id,
          transform: instanceTransform(inst, mctx),
          color: inst.color ?? part.color,
        })
      } catch (e) {
        errors.push(`instance "${inst.id}": ${errorMessage(e)}`)
      }
    }
  } else {
    const part = model.parts[0]!
    placements.push({
      instanceId: part.id,
      partId: part.id,
      name: part.name,
      transform: { R: [1, 0, 0, 0, 1, 0, 0, 0, 1], t: [0, 0, 0] },
      color: part.color,
    })
  }
  return { parts, resolution, placements, errors }
}

/** Applies a rigid transform to a replicad shape (returns a new shape). */
export function placeShape(shape: Shape3D, T: RigidTransform): Shape3D {
  const R = T.R
  // Axis-angle from the rotation matrix.
  const trace = R[0] + R[4] + R[8]
  const cos = Math.min(1, Math.max(-1, (trace - 1) / 2))
  let angle = Math.acos(cos)
  let out = shape.clone() as Shape3D
  if (angle > 1e-9) {
    let axis: V3
    if (Math.PI - angle > 1e-6) {
      axis = [R[7] - R[5], R[2] - R[6], R[3] - R[1]]
    } else {
      // 180 degrees: axis from the diagonal.
      const xx = Math.sqrt(Math.max(0, (R[0] + 1) / 2))
      const yy = Math.sqrt(Math.max(0, (R[4] + 1) / 2))
      const zz = Math.sqrt(Math.max(0, (R[8] + 1) / 2))
      axis = [xx, R[1] >= 0 ? yy : -yy, R[2] >= 0 ? zz : -zz]
      if (xx < 1e-9) axis = [0, yy, R[5] >= 0 ? zz : -zz]
    }
    axis = v3.norm(axis)
    angle = (angle * 180) / Math.PI
    out = out.rotate(angle, [0, 0, 0], axis) as Shape3D
  }
  return out.translate(T.t[0], T.t[1], T.t[2]) as Shape3D
}

/** STEP export of a built model (assembly instances are placed and named). */
export function modelToStep(model: CadModel, built: ModelBuildResult): Blob {
  const byId = new Map(built.parts.map((p) => [p.partId, p]))
  const items: Array<{ shape: AnyShape; name: string; color?: string }> = []
  for (const pl of built.placements) {
    const shape = byId.get(pl.partId)?.shape
    if (!shape) continue
    const partName = model.parts.find((p) => p.id === pl.partId)?.name ?? pl.partId
    items.push({
      shape: model.kind === 'assembly' ? placeShape(shape, pl.transform) : shape,
      name: model.kind === 'assembly' ? `${partName}:${pl.name}` : partName,
      color: pl.color,
    })
  }
  if (items.length === 0) throw new Error('nothing to export')
  return exportSTEP(items)
}
