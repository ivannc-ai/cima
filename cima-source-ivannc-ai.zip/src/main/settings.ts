/**
 * Persistent settings (userData/settings.json) and API keys encrypted with Electron safeStorage
 * (userData/keys.json). Keys never leave the main process.
 */
import { app, safeStorage } from 'electron'
import fs from 'node:fs'
import path from 'node:path'
import type { ProviderConfig } from '@shared/ai/types'
import { DEFAULT_PROVIDERS, DEFAULT_SETTINGS, type AppSettings, type SettingsPatch } from '@shared/settings'

type StoredKeys = Record<string, { enc: boolean; value: string }>

export class SettingsStore {
  private settings: AppSettings
  private keys: StoredKeys
  private readonly settingsPath: string
  private readonly keysPath: string

  constructor(dir = app.getPath('userData')) {
    fs.mkdirSync(dir, { recursive: true })
    this.settingsPath = path.join(dir, 'settings.json')
    this.keysPath = path.join(dir, 'keys.json')
    this.keys = readJson<StoredKeys>(this.keysPath) ?? {}
    this.settings = mergeSettings(readJson<Partial<AppSettings>>(this.settingsPath))
    this.refreshKeyFlags()
  }

  get(): AppSettings {
    return structuredClone(this.settings)
  }

  update(patch: SettingsPatch): AppSettings {
    const s = this.settings
    if (patch.language) s.language = patch.language
    if (patch.ai) s.ai = { ...s.ai, ...patch.ai }
    if (patch.catia) s.catia = { ...s.catia, ...patch.catia }
    if (patch.viewer) s.viewer = { ...s.viewer, ...patch.viewer }
    if (patch.removeProviders?.length) {
      const removable = new Set(patch.removeProviders.filter((id) => id.startsWith('custom-')))
      s.providers = s.providers.filter((p) => !removable.has(p.id))
      for (const id of removable) delete this.keys[id]
    }
    for (const p of patch.providers ?? []) {
      const existing = s.providers.find((x) => x.id === p.id)
      if (existing) {
        Object.assign(existing, sanitizeProviderPatch(p))
      } else if (p.id.startsWith('custom-')) {
        s.providers.push({
          id: p.id,
          kind: 'openai-compatible',
          label: p.label ?? 'Personalizado',
          baseURL: p.baseURL ?? 'http://localhost:1234/v1',
          model: p.model ?? '',
          models: p.models ?? [],
          hasApiKey: false,
          requiresApiKey: p.requiresApiKey ?? false,
          enabled: p.enabled ?? true,
        })
      }
    }
    if (patch.activeProviderId && s.providers.some((p) => p.id === patch.activeProviderId)) {
      s.activeProviderId = patch.activeProviderId
    }
    if (!s.providers.some((p) => p.id === s.activeProviderId)) s.activeProviderId = s.providers[0]?.id ?? 'anthropic'
    this.refreshKeyFlags()
    this.persist()
    return this.get()
  }

  setApiKey(providerId: string, apiKey: string | null): AppSettings {
    if (!this.settings.providers.some((p) => p.id === providerId)) throw new Error(`Proveedor desconocido: ${providerId}`)
    const trimmed = apiKey?.trim()
    if (!trimmed) {
      delete this.keys[providerId]
    } else if (safeStorage.isEncryptionAvailable()) {
      this.keys[providerId] = { enc: true, value: safeStorage.encryptString(trimmed).toString('base64') }
    } else {
      // Fallback (should not happen on Windows): store obfuscated only.
      this.keys[providerId] = { enc: false, value: Buffer.from(trimmed, 'utf8').toString('base64') }
    }
    writeJson(this.keysPath, this.keys)
    this.refreshKeyFlags()
    this.persist()
    return this.get()
  }

  getApiKey(providerId: string): string | null {
    const k = this.keys[providerId]
    if (!k) return null
    try {
      const buf = Buffer.from(k.value, 'base64')
      return k.enc ? safeStorage.decryptString(buf) : buf.toString('utf8')
    } catch {
      return null
    }
  }

  private refreshKeyFlags(): void {
    for (const p of this.settings.providers) p.hasApiKey = !!this.keys[p.id]
  }

  private persist(): void {
    writeJson(this.settingsPath, this.settings)
  }
}

function sanitizeProviderPatch(p: Partial<ProviderConfig>): Partial<ProviderConfig> {
  const out: Partial<ProviderConfig> = {}
  if (typeof p.label === 'string') out.label = p.label
  if (typeof p.model === 'string') out.model = p.model.trim()
  if (typeof p.baseURL === 'string') out.baseURL = p.baseURL.trim()
  if (typeof p.proxy === 'string') out.proxy = p.proxy.trim()
  if (typeof p.caCertificate === 'string') out.caCertificate = p.caCertificate.trim()
  if (typeof p.enabled === 'boolean') out.enabled = p.enabled
  if (Array.isArray(p.models)) out.models = p.models.filter((m) => typeof m === 'string')
  if (typeof p.requiresApiKey === 'boolean') out.requiresApiKey = p.requiresApiKey
  return out
}

function mergeSettings(stored: Partial<AppSettings> | null): AppSettings {
  const base = structuredClone(DEFAULT_SETTINGS)
  if (!stored) return base
  const providers: ProviderConfig[] = DEFAULT_PROVIDERS.map((def) => {
    const s = stored.providers?.find((p) => p.id === def.id)
    // Keep the user's choices, including an edited model list; refresh nothing from the defaults.
    return s
      ? {
          ...def,
          model: s.model || def.model,
          ...(Array.isArray(s.models) && s.models.length ? { models: s.models.map((m) => String(m)) } : {}),
          baseURL: s.baseURL ?? def.baseURL,
          proxy: s.proxy ?? def.proxy,
          caCertificate: s.caCertificate ?? def.caCertificate,
          enabled: s.enabled ?? true,
        }
      : { ...def }
  })
  for (const p of stored.providers ?? []) if (p.id.startsWith('custom-')) providers.push({ ...p })
  return {
    language: stored.language ?? base.language,
    activeProviderId: stored.activeProviderId ?? base.activeProviderId,
    providers,
    ai: { ...base.ai, ...(stored.ai ?? {}) },
    catia: { ...base.catia, ...(stored.catia ?? {}) },
    viewer: { ...base.viewer, ...(stored.viewer ?? {}) },
  }
}

function readJson<T>(file: string): T | null {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8')) as T
  } catch {
    return null
  }
}

function writeJson(file: string, data: unknown): void {
  const tmp = `${file}.tmp`
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8')
  fs.renameSync(tmp, file)
}
