/**
 * File logger for everything that fails (AI generation, CATIA jobs, renderer errors, crashes).
 * Logs go to <userData>/logs/cima-YYYY-MM-DD.log (one file per day, pruned after 14 days).
 * Logging never throws: a failure to write must not take the app down.
 */
import fs from 'node:fs'
import path from 'node:path'

export type LogLevel = 'info' | 'warn' | 'error'

const RETENTION_DAYS = 14

let logsDirPath = ''

/** Initializes the logs folder (called once from the main process startup). Returns the folder. */
export function initLogs(userDataDir: string): string {
  try {
    logsDirPath = path.join(userDataDir, 'logs')
    fs.mkdirSync(logsDirPath, { recursive: true })
    pruneOldLogs()
  } catch {
    logsDirPath = ''
  }
  return logsDirPath
}

export function logsDir(): string {
  return logsDirPath
}

/** Appends one line to today's log file. */
export function appLog(level: LogLevel, scope: string, message: string, detail?: unknown): void {
  if (!logsDirPath) return
  const line = `${new Date().toISOString()} [${level.toUpperCase()}] [${scope}] ${message}${detailText(detail)}\n`
  try {
    fs.appendFileSync(path.join(logsDirPath, `cima-${new Date().toISOString().slice(0, 10)}.log`), line, 'utf8')
  } catch {
    /* ignore */
  }
}

function detailText(detail: unknown): string {
  if (detail === undefined || detail === null || detail === '') return ''
  const text = flattenDetail(detail)
  return text ? ` :: ${text}` : ''
}

function flattenDetail(detail: unknown): string {
  if (typeof detail === 'string') return detail.replace(/\s+\r?\n\s*/g, ' | ').trim()
  if (detail instanceof Error) return `${detail.message}${detail.stack ? ` :: ${firstStackLine(detail.stack)}` : ''}`
  try {
    return flattenDetail(JSON.stringify(detail))
  } catch {
    return String(detail)
  }
}

function firstStackLine(stack: string): string {
  return stack.split(/\r?\n/).slice(0, 3).join(' | ')
}

function pruneOldLogs(): void {
  try {
    const cutoff = Date.now() - RETENTION_DAYS * 24 * 3600 * 1000
    for (const f of fs.readdirSync(logsDirPath)) {
      const m = /^cima-\d{4}-\d{2}-\d{2}\.log$/.exec(f)
      if (!m) continue
      const p = path.join(logsDirPath, f)
      try {
        if (fs.statSync(p).mtimeMs < cutoff) fs.rmSync(p, { force: true })
      } catch {
        /* ignore */
      }
    }
  } catch {
    /* ignore */
  }
}
