/**
 * Start models (Documents.NewFrom) for the CATIA tab: local .CATPart / .CATProduct templates
 * discovered from the program's MODLOCAL DLNames (MMaterial line). No fallback to a default.
 */
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import type { CatiaStartModel } from '@shared/catia/types'

export type { CatiaStartModel }

export interface StartModelCatalog {
  models: CatiaStartModel[]
  /** DLNames file of the program (when located). */
  dlNamesFile?: string
  /** MMaterial folder (when readable). */
  mmaterialDir?: string
  /** Reason when there are no models (no MODLOCAL/DLNames, share without access...). */
  error?: string
}

/** DLNames line prefix that points to the templates folder. */
const MMATERIAL_HEADER = 'Mmaterial;'

/** e.g. "R27" or 27 or "V5R27" → "27"; anything else → "". */
function normalizeRelease(release?: string | number | null): string {
  if (release == null) return ''
  const s = String(release).replace(/^v5r/i, '').replace(/^r/i, '')
  return /^\d+$/.test(s) ? s : ''
}

/**
 * Locates the DLNames file of a program: `%USERPROFILE%\MODLOCAL\{program}\CATSettingsRefV5R{release}\{program}_DLNames.txt`.
 * Falls back to any `CATSettingsRefV5R*` folder when the concrete release is unknown / missing.
 */
export async function findDlNamesFile(
  program?: string | null,
  release?: string | number | null,
  home = os.homedir(),
): Promise<string | null> {
  if (!program) return null
  const base = path.join(home, 'MODLOCAL', program)
  if (!fs.existsSync(base)) return null

  const rel = normalizeRelease(release)
  if (rel) {
    const exact = path.join(base, `CATSettingsRefV5R${rel}`, `${program}_DLNames.txt`)
    if (fs.existsSync(exact)) return exact
  }
  for (const entry of fs.readdirSync(base, { withFileTypes: true })) {
    if (!entry.isDirectory() || !/^CATSettingsRefV5R\d+$/i.test(entry.name)) continue
    const candidate = path.join(base, entry.name, `${program}_DLNames.txt`)
    if (fs.existsSync(candidate)) return candidate
  }
  return null
}

function readText(file: string): string | null {
  try {
    const buf = fs.readFileSync(file)
    let s: string
    if (buf.length >= 2 && buf[0] === 0xff && buf[1] === 0xfe) {
      s = buf.subarray(2).toString('utf16le')
    } else {
      s = buf.toString('utf8')
    }
    if (s.charCodeAt(0) === 0xfeff) s = s.slice(1)
    return s
  } catch {
    return null
  }
}

/** Reads the `Mmaterial;<ruta>` line (formats `ruta` or `rutaWindows;rutaUnix`) and normalizes the Windows path. */
export async function readMmaterialDir(dlNamesFile: string): Promise<string | null> {
  const text = readText(dlNamesFile)
  if (text === null) return null
  for (const line of text.split(/\r?\n/)) {
    const t = line.trim()
    if (!t.startsWith(MMATERIAL_HEADER)) continue
    const parts = t.split(';')
    const dir = (parts[1] ?? '').trim()
    return dir ? path.normalize(dir) : null
  }
  return null
}

/**
 * Lists the .CATPart (part) and .CATProduct (product) files of the program's MMaterial folder.
 * Parts first, then products, both alphabetically. No fallback: returns an error when the program
 * is unknown, DLNames is missing or the share cannot be read.
 */
export async function listStartModels(
  program?: string | null,
  release?: string | number | null,
  home = os.homedir(),
): Promise<StartModelCatalog> {
  const models: CatiaStartModel[] = []
  if (!program) {
    return { models, error: 'No se detectó el programa (inicia CATIA y ve a la pestaña CATIA).' }
  }
  const dlNamesFile = await findDlNamesFile(program, release, home)
  if (!dlNamesFile) {
    return {
      models,
      error: `No se encontró el DLNames de ${program} en ${path.join(home, 'MODLOCAL', program)}.`,
    }
  }
  const mmaterialDir = await readMmaterialDir(dlNamesFile)
  if (!mmaterialDir) {
    return { models, dlNamesFile, error: `El DLNames ${dlNamesFile} no define la línea ${MMATERIAL_HEADER}<ruta>.` }
  }
  if (!fs.existsSync(mmaterialDir)) {
    return { models, dlNamesFile, mmaterialDir, error: `Sin acceso a la carpeta de modelos de inicio: ${mmaterialDir}` }
  }

  let entries: fs.Dirent[]
  try {
    entries = fs.readdirSync(mmaterialDir, { withFileTypes: true })
  } catch {
    return { models, dlNamesFile, mmaterialDir, error: `Sin acceso a la carpeta de modelos de inicio: ${mmaterialDir}` }
  }
  for (const e of entries) {
    if (!e.isFile()) continue
    const ext = path.extname(e.name).toLowerCase()
    const type = ext === '.catproduct' ? 'product' : ext === '.catpart' ? 'part' : null
    if (!type) continue
    models.push({ name: e.name.slice(0, -path.extname(e.name).length), path: path.join(mmaterialDir, e.name), type })
  }
  models.sort((a, b) =>
    a.type === b.type ? a.name.localeCompare(b.name) : a.type === 'part' ? -1 : 1,
  )
  return { models, dlNamesFile, mmaterialDir }
}