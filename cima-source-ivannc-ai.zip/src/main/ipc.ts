/** Registers every ipcMain handler of the window.cima bridge. */
import { app, BrowserWindow, dialog, ipcMain, shell } from 'electron'
import { IPC_CHANNELS as C, type AppInfo, type SaveResult } from '@shared/ipc'
import type { ChatRequest } from '@shared/ai/types'
import type { CatiaPushRequest, CatiaScriptRequest, CatiaSetParametersRequest } from '@shared/catia/types'
import type { SettingsPatch } from '@shared/settings'
import type { CimaProject } from '@shared/project'
import type { SettingsStore } from './settings'
import type { AiService } from './ai'
import type { CatiaService } from './catia'
import { openProject, sanitizeFileName, saveFile, saveProject } from './files'
import { appLog, logsDir } from './logs'
import { listStartModels } from './start-models'
import fs from 'node:fs'

export function registerIpc(deps: { settings: SettingsStore; ai: AiService; catia: CatiaService }): void {
  const { settings, ai, catia } = deps
  const winOf = (e: Electron.IpcMainInvokeEvent) => BrowserWindow.fromWebContents(e.sender)

  // --- app ---------------------------------------------------------------
  ipcMain.handle(C.appInfo, (): AppInfo => ({
    name: app.getName(),
    version: app.getVersion(),
    platform: process.platform,
    isPackaged: app.isPackaged,
    electron: process.versions.electron ?? '',
    userDataPath: app.getPath('userData'),
  }))
  ipcMain.handle(C.appOpenExternal, async (_e, url: string) => {
    if (typeof url === 'string' && /^https?:\/\//i.test(url)) await shell.openExternal(url)
  })
  ipcMain.handle(C.appShowItemInFolder, (_e, p: string) => {
    if (typeof p === 'string' && p) shell.showItemInFolder(p)
  })
  ipcMain.handle(C.appOpenLogsFolder, async () => {
    const dir = logsDir()
    if (dir && fs.existsSync(dir)) await shell.openPath(dir)
  })
  ipcMain.handle(C.appClientLog, (_e, level: string, scope: string, message: string) => {
    if (level !== 'info' && level !== 'warn' && level !== 'error') return
    if (typeof scope !== 'string' || typeof message !== 'string') return
    appLog(level, `renderer:${scope}`, message.slice(0, 4000))
  })

  // --- settings ----------------------------------------------------------
  ipcMain.handle(C.settingsGet, () => settings.get())
  ipcMain.handle(C.settingsUpdate, (_e, patch: SettingsPatch) => settings.update(patch ?? {}))
  ipcMain.handle(C.settingsSetApiKey, (_e, providerId: string, key: string | null) => settings.setApiKey(providerId, key))
  ipcMain.handle(C.settingsChooseDirectory, async (e, title?: string) => {
    const win = winOf(e)
    const opts = { title: title ?? 'Seleccionar carpeta', properties: ['openDirectory' as const, 'createDirectory' as const] }
    const res = win ? await dialog.showOpenDialog(win, opts) : await dialog.showOpenDialog(opts)
    return res.canceled ? null : (res.filePaths[0] ?? null)
  })

  // --- ai ----------------------------------------------------------------
  ipcMain.handle(C.aiChat, async (e, request: ChatRequest) => {
    const sender = e.sender
    await ai.chat(request, (event) => {
      if (!sender.isDestroyed()) sender.send(C.aiEvent, event)
    })
  })
  ipcMain.handle(C.aiCancel, (_e, requestId: string) => ai.cancel(requestId))
  ipcMain.handle(C.aiTestProvider, (_e, providerId: string) => ai.testProvider(providerId))

  // --- catia -------------------------------------------------------------
  ipcMain.handle(C.catiaStatus, () => catia.status())
  ipcMain.handle(C.catiaGenerateScript, (_e, req: CatiaScriptRequest) => catia.generateScript(req))
  ipcMain.handle(C.catiaPush, (e, req: CatiaPushRequest) => {
    const sender = e.sender
    return catia.push(req, (event) => {
      if (!sender.isDestroyed()) sender.send(C.catiaEvent, event)
    })
  })
  ipcMain.handle(C.catiaCancel, (_e, jobId: string) => catia.cancel(jobId))
  ipcMain.handle(C.catiaExportMacro, async (e, req: CatiaScriptRequest, suggestedName: string): Promise<SaveResult> => {
    const text = catia.generateScript(req)
    // In-CATIA macros are pure VBScript: .catvbs (V5 R16+ and 3DEXPERIENCE macro libraries).
    const ext = req.options.flavor === 'catscript' ? 'catvbs' : 'vbs'
    const win = winOf(e)
    const opts = {
      title: 'Exportar macro de CATIA',
      defaultPath: `${sanitizeFileName(suggestedName || 'cima')}.${ext}`,
      filters: [{ name: ext === 'vbs' ? 'VBScript (cscript)' : 'Macro VBScript de CATIA', extensions: [ext] }],
    }
    const res = win ? await dialog.showSaveDialog(win, opts) : await dialog.showSaveDialog(opts)
    if (res.canceled || !res.filePath) return { ok: false, canceled: true }
    try {
      // UTF-16LE with BOM: understood by cscript and by the CATIA macro editor, keeps accents intact.
      fs.writeFileSync(res.filePath, Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from(text.replace(/\r?\n/g, '\r\n'), 'utf16le')]))
      return { ok: true, path: res.filePath }
    } catch (err) {
      return { ok: false, error: (err as Error).message }
    }
  })
  ipcMain.handle(C.catiaInspect, () => catia.inspect())
  ipcMain.handle(C.catiaSetParameters, (e, req: CatiaSetParametersRequest) => {
    const sender = e.sender
    return catia.setParameters(req, (event) => {
      if (!sender.isDestroyed()) sender.send(C.catiaEvent, event)
    })
  })
  ipcMain.handle(C.catiaListStartModels, (_e, program?: string | null, release?: string | number | null) =>
    listStartModels(program, release),
  )

  // --- files -------------------------------------------------------------
  ipcMain.handle(C.filesOpenProject, (e) => openProject(winOf(e)))
  ipcMain.handle(C.filesSaveProject, (e, project: CimaProject, options?: { path?: string; saveAs?: boolean }) =>
    saveProject(winOf(e), project, options),
  )
  ipcMain.handle(C.filesSaveFile, (e, req) => saveFile(winOf(e), req))
}
