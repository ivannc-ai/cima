/** CATIA connector service (main process): script generation + execution through cscript.exe. */
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import type {
  CatiaFeatureResult,
  CatiaInspection,
  CatiaJobEvent,
  CatiaJobResult,
  CatiaPushRequest,
  CatiaScriptEvent,
  CatiaScriptRequest,
  CatiaSetParametersRequest,
  CatiaStatus,
  CatiaTarget,
} from '@shared/catia/types'
import type { AppSettings } from '@shared/settings'
import { validateModel } from '@shared/model/validate'
import { generateScript } from './generator'
import { inspectScript, setParametersScript, statusScript } from './aux-scripts'
import { parseCatiaCaption } from './caption'
import { readCatiaWindowTitle } from './session-title'
import { cscriptPath, runScript, writeScript, type RunningScript } from './runner'
import { appLog } from '../logs'

export interface CatiaService {
  status(): Promise<CatiaStatus>
  generateScript(request: CatiaScriptRequest): string
  push(request: CatiaPushRequest, emit: (e: CatiaJobEvent) => void): Promise<CatiaJobResult>
  cancel(jobId: string): void
  inspect(): Promise<CatiaInspection>
  setParameters(request: CatiaSetParametersRequest, emit: (e: CatiaJobEvent) => void): Promise<CatiaJobResult>
}

export function createCatiaService(deps: { getSettings(): AppSettings; tempDir: string }): CatiaService {
  const jobs = new Map<string, RunningScript>()
  const isWin = process.platform === 'win32'

  const scriptFile = (name: string) => {
    fs.mkdirSync(deps.tempDir, { recursive: true })
    return path.join(deps.tempDir, name)
  }

  const requireWindows = () => {
    if (!isWin) throw new Error('La conexión con CATIA solo está disponible en Windows.')
    if (!fs.existsSync(cscriptPath())) throw new Error('No se encuentra cscript.exe (Windows Script Host).')
  }

  async function runAux(name: string, text: string, timeoutMs = 30_000) {
    requireWindows()
    const file = scriptFile(name)
    writeScript(file, text)
    return runScript(file, { timeoutMs }).promise
  }

  const logJobErrors = (what: string, r: CatiaJobResult): void => {
    if (r.ok || r.cancelled) return
    for (const e of r.errors.slice(0, 40)) appLog('error', 'catia', `${what} ${r.jobId}: ${e}`)
    if (r.timedOut) appLog('error', 'catia', `${what} ${r.jobId}: timeout`)
    if (r.scriptPath) appLog('info', 'catia', `${what} ${r.jobId}: script generado en ${r.scriptPath}`)
  }

  function validateRequest(req: CatiaScriptRequest): void {
    const v = validateModel(req.model)
    const errors = v.issues.filter((i) => i.severity === 'error')
    if (!v.ok || errors.length) {
      throw new Error(`El modelo no es válido: ${errors.slice(0, 5).map((i) => `${i.path}: ${i.message}`).join('; ')}`)
    }
  }

  function toResult(
    jobId: string,
    run: Awaited<RunningScript['promise']>,
    scriptPath?: string,
  ): CatiaJobResult {
    const features: CatiaFeatureResult[] = []
    const errors: string[] = []
    const warnings: string[] = []
    const savedFiles: string[] = []
    let endOk: boolean | null = null
    for (const e of run.events) {
      if (e.t === 'feature') {
        features.push({ part: e.part, feature: e.feature, status: e.status, msg: e.msg })
        if (e.status === 'error') errors.push(`${e.part}/${e.feature}: ${e.msg ?? ''}`)
      } else if (e.t === 'part' && e.status === 'error') errors.push(`${e.part}: ${e.msg ?? ''}`)
      else if (e.t === 'log' && e.level === 'error') errors.push(e.msg)
      else if (e.t === 'log' && e.level === 'warn') warnings.push(e.msg)
      else if (e.t === 'saved') savedFiles.push(e.path)
      else if (e.t === 'end') endOk = e.ok
    }
    // Runtime errors of the script itself (VBScript error dialog text goes to stderr with //nologo).
    for (const l of run.stderr) errors.push(l)
    if (run.timedOut) errors.push('Tiempo de espera agotado: revisa si CATIA muestra un cuadro de diálogo esperando respuesta.')
    if (endOk === null && !run.cancelled && !run.timedOut && errors.length === 0) {
      errors.push(`El script terminó sin informe final (código ${run.exitCode ?? 'desconocido'}).`)
    }
    return {
      jobId,
      ok: !run.cancelled && !run.timedOut && endOk === true && errors.length === 0,
      exitCode: run.exitCode,
      cancelled: run.cancelled,
      timedOut: run.timedOut,
      durationMs: run.durationMs,
      features,
      errors,
      warnings,
      savedFiles,
      scriptPath,
    }
  }

  const failed = (jobId: string, message: string): CatiaJobResult => {
    appLog('error', 'catia', `job ${jobId}: ${message}`)
    return ({
      jobId,
      ok: false,
      exitCode: null,
      cancelled: false,
      timedOut: false,
      durationMs: 0,
      features: [],
      errors: [message],
      warnings: [],
      savedFiles: [],
    })
  }

  return {
    async status(): Promise<CatiaStatus> {
      const base: CatiaStatus = { platformSupported: isWin, cscriptAvailable: isWin && fs.existsSync(cscriptPath()), running: false }
      if (!base.platformSupported || !base.cscriptAvailable) return base
      try {
        const r = await runAux('cima-status.vbs', statusScript(), 20_000)
        const ev = r.events.find((e) => (e as { t: string }).t === 'status') as unknown as
          | { running: boolean; target?: CatiaTarget; version?: string; docName?: string; docType?: string; docPath?: string; caption?: string; error?: string }
          | undefined
        if (!ev) return { ...base, error: r.stderr.join(' ') || 'Sin respuesta del script de estado' }
        // Session context (program, department, user) lives in the CATIA main window title bar
        // (process cnext); the COM window captions are a secondary source.
        const title = (await readCatiaWindowTitle().catch(() => null)) ?? ev.caption ?? ''
        const cap = parseCatiaCaption(title)
        return {
          ...base,
          running: ev.running,
          target: ev.target,
          version: ev.version,
          activeDocument: ev.docName ? { name: ev.docName, type: ev.docType ?? '' } : undefined,
          docPath: ev.docPath || undefined,
          program: cap.program ?? undefined,
          department: cap.department ?? undefined,
          user: cap.user ?? undefined,
          host: os.hostname(),
          error: ev.running ? undefined : 'CATIA no está abierto (o no está registrado para automatización COM).',
        }
      } catch (e) {
        appLog('warn', 'catia', `status: ${(e as Error).message}`)
        return { ...base, error: (e as Error).message }
      }
    },

    generateScript(req) {
      validateRequest(req)
      return generateScript(req)
    },

    async push(req, emit) {
      try {
        requireWindows()
        validateRequest(req)
      } catch (e) {
        return failed(req.jobId, (e as Error).message)
      }
      const settings = deps.getSettings()
      const timeoutMs = req.timeoutMs ?? Math.max(30, settings.catia.timeoutSec) * 1000
      const text = generateScript({ ...req, options: { ...req.options, flavor: 'vbs' } })
      const file = scriptFile(`cima-push-${req.jobId.replace(/[^A-Za-z0-9_-]/g, '')}.vbs`)
      writeScript(file, text)
      const running = runScript(file, {
        timeoutMs,
        onEvent: (event: CatiaScriptEvent) => emit({ jobId: req.jobId, type: 'script', event }),
        onStdout: (line) => emit({ jobId: req.jobId, type: 'stdout', line }),
        onStderr: (line) => emit({ jobId: req.jobId, type: 'stderr', line }),
      })
      jobs.set(req.jobId, running)
      try {
        const result = await toResult(req.jobId, await running.promise, file)
        logJobErrors('push', result)
        return result
      } finally {
        jobs.delete(req.jobId)
      }
    },

    cancel(jobId) {
      jobs.get(jobId)?.cancel()
    },

    async inspect(): Promise<CatiaInspection> {
      try {
        const r = await runAux('cima-inspect.vbs', inspectScript(), 60_000)
        const head = r.events.find((e) => (e as { t: string }).t === 'inspect') as unknown as
          | { ok: boolean; docName?: string; docType?: string; error?: string }
          | undefined
        const status = r.events.find((e) => (e as { t: string }).t === 'status') as unknown as { error?: string } | undefined
        if (!head) {
          const msg = status?.error ?? (r.stderr.join(' ') || 'CATIA no responde')
          appLog('error', 'catia', `inspect: ${msg}`)
          return { ok: false, parameters: [], error: msg }
        }
        const params = r.events
          .filter((e) => (e as { t: string }).t === 'param')
          .map((e) => {
            const p = e as unknown as { name: string; value: string; numeric: string; kind: string; user: boolean }
            const num = p.numeric === '' ? undefined : Number(p.numeric)
            return { name: p.name, value: p.value, numeric: Number.isFinite(num) ? num : undefined, kind: p.kind, userParameter: p.user }
          })
        return { ok: head.ok, documentName: head.docName, documentType: head.docType, parameters: params, error: head.error }
      } catch (e) {
        appLog('error', 'catia', `inspect: ${(e as Error).message}`)
        return { ok: false, parameters: [], error: (e as Error).message }
      }
    },

    async setParameters(req, emit) {
      const jobId = `params-${Date.now()}`
      try {
        requireWindows()
        const file = scriptFile('cima-setparams.vbs')
        writeScript(file, setParametersScript(req.values))
        const run = await runScript(file, {
          timeoutMs: 120_000,
          onEvent: (event) => emit({ jobId, type: 'script', event }),
        }).promise
        const result = toResult(jobId, run, file)
        logJobErrors('setParameters', result)
        return result
      } catch (e) {
        return failed(jobId, (e as Error).message)
      }
    },
  }
}
