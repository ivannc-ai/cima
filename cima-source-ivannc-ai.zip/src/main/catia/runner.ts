/** Runs VBScript files with cscript.exe and streams their machine-readable output lines. */
import { spawn, type ChildProcess } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { CATIA_LINE_PREFIX, type CatiaScriptEvent } from '@shared/catia/types'

export interface RunOptions {
  timeoutMs: number
  onEvent?: (e: CatiaScriptEvent) => void
  onStdout?: (line: string) => void
  onStderr?: (line: string) => void
  args?: string[]
}

export interface RunResult {
  exitCode: number | null
  timedOut: boolean
  cancelled: boolean
  events: CatiaScriptEvent[]
  stdout: string[]
  stderr: string[]
  durationMs: number
}

export function cscriptPath(): string {
  const root = process.env['SystemRoot'] ?? 'C:\\Windows'
  // Prefer the native 64-bit host (Sysnative when running inside a 32-bit process).
  const sysnative = path.join(root, 'Sysnative', 'cscript.exe')
  if (fs.existsSync(sysnative)) return sysnative
  return path.join(root, 'System32', 'cscript.exe')
}

/** Writes a script as UTF-16LE with BOM (cscript reads it as Unicode: accents survive). */
export function writeScript(file: string, text: string): void {
  fs.mkdirSync(path.dirname(file), { recursive: true })
  const body = Buffer.from(text.replace(/\r?\n/g, '\r\n'), 'utf16le')
  fs.writeFileSync(file, Buffer.concat([Buffer.from([0xff, 0xfe]), body]))
}

/** Parses one stdout line; returns the event for machine-readable lines. */
export function parseLine(line: string): CatiaScriptEvent | null {
  const i = line.indexOf(CATIA_LINE_PREFIX)
  if (i < 0) return null
  try {
    return JSON.parse(line.slice(i + CATIA_LINE_PREFIX.length)) as CatiaScriptEvent
  } catch {
    return null
  }
}

/** Incremental UTF-16LE line splitter for cscript //U output. */
class Utf16Lines {
  private pending = Buffer.alloc(0)
  private text = ''
  constructor(private readonly onLine: (l: string) => void) {}
  push(chunk: Buffer): void {
    let buf = Buffer.concat([this.pending, chunk])
    const even = buf.length - (buf.length % 2)
    this.pending = buf.subarray(even)
    buf = buf.subarray(0, even)
    this.text += buf.toString('utf16le').replace(/^\uFEFF/, '')
    let nl: number
    while ((nl = this.text.indexOf('\n')) >= 0) {
      const line = this.text.slice(0, nl).replace(/\r$/, '')
      this.text = this.text.slice(nl + 1)
      this.onLine(line)
    }
  }
  end(): void {
    if (this.text.length) this.onLine(this.text.replace(/\r$/, ''))
    this.text = ''
  }
}

export interface RunningScript {
  promise: Promise<RunResult>
  cancel(): void
}

export function runScript(scriptFile: string, opts: RunOptions): RunningScript {
  const started = Date.now()
  const events: CatiaScriptEvent[] = []
  const stdout: string[] = []
  const stderr: string[] = []
  let timedOut = false
  let cancelled = false
  let child: ChildProcess
  try {
    child = spawn(cscriptPath(), ['//nologo', '//U', scriptFile, ...(opts.args ?? [])], { windowsHide: true })
  } catch (e) {
    return {
      promise: Promise.resolve({
        exitCode: null,
        timedOut: false,
        cancelled: false,
        events,
        stdout,
        stderr: [(e as Error).message],
        durationMs: 0,
      }),
      cancel() {},
    }
  }
  const out = new Utf16Lines((line) => {
    const ev = parseLine(line)
    if (ev) {
      events.push(ev)
      opts.onEvent?.(ev)
    } else if (line.trim()) {
      stdout.push(line)
      opts.onStdout?.(line)
    }
  })
  const err = new Utf16Lines((line) => {
    if (!line.trim()) return
    stderr.push(line)
    opts.onStderr?.(line)
  })
  child.stdout?.on('data', (c: Buffer) => out.push(c))
  child.stderr?.on('data', (c: Buffer) => err.push(c))
  const timer = setTimeout(() => {
    timedOut = true
    child.kill()
  }, opts.timeoutMs)

  const promise = new Promise<RunResult>((resolve) => {
    const finish = (code: number | null) => {
      clearTimeout(timer)
      out.end()
      err.end()
      resolve({ exitCode: code, timedOut, cancelled, events, stdout, stderr, durationMs: Date.now() - started })
    }
    child.on('error', (e) => {
      stderr.push(e.message)
      finish(null)
    })
    child.on('close', (code) => finish(code))
  })
  return {
    promise,
    cancel() {
      cancelled = true
      child.kill()
    },
  }
}
