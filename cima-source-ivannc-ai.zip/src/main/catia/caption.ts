/**
 * Parses the caption of the CATIA main window to extract the session context (program, department,
 * user). Same data source as the department bridge: the window caption, typically pipe-separated:
 *
 *   <Organización> | CATIA.V5Rxx | <PROGRAMA> | <DEPARTAMENTO> | ... | User <user>@<host> |
 */
export interface CatiaCaptionInfo {
  program: string | null
  department: string | null
  user: string | null
}

export function parseCatiaCaption(caption: string | undefined | null): CatiaCaptionInfo {
  if (!caption || !caption.includes('|')) return { program: null, department: null, user: null }
  const parts = caption.split('|').map((p) => p.trim())
  const at = (i: number): string | null => (i < parts.length ? parts[i] || null : null)
  let user: string | null = null
  for (const p of parts) {
    if (p.slice(0, 5).toLowerCase() === 'user ') {
      user = p.slice(5).split('@')[0]?.trim() || null
      break
    }
  }
  return { program: at(2), department: at(3), user }
}
