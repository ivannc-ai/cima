/**
 * CIMA model -> VBScript that rebuilds the model natively in CATIA (V5 or 3DEXPERIENCE).
 *
 * Every sketch gets an explicit absolute axis (origin, H = u, V = v) so CATIA's sketch orientation
 * is exactly CIMA's. Feature dimensions are set numerically (values resolved with the current
 * slider values) and, when requested, driven by formulas over CATIA user parameters.
 * Patterns are unrolled into copies of the patterned features (robust, no reference juggling).
 */
import type { CatiaScriptOptions, CatiaScriptRequest } from '@shared/catia/types'
import type { CadModel, Expr, Feature, Part } from '@shared/model/schema'
import {
  modelContext,
  partContext,
  resolveModelParameters,
  type EvalContext,
  type ModelParameterResolution,
} from '@shared/model/evaluate'
import { identifiersOf, parseExpr, renderFormula, type Dim } from '@shared/model/expr'
import {
  AXIS_INDEX,
  AXIS_VECTORS,
  instanceTransform,
  planeFrame,
  resolveEdgeSelector,
  resolveFaceSelector,
  resolvePositions,
  resolveSketch,
  toWorld,
  v3,
  type Frame,
  type Loop,
  type RigidTransform,
  type V2,
  type V3,
} from '@shared/model/geometry'
import { vbsRuntime } from './vbs-runtime'

// ---------------------------------------------------------------------------
// Formatting helpers
// ---------------------------------------------------------------------------

/** Locale-independent VBScript numeric literal. */
export function vn(x: number): string {
  if (!Number.isFinite(x)) throw new Error(`non-finite number ${x}`)
  if (Math.abs(x) < 1e-12) return '0'
  const s = Number(x.toFixed(10)).toString()
  if (s.includes('e')) return x.toFixed(12)
  return s
}

/** VBScript string literal. */
export function vs(s: string): string {
  return `"${s.replace(/"/g, '""').replace(/\r?\n/g, ' ')}"`
}

const hexToRgb = (hex: string): [number, number, number] => [
  parseInt(hex.slice(1, 3), 16),
  parseInt(hex.slice(3, 5), 16),
  parseInt(hex.slice(5, 7), 16),
]

/** Sanitized CATIA part number / instance name. */
export function catiaName(s: string, fallback: string): string {
  const out = s.normalize('NFC').replace(/[\\/:*?"<>|.!]/g, '_').trim()
  return out || fallback
}

const CATIA_FN: Record<string, string | null> = {
  sin: 'sin',
  cos: 'cos',
  tan: 'tan',
  asin: 'asin',
  acos: 'acos',
  atan: 'atan',
  atan2: null,
  sqrt: 'sqrt',
  abs: 'abs',
  min: 'min',
  max: 'max',
  round: null,
  floor: 'floor',
  ceil: 'ceil',
}

// ---------------------------------------------------------------------------
// Generator
// ---------------------------------------------------------------------------

interface Emitter {
  lines: string[]
  subs: string[]
}

class PartWriter {
  private formulaSeq = 0
  constructor(
    private readonly model: CadModel,
    private readonly part: Part,
    private readonly ctx: EvalContext,
    private readonly opts: CatiaScriptOptions,
    private readonly out: Emitter,
    private readonly subPrefix: string,
  ) {}

  /** Formula call for a CATIA parameter object expression `target` (VBScript). */
  private formula(target: string, expr: Expr | undefined, dim: Dim, label: string, wrap?: (f: string) => string): string[] {
    if (!this.opts.createParameters || !this.opts.createFormulas || typeof expr !== 'string') return []
    let ids: Set<string>
    try {
      ids = identifiersOf(parseExpr(expr))
    } catch {
      return []
    }
    if (ids.size === 0) return []
    const dimOf = (n: string): Dim | undefined => {
      const u = this.ctx.unitOf(n)
      return u === 'mm' ? 'L' : u === 'deg' ? 'A' : u === 'none' ? 'N' : undefined
    }
    const plain = renderFormula(expr, dim, { dimOf, fn: (n) => CATIA_FN[n] ?? null, power: '**', pi: 'PI' })
    if (!plain) return [`  CimaLog "warn", ${vs(`${label}: la expresion "${expr}" no se puede convertir en formula de CATIA; se usa el valor numerico`)}`]
    const quoted = renderFormula(expr, dim, {
      dimOf,
      fn: (n) => CATIA_FN[n] ?? null,
      power: '**',
      pi: 'PI',
      ident: (n) => `\`${n}\``,
    })
    const w = wrap ?? ((f: string) => f)
    const name = `CIMA_${label.replace(/[^A-Za-z0-9_]/g, '_')}_${++this.formulaSeq}`
    return [`  CimaFormula ${vs(name)}, ${target}, ${vs(w(plain))}, ${vs(quoted ? w(quoted) : '')}`]
  }

  // --- sketches -------------------------------------------------------------

  private sketchCode(frame: Frame, loops: Loop[], extra?: (lines: string[]) => void): string[] {
    const L: string[] = []
    const f = frame
    L.push(
      `  Set sk = CimaSketch(${[...f.origin, ...f.u, ...f.v].map(vn).join(', ')})`,
      '  If CimaErr("sketch") Then',
      '    CimaFeature fid, "error", CIMA_LASTERR',
      '    Exit Sub',
      '  End If',
      '  Set f2 = sk.OpenEdition()',
    )
    for (const loop of loops) {
      if (loop.kind === 'circle') {
        L.push(`  CimaCircle f2, ${vn(loop.center[0])}, ${vn(loop.center[1])}, ${vn(loop.radius)}`)
        continue
      }
      const segs = loop.segments
      // One shared point per vertex.
      const pts = segs.map((s) => s.from)
      L.push(`  ReDim P(${pts.length - 1})`)
      pts.forEach((p, i) => L.push(`  Set P(${i}) = CimaPt(f2, ${vn(p[0])}, ${vn(p[1])})`))
      segs.forEach((s, i) => {
        const a = `P(${i})`
        const b = `P(${(i + 1) % segs.length})`
        if (s.kind === 'line') {
          L.push(`  CimaLine f2, ${a}, ${b}, ${vn(s.from[0])}, ${vn(s.from[1])}, ${vn(s.to[0])}, ${vn(s.to[1])}`)
        } else {
          // CATIA arcs run counter-clockwise from start to end angle.
          const angOf = (p: V2) => Math.atan2(p[1] - s.center[1], p[0] - s.center[0])
          let startPt = a
          let endPt = b
          let a1 = angOf(s.from)
          let a2 = angOf(s.to)
          if (!s.ccw) {
            ;[startPt, endPt] = [b, a]
            ;[a1, a2] = [a2, a1]
          }
          while (a2 <= a1) a2 += 2 * Math.PI
          L.push(`  CimaArc f2, ${vn(s.center[0])}, ${vn(s.center[1])}, ${vn(s.radius)}, ${vn(a1)}, ${vn(a2)}, ${startPt}, ${endPt}`)
        }
      })
    }
    extra?.(L)
    L.push(
      '  CimaEndSketch sk',
      '  If CimaErr("sketch geometry") Then',
      '    CimaFeature fid, "error", CIMA_LASTERR',
      '    Exit Sub',
      '  End If',
    )
    return L
  }

  // --- features ---------------------------------------------------------------

  private sub(featureId: string, label: string, body: string[]): void {
    const name = `${this.subPrefix}_${this.out.subs.length}`
    this.out.subs.push(
      [
        `Sub ${name}()`,
        `  ' ${label.replace(/\r?\n/g, ' ')}`,
        '  Dim fid, sk, f2, P(), feat, v0, v1, refs(), n, i, ok, bmin(2), bmax(2)',
        `  fid = ${vs(featureId)}`,
        '  On Error Resume Next',
        '  Err.Clear',
        ...body,
        'End Sub',
      ].join('\r\n'),
    )
    this.out.lines.push(`  ${name}`)
  }

  /** Emits code for one feature; `xf` is an optional rigid transform (pattern copies). */
  writeFeature(f: Feature, index: number, xf?: { T: RigidTransform; copy: number }): void {
    const path = `parts.${this.part.id}.features[${index}]`
    const fid = xf ? `${f.id}#${xf.copy}` : f.id
    const featName = catiaName(f.name ?? f.id, f.id) + (xf ? `_${xf.copy}` : '')
    const ctx = this.ctx
    const tf = (fr: Frame): Frame => (xf ? transformFrame(fr, xf.T) : fr)
    const nameLine = `  feat.Name = ${vs(featName)}`
    let body: string[]
    try {
      switch (f.type) {
        case 'pad': {
          const sk = resolveSketch(f.sketch, ctx, `${path}.sketch`)
          const L = ctx.pos(f.length, `${path}.length`)
          const dir = f.direction ?? 'normal'
          body = [
            ...this.sketchCode(tf(sk.frame), sk.loops),
            '  v0 = CimaVolume()',
            `  Set feat = G_SF.AddNewPad(sk, ${vn(dir === 'symmetric' ? L / 2 : L)})`,
            '  If CimaErr("AddNewPad") Then',
            '    CimaFeature fid, "error", CIMA_LASTERR',
            '    Exit Sub',
            '  End If',
            nameLine,
            ...(dir === 'reverse' ? ['  feat.DirectionOrientation = 1'] : []),
            ...(dir === 'symmetric' ? ['  feat.IsSymmetric = True'] : []),
            ...(f.length2 !== undefined && dir !== 'symmetric'
              ? [`  feat.SecondLimit.Dimension.Value = ${vn(ctx.n(f.length2, `${path}.length2`))}`]
              : []),
            ...this.formula('feat.FirstLimit.Dimension', f.length, 'L', `${f.id}_length`, dir === 'symmetric' ? (s) => `(${s}) / 2` : undefined),
            ...(f.length2 !== undefined && dir !== 'symmetric' ? this.formula('feat.SecondLimit.Dimension', f.length2, 'L', `${f.id}_length2`) : []),
            ...this.finish('material', 'add'),
          ]
          break
        }
        case 'pocket': {
          const sk = resolveSketch(f.sketch, ctx, `${path}.sketch`)
          const dir = f.direction ?? 'reverse'
          const D = f.throughAll ? 1 : ctx.pos(f.depth ?? 0, `${path}.depth`)
          // Assumption: CATIA's regular pocket direction removes material opposite to the sketch
          // normal (CIMA "reverse"). The volume check below flips it if that is not the case.
          const ori = dir === 'normal' ? 1 : 0
          body = [
            ...this.sketchCode(tf(sk.frame), sk.loops),
            '  v0 = CimaVolume()',
            `  Set feat = G_SF.AddNewPocket(sk, ${vn(dir === 'symmetric' && !f.throughAll ? D / 2 : D)})`,
            '  If CimaErr("AddNewPocket") Then',
            '    CimaFeature fid, "error", CIMA_LASTERR',
            '    Exit Sub',
            '  End If',
            nameLine,
            `  feat.DirectionOrientation = ${ori}`,
            ...(dir === 'symmetric' ? ['  feat.IsSymmetric = True'] : []),
            ...(f.throughAll ? ['  feat.FirstLimit.LimitMode = 2', ...(dir === 'symmetric' ? ['  feat.SecondLimit.LimitMode = 2'] : [])] : []),
            ...(!f.throughAll
              ? this.formula('feat.FirstLimit.Dimension', f.depth, 'L', `${f.id}_depth`, dir === 'symmetric' ? (s) => `(${s}) / 2` : undefined)
              : []),
            ...this.finish('material', 'remove', dir === 'symmetric' ? undefined : `  feat.DirectionOrientation = ${1 - ori}`),
          ]
          break
        }
        case 'shaft':
        case 'groove': {
          const sk = resolveSketch(f.sketch, ctx, `${path}.sketch`)
          const ang = f.angle === undefined ? 360 : ctx.n(f.angle, `${path}.angle`)
          const isU = f.axis === 'u'
          body = [
            ...this.sketchCode(tf(sk.frame), sk.loops, (L) => L.push(`  CimaAxisLine f2, sk, ${isU ? 'True' : 'False'}`)),
            '  v0 = CimaVolume()',
            `  Set feat = G_SF.${f.type === 'shaft' ? 'AddNewShaft' : 'AddNewGroove'}(sk)`,
            `  If CimaErr("${f.type === 'shaft' ? 'AddNewShaft' : 'AddNewGroove'}") Then`,
            '    CimaFeature fid, "error", CIMA_LASTERR',
            '    Exit Sub',
            '  End If',
            nameLine,
            `  feat.FirstAngle.Value = ${vn(ang)}`,
            '  feat.SecondAngle.Value = 0',
            ...this.formula('feat.FirstAngle', f.angle, 'A', `${f.id}_angle`),
            ...this.finish('material', f.type === 'shaft' ? 'add' : 'remove'),
          ]
          break
        }
        case 'hole':
          this.writeHoles(f, index, xf)
          return
        case 'fillet':
        case 'chamfer': {
          const sel = resolveEdgeSelector(f.edges, ctx, `${path}.edges`)
          const value = f.type === 'fillet' ? ctx.pos(f.radius, `${path}.radius`) : ctx.pos(f.distance, `${path}.distance`)
          const box = sel.inBox
          body = [
            ...(box ? [0, 1, 2].map((k) => `  bmin(${k}) = ${vn(box.min[k]!)}: bmax(${k}) = ${vn(box.max[k]!)}`) : []),
            `  n = CimaCollectEdges(refs, ${sel.direction ? AXIS_INDEX[sel.direction] : -1}, ${vs(sel.curve ?? '')}, ${
              sel.onPlane ? AXIS_INDEX[sel.onPlane.axis] : -1
            }, ${vn(sel.onPlane?.at ?? 0)}, ${box ? 'True' : 'False'}, bmin, bmax, ${vn(sel.radius ?? -1)}, 0.001)`,
            '  If n = 0 Then',
            '    CimaFeature fid, "error", "Ninguna arista coincide con el selector (o la busqueda topologica no esta disponible en este idioma de CATIA)"',
            '    Exit Sub',
            '  End If',
            ...(f.type === 'fillet'
              ? [
                  `  Set feat = G_SF.AddNewSolidEdgeFilletWithConstantRadius(refs(0), 1, ${vn(value)})`,
                  '  If Err.Number <> 0 Then',
                  '    Err.Clear',
                  `    Set feat = G_SF.AddNewEdgeFilletWithConstantRadius(refs(0), 1, ${vn(value)})`,
                  '  End If',
                  '  If CimaErr("AddNewEdgeFillet") Then',
                  '    CimaFeature fid, "error", CIMA_LASTERR',
                  '    Exit Sub',
                  '  End If',
                  '  For i = 1 To n - 1',
                  '    feat.AddObjectToFillet refs(i)',
                  '  Next',
                  ...this.formula('feat.Radius', f.radius, 'L', `${f.id}_radius`),
                ]
              : [
                  `  Set feat = G_SF.AddNewChamfer(refs(0), 0, 1, 0, ${vn(value)}, 45)`,
                  '  If CimaErr("AddNewChamfer") Then',
                  '    CimaFeature fid, "error", CIMA_LASTERR',
                  '    Exit Sub',
                  '  End If',
                  '  For i = 1 To n - 1',
                  '    feat.AddElementToChamfer refs(i)',
                  '  Next',
                  ...this.formula('feat.Length1', f.distance, 'L', `${f.id}_distance`),
                ]),
            '  Err.Clear',
            nameLine,
            ...this.finish('update'),
          ]
          break
        }
        case 'shell': {
          const sel = resolveFaceSelector(f.openFaces, ctx, `${path}.openFaces`)
          const t = ctx.pos(f.thickness, `${path}.thickness`)
          const nAxis = sel.normal ? AXIS_INDEX[sel.normal[1] as 'X' | 'Y' | 'Z'] : -1
          const nSign = sel.normal?.[0] === '-' ? -1 : 1
          body = [
            `  n = CimaCollectFaces(refs, ${nAxis}, ${nSign}, ${sel.onPlane ? AXIS_INDEX[sel.onPlane.axis] : -1}, ${vn(
              sel.onPlane?.at ?? 0,
            )}, ${vs(sel.surface ?? '')}, 0.001)`,
            '  If n = 0 Then',
            '    CimaFeature fid, "error", "Ninguna cara coincide con el selector (o la busqueda topologica no esta disponible en este idioma de CATIA)"',
            '    Exit Sub',
            '  End If',
            `  Set feat = G_SF.AddNewShell(refs(0), ${vn(t)}, 0)`,
            '  If CimaErr("AddNewShell") Then',
            '    CimaFeature fid, "error", CIMA_LASTERR',
            '    Exit Sub',
            '  End If',
            '  For i = 1 To n - 1',
            '    feat.AddFaceToRemove refs(i)',
            '  Next',
            '  Err.Clear',
            nameLine,
            ...this.formula('feat.InternalThickness', f.thickness, 'L', `${f.id}_thickness`),
            ...this.finish('update'),
          ]
          break
        }
        case 'mirror': {
          const planeProp = { XY: 'PlaneXY', YZ: 'PlaneYZ', ZX: 'PlaneZX' }[f.plane]
          body = [
            `  Set feat = G_SF.AddNewMirror(G_PART.CreateReferenceFromObject(G_PART.OriginElements.${planeProp}))`,
            '  If CimaErr("AddNewMirror") Then',
            '    CimaFeature fid, "error", CIMA_LASTERR',
            '    Exit Sub',
            '  End If',
            nameLine,
            ...this.finish('update'),
          ]
          break
        }
        case 'linearPattern':
        case 'circularPattern':
          this.writePattern(f, index)
          return
      }
    } catch (e) {
      body = [`  CimaFeature fid, "error", ${vs(`No se pudo evaluar: ${(e as Error).message}`)}`]
    }
    this.sub(fid, `${f.type} ${f.id}`, body)
  }

  /**
   * Common ending: update the feature, delete it on failure; for material features check the
   * volume change and optionally try the alternative direction once.
   */
  private finish(kind: 'material' | 'update', sense?: 'add' | 'remove', flip?: string): string[] {
    const L = [
      '  Err.Clear',
      '  ok = CimaUpdate(feat)',
      '  If Not ok Then',
      '    CimaFeature fid, "error", CIMA_LASTERR',
      '    CimaDelete feat',
      '    Exit Sub',
      '  End If',
    ]
    if (kind === 'material') {
      const bad = sense === 'add' ? 'v1 <= v0 + 0.000000001' : 'v1 >= v0 - 0.000000001'
      L.push('  v1 = CimaVolume()')
      if (flip) {
        L.push(
          `  If v0 >= 0 And v1 >= 0 And ${bad} Then`,
          flip,
          '    ok = CimaUpdate(feat)',
          '    v1 = CimaVolume()',
          '    If ok Then CimaLog "info", fid & ": direccion invertida para que la operacion quite material"',
          '  End If',
        )
      }
      L.push(
        `  If v0 >= 0 And v1 >= 0 And ${bad} Then`,
        `    CimaFeature fid, "error", "La operacion no ${sense === 'add' ? 'anade' : 'quita'} material (revisa plano, posicion y direccion)"`,
        '    Exit Sub',
        '  End If',
      )
    }
    L.push('  CimaFeature fid, "ok", ""')
    return L
  }

  private writeHoles(f: Extract<Feature, { type: 'hole' }>, index: number, xf?: { T: RigidTransform; copy: number }): void {
    const ctx = this.ctx
    const path = `parts.${this.part.id}.features[${index}]`
    const baseId = xf ? `${f.id}#${xf.copy}` : f.id
    let frame: Frame
    let centers: V2[]
    try {
      frame = planeFrame(f.plane, ctx, `${path}.plane`)
      centers = resolvePositions(f.positions, f.repeat, ctx, path)
    } catch (e) {
      this.sub(baseId, `hole ${f.id}`, [`  CimaFeature fid, "error", ${vs((e as Error).message)}`])
      return
    }
    if (xf) frame = transformFrame(frame, xf.T)
    const d = ctx.pos(f.diameter, `${path}.diameter`)
    const kind = f.kind ?? 'simple'
    const depth = f.throughAll ? 0 : ctx.pos(f.depth ?? 0, `${path}.depth`)
    const head = kind !== 'simple' ? ctx.pos(f.headDiameter ?? 0, `${path}.headDiameter`) : 0
    const headAngle = f.headAngle === undefined ? 90 : ctx.n(f.headAngle, `${path}.headAngle`)
    const headDepth =
      kind === 'counterbored'
        ? ctx.pos(f.headDepth ?? 0, `${path}.headDepth`)
        : kind === 'countersunk'
          ? (head - d) / 2 / Math.tan(((headAngle / 2) * Math.PI) / 180)
          : 0
    // Hole sketches use a frame whose normal points against the drilling direction.
    const drillAlongNormal = !!f.reverse
    centers.forEach((c, k) => {
      const fid = centers.length > 1 ? `${baseId}.${k + 1}` : baseId
      // All holes of the feature share the entry plane (and its construction plane in CATIA);
      // each one gets its own positioning sketch with a single point.
      const hf: Frame = drillAlongNormal
        ? { origin: frame.origin, u: v3.scale(frame.u, -1), v: frame.v, n: v3.scale(frame.n, -1) }
        : frame
      const local: V2 = drillAlongNormal ? [-c[0], c[1]] : c
      const name = catiaName(f.name ?? f.id, f.id) + (centers.length > 1 ? `_${k + 1}` : '') + (xf ? `_${xf.copy}` : '')
      const body = [
        ...this.sketchCode(hf, [], (L) => L.push(`  Set feat = CimaPt(f2, ${vn(local[0])}, ${vn(local[1])})`)),
        '  v0 = CimaVolume()',
        `  Set feat = G_SF.AddNewHoleFromSketch(sk, ${vn(depth || 10)})`,
        '  If CimaErr("AddNewHoleFromSketch") Then',
        '    CimaFeature fid, "error", CIMA_LASTERR',
        '    Exit Sub',
        '  End If',
        `  feat.Name = ${vs(name)}`,
        `  feat.Type = ${kind === 'counterbored' ? 2 : kind === 'countersunk' ? 3 : 0}`,
        `  feat.Diameter.Value = ${vn(d)}`,
        f.throughAll ? '  feat.BottomLimit.LimitMode = 2' : `  feat.BottomLimit.Dimension.Value = ${vn(depth)}`,
        ...(kind === 'counterbored' ? [`  feat.HeadDiameter.Value = ${vn(head)}`, `  feat.HeadDepth.Value = ${vn(headDepth)}`] : []),
        ...(kind === 'countersunk'
          ? [`  feat.HeadAngle.Value = ${vn(headAngle)}`, `  feat.HeadDepth.Value = ${vn(headDepth)}`, `  feat.HeadDiameter.Value = ${vn(head)}`]
          : []),
        '  If CimaErr("hole parameters") Then CimaLog "warn", fid & ": " & CIMA_LASTERR',
        ...(f.thread
          ? [
              '  feat.ThreadingMode = 0',
              `  feat.ThreadDepth.Value = ${vn(f.thread.depth !== undefined ? ctx.pos(f.thread.depth, `${path}.thread.depth`) : depth || d * 2)}`,
              `  feat.ThreadDiameter.Value = ${vn(threadNominal(f.thread.size) ?? d)}`,
              `  If CimaErr("thread") Then CimaLog "warn", fid & ": rosca ${f.thread.size.replace(/"/g, '')} no aplicada: " & CIMA_LASTERR`,
            ]
          : []),
        ...this.formula('feat.Diameter', f.diameter, 'L', `${f.id}_diameter`),
        ...(!f.throughAll ? this.formula('feat.BottomLimit.Dimension', f.depth, 'L', `${f.id}_depth`) : []),
        ...(kind === 'counterbored' ? this.formula('feat.HeadDiameter', f.headDiameter, 'L', `${f.id}_head_d`) : []),
        ...(kind === 'counterbored' ? this.formula('feat.HeadDepth', f.headDepth, 'L', `${f.id}_head_depth`) : []),
        ...this.finish('material', 'remove', '    feat.Reverse'),
      ]
      this.sub(fid, `hole ${f.id} #${k + 1}`, body)
    })
  }

  private writePattern(f: Extract<Feature, { type: 'linearPattern' | 'circularPattern' }>, index: number): void {
    const ctx = this.ctx
    const path = `parts.${this.part.id}.features[${index}]`
    const transforms: RigidTransform[] = []
    try {
      const count = ctx.int(f.count, `${path}.count`)
      if (f.type === 'linearPattern') {
        const d1 = v3.norm(f.direction as V3)
        const s1 = ctx.n(f.spacing, `${path}.spacing`)
        const c2 = f.count2 === undefined ? 1 : ctx.int(f.count2, `${path}.count2`)
        const d2 = f.direction2 ? v3.norm(f.direction2 as V3) : ([0, 0, 0] as V3)
        const s2 = f.spacing2 === undefined ? 0 : ctx.n(f.spacing2, `${path}.spacing2`)
        for (let j = 0; j < c2; j++)
          for (let i = 0; i < count; i++) {
            if (i === 0 && j === 0) continue
            transforms.push({ R: [1, 0, 0, 0, 1, 0, 0, 0, 1], t: v3.add(v3.scale(d1, i * s1), v3.scale(d2, j * s2)) })
          }
      } else {
        const total = f.totalAngle === undefined ? 360 : ctx.n(f.totalAngle, `${path}.totalAngle`)
        const full = Math.abs(Math.abs(total) - 360) < 1e-9
        const step = count <= 1 ? 0 : full ? total / count : total / (count - 1)
        const center = f.center ? ctx.vec3(f.center, `${path}.center`) : ([0, 0, 0] as V3)
        for (let k = 1; k < count; k++) transforms.push(rotationAbout(AXIS_VECTORS[f.axis], center, k * step))
      }
    } catch (e) {
      this.sub(f.id, `pattern ${f.id}`, [`  CimaFeature fid, "error", ${vs((e as Error).message)}`])
      return
    }
    const byId = new Map(this.part.features.map((x, i) => [x.id, { f: x, i }]))
    transforms.forEach((T, k) => {
      for (const ref of f.features) {
        const src = byId.get(ref)
        if (!src || src.f.suppressed) continue
        this.writeFeature(src.f, src.i, { T, copy: k + 1 })
      }
    })
    this.sub(f.id, `pattern ${f.id}`, [`  CimaFeature fid, "ok", ${vs(`${transforms.length} copias creadas como operaciones independientes`)}`])
  }

  writeParameters(): void {
    if (!this.opts.createParameters) return
    // Model-level parameters are copied into every part (CATIA parts are independent documents).
    const all = [...this.model.parameters, ...this.part.parameters]
    if (all.length === 0) return
    const lines: string[] = [`  ReDim prm(${all.length - 1})`]
    // 1) create every parameter, 2) then the formulas of derived ones (any order of dependencies).
    all.forEach((p, i) => {
      const kind = p.unit === 'mm' ? 'LENGTH' : p.unit === 'deg' ? 'ANGLE' : 'REAL'
      const value = this.ctx.get(p.name) ?? p.value
      lines.push(`  Set prm(${i}) = CimaParam(${vs(p.name)}, ${vs(kind)}, ${vn(value)}, ${vs(p.description ?? '')})`)
    })
    all.forEach((p, i) => {
      if (!p.expression || !this.opts.createFormulas) return
      const dim: Dim = p.unit === 'mm' ? 'L' : p.unit === 'deg' ? 'A' : 'N'
      const f = this.formula(`prm(${i})`, p.expression, dim, `param_${p.name}`)
      if (f.length) lines.push(`  If Not prm(${i}) Is Nothing Then`, ...f.map((x) => `  ${x}`), '  End If')
    })
    const name = `${this.subPrefix}_params`
    this.out.subs.push([`Sub ${name}()`, '  Dim prm()', '  On Error Resume Next', ...lines, '  Err.Clear', 'End Sub'].join('\r\n'))
    this.out.lines.push(`  ${name}`)
  }
}

function threadNominal(size: string): number | null {
  const m = /^M\s*(\d+(?:[.,]\d+)?)/i.exec(size.trim())
  return m ? Number(m[1]!.replace(',', '.')) : null
}

function rotationAbout(axis: V3, center: V3, deg: number): RigidTransform {
  const a = (deg * Math.PI) / 180
  const [x, y, z] = v3.norm(axis)
  const c = Math.cos(a)
  const s = Math.sin(a)
  const t = 1 - c
  const R: RigidTransform['R'] = [
    t * x * x + c, t * x * y - s * z, t * x * z + s * y,
    t * x * y + s * z, t * y * y + c, t * y * z - s * x,
    t * x * z - s * y, t * y * z + s * x, t * z * z + c,
  ]
  // world = R (p - center) + center
  const rc: V3 = [
    R[0] * center[0] + R[1] * center[1] + R[2] * center[2],
    R[3] * center[0] + R[4] * center[1] + R[5] * center[2],
    R[6] * center[0] + R[7] * center[1] + R[8] * center[2],
  ]
  return { R, t: v3.sub(center, rc) }
}

function applyR(R: RigidTransform['R'], p: V3): V3 {
  return [R[0] * p[0] + R[1] * p[1] + R[2] * p[2], R[3] * p[0] + R[4] * p[1] + R[5] * p[2], R[6] * p[0] + R[7] * p[1] + R[8] * p[2]]
}

function transformFrame(f: Frame, T: RigidTransform): Frame {
  return { origin: v3.add(applyR(T.R, f.origin), T.t), u: applyR(T.R, f.u), v: applyR(T.R, f.v), n: applyR(T.R, f.n) }
}

// ---------------------------------------------------------------------------
// Document layer
// ---------------------------------------------------------------------------

function partBuildSub(
  model: CadModel,
  part: Part,
  index: number,
  resolution: ModelParameterResolution,
  opts: CatiaScriptOptions,
  subs: string[],
): string {
  const ctx = partContext(model, part.id, resolution)
  const out: Emitter = { lines: [], subs }
  const w = new PartWriter(model, part, ctx, opts, out, `CimaP${index}`)
  w.writeParameters()
  part.features.forEach((f, i) => {
    if (f.suppressed) {
      out.lines.push(`  G_PARTID = ${vs(part.id)}: CimaFeature ${vs(f.id)}, "skipped", "suprimida"`)
      return
    }
    w.writeFeature(f, i)
  })
  const color = part.color ? hexToRgb(part.color) : null
  const name = `CimaBuildPart${index}`
  subs.push(
    [
      `Sub ${name}()`,
      ...out.lines,
      '  On Error Resume Next',
      ...(opts.applyColors && color ? [`  CimaColor G_BODY, ${color.join(', ')}`] : []),
      '  G_PART.Update',
      '  If Err.Number <> 0 Then CimaLog "warn", "Actualizacion final de la pieza: " & Err.Description',
      '  Err.Clear',
      'End Sub',
    ].join('\r\n'),
  )
  return name
}

/** Creates the document for one part and builds it. Returns VBScript lines (inside CimaRun). */
function createPartLines(part: Part, index: number, buildSub: string, opts: CatiaScriptOptions, saveDir: string | undefined): string[] {
  const pn = opts.startModelName ? catiaName(opts.startModelName, part.id) : catiaName(part.name, part.id)
  const L = [`  ' ---- part ${part.id} ----`, `  CimaPartEvent ${vs(part.id)}, "start", ""`, '  Err.Clear']
  if (opts.target === '3dx') {
    L.push(
      '  Set svc = G_APP.GetSessionService("PLMNewService")',
      `  svc.SetAttributeValue "V_Name", ${vs(pn)}`,
      '  Err.Clear',
      '  Set ed = Nothing',
      '  svc.PLMCreate "3DShape", ed',
      '  If Err.Number <> 0 Then',
      '    CimaLog "warn", "PLMCreate: " & Err.Description',
      '    Err.Clear',
      '  End If',
      '  If Not IsObject(ed) Then Set ed = Nothing',
      '  If ed Is Nothing Then Set ed = G_APP.ActiveEditor',
      '  Set prt = ed.ActiveObject',
      '  If CimaErr("PLMCreate 3DShape") Then',
      `    CimaPartEvent ${vs(part.id)}, "error", CIMA_LASTERR`,
      '  Else',
      `    CimaUsePart ${vs(part.id)}, Nothing, ed, prt`,
      `    ${buildSub}`,
      `    CimaPartEvent ${vs(part.id)}, "ok", ""`,
      '  End If',
    )
  } else {
    L.push(
      '  If G_STARTMODEL <> "" Then',
      '    Set doc = G_APP.Documents.NewFrom(G_STARTMODEL)',
      '    If CimaErr("Documents.NewFrom") Then',
      '      CimaPartEvent ' + vs(part.id) + ', "error", "No se pudo abrir el modelo de inicio (sin acceso a la plantilla): " & CIMA_LASTERR',
      '    Else',
      '      Set prt = doc.Part',
      `      Set PDOC${index} = doc`,
      `      doc.Product.PartNumber = ${vs(pn)}`,
      '      Err.Clear',
      `      CimaUsePart ${vs(part.id)}, doc, Nothing, prt`,
      `      ${buildSub}`,
      ...(saveDir
        ? [
            `      sp = ${vs(saveDir)} & "\\" & ${vs(pn)} & ".CATPart"`,
            '      doc.SaveAs sp',
            '      If CimaErr("SaveAs") Then',
            '        CimaLog "error", CIMA_LASTERR',
            '      Else',
            '        CimaSaved sp',
            '      End If',
          ]
        : []),
      `      CimaPartEvent ${vs(part.id)}, "ok", ""`,
      '    End If',
      '  Else',
      '    Set doc = G_APP.Documents.Add("Part")',
      '    If CimaErr("Documents.Add Part") Then',
      `      CimaPartEvent ${vs(part.id)}, "error", CIMA_LASTERR`,
      '    Else',
      '      Set prt = doc.Part',
      `      Set PDOC${index} = doc`,
      `      doc.Product.PartNumber = ${vs(pn)}`,
      '      Err.Clear',
      `      CimaUsePart ${vs(part.id)}, doc, Nothing, prt`,
      `      ${buildSub}`,
      ...(saveDir
        ? [
            `      sp = ${vs(saveDir)} & "\\" & ${vs(pn)} & ".CATPart"`,
            '      doc.SaveAs sp',
            '      If CimaErr("SaveAs") Then',
            '        CimaLog "error", CIMA_LASTERR',
            '      Else',
            '        CimaSaved sp',
            '      End If',
          ]
        : []),
      `      CimaPartEvent ${vs(part.id)}, "ok", ""`,
      '    End If',
      '  End If',
    )
  }
  return L
}

/** Generates the complete script for a push request. */
export function generateCatiaScript(req: CatiaScriptRequest): string {
  const { model, overrides, options: opts } = req
  const resolution = resolveModelParameters(model, overrides)
  const subs: string[] = []
  const run: string[] = []
  const saveDir = opts.target === 'v5' && opts.saveDirectory ? opts.saveDirectory.replace(/[\\/]+$/, '') : undefined

    run.push(
      'Sub CimaRun()',
      '  Dim svc, ed, doc, prt, sp, pdoc, root, comp, inst, arr(11), cons, rf, pathPrefix, i',
      '  On Error Resume Next',
      `  G_TARGET = ${vs(opts.target)}`,
      `  G_STARTMODEL = ${vs(opts.target === 'v5' ? (opts.startModel ?? '') : '')}`,
      '  G_APP.RefreshDisplay = False',
    '  G_APP.DisplayFileAlerts = False',
    '  Err.Clear',
    `  CimaEmit "{""t"":""start"",""target"":" & CimaQ(G_TARGET) & ",""version"":" & CimaQ(CimaVersion(G_APP)) & "}", "CIMA -> " & CimaVersion(G_APP)`,
    `  If CimaDetect(G_APP) <> G_TARGET Then CimaLog "warn", "El CATIA conectado parece " & UCase(CimaDetect(G_APP)) & " pero el destino es " & UCase(G_TARGET)`,
  )

  const builtParts = new Map<string, number>()
  const usedPartIds = new Set(model.kind === 'assembly' ? (model.instances ?? []).map((i) => i.part) : [model.parts[0]!.id])
  model.parts.forEach((part, i) => {
    if (!usedPartIds.has(part.id)) {
      run.push(`  CimaLog "warn", ${vs(`La pieza "${part.id}" no tiene instancias y no se crea`)}`)
      return
    }
    const sub = partBuildSub(model, part, i, resolution, opts, subs)
    run.push(...createPartLines(part, i, sub, opts, saveDir))
    builtParts.set(part.id, i)
  })

  if (model.kind === 'assembly' && model.instances?.length) {
    if (opts.target === '3dx') {
      run.push(
        '  CimaLog "warn", "3DEXPERIENCE: las piezas se han creado como 3D Shapes independientes. El ensamblaje (Physical Product) requiere licencia de autor de productos; importa el STEP del ensamblaje exportado desde CIMA o colócalas manualmente."',
      )
    } else {
      run.push(...assemblyLines(model, resolution, saveDir, opts.applyColors, opts))
    }
  } else if (saveDir && opts.exportStep) {
    const pn = opts.startModelName ? catiaName(opts.startModelName, model.parts[0]!.id) : catiaName(model.parts[0]!.name, model.parts[0]!.id)
    run.push(
      `  sp = ${vs(saveDir)} & "\\" & ${vs(pn)} & ".stp"`,
      '  doc.ExportData sp, "stp"',
      '  If CimaErr("ExportData") Then',
      '    CimaLog "error", CIMA_LASTERR',
      '  Else',
      '    CimaSaved sp',
      '  End If',
    )
  }

  run.push(
    '  G_APP.RefreshDisplay = True',
    '  G_APP.DisplayFileAlerts = True',
    '  Err.Clear',
    '  If CIMA_ERRORS = 0 Then sp = "true" Else sp = "false"',
    '  CimaEmit "{""t"":""end"",""ok"":" & sp & ",""errors"":" & CIMA_ERRORS & ",""warnings"":" & CIMA_WARNINGS & "}", "Fin: " & CIMA_ERRORS & " errores, " & CIMA_WARNINGS & " avisos"',
    'End Sub',
  )

  const header =
    opts.flavor === 'vbs'
      ? [
          `' CIMA -> CATIA ${opts.target.toUpperCase()} - script generado automaticamente`,
          `' Modelo: ${model.name.replace(/\r?\n/g, ' ')}`,
          "' Ejecucion: cscript //nologo //U este_archivo.vbs   (con CATIA abierto)",
          '',
        ]
      : [
          `' CIMA -> CATIA ${opts.target.toUpperCase()} - macro generada automaticamente (VBScript)`,
          `' Modelo: ${model.name.replace(/\r?\n/g, ' ')}`,
          "' Uso: Herramientas > Macro > Macros > Bibliotecas (tipo VBScript/.catvbs) > ejecutar CATMain",
          '',
        ]

  const entry =
    opts.flavor === 'vbs'
      ? [
          '',
          "' ---------- entry point (external) ----------",
          'If WScript.Arguments.Count > 0 Then',
          '  If WScript.Arguments(0) = "--check" Then WScript.Quit 0',
          'End If',
          'On Error Resume Next',
          opts.connect === 'launch'
            ? 'Set G_APP = GetObject(, "CATIA.Application")\r\nIf Err.Number <> 0 Then\r\n  Err.Clear\r\n  Set G_APP = CreateObject("CATIA.Application")\r\n  G_APP.Visible = True\r\nEnd If'
            : 'Set G_APP = GetObject(, "CATIA.Application")',
          'If Err.Number <> 0 Then',
          '  CimaEmit "{""t"":""log"",""level"":""error"",""msg"":" & CimaQ("No se pudo conectar con CATIA (" & Err.Number & "): " & Err.Description & ". Abre CATIA y vuelve a intentarlo.") & "}", ""',
          '  CimaEmit "{""t"":""end"",""ok"":false,""errors"":1,""warnings"":0}", ""',
          '  WScript.Quit 2',
          'End If',
          'On Error GoTo 0',
          'CimaRun',
          'If CIMA_ERRORS > 0 Then WScript.Quit 1',
          'WScript.Quit 0',
        ]
      : [
          '',
          'Sub CATMain()',
          '  Set G_APP = CATIA',
          '  CimaRun',
          '  MsgBox "CIMA" & vbLf & vbLf & CIMA_LOGTEXT, 64, "CIMA"',
          'End Sub',
        ]

  return [...header, vbsRuntime(opts.flavor), ...subs, '', run.join('\r\n'), ...entry, ''].join('\r\n')
}

function assemblyLines(
  model: CadModel,
  resolution: ModelParameterResolution,
  saveDir: string | undefined,
  applyColors: boolean,
  opts: CatiaScriptOptions,
): string[] {
  const mctx = modelContext(model, resolution)
  const rootName = opts.startModelName ? catiaName(opts.startModelName, 'Ensamblaje') : catiaName(model.name, 'Ensamblaje')
  const L: string[] = [
    "  ' ---- assembly ----",
    '  Err.Clear',
    '  If G_STARTMODEL <> "" Then',
    '    Set pdoc = G_APP.Documents.NewFrom(G_STARTMODEL)',
    '    If CimaErr("Documents.NewFrom") Then',
    '      CimaLog "error", "No se pudo abrir el modelo de inicio (sin acceso a la plantilla): " & CIMA_LASTERR',
    '      Exit Sub',
    '    End If',
    '  Else',
    '    Set pdoc = G_APP.Documents.Add("Product")',
    '    If CimaErr("Documents.Add Product") Then',
    '      CimaLog "error", CIMA_LASTERR',
    '      Exit Sub',
    '    End If',
    '  End If',
    '  Set root = pdoc.Product',
    `  root.PartNumber = ${vs(rootName)}`,
    '  Err.Clear',
  ]
  // Parts are standalone documents already open in the session: insert them by reference.
  const firstInstanceVar = new Map<string, string>()
  const usedNames = new Set<string>()
  model.parts.forEach((part, i) => {
    if (!(model.instances ?? []).some((x) => x.part === part.id)) return
    const pn = catiaName(part.name, part.id)
    L.push(
      `  ' component ${part.id}`,
      '  Set comp = Nothing',
      `  If Not PDOC${i} Is Nothing Then`,
      `    Set comp = root.Products.AddComponent(PDOC${i}.Product)`,
      '    If Err.Number <> 0 Then',
      `      CimaErr "AddComponent"`,
      '      Set comp = Nothing',
      ...(saveDir
        ? [
            `      root.Products.AddComponentsFromFiles Array(${vs(saveDir)} & "\\" & ${vs(pn)} & ".CATPart"), "All"`,
            '      If Err.Number = 0 Then Set comp = root.Products.Item(root.Products.Count)',
            '      Err.Clear',
          ]
        : []),
      '    End If',
      '  End If',
      '  If comp Is Nothing Then',
      `    CimaLog "error", ${vs(`No se pudo insertar la pieza ${pn} en el ensamblaje: `)} & CIMA_LASTERR`,
      '  Else',
      `    Set REFP${i} = comp.ReferenceProduct`,
      `    Set FIRSTINST${i} = comp`,
      '  End If',
      '  Err.Clear',
    )
    firstInstanceVar.set(part.id, String(i))
  })
  for (const inst of model.instances ?? []) {
    const idx = firstInstanceVar.get(inst.part)
    if (idx === undefined) continue
    let T: RigidTransform
    try {
      T = instanceTransform(inst, mctx)
    } catch (e) {
      L.push(`  CimaLog "error", ${vs(`Instancia ${inst.id}: ${(e as Error).message}`)}`)
      continue
    }
    let nm = catiaName(inst.name ?? inst.id, inst.id)
    while (usedNames.has(nm)) nm += '_'
    usedNames.add(nm)
    const R = T.R
    // Position components: X axis, Y axis, Z axis (columns of R), then origin — mm.
    const comps = [R[0], R[3], R[6], R[1], R[4], R[7], R[2], R[5], R[8], T.t[0], T.t[1], T.t[2]]
    L.push(
      `  ' instance ${inst.id}`,
      `  If Not REFP${idx} Is Nothing Then`,
      `    If Not FIRSTINST${idx} Is Nothing Then`,
      `      Set inst = FIRSTINST${idx}`,
      `      Set FIRSTINST${idx} = Nothing`,
      '    Else',
      `      Set inst = root.Products.AddComponent(REFP${idx})`,
      '    End If',
      `    inst.Name = ${vs(nm)}`,
      ...comps.map((c, k) => `    arr(${k}) = ${vn(c)}`),
      '    inst.Position.SetComponents arr',
      `    If CimaErr("Position ${inst.id}") Then CimaLog "error", CIMA_LASTERR`,
      ...(inst.color && applyColors
        ? [
            // Instance-level color override (assembly context), cosmetic: failures are only warnings.
            '    Set G_SEL = pdoc.Selection',
            '    G_SEL.Clear',
            '    G_SEL.Add inst',
            `    G_SEL.VisProperties.SetRealColor ${hexToRgb(inst.color).join(', ')}, 1`,
            '    G_SEL.Clear',
            `    If CimaErr("Color ${inst.id}") Then CimaLog "warn", "Color de instancia no aplicado: " & CIMA_LASTERR`,
          ]
        : []),
      ...(inst.fixed
        ? [
            '    Set cons = root.Connections("CATIAConstraints")',
            '    Set rf = root.CreateReferenceFromName(root.Name & "/" & inst.Name & "/!" & root.Name & "/" & inst.Name & "/")',
            '    cons.AddMonoEltCst 0, rf',
            `    If CimaErr("Fix ${inst.id}") Then CimaLog "warn", "No se pudo fijar la instancia: " & CIMA_LASTERR`,
          ]
        : []),
      '  End If',
    )
  }
  L.push('  root.Update', '  Err.Clear')
  if (saveDir) {
    L.push(
      `  sp = ${vs(saveDir)} & "\\" & ${vs(rootName)} & ".CATProduct"`,
      '  pdoc.SaveAs sp',
      '  If CimaErr("SaveAs product") Then',
      '    CimaLog "error", CIMA_LASTERR',
      '  Else',
      '    CimaSaved sp',
      '  End If',
    )
  }
  return L
}

/** Per-part globals: created document, reference product and first instance (assemblies). */
function partGlobals(model: CadModel): string {
  const decl = model.parts.map((_, i) => `PDOC${i}, REFP${i}, FIRSTINST${i}`).join(', ')
  const init = model.parts.map((_, i) => `Set PDOC${i} = Nothing: Set REFP${i} = Nothing: Set FIRSTINST${i} = Nothing`).join('\r\n')
  return `Dim ${decl}\r\n${init}`
}

/** Full script (public entry point). */
export function generateScript(req: CatiaScriptRequest): string {
  return generateCatiaScript(req).replace(
    "' =================== end CIMA runtime ===================",
    `${partGlobals(req.model)}\r\n' =================== end CIMA runtime ===================`,
  )
}
