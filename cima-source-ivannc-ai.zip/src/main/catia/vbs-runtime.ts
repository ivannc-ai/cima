/**
 * VBScript runtime library embedded in every generated CATIA script.
 *
 * Written in the common subset of VBScript understood by cscript.exe and by CATIA's VBScript macro
 * engine (.catvbs): no "Dim x As Type", no classes, no Execute, numeric literals for every CATIA enum
 * (external scripts do not know the CATIA enum names).
 *
 * Enum values used (identical on V5 and 3DEXPERIENCE):
 *   CatLimitMode: 0 offset, 2 up to last          CatPrismOrientation: 0 regular, 1 inverse
 *   CatFilletEdgePropagation: 1 tangency           CatChamferPropagation: 0 tangency
 *   CatChamferMode: 1 length-angle                  CatChamferOrientation: 0 no reverse
 *   CatHoleType: 0 simple, 2 counterbored, 3 countersunk
 *   CatHoleThreadingMode: 0 threaded, 1 smooth     CatConstraintType: 0 reference (fix)
 */
import type { CatiaScriptOptions } from '@shared/catia/types'
import { CATIA_LINE_PREFIX } from '@shared/catia/types'

export function vbsRuntime(flavor: CatiaScriptOptions['flavor']): string {
  const emit =
    flavor === 'vbs'
      ? `Sub CimaEmit(json, human)
  WScript.StdOut.WriteLine "${CATIA_LINE_PREFIX}" & json
End Sub`
      : `Sub CimaEmit(json, human)
  If Len(human) > 0 Then CIMA_LOGTEXT = CIMA_LOGTEXT & human & vbLf
End Sub`

  return `' ===================== CIMA runtime =====================
Dim CIMA_ERRORS, CIMA_WARNINGS, CIMA_LOGTEXT
CIMA_ERRORS = 0
CIMA_WARNINGS = 0
CIMA_LOGTEXT = ""
Dim G_TARGET, G_APP, G_DOC, G_EDITOR, G_PART, G_BODY, G_SEL, G_SPA, G_HSF, G_SF, G_CONSTR, G_PARTID, G_EDGE_KW, G_FACE_KW
G_EDGE_KW = ""
G_FACE_KW = ""

Function CimaQ(s)
  Dim r
  r = CStr(s)
  r = Replace(r, "\\", "\\\\")
  r = Replace(r, """", "\\""")
  r = Replace(r, vbCr, "\\r")
  r = Replace(r, vbLf, "\\n")
  r = Replace(r, vbTab, "\\t")
  CimaQ = """" & r & """"
End Function

Function CimaNum(x)
  CimaNum = Replace(CStr(x), ",", ".")
End Function

${emit}

Sub CimaLog(level, msg)
  If level = "error" Then CIMA_ERRORS = CIMA_ERRORS + 1
  If level = "warn" Then CIMA_WARNINGS = CIMA_WARNINGS + 1
  CimaEmit "{""t"":""log"",""level"":" & CimaQ(level) & ",""msg"":" & CimaQ(msg) & "}", UCase(level) & ": " & msg
End Sub

Sub CimaFeature(featId, status, msg)
  If status = "error" Then CIMA_ERRORS = CIMA_ERRORS + 1
  CimaEmit "{""t"":""feature"",""part"":" & CimaQ(G_PARTID) & ",""feature"":" & CimaQ(featId) & ",""status"":" & CimaQ(status) & ",""msg"":" & CimaQ(msg) & "}", G_PARTID & "/" & featId & ": " & status & " " & msg
End Sub

Sub CimaPartEvent(partId, status, msg)
  CimaEmit "{""t"":""part"",""part"":" & CimaQ(partId) & ",""status"":" & CimaQ(status) & ",""msg"":" & CimaQ(msg) & "}", "Pieza " & partId & ": " & status & " " & msg
End Sub

Sub CimaSaved(path)
  CimaEmit "{""t"":""saved"",""path"":" & CimaQ(path) & "}", "Guardado: " & path
End Sub

Function CimaErr(stage)
  ' Returns True (and logs) if an error is pending.
  CimaErr = False
  If Err.Number <> 0 Then
    CimaErr = True
    CIMA_LASTERR = stage & ": " & Err.Description & " (" & Err.Number & ")"
    Err.Clear
  End If
End Function
Dim CIMA_LASTERR
CIMA_LASTERR = ""

' ---------- application ----------
Function CimaDetect(app)
  Dim nm, svc
  nm = ""
  On Error Resume Next
  nm = UCase(CStr(app.Name))
  Err.Clear
  Set svc = app.GetSessionService("PLMNewService")
  If Err.Number = 0 Then
    CimaDetect = "3dx"
  ElseIf nm = "3DEXPERIENCE" Then
    CimaDetect = "3dx"
  Else
    CimaDetect = "v5"
  End If
  Err.Clear
  On Error GoTo 0
End Function

Function CimaVersion(app)
  Dim v
  v = ""
  On Error Resume Next
  v = CStr(app.Name) & " V" & CStr(app.SystemConfiguration.Version) & "R" & CStr(app.SystemConfiguration.Release) & " SP" & CStr(app.SystemConfiguration.ServicePack)
  Err.Clear
  On Error GoTo 0
  CimaVersion = v
End Function

' ---------- geometry helpers ----------
Sub CimaHide(obj)
  On Error Resume Next
  G_SEL.Clear
  G_SEL.Add obj
  G_SEL.VisProperties.SetShow 1
  G_SEL.Clear
  Err.Clear
End Sub

Function CimaPlaneRef(ox, oy, oz, nx, ny, nz)
  Dim d, pl
  d = nx * ox + ny * oy + nz * oz
  If Abs(d) < 0.000000001 Then
    If Abs(Abs(nz) - 1) < 0.000000001 Then
      Set CimaPlaneRef = G_PART.CreateReferenceFromObject(G_PART.OriginElements.PlaneXY)
      Exit Function
    End If
    If Abs(Abs(nx) - 1) < 0.000000001 Then
      Set CimaPlaneRef = G_PART.CreateReferenceFromObject(G_PART.OriginElements.PlaneYZ)
      Exit Function
    End If
    If Abs(Abs(ny) - 1) < 0.000000001 Then
      Set CimaPlaneRef = G_PART.CreateReferenceFromObject(G_PART.OriginElements.PlaneZX)
      Exit Function
    End If
  End If
  ' Reuse an identical construction plane of this part when possible.
  Dim key, i
  key = CStr(Round(nx, 9)) & "|" & CStr(Round(ny, 9)) & "|" & CStr(Round(nz, 9)) & "|" & CStr(Round(d, 6))
  For i = 0 To G_PLCOUNT - 1
    If G_PLKEYS(i) = key Then
      Set CimaPlaneRef = G_PART.CreateReferenceFromObject(G_PLOBJS(i))
      Exit Function
    End If
  Next
  Set pl = G_HSF.AddNewPlaneEquation(nx, ny, nz, d)
  G_CONSTR.AppendHybridShape pl
  G_PART.InWorkObject = pl
  G_PART.UpdateObject pl
  CimaHide pl
  If G_PLCOUNT > UBound(G_PLKEYS) Then
    ReDim Preserve G_PLKEYS(G_PLCOUNT * 2)
    ReDim Preserve G_PLOBJS(G_PLCOUNT * 2)
  End If
  G_PLKEYS(G_PLCOUNT) = key
  Set G_PLOBJS(G_PLCOUNT) = pl
  G_PLCOUNT = G_PLCOUNT + 1
  Set CimaPlaneRef = G_PART.CreateReferenceFromObject(pl)
End Function
Dim G_PLKEYS(), G_PLOBJS(), G_PLCOUNT
ReDim G_PLKEYS(7)
ReDim G_PLOBJS(7)
G_PLCOUNT = 0

' Creates a sketch whose absolute axis is exactly (origin, H = u, V = v).
Function CimaSketch(ox, oy, oz, ux, uy, uz, vx, vy, vz)
  Dim nx, ny, nz, ref, sk, ad(8)
  nx = uy * vz - uz * vy
  ny = uz * vx - ux * vz
  nz = ux * vy - uy * vx
  Set ref = CimaPlaneRef(ox, oy, oz, nx, ny, nz)
  Set sk = G_BODY.Sketches.Add(ref)
  ad(0) = ox: ad(1) = oy: ad(2) = oz
  ad(3) = ux: ad(4) = uy: ad(5) = uz
  ad(6) = vx: ad(7) = vy: ad(8) = vz
  sk.SetAbsoluteAxisData ad
  G_PART.InWorkObject = sk
  Set CimaSketch = sk
End Function

Function CimaPt(f2, x, y)
  Set CimaPt = f2.CreatePoint(x, y)
End Function

Sub CimaLine(f2, pa, pb, x1, y1, x2, y2)
  Dim l
  Set l = f2.CreateLine(x1, y1, x2, y2)
  l.StartPoint = pa
  l.EndPoint = pb
End Sub

' Counter-clockwise arc from angle a1 to a2 (radians, a2 > a1) between existing points ps -> pe.
Sub CimaArc(f2, cx, cy, r, a1, a2, ps, pe)
  Dim pc, c
  Set pc = f2.CreatePoint(cx, cy)
  Set c = f2.CreateCircle(cx, cy, r, a1, a2)
  c.CenterPoint = pc
  c.StartPoint = ps
  c.EndPoint = pe
End Sub

Sub CimaCircle(f2, cx, cy, r)
  Dim c
  Set c = f2.CreateClosedCircle(cx, cy, r)
End Sub

Sub CimaAxisLine(f2, sk, isU)
  Dim l
  If isU Then
    Set l = f2.CreateLine(-100, 0, 100, 0)
  Else
    Set l = f2.CreateLine(0, -100, 0, 100)
  End If
  l.Construction = True
  sk.CenterLine = l
End Sub

Sub CimaEndSketch(sk)
  sk.CloseEdition
  G_PART.InWorkObject = sk
  G_PART.UpdateObject sk
  G_PART.InWorkObject = G_BODY
End Sub

' ---------- knowledgeware ----------
Function CimaParam(name, kind, value, comment)
  Dim p
  On Error Resume Next
  If kind = "LENGTH" Or kind = "ANGLE" Then
    Set p = G_PART.Parameters.CreateDimension(name, kind, value)
  Else
    Set p = G_PART.Parameters.CreateReal(name, value)
  End If
  If Err.Number <> 0 Then
    CimaLog "warn", "Parametro " & name & ": " & Err.Description
    Err.Clear
    Set CimaParam = Nothing
    Exit Function
  End If
  If Len(comment) > 0 Then p.Comment = comment
  Err.Clear
  Set CimaParam = p
End Function

' Creates a formula; tries plain parameter names first, then back-quoted names.
Sub CimaFormula(fname, target, plain, quoted)
  Dim f
  On Error Resume Next
  Set f = G_PART.Relations.CreateFormula(fname, "CIMA", target, plain)
  If Err.Number <> 0 Then
    Err.Clear
    If Len(quoted) > 0 Then Set f = G_PART.Relations.CreateFormula(fname, "CIMA", target, quoted)
    If Err.Number <> 0 Then
      CimaLog "warn", "Formula " & fname & " = " & plain & " no aplicada: " & Err.Description
      Err.Clear
    End If
  End If
End Sub

' ---------- measurement ----------
Function CimaVolume()
  Dim m, v
  v = -1
  On Error Resume Next
  Set m = G_SPA.GetMeasurable(G_PART.CreateReferenceFromObject(G_BODY))
  If Err.Number = 0 Then v = m.Volume
  If Err.Number <> 0 Then v = -1
  Err.Clear
  CimaVolume = v
End Function

Function CimaBodyCog(c)
  Dim m
  CimaBodyCog = False
  On Error Resume Next
  Set m = G_SPA.GetMeasurable(G_PART.CreateReferenceFromObject(G_BODY))
  If Err.Number = 0 Then m.GetCOG c
  If Err.Number = 0 Then CimaBodyCog = True
  Err.Clear
End Function

' Deletes a feature that failed so that the part stays consistent.
Sub CimaDelete(obj)
  On Error Resume Next
  G_SEL.Clear
  G_SEL.Add obj
  G_SEL.Delete
  G_SEL.Clear
  G_PART.InWorkObject = G_BODY
  Err.Clear
End Sub

' Updates a feature; returns True on success.
Function CimaUpdate(obj)
  On Error Resume Next
  G_PART.UpdateObject obj
  If Err.Number <> 0 Then
    CIMA_LASTERR = "Update: " & Err.Description
    Err.Clear
    CimaUpdate = False
  Else
    CimaUpdate = True
  End If
End Function

' ---------- topology search ----------
' Selects topology cells (edges or faces) of the current body. Tries several keyword spellings
' because CATIA localizes the search keywords.
Function CimaSearch(isEdge)
  Dim kws, kw, i, n
  If isEdge Then
    If Len(G_EDGE_KW) > 0 Then
      kws = Array(G_EDGE_KW)
    Else
      kws = Array("Topology.CGMEdge", "Topology.Edge", "Topología.Arista", "Topologia.Arista", "Topologie.Arête", "Topologie.Kante", "Topologia.Spigolo")
    End If
  Else
    If Len(G_FACE_KW) > 0 Then
      kws = Array(G_FACE_KW)
    Else
      kws = Array("Topology.CGMFace", "Topology.Face", "Topología.Cara", "Topologia.Cara", "Topologie.Face", "Topologie.Fläche", "Topologia.Faccia")
    End If
  End If
  n = 0
  On Error Resume Next
  For i = 0 To UBound(kws)
    kw = kws(i)
    G_SEL.Clear
    G_SEL.Add G_BODY
    Err.Clear
    G_SEL.Search kw & ",sel"
    If Err.Number = 0 Then
      n = G_SEL.Count
      If n > 0 Then
        If isEdge Then G_EDGE_KW = kw Else G_FACE_KW = kw
        Exit For
      End If
    End If
    Err.Clear
  Next
  Err.Clear
  CimaSearch = n
End Function

Function CimaDist(a, i, b, j)
  CimaDist = Sqr((a(i) - b(j)) ^ 2 + (a(i + 1) - b(j + 1)) ^ 2 + (a(i + 2) - b(j + 2)) ^ 2)
End Function

' Edge criteria: dirAxis (-1 none, 0 X, 1 Y, 2 Z); curve ("" | "line" | "circle");
' onAxis (-1 none) with onAt; useBox with bmin/bmax arrays; radius (<0 none); tol.
Function CimaEdgeMatches(ref, dirAxis, curve, onAxis, onAt, useBox, bmin, bmax, radius, tol)
  Dim m, p(8), L, chord, isLine, isCircle, r, k, d(2), dl, cc(2), ax(2), hasAxis, ok
  CimaEdgeMatches = False
  On Error Resume Next
  Set m = G_SPA.GetMeasurable(ref)
  If Err.Number <> 0 Then
    Err.Clear
    Exit Function
  End If
  m.GetPointsOnCurve p
  If Err.Number <> 0 Then
    Err.Clear
    Exit Function
  End If
  L = m.Length
  If Err.Number <> 0 Then
    L = -1
    Err.Clear
  End If
  chord = CimaDist(p, 0, p, 6)
  isLine = (L > 0 And Abs(chord - L) <= 0.000001 * (1 + L))
  r = m.Radius
  If Err.Number <> 0 Then
    r = -1
    Err.Clear
  End If
  isCircle = (Not isLine) And r > 0
  If curve = "line" And Not isLine Then Exit Function
  If curve = "circle" And Not isCircle Then Exit Function
  If dirAxis >= 0 Then
    If Not isLine Then Exit Function
    For k = 0 To 2
      d(k) = (p(6 + k) - p(k)) / chord
    Next
    If Abs(Abs(d(dirAxis)) - 1) > 0.000001 Then Exit Function
  End If
  If radius > 0 Then
    If Not isCircle Then Exit Function
    If Abs(r - radius) > tol Then Exit Function
  End If
  hasAxis = False
  If isCircle Then
    m.GetCenter cc
    If Err.Number = 0 Then
      m.GetAxis ax
      If Err.Number = 0 Then hasAxis = True
    End If
    Err.Clear
  End If
  If onAxis >= 0 Then
    For k = 0 To 2
      If Abs(p(3 * k + onAxis) - onAt) > tol Then Exit Function
    Next
    If hasAxis Then
      ' A circle lies in the plane only if its axis is normal to it.
      dl = Sqr(ax(0) ^ 2 + ax(1) ^ 2 + ax(2) ^ 2)
      If dl > 0 Then
        If Abs(Abs(ax(onAxis) / dl) - 1) > 0.000001 Then Exit Function
      End If
    End If
  End If
  If useBox Then
    For k = 0 To 2
      If p(k) < bmin(k) - tol Or p(k) > bmax(k) + tol Then Exit Function
      If p(3 + k) < bmin(k) - tol Or p(3 + k) > bmax(k) + tol Then Exit Function
      If p(6 + k) < bmin(k) - tol Or p(6 + k) > bmax(k) + tol Then Exit Function
      If isCircle And hasAxis Then
        If cc(k) - r < bmin(k) - tol And Abs(ax(k)) < 0.999999 Then Exit Function
        If cc(k) + r > bmax(k) + tol And Abs(ax(k)) < 0.999999 Then Exit Function
      End If
    Next
  End If
  Err.Clear
  CimaEdgeMatches = True
End Function

' Face criteria: nAxis (-1 none, 0 X, 1 Y, 2 Z) with nSign (+1/-1); onAxis/onAt; surf ("" | "plane" | "cylinder").
Function CimaFaceMatches(ref, nAxis, nSign, onAxis, onAt, surf, tol, bodyCog, hasBodyCog)
  Dim m, pl(8), cg(2), n(2), nl, isPlane, isCyl, r, k, s
  CimaFaceMatches = False
  On Error Resume Next
  Set m = G_SPA.GetMeasurable(ref)
  If Err.Number <> 0 Then
    Err.Clear
    Exit Function
  End If
  isPlane = False
  m.GetPlane pl
  If Err.Number = 0 Then isPlane = True
  Err.Clear
  isCyl = False
  If Not isPlane Then
    r = m.Radius
    If Err.Number = 0 And r > 0 Then isCyl = True
    Err.Clear
  End If
  If surf = "plane" And Not isPlane Then Exit Function
  If surf = "cylinder" And Not isCyl Then Exit Function
  If nAxis >= 0 Or onAxis >= 0 Then
    If Not isPlane Then Exit Function
    n(0) = pl(4) * pl(8) - pl(5) * pl(7)
    n(1) = pl(5) * pl(6) - pl(3) * pl(8)
    n(2) = pl(3) * pl(7) - pl(4) * pl(6)
    nl = Sqr(n(0) ^ 2 + n(1) ^ 2 + n(2) ^ 2)
    If nl = 0 Then Exit Function
    For k = 0 To 2
      n(k) = n(k) / nl
    Next
    m.GetCOG cg
    If Err.Number <> 0 Then
      Err.Clear
      For k = 0 To 2
        cg(k) = pl(k)
      Next
    End If
    If hasBodyCog Then
      ' Orient the normal outwards (away from the body centre of gravity).
      s = (cg(0) - bodyCog(0)) * n(0) + (cg(1) - bodyCog(1)) * n(1) + (cg(2) - bodyCog(2)) * n(2)
      If s < 0 Then
        For k = 0 To 2
          n(k) = -n(k)
        Next
      End If
    End If
    If nAxis >= 0 Then
      If n(nAxis) * nSign < 0.999999 Then Exit Function
    End If
    If onAxis >= 0 Then
      If Abs(Abs(n(onAxis)) - 1) > 0.000001 Then Exit Function
      If Abs(cg(onAxis) - onAt) > tol Then Exit Function
    End If
  End If
  Err.Clear
  CimaFaceMatches = True
End Function

' Collects references of matching edges into refs (dynamic array); returns the count.
Function CimaCollectEdges(refs, dirAxis, curve, onAxis, onAt, useBox, bmin, bmax, radius, tol)
  Dim n, i, cand(), cnt, rf
  cnt = 0
  n = CimaSearch(True)
  If n = 0 Then
    CimaCollectEdges = 0
    Exit Function
  End If
  ReDim cand(n - 1)
  On Error Resume Next
  For i = 1 To n
    Set cand(i - 1) = G_SEL.Item(i).Reference
  Next
  G_SEL.Clear
  ReDim refs(n - 1)
  For i = 0 To n - 1
    If CimaEdgeMatches(cand(i), dirAxis, curve, onAxis, onAt, useBox, bmin, bmax, radius, tol) Then
      Set refs(cnt) = cand(i)
      cnt = cnt + 1
    End If
  Next
  Err.Clear
  CimaCollectEdges = cnt
End Function

Function CimaCollectFaces(refs, nAxis, nSign, onAxis, onAt, surf, tol)
  Dim n, i, cand(), cnt, cog(2), hasCog
  cnt = 0
  hasCog = CimaBodyCog(cog)
  n = CimaSearch(False)
  If n = 0 Then
    CimaCollectFaces = 0
    Exit Function
  End If
  ReDim cand(n - 1)
  On Error Resume Next
  For i = 1 To n
    Set cand(i - 1) = G_SEL.Item(i).Reference
  Next
  G_SEL.Clear
  ReDim refs(n - 1)
  For i = 0 To n - 1
    If CimaFaceMatches(cand(i), nAxis, nSign, onAxis, onAt, surf, tol, cog, hasCog) Then
      Set refs(cnt) = cand(i)
      cnt = cnt + 1
    End If
  Next
  Err.Clear
  CimaCollectFaces = cnt
End Function

' ---------- part context ----------
Sub CimaUsePart(partId, doc, editor, part)
  G_PARTID = partId
  G_PLCOUNT = 0
  Set G_DOC = doc
  Set G_EDITOR = editor
  Set G_PART = part
  Set G_BODY = part.MainBody
  Set G_SF = part.ShapeFactory
  Set G_HSF = part.HybridShapeFactory
  On Error Resume Next
  If G_TARGET = "3dx" Then
    Set G_SEL = editor.Selection
    Set G_SPA = editor.GetService("MeasurableService")
  Else
    Set G_SEL = doc.Selection
    Set G_SPA = doc.GetWorkbench("SPAWorkbench")
  End If
  Err.Clear
  Set G_CONSTR = part.HybridBodies.Add()
  G_CONSTR.Name = "CIMA_Construccion"
  If Err.Number <> 0 Then CimaLog "warn", "No se pudo crear el set geometrico: " & Err.Description
  Err.Clear
  G_PART.InWorkObject = G_BODY
  Err.Clear
End Sub

Sub CimaColor(obj, r, g, b)
  On Error Resume Next
  G_SEL.Clear
  G_SEL.Add obj
  G_SEL.VisProperties.SetRealColor r, g, b, 1
  G_SEL.Clear
  Err.Clear
End Sub
' =================== end CIMA runtime ===================
`
}
