/** Small VBScripts for status detection, document inspection and parameter writing. */
import { CATIA_LINE_PREFIX } from '@shared/catia/types'
import { vn, vs } from './generator'

const COMMON = `Function Q(s)
  Dim r
  r = CStr(s)
  r = Replace(r, "\\", "\\\\")
  r = Replace(r, """", "\\""")
  r = Replace(r, vbCr, "\\r")
  r = Replace(r, vbLf, "\\n")
  r = Replace(r, vbTab, "\\t")
  Q = """" & r & """"
End Function
Function N(x)
  N = Replace(CStr(x), ",", ".")
End Function
Sub Emit(json)
  WScript.StdOut.WriteLine "${CATIA_LINE_PREFIX}" & json
End Sub
Function Detect(app)
  Dim nm, svc
  nm = ""
  On Error Resume Next
  nm = UCase(CStr(app.Name))
  Err.Clear
  Set svc = app.GetSessionService("PLMNewService")
  If Err.Number = 0 Then
    Detect = "3dx"
  ElseIf nm = "3DEXPERIENCE" Then
    Detect = "3dx"
  Else
    Detect = "v5"
  End If
  Err.Clear
End Function
Function Version(app)
  Dim v
  v = ""
  On Error Resume Next
  v = CStr(app.Name) & " V" & CStr(app.SystemConfiguration.Version) & " R" & CStr(app.SystemConfiguration.Release) & " SP" & CStr(app.SystemConfiguration.ServicePack)
  Err.Clear
  Version = v
End Function
' Active document (V5) or active editor object (3DEXPERIENCE) -> (name, type, parameters owner)
Function ActiveTarget(app, tgt, nm, tp)
  Dim d, ed, obj
  Set ActiveTarget = Nothing
  nm = ""
  tp = ""
  On Error Resume Next
  If tgt = "3dx" Then
    Set ed = app.ActiveEditor
    If Err.Number <> 0 Then Exit Function
    Set obj = ed.ActiveObject
    If Err.Number <> 0 Then Exit Function
    tp = TypeName(obj)
    nm = ""
    nm = obj.Parent.GetAttributeValue("V_Name")
    Err.Clear
    If Len(nm) = 0 Then nm = tp
    Set ActiveTarget = obj
  Else
    Set d = app.ActiveDocument
    If Err.Number <> 0 Then Exit Function
    nm = d.Name
    tp = TypeName(d)
    If tp = "PartDocument" Then
      Set ActiveTarget = d.Part
    ElseIf tp = "ProductDocument" Then
      Set ActiveTarget = d.Product
    End If
  End If
  Err.Clear
End Function
`

const ATTACH = `On Error Resume Next
Set app = GetObject(, "CATIA.Application")
If Err.Number <> 0 Then
  Emit "{""t"":""status"",""running"":false,""error"":" & Q(Err.Description & " (" & Err.Number & ")") & "}"
  WScript.Quit 0
End If
Err.Clear`

export function statusScript(): string {
  return `${COMMON}
Dim app, tgt, nm, tp, obj, dp, cap, w, c
${ATTACH}
tgt = Detect(app)
Set obj = ActiveTarget(app, tgt, nm, tp)
dp = ""
Err.Clear
If tgt = "v5" Then
  Dim d
  Set d = app.ActiveDocument
  If Err.Number = 0 Then dp = d.Path
  Err.Clear
End If
' Caption of the main window (pipe-separated: organization | CATIA.V5Rxx | PROGRAM | DEPARTMENT | ... | User user@host)
cap = ""
Err.Clear
For w = 1 To app.Windows.Count
  If w > 10 Then Exit For
  c = app.Windows.Item(w).Caption
  If Err.Number = 0 And InStr(c, "|") > 0 Then
    cap = c
    Exit For
  End If
  Err.Clear
Next
Emit "{""t"":""status"",""running"":true,""target"":" & Q(tgt) & ",""version"":" & Q(Version(app)) & ",""docName"":" & Q(nm) & ",""docType"":" & Q(tp) & ",""docPath"":" & Q(dp) & ",""caption"":" & Q(cap) & "}"
WScript.Quit 0
`
}

export function inspectScript(): string {
  return `${COMMON}
Dim app, tgt, nm, tp, obj, ps, i, p, val, kind, num, isUser
${ATTACH}
tgt = Detect(app)
Set obj = ActiveTarget(app, tgt, nm, tp)
If obj Is Nothing Then
  Emit "{""t"":""inspect"",""ok"":false,""error"":" & Q("No hay ningun documento de pieza o producto activo en CATIA") & "}"
  WScript.Quit 0
End If
Emit "{""t"":""inspect"",""ok"":true,""docName"":" & Q(nm) & ",""docType"":" & Q(tp) & "}"
Set ps = obj.Parameters
For i = 1 To ps.Count
  Err.Clear
  Set p = ps.Item(i)
  val = ""
  val = p.ValueAsString
  kind = TypeName(p)
  num = ""
  If kind = "Length" Or kind = "Angle" Or kind = "RealParam" Or kind = "IntParam" Or kind = "Dimension" Then
    num = N(p.Value)
  End If
  isUser = "false"
  If InStr(p.Name, "\\") = 0 Then isUser = "true"
  If Err.Number = 0 Then
    Emit "{""t"":""param"",""name"":" & Q(p.Name) & ",""value"":" & Q(val) & ",""numeric"":" & Q(num) & ",""kind"":" & Q(kind) & ",""user"":" & isUser & "}"
  End If
Next
Err.Clear
WScript.Quit 0
`
}

export function setParametersScript(values: Array<{ name: string; value: number }>): string {
  const sets = values
    .map(
      (v) => `Err.Clear
Set p = ps.Item(${vs(v.name)})
If Err.Number <> 0 Then
  Emit "{""t"":""feature"",""part"":""active"",""feature"":" & Q(${vs(v.name)}) & ",""status"":""error"",""msg"":" & Q("Parametro no encontrado") & "}"
  errs = errs + 1
Else
  p.Value = ${vn(v.value)}
  If Err.Number <> 0 Then
    Emit "{""t"":""feature"",""part"":""active"",""feature"":" & Q(${vs(v.name)}) & ",""status"":""error"",""msg"":" & Q(Err.Description) & "}"
    errs = errs + 1
  Else
    Emit "{""t"":""feature"",""part"":""active"",""feature"":" & Q(${vs(v.name)}) & ",""status"":""ok"",""msg"":""""}"
  End If
End If`,
    )
    .join('\n')
  return `${COMMON}
Dim app, tgt, nm, tp, obj, ps, p, errs, okS
${ATTACH}
errs = 0
tgt = Detect(app)
Set obj = ActiveTarget(app, tgt, nm, tp)
If obj Is Nothing Then
  Emit "{""t"":""log"",""level"":""error"",""msg"":" & Q("No hay ningun documento activo en CATIA") & "}"
  Emit "{""t"":""end"",""ok"":false,""errors"":1,""warnings"":0}"
  WScript.Quit 1
End If
Set ps = obj.Parameters
${sets}
Err.Clear
obj.Update
If Err.Number <> 0 Then
  Emit "{""t"":""log"",""level"":""error"",""msg"":" & Q("Actualizacion: " & Err.Description) & "}"
  errs = errs + 1
End If
If errs = 0 Then okS = "true" Else okS = "false"
Emit "{""t"":""end"",""ok"":" & okS & ",""errors"":" & errs & ",""warnings"":0}"
WScript.Quit 0
`
}
