/**
 * Reads the main window title of the CATIA V5 session (process "cnext"). The title bar carries the
 * session context, pipe-separated: "Airbus Defence and Space | CATIA.V5R27 | PROGRAM | DEPARTMENT |
 * ... | User user@host |". Best-effort: returns null when CATIA is not running or PowerShell fails.
 */
import { execFile } from 'node:child_process'

const PS_COMMAND =
  '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; ' +
  '(Get-Process cnext -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle } | Select-Object -First 1).MainWindowTitle'

export function readCatiaWindowTitle(timeoutMs = 5000): Promise<string | null> {
  return new Promise((resolve) => {
    try {
      execFile(
        'powershell.exe',
        ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', PS_COMMAND],
        { timeout: timeoutMs, windowsHide: true, maxBuffer: 64 * 1024 },
        (err, stdout) => {
          const title = (stdout ?? '').trim()
          resolve(!err && title ? title : null)
        },
      )
    } catch {
      resolve(null)
    }
  })
}
