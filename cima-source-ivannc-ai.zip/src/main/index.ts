﻿/**
 * CIMA — Electron main process.
 *
 * In production the renderer is served from the privileged custom scheme app://cima/ (instead of
 * file://) so that fetch(), module workers and WebAssembly streaming compilation of the
 * OpenCascade kernel work, and a strict Content-Security-Policy can be attached.
 */
import { app, BrowserWindow, Menu, net, protocol, shell } from 'electron'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { SettingsStore } from './settings'
import { createAiService } from './ai'
import { createCatiaService } from './catia'
import { registerIpc } from './ipc'
import { appLog, initLogs } from './logs'

const APP_SCHEME = 'app'
const APP_HOST = 'cima'

protocol.registerSchemesAsPrivileged([
  {
    scheme: APP_SCHEME,
    privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true },
  },
])

const CSP = [
  "default-src 'self'",
  "script-src 'self' 'wasm-unsafe-eval'",
  "worker-src 'self' blob:",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "font-src 'self' data:",
  "connect-src 'self' data: blob:",
  "object-src 'none'",
  "base-uri 'none'",
  "frame-ancestors 'none'",
].join('; ')

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.wasm': 'application/wasm',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
}

function registerAppProtocol(rendererDir: string): void {
  protocol.handle(APP_SCHEME, async (request) => {
    const url = new URL(request.url)
    const rel = decodeURIComponent(url.pathname).replace(/^\/+/, '') || 'index.html'
    const file = path.normalize(path.join(rendererDir, rel))
    if (!file.startsWith(rendererDir)) return new Response('Forbidden', { status: 403 })
    try {
      const res = await net.fetch(pathToFileURL(file).toString())
      const headers = new Headers(res.headers)
      headers.set('Content-Type', MIME[path.extname(file).toLowerCase()] ?? 'application/octet-stream')
      if (file.endsWith('.html')) headers.set('Content-Security-Policy', CSP)
      return new Response(res.body, { status: res.status, headers })
    } catch {
      return new Response('Not found', { status: 404 })
    }
  })
}

function createWindow(): BrowserWindow {
  const win = new BrowserWindow({
    width: 1480,
    height: 920,
    minWidth: 1100,
    minHeight: 700,
    title: 'CIMA',
    backgroundColor: '#0e1014',
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, '../preload/index.js'),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  })
  win.once('ready-to-show', () => win.show())
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) void shell.openExternal(url)
    return { action: 'deny' }
  })
  win.webContents.on('will-navigate', (e, url) => {
    const allowed = process.env['ELECTRON_RENDERER_URL'] ?? `${APP_SCHEME}://${APP_HOST}`
    if (!url.startsWith(allowed)) e.preventDefault()
  })
  win.webContents.on('before-input-event', (_e, input) => {
    if (input.type === 'keyDown' && input.key === 'F12') win.webContents.toggleDevTools()
  })

  const devUrl = process.env['ELECTRON_RENDERER_URL']
  if (!app.isPackaged && devUrl) void win.loadURL(devUrl)
  else void win.loadURL(`${APP_SCHEME}://${APP_HOST}/index.html`)
  return win
}

const gotLock = app.requestSingleInstanceLock()
if (!gotLock) {
  app.quit()
} else {
  app.on('second-instance', () => {
    const w = BrowserWindow.getAllWindows()[0]
    if (w) {
      if (w.isMinimized()) w.restore()
      w.focus()
    }
  })

  app.whenReady().then(() => {
    app.setAppUserModelId('com.cima.app')
    Menu.setApplicationMenu(null)
    const logsFolder = initLogs(app.getPath('userData'))
    process.on('uncaughtException', (e) => appLog('error', 'main', 'uncaughtException', e))
    process.on('unhandledRejection', (e) => appLog('error', 'main', 'unhandledRejection', e))
    appLog('info', 'main', `CIMA ${app.getVersion()} iniciada (Electron ${process.versions.electron ?? '?'}) — logs en ${logsFolder}`)
    registerAppProtocol(path.join(__dirname, '../renderer'))
    const settings = new SettingsStore()
    const ai = createAiService({ getSettings: () => settings.get(), getApiKey: (id) => settings.getApiKey(id) })
    const catia = createCatiaService({ getSettings: () => settings.get(), tempDir: path.join(app.getPath('temp'), 'cima') })
    registerIpc({ settings, ai, catia })
    createWindow()
    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow()
    })
  })

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit()
  })
}

