/**
 * Network dispatchers for OpenAI-compatible endpoints: HTTP proxy and/or custom CA certificate.
 * Built with undici (the fetch implementation bundled with Node) and injected through the OpenAI
 * SDK's documented `fetch` + `fetchOptions.dispatcher` options.
 */
import fs from 'node:fs'
import { Agent, ProxyAgent, type Dispatcher } from 'undici'

/**
 * Resolves the CA certificate: inline PEM content or a path to a .pem/.crt/.cer file.
 * Throws with a clear message when a path cannot be read.
 */
export function resolveCaCertificate(caCertificate?: string): string | undefined {
  const v = caCertificate?.trim()
  if (!v) return undefined
  if (v.includes('-----BEGIN')) return v
  try {
    return fs.readFileSync(v, 'utf8')
  } catch (e) {
    throw new Error(`No se pudo leer el certificado CA "${v}": ${e instanceof Error ? e.message : String(e)}`)
  }
}

/**
 * Splits a proxy URL into the plain URI and the Proxy-Authorization token. Passwords with special
 * characters that are not percent-encoded (common when pasted from a corporate configuration) are
 * handled by a manual split that never decodes them.
 */
export function splitProxyUrl(proxy: string): { uri: string; token?: string } {
  try {
    const u = new URL(proxy)
    if (!u.username && !u.password) return { uri: `${u.protocol}//${u.host}` }
    const user = decodeURIComponent(u.username)
    const pass = decodeURIComponent(u.password)
    const token = 'Basic ' + Buffer.from(`${user}:${pass}`, 'utf8').toString('base64')
    return { uri: `${u.protocol}//${u.host}`, token }
  } catch {
    // Invalid URL (e.g. unencoded specials): take everything after the scheme as userinfo@host.
    const m = /^([a-z][a-z0-9+.-]*:\/\/)([^@]*)@(.+)$/i.exec(proxy)
    if (!m) return { uri: proxy }
    const scheme = m[1] ?? ''
    const userinfo = m[2] ?? ''
    const host = m[3] ?? ''
    return { uri: scheme + host, token: 'Basic ' + Buffer.from(userinfo, 'utf8').toString('base64') }
  }
}

/**
 * Builds the dispatcher for an endpoint reached through a proxy and/or verified against a custom CA.
 * Returns undefined when neither is configured (default network behavior).
 */
export function buildNetworkDispatcher(proxy?: string, caCertificate?: string): Dispatcher | undefined {
  const ca = resolveCaCertificate(caCertificate)
  const p = proxy?.trim()
  if (p) {
    const { uri, token } = splitProxyUrl(p)
    return new ProxyAgent({
      uri,
      ...(token ? { token } : {}),
      // TLS to the target is end-to-end through the CONNECT tunnel: the CA validates the target.
      ...(ca ? { requestTls: { ca } } : {}),
    })
  }
  if (ca) return new Agent({ connect: { ca } })
  return undefined
}
