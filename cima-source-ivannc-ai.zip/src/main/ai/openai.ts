/**
 * OpenAI-compatible provider (Chat Completions streaming): OpenAI, Gemini (OpenAI endpoint), Ollama and custom
 * OpenAI-compatible servers.
 */
import OpenAI, {
  APIConnectionError,
  APIConnectionTimeoutError,
  APIError,
  APIUserAbortError,
  AuthenticationError,
  BadRequestError,
  InternalServerError,
  NotFoundError,
  OpenAIError,
  PermissionDeniedError,
  RateLimitError,
  UnprocessableEntityError,
} from 'openai'
import type {
  ChatCompletion,
  ChatCompletionAssistantMessageParam,
  ChatCompletionChunk,
  ChatCompletionContentPart,
  ChatCompletionCreateParamsNonStreaming,
  ChatCompletionCreateParamsStreaming,
  ChatCompletionFunctionTool,
  ChatCompletionMessageFunctionToolCall,
  ChatCompletionMessageParam,
} from 'openai/resources/chat/completions/completions'
import {
  TOOL_NUDGE_TEXT,
  CAD_TOOL_NAME,
  type AssistantMessage,
  type ChatMessage,
  type ProviderConfig,
  type ProviderKind,
  type StopReason,
  type TokenUsage,
  type ToolCall,
} from '../../shared/ai/types'
import type { AiSettings } from '../../shared/settings'
import {
  errorText,
  looksLikeNoToolsSupport,
  looksLikeReasoningRejection,
  looksLikeSchemaRejection,
  looksLikeStreamOptionsRejection,
  messageForStatus,
  randomId,
  sanitizeToolId,
  truncate,
  type ChatError,
  type ProviderRunContext,
  type StreamEventBody,
} from './common'
import { extractModelFromText } from './extract'
import { NO_TOOLS_ADDENDUM, NO_TOOLS_TEMPLATE_ADDENDUM, SYSTEM_PROMPT, systemPromptFor } from './prompt'
import { CAD_TOOL_DESCRIPTION, TEMPLATE_TOOL_DESCRIPTION, cadToolSchema, templateToolSchema } from './schema'
import { TEMPLATE_TOOL_NAME } from '../../shared/templates'
import { fetch as undiciFetch } from 'undici'
import { buildNetworkDispatcher } from './proxy'

export const DEFAULT_OLLAMA_URL = 'http://localhost:11434/v1'
const OPENAI_ID_MAX = 40

// ---------------------------------------------------------------------------
// Transport (injectable for tests)
// ---------------------------------------------------------------------------

export interface OpenAITransport {
  stream(params: ChatCompletionCreateParamsStreaming, options: { signal: AbortSignal }): Promise<AsyncIterable<ChatCompletionChunk>>
  create(params: ChatCompletionCreateParamsNonStreaming, options: { timeout: number; signal?: AbortSignal }): Promise<ChatCompletion>
}

export type OpenAITransportFactory = (config: { apiKey: string; baseURL?: string; proxy?: string; caCertificate?: string }) => OpenAITransport

export const sdkOpenAITransport: OpenAITransportFactory = ({ apiKey, baseURL, proxy, caCertificate }) => {
  // Optional proxy / custom CA for corporate networks (undici dispatcher; undefined = default fetch).
  const dispatcher = buildNetworkDispatcher(proxy, caCertificate)
  const clientOptions: ConstructorParameters<typeof OpenAI>[0] = { apiKey, baseURL: baseURL || undefined, maxRetries: 5 }
  if (dispatcher) {
    clientOptions.fetch = undiciFetch as never
    clientOptions.fetchOptions = { dispatcher }
  }
  // Chat streams retry transient failures (429 / 503 "model overloaded", common on Gemini's free
  // tier) with the SDK's exponential backoff; the connection test uses maxRetries 0.
  const client = new OpenAI(clientOptions)
  return {
    stream: (params, options) => client.chat.completions.create(params, options),
    create: (params, options) => client.chat.completions.create(params, { ...options, maxRetries: 0 }),
  }
}

/** Resolves endpoint, key, proxy and CA for a provider (Ollama / keyless custom servers get a placeholder key). */
export function clientConfig(provider: ProviderConfig, apiKey: string | null): {
  apiKey: string
  baseURL?: string
  proxy?: string
  caCertificate?: string
} {
  const baseURL = provider.baseURL?.trim() || (provider.kind === 'ollama' ? DEFAULT_OLLAMA_URL : undefined)
  return {
    apiKey: apiKey && apiKey.length > 0 ? apiKey : 'not-needed',
    baseURL,
    proxy: provider.proxy?.trim() || undefined,
    caCertificate: provider.caCertificate?.trim() || undefined,
  }
}

// ---------------------------------------------------------------------------
// Capabilities
// ---------------------------------------------------------------------------

/** OpenAI reasoning models (o-series, gpt-5 family) accept `reasoning_effort`. */
export function supportsReasoningEffort(kind: ProviderKind, model: string): boolean {
  return kind === 'openai' && /^(o\d|gpt-5)/i.test(model)
}

export function mapReasoningEffort(effort: AiSettings['effort']): 'low' | 'medium' | 'high' {
  return effort === 'low' ? 'low' : effort === 'medium' ? 'medium' : 'high'
}

// ---------------------------------------------------------------------------
// Request building
// ---------------------------------------------------------------------------

export function buildOpenAITool(kind: ProviderKind, strict: boolean): ChatCompletionFunctionTool {
  if (kind === 'openai') {
    return {
      type: 'function',
      function: {
        name: CAD_TOOL_NAME,
        description: CAD_TOOL_DESCRIPTION,
        parameters: cadToolSchema(strict ? 'openai-strict' : 'openai'),
        ...(strict ? { strict: true } : {}),
      },
    }
  }
  return { type: 'function', function: { name: CAD_TOOL_NAME, description: CAD_TOOL_DESCRIPTION, parameters: cadToolSchema('compat') } }
}

export function buildOpenAITemplateTool(kind: ProviderKind, strict: boolean): ChatCompletionFunctionTool {
  const variant = kind === 'openai' ? (strict ? 'openai-strict' : 'openai') : 'compat'
  return {
    type: 'function',
    function: {
      name: TEMPLATE_TOOL_NAME,
      description: TEMPLATE_TOOL_DESCRIPTION,
      parameters: templateToolSchema(variant),
      ...(kind === 'openai' && strict ? { strict: true } : {}),
    },
  }
}

function dataUrl(mediaType: string, data: string): string {
  return `data:${mediaType};base64,${data}`
}

function argumentsString(input: unknown): string {
  if (typeof input === 'string') return input
  try {
    return JSON.stringify(input ?? {})
  } catch {
    return '{}'
  }
}

export interface OpenAIMessageOptions {
  kind: ProviderKind
  model: string
  /** false when the model cannot use tools: tool calls/results are rendered as text. */
  tools: boolean
  /** Template / audit options (default: both off = original prompt). */
  ai?: { templates?: boolean; audit?: boolean }
}

/** Converts provider-neutral messages into Chat Completions messages (system prompt included). */
export function toOpenAIMessages(messages: ReadonlyArray<ChatMessage>, o: OpenAIMessageOptions): ChatCompletionMessageParam[] {
  const out: ChatCompletionMessageParam[] = [{ role: 'system', content: o.ai ? systemPromptFor(o.ai) : SYSTEM_PROMPT }]
  if (!o.tools) {
    out.push({ role: 'system', content: o.ai?.templates ? `${NO_TOOLS_ADDENDUM}\n${NO_TOOLS_TEMPLATE_ADDENDUM}` : NO_TOOLS_ADDENDUM })
  }
  let pending: string[] = []

  const flushMissing = (answered: Set<string>) => {
    for (const id of pending) {
      if (!answered.has(id)) out.push({ role: 'tool', tool_call_id: id, content: 'No result was returned for this tool call.' })
    }
    pending = []
  }

  for (const m of messages) {
    if (m.role === 'assistant') {
      if (pending.length > 0) flushMissing(new Set())
      if (!o.tools) {
        const parts: string[] = []
        if (m.text.trim()) parts.push(m.text)
        for (const tc of m.toolCalls ?? []) parts.push('```json\n' + argumentsString(tc.input) + '\n```')
        if (parts.length > 0) out.push({ role: 'assistant', content: parts.join('\n\n') })
        continue
      }
      const raw = m.raw
      if (raw && raw.providerKind === o.kind && raw.model === o.model && raw.content && typeof raw.content === 'object') {
        const replay = raw.content as ChatCompletionAssistantMessageParam
        out.push(replay)
        pending = (replay.tool_calls ?? []).map((t) => t.id)
        continue
      }
      // Models that arrived as text (synthetic calls) go back as text, not as function calls.
      const textCalls = (m.toolCalls ?? []).filter((tc) => tc.id.startsWith('call_text'))
      const toolCalls: ChatCompletionMessageFunctionToolCall[] = (m.toolCalls ?? [])
        .filter((tc) => !tc.id.startsWith('call_text'))
        .map((tc) => ({
          id: sanitizeToolId(tc.id, OPENAI_ID_MAX),
          type: 'function',
          function: { name: tc.name, arguments: argumentsString(tc.input) },
        }))
      const content = [m.text.trim() ? m.text : '', ...textCalls.map((tc) => '```json\n' + argumentsString(tc.input) + '\n```')]
        .filter(Boolean)
        .join('\n\n')
      if (!content && toolCalls.length === 0) continue
      const msg: ChatCompletionAssistantMessageParam = { role: 'assistant', content: content || null }
      if (toolCalls.length > 0) msg.tool_calls = toolCalls
      out.push(msg)
      pending = toolCalls.map((t) => t.id)
      continue
    }

    // user
    const answered = new Set<string>()
    const orphanTexts: string[] = []
    for (const r of m.toolResults ?? []) {
      const label = `Tool result${r.isError ? ' (error)' : ''}:\n${r.content}`
      if (!o.tools) {
        orphanTexts.push(label)
        continue
      }
      const id = pending.includes(r.toolCallId) ? r.toolCallId : sanitizeToolId(r.toolCallId, OPENAI_ID_MAX)
      if (pending.includes(id) && !answered.has(id)) {
        answered.add(id)
        out.push({ role: 'tool', tool_call_id: id, content: r.content || '(empty)' })
      } else orphanTexts.push(label)
    }
    if (pending.length > 0) flushMissing(answered)
    pending = []
    const parts: ChatCompletionContentPart[] = []
    for (const p of m.content) {
      if (p.type === 'image') parts.push({ type: 'image_url', image_url: { url: dataUrl(p.mediaType, p.data) } })
    }
    for (const t of orphanTexts) parts.push({ type: 'text', text: t })
    for (const p of m.content) {
      if (p.type === 'text' && p.text.trim()) parts.push({ type: 'text', text: p.text })
    }
    if (parts.length === 0) {
      if ((m.toolResults?.length ?? 0) > 0 && o.tools) continue // only tool results: nothing else to say
      parts.push({ type: 'text', text: '(mensaje vacío)' })
    }
    // Plain string when there is only text (best compatibility with local servers).
    if (parts.every((p) => p.type === 'text')) {
      out.push({ role: 'user', content: parts.map((p) => (p as { text: string }).text).join('\n\n') })
    } else out.push({ role: 'user', content: parts })
  }
  if (pending.length > 0) flushMissing(new Set())
  return out
}

export interface OpenAIRequestOptions {
  kind: ProviderKind
  model: string
  messages: ChatMessage[]
  ai: AiSettings
  strict: boolean
  tools: boolean
  reasoning: boolean
  streamUsage: boolean
  /** Force tool_choice "required" (default: only when the last user message is the tool nudge). */
  forceTool?: boolean
}

/** True when the last message is the renderer's automatic "call the tool now" follow-up. */
export function isToolNudge(messages: ChatMessage[]): boolean {
  const last = messages[messages.length - 1]
  if (!last || last.role !== 'user') return false
  return last.content.some((p) => p.type === 'text' && p.text.startsWith(TOOL_NUDGE_TEXT))
}

export function buildOpenAIParams(o: OpenAIRequestOptions): ChatCompletionCreateParamsStreaming {
  const params: ChatCompletionCreateParamsStreaming = {
    model: o.model,
    messages: toOpenAIMessages(o.messages, { kind: o.kind, model: o.model, tools: o.tools, ai: o.ai }),
    stream: true,
  }
  if (o.streamUsage) params.stream_options = { include_usage: true }
  if (o.tools) {
    params.tools = o.ai.templates ? [buildOpenAITool(o.kind, o.strict), buildOpenAITemplateTool(o.kind, o.strict)] : [buildOpenAITool(o.kind, o.strict)]
    if (o.kind === 'openai') params.parallel_tool_calls = false
    // After a text-only design answer the renderer nudges the model; force the tool on that turn.
    if (o.forceTool ?? isToolNudge(o.messages)) params.tool_choice = 'required'
  }
  if (o.kind === 'openai') params.prompt_cache_key = 'cima-cad-v1'
  if (o.reasoning && supportsReasoningEffort(o.kind, o.model)) params.reasoning_effort = mapReasoningEffort(o.ai.effort)
  return params
}

// ---------------------------------------------------------------------------
// Stream mapping
// ---------------------------------------------------------------------------

interface AccToolCall {
  id: string
  name: string
  args: string
  /** Provider-specific extras on the tool call (e.g. Gemini thought signatures), replayed verbatim. */
  extra: Record<string, unknown>
}

const PROGRESS_STEP = 256

export class OpenAIStreamMapper {
  text = ''
  reasoning = ''
  finishReason: string | null = null
  started = false
  usage: TokenUsage | undefined
  model: string | undefined
  readonly calls: AccToolCall[] = []
  private readonly byIndex = new Map<number, AccToolCall>()
  private lastProgress = new Map<AccToolCall, number>()

  constructor(
    private readonly emit: (e: StreamEventBody) => void,
    private readonly showThinking: boolean,
  ) {}

  handle(chunk: ChatCompletionChunk): void {
    this.started = true
    if (chunk.model) this.model = chunk.model
    if (chunk.usage) {
      const details = chunk.usage.prompt_tokens_details as { cached_tokens?: number } | undefined
      this.usage = {
        inputTokens: chunk.usage.prompt_tokens,
        outputTokens: chunk.usage.completion_tokens,
        cacheReadTokens: details?.cached_tokens ?? undefined,
      }
    }
    for (const choice of chunk.choices ?? []) {
      if (choice.index !== undefined && choice.index !== 0) continue
      const delta = choice.delta ?? {}
      const extraDelta = delta as { reasoning_content?: string | null; reasoning?: string | null }
      const r = extraDelta.reasoning_content ?? extraDelta.reasoning
      if (typeof r === 'string' && r) {
        this.reasoning += r
        if (this.showThinking) this.emit({ type: 'thinking_delta', text: r })
      }
      if (typeof delta.content === 'string' && delta.content) {
        this.text += delta.content
        this.emit({ type: 'text_delta', text: delta.content })
      }
      for (const tc of delta.tool_calls ?? []) this.handleToolDelta(tc)
      if (choice.finish_reason) this.finishReason = choice.finish_reason
    }
  }

  private handleToolDelta(tc: ChatCompletionChunk.Choice.Delta.ToolCall): void {
    let acc: AccToolCall | undefined
    if (typeof tc.index === 'number') acc = this.byIndex.get(tc.index)
    if (!acc && tc.id) acc = this.calls.find((c) => c.id === tc.id)
    if (!acc) {
      acc = { id: tc.id ?? '', name: '', args: '', extra: {} }
      this.calls.push(acc)
      if (typeof tc.index === 'number') this.byIndex.set(tc.index, acc)
    }
    if (tc.id && !acc.id) acc.id = tc.id
    if (tc.function?.name) acc.name = acc.name && acc.name !== tc.function.name ? acc.name + tc.function.name : tc.function.name
    if (tc.function?.arguments) acc.args += tc.function.arguments
    for (const [k, v] of Object.entries(tc)) {
      if (!['index', 'id', 'type', 'function', 'custom'].includes(k) && v !== undefined) acc.extra[k] = v
    }
    const last = this.lastProgress.get(acc) ?? -PROGRESS_STEP
    if (acc.args.length - last >= PROGRESS_STEP) {
      this.lastProgress.set(acc, acc.args.length)
      this.emit({ type: 'tool_progress', name: acc.name || undefined, bytes: acc.args.length })
    }
  }

  /** Builds the final assistant message (with the text-JSON fallback applied). */
  finish(kind: ProviderKind, requestModel: string): { message: AssistantMessage; stopReason: StopReason; truncatedToolCall: boolean } {
    const calls = this.calls.map((c) => ({ ...c, id: c.id || randomId('call') }))
    let text = this.text
    const toolCalls: ToolCall[] = calls.map((c) => ({ id: c.id, name: c.name || CAD_TOOL_NAME, input: parseArgs(c.args) }))
    let synthetic = false
    if (toolCalls.length === 0) {
      const found = extractModelFromText(text)
      if (found) {
        const id = randomId('call_text')
        const toolName = found.kind === 'template' ? TEMPLATE_TOOL_NAME : CAD_TOOL_NAME
        toolCalls.push({ id, name: toolName, input: found.model })
        calls.push({ id, name: toolName, args: JSON.stringify(found.model), extra: {} })
        text = found.text
        synthetic = true
      }
    }
    const message: AssistantMessage = { role: 'assistant', text }
    if (this.showThinking && this.reasoning) message.thinking = this.reasoning
    if (toolCalls.length > 0) message.toolCalls = toolCalls
    // A model written as text (synthetic tool call) is replayed as that same text, never as a function call:
    // providers such as Gemini 3 reject replayed function calls they did not issue (thought signatures).
    // Its tool result then travels as a "Tool result:" text in the next user message.
    const rawMsg: ChatCompletionAssistantMessageParam = { role: 'assistant', content: (synthetic ? this.text : text) || null }
    if (calls.length > 0 && !synthetic) {
      rawMsg.tool_calls = calls.map(
        (c) => ({ ...c.extra, id: c.id, type: 'function', function: { name: c.name || CAD_TOOL_NAME, arguments: c.args } }) as ChatCompletionMessageFunctionToolCall,
      )
    }
    message.raw = { providerKind: kind, model: requestModel, content: rawMsg }

    let stopReason: StopReason
    switch (this.finishReason) {
      case 'length':
        stopReason = 'max_tokens'
        break
      case 'content_filter':
        stopReason = 'refusal'
        break
      case 'tool_calls':
      case 'function_call':
        stopReason = 'tool_use'
        break
      case 'stop':
        stopReason = 'end_turn'
        break
      default:
        stopReason = this.finishReason ? 'other' : 'end_turn'
    }
    if (toolCalls.length > 0 && stopReason !== 'max_tokens' && stopReason !== 'refusal') stopReason = 'tool_use'
    const truncatedToolCall = stopReason === 'max_tokens' && this.calls.length > 0 && !synthetic
    return { message, stopReason, truncatedToolCall }
  }
}

/** Parses tool arguments; returns the raw string when it is not valid JSON (the renderer reports it as INVALID). */
export function parseArgs(args: string): unknown {
  if (!args.trim()) return {}
  try {
    return JSON.parse(args)
  } catch {
    return args
  }
}

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

export function mapOpenAIError(err: unknown, label: string, kind?: ProviderKind): ChatError {
  const detail = err instanceof APIError ? apiDetail(err) : errorText(err)
  if (err instanceof AuthenticationError) return messageForStatus(401, label, detail)
  if (err instanceof PermissionDeniedError) return messageForStatus(403, label, detail)
  if (err instanceof NotFoundError) return messageForStatus(404, label, detail)
  if (err instanceof RateLimitError) return messageForStatus(429, label, detail)
  if (err instanceof BadRequestError) return messageForStatus(400, label, detail)
  if (err instanceof UnprocessableEntityError) return messageForStatus(422, label, detail)
  if (err instanceof APIConnectionTimeoutError) {
    return { code: 'timeout', message: `${label} tardó demasiado en responder. Inténtalo de nuevo.`, retryable: true }
  }
  if (err instanceof APIConnectionError) {
    const hint = kind === 'ollama' ? ' ¿Está Ollama en ejecución (ollama serve) y la URL base es correcta?' : ' Comprueba tu conexión y la URL base.'
    return { code: 'network', message: `No se pudo conectar con ${label}.${hint}`, retryable: true }
  }
  if (err instanceof InternalServerError) return messageForStatus(err.status, label, detail)
  if (err instanceof APIError) {
    if (err.status === undefined) {
      return { code: 'stream', message: `La conexión con ${label} se interrumpió durante la respuesta. Inténtalo de nuevo.`, retryable: true }
    }
    return messageForStatus(err.status, label, detail)
  }
  if (err instanceof OpenAIError) return { code: 'stream', message: `Respuesta inválida de ${label}: ${truncate(err.message, 300)}`, retryable: true }
  return { code: 'unknown', message: `Error inesperado con ${label}: ${truncate(errorText(err), 300)}`, retryable: false }
}

function apiDetail(err: APIError): string {
  const body = err.error as { message?: string } | undefined
  return body?.message ?? err.message
}

// ---------------------------------------------------------------------------
// Chat
// ---------------------------------------------------------------------------

export async function runOpenAIChat(ctx: ProviderRunContext, factory: OpenAITransportFactory = sdkOpenAITransport): Promise<void> {
  const { provider, model, settings, quirks, emit, signal } = ctx
  const kind = provider.kind
  const transport = factory(clientConfig(provider, ctx.apiKey))

  let strict = kind === 'openai' && !quirks.has('no-strict', provider.id, model)
  let tools = !quirks.has('no-tools', provider.id, model)
  let reasoning = !quirks.has('no-reasoning', provider.id, model)
  let streamUsage = kind !== 'openai-compatible' && !quirks.has('no-stream-usage', provider.id, model)

  // Nudge turn (the model described a design without emitting it): force the tool call. Servers that
  // cannot force it (e.g. Gemini: "schema produces a constraint that has too many states") get the
  // request without tools instead, so the model writes the JSON in a fenced block (text fallback).
  const nudge = isToolNudge(ctx.request.messages)
  let forceTool = nudge && tools && !quirks.has('no-tool-choice', provider.id, model)
  if (nudge && quirks.has('no-tool-choice', provider.id, model)) tools = false

  emit({ type: 'start', model })

  for (let attempt = 0; attempt < 6; attempt++) {
    const mapper = new OpenAIStreamMapper(emit, settings.ai.showThinking)
    try {
      const params = buildOpenAIParams({ kind, model, messages: ctx.request.messages, ai: settings.ai, strict, tools, reasoning, streamUsage, forceTool })
      const stream = await transport.stream(params, { signal })
      for await (const chunk of stream) mapper.handle(chunk)
      if (signal.aborted) throw new APIUserAbortError()
    } catch (err) {
      if (signal.aborted || err instanceof APIUserAbortError) {
        const message: AssistantMessage = { role: 'assistant', text: mapper.text }
        if (settings.ai.showThinking && mapper.reasoning) message.thinking = mapper.reasoning
        emit({ type: 'done', message, stopReason: 'cancelled', usage: mapper.usage })
        return
      }
      if (!mapper.started && (err instanceof BadRequestError || err instanceof UnprocessableEntityError || err instanceof NotFoundError)) {
        const text = errorText(err)
        if (forceTool) {
          // The server cannot force the tool (unsupported tool_choice, or constrained decoding of the large
          // CAD schema rejected): retry this nudge turn without tools -> JSON in a fenced text block.
          forceTool = false
          tools = false
          quirks.set('no-tool-choice', provider.id, model)
          continue
        }
        if (tools && looksLikeNoToolsSupport(text)) {
          tools = false
          quirks.set('no-tools', provider.id, model)
          continue
        }
        if (err instanceof NotFoundError) {
          emit({ type: 'error', error: mapOpenAIError(err, provider.label, kind) })
          return
        }
        if (strict && looksLikeSchemaRejection(text)) {
          strict = false
          quirks.set('no-strict', provider.id, model)
          continue
        }
        if (reasoning && supportsReasoningEffort(kind, model) && looksLikeReasoningRejection(text)) {
          reasoning = false
          quirks.set('no-reasoning', provider.id, model)
          continue
        }
        if (streamUsage && looksLikeStreamOptionsRejection(text)) {
          streamUsage = false
          quirks.set('no-stream-usage', provider.id, model)
          continue
        }
      }
      emit({ type: 'error', error: mapOpenAIError(err, provider.label, kind) })
      return
    }
    const { message, stopReason, truncatedToolCall } = mapper.finish(kind, model)
    if (truncatedToolCall) {
      emit({
        type: 'error',
        error: {
          code: 'max_tokens',
          message: 'La respuesta alcanzó el límite de longitud mientras se generaba el modelo y quedó incompleta. Pide un modelo más sencillo o divide el diseño en pasos.',
          retryable: true,
        },
      })
      return
    }
    if (stopReason === 'refusal') {
      const note =
        settings.language === 'en'
          ? 'The provider blocked this response (content filter). Try rephrasing the request.'
          : 'El proveedor bloqueó esta respuesta (filtro de contenido). Prueba a reformular la petición.'
      emit({ type: 'done', message: { role: 'assistant', text: [message.text.trim(), note].filter(Boolean).join('\n\n') }, stopReason, usage: mapper.usage })
      return
    }
    emit({ type: 'done', message, stopReason, usage: mapper.usage })
    return
  }
  emit({ type: 'error', error: { code: 'bad_request', message: `${provider.label} rechazó la petición repetidamente.`, retryable: false } })
}

// ---------------------------------------------------------------------------
// Connection test
// ---------------------------------------------------------------------------

export async function testOpenAI(provider: ProviderConfig, apiKey: string | null, model: string, timeoutMs: number, factory: OpenAITransportFactory = sdkOpenAITransport): Promise<string> {
  const transport = factory(clientConfig(provider, apiKey))
  const res = await transport.create({ model, messages: [{ role: 'user', content: 'Reply with OK' }] }, { timeout: timeoutMs })
  return (res.choices?.[0]?.message?.content ?? '').trim()
}
