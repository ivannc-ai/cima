/**
 * Fallback for providers/models that write the model JSON as plain text instead of calling a tool:
 * finds a JSON object (fenced ```json block, or the whole reply) and converts it into a synthetic tool call.
 *
 *  - {"schemaVersion": ...} or anything with "parts"/"features" -> CIMA model (emit_cad_model). Objects in an
 *    invented format still go through validation, so the repair loop can explain the expected format.
 *  - {"template": "...", "params": ...}                          -> template request (use_cad_template).
 */

export interface ExtractedModel {
  /** Which tool the JSON corresponds to. */
  kind: 'model' | 'template'
  /** Parsed object. */
  model: Record<string, unknown>
  /** The text with the JSON block removed (what is shown to the user). */
  text: string
}

const FENCE_RE = /```[ \t]*([A-Za-z0-9_-]*)[ \t]*\r?\n([\s\S]*?)```/g

function classify(v: Record<string, unknown>): ExtractedModel['kind'] | undefined {
  if ('schemaVersion' in v || 'parts' in v || 'features' in v) return 'model'
  if (typeof v.template === 'string') return 'template'
  return undefined
}

function parseObject(src: string): { kind: ExtractedModel['kind']; model: Record<string, unknown> } | undefined {
  const trimmed = src.trim()
  if (!trimmed.startsWith('{')) return undefined
  try {
    const v: unknown = JSON.parse(trimmed)
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      const kind = classify(v as Record<string, unknown>)
      if (kind) return { kind, model: v as Record<string, unknown> }
    }
  } catch {
    /* not JSON */
  }
  return undefined
}

/** Returns the model / template request found in `text` (last matching fenced block wins), or undefined. */
export function extractModelFromText(text: string): ExtractedModel | undefined {
  const blocks: Array<{ start: number; end: number; body: string; lang: string }> = []
  for (const m of text.matchAll(FENCE_RE)) {
    blocks.push({ start: m.index ?? 0, end: (m.index ?? 0) + m[0].length, lang: (m[1] ?? '').toLowerCase(), body: m[2] ?? '' })
  }
  for (let i = blocks.length - 1; i >= 0; i--) {
    const b = blocks[i]!
    if (b.lang !== '' && b.lang !== 'json' && b.lang !== 'jsonc' && b.lang !== 'javascript') continue
    const found = parseObject(b.body)
    if (found) {
      const rest = (text.slice(0, b.start) + text.slice(b.end)).replace(/\n{3,}/g, '\n\n').trim()
      return { ...found, text: rest }
    }
  }
  // Whole reply is a bare JSON object.
  const whole = parseObject(text)
  if (whole) return { ...whole, text: '' }
  // Unfenced JSON object after some prose (only when the reply has no code fences at all).
  if (blocks.length > 0) return undefined
  for (const marker of ['{"schemaVersion"', '{"template"']) {
    const idx = text.indexOf(marker)
    if (idx < 0) continue
    const tail = text.slice(idx)
    const end = tail.lastIndexOf('}')
    if (end > 0) {
      const found = parseObject(tail.slice(0, end + 1))
      if (found) return { ...found, text: (text.slice(0, idx) + tail.slice(end + 1)).trim() }
    }
  }
  return undefined
}
