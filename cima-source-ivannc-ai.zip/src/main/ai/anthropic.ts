/**
 * Anthropic provider (Messages API, beta endpoint because of server-side refusal fallbacks).
 */
import Anthropic, {
  AnthropicError,
  APIConnectionError,
  APIConnectionTimeoutError,
  APIError,
  APIUserAbortError,
  AuthenticationError,
  BadRequestError,
  InternalServerError,
  NotFoundError,
  OverloadedError,
  PermissionDeniedError,
  RateLimitError,
} from '@anthropic-ai/sdk'
import type {
  BetaContentBlock,
  BetaContentBlockParam,
  BetaMessage,
  BetaMessageParam,
  BetaMessageStreamParams,
  BetaRawMessageStreamEvent,
  BetaTool,
  BetaToolResultBlockParam,
  MessageCreateParamsNonStreaming,
} from '@anthropic-ai/sdk/resources/beta/messages/messages'
import { CAD_TOOL_NAME, type AssistantMessage, type ChatMessage, type StopReason, type TokenUsage, type ToolCall } from '../../shared/ai/types'
import type { AiSettings } from '../../shared/settings'
import {
  errorText,
  looksLikeEagerStreamingRejection,
  looksLikeFallbackRejection,
  looksLikeSchemaRejection,
  messageForStatus,
  sanitizeToolId,
  truncate,
  type ChatError,
  type ProviderRunContext,
  type StreamEventBody,
} from './common'
import { systemPromptFor } from './prompt'
import { CAD_TOOL_DESCRIPTION, TEMPLATE_TOOL_DESCRIPTION, cadToolSchema, templateToolSchema } from './schema'
import { TEMPLATE_TOOL_NAME } from '../../shared/templates'

export const ANTHROPIC_MAX_TOKENS = 64000
export const FALLBACK_BETA = 'server-side-fallback-2026-07-01'
/** Models that support server-side refusal fallbacks with `fallbacks: "default"`. */
export const FALLBACK_MODELS: ReadonlySet<string> = new Set(['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-fable-5-2'])

// ---------------------------------------------------------------------------
// Transport (injectable for tests)
// ---------------------------------------------------------------------------

export interface AnthropicStreamLike extends AsyncIterable<BetaRawMessageStreamEvent> {
  finalMessage(): Promise<BetaMessage>
  abort(): void
}

export interface AnthropicTransport {
  stream(params: BetaMessageStreamParams, options: { signal: AbortSignal }): AnthropicStreamLike
  create(params: MessageCreateParamsNonStreaming, options: { timeout: number; signal?: AbortSignal }): Promise<BetaMessage>
}

export type AnthropicTransportFactory = (apiKey: string) => AnthropicTransport

/** Real SDK transport: a client per request with the stored key. */
export const sdkAnthropicTransport: AnthropicTransportFactory = (apiKey) => {
  // Chat streams retry transient failures (429 / 5xx "overloaded") with the SDK's exponential
  // backoff, honouring retry-after; the connection test uses maxRetries 0.
  const client = new Anthropic({ apiKey, maxRetries: 5 })
  return {
    stream: (params, options) => client.beta.messages.stream(params, options),
    create: (params, options) => client.beta.messages.create(params, { ...options, maxRetries: 0 }),
  }
}

// ---------------------------------------------------------------------------
// Model capabilities
// ---------------------------------------------------------------------------

/** Adaptive thinking + effort: Claude 5.x family and 4.6+ (older models reject them). */
export function supportsAdaptiveThinking(model: string): boolean {
  const m = /claude-(?:opus|sonnet|haiku|fable|mythos)-(\d+)(?:-(\d{1,2}))?(?:$|[^0-9])/.exec(model)
  if (!m) return false
  const major = Number(m[1])
  const minor = m[2] === undefined ? 0 : Number(m[2])
  return major >= 5 || (major === 4 && minor >= 6)
}

// ---------------------------------------------------------------------------
// Request building
// ---------------------------------------------------------------------------

export function buildAnthropicTool(opts: { strict: boolean; eager: boolean }): BetaTool {
  const tool: BetaTool = {
    name: CAD_TOOL_NAME,
    description: CAD_TOOL_DESCRIPTION,
    input_schema: cadToolSchema('anthropic') as BetaTool['input_schema'],
  }
  if (opts.strict) tool.strict = true
  if (opts.eager) tool.eager_input_streaming = true
  return tool
}

export function buildAnthropicTemplateTool(opts: { strict: boolean }): BetaTool {
  const tool: BetaTool = {
    name: TEMPLATE_TOOL_NAME,
    description: TEMPLATE_TOOL_DESCRIPTION,
    input_schema: templateToolSchema('anthropic') as BetaTool['input_schema'],
  }
  if (opts.strict) tool.strict = true
  return tool
}

export interface AnthropicRequestOptions {
  model: string
  messages: ChatMessage[]
  ai: AiSettings
  strict: boolean
  fallbacks: boolean
  eager: boolean
}

export function buildAnthropicParams(o: AnthropicRequestOptions): BetaMessageStreamParams {
  const params: BetaMessageStreamParams = {
    model: o.model,
    max_tokens: ANTHROPIC_MAX_TOKENS,
    system: [{ type: 'text', text: systemPromptFor(o.ai), cache_control: { type: 'ephemeral' } }],
    messages: toAnthropicMessages(o.messages),
    tools: o.ai.templates
      ? [buildAnthropicTool({ strict: o.strict, eager: o.eager }), buildAnthropicTemplateTool({ strict: o.strict })]
      : [buildAnthropicTool({ strict: o.strict, eager: o.eager })],
    // Forced tool choice ("any"/"tool") is rejected by Opus 5.5 / Sonnet 5.5 / Fable: steer through the prompt.
    tool_choice: { type: 'auto' },
    cache_control: { type: 'ephemeral' },
  }
  if (supportsAdaptiveThinking(o.model)) {
    params.thinking = { type: 'adaptive', display: 'summarized' }
    params.output_config = { effort: o.ai.effort }
  }
  if (o.fallbacks) {
    params.betas = [FALLBACK_BETA]
    params.fallbacks = 'default'
  }
  return params
}

function toolInputObject(input: unknown): Record<string, unknown> {
  if (input && typeof input === 'object' && !Array.isArray(input)) return input as Record<string, unknown>
  if (typeof input === 'string') {
    try {
      const v: unknown = JSON.parse(input)
      if (v && typeof v === 'object' && !Array.isArray(v)) return v as Record<string, unknown>
    } catch {
      /* fallthrough */
    }
    return { INVALID_JSON: input }
  }
  return { value: input ?? null }
}

/** Converts provider-neutral messages into Anthropic message params (tool_use / tool_result pairing enforced). */
export function toAnthropicMessages(messages: ReadonlyArray<ChatMessage>): BetaMessageParam[] {
  const out: BetaMessageParam[] = []
  let pending: string[] = []

  const missingResults = (answered: Set<string>): BetaToolResultBlockParam[] =>
    pending
      .filter((id) => !answered.has(id))
      .map((id) => ({ type: 'tool_result', tool_use_id: id, content: 'No result was returned for this tool call.', is_error: true }))

  for (const m of messages) {
    if (m.role === 'assistant') {
      if (pending.length > 0) {
        out.push({ role: 'user', content: missingResults(new Set()) })
        pending = []
      }
      let content: BetaContentBlockParam[]
      if (m.raw?.providerKind === 'anthropic' && Array.isArray(m.raw.content) && m.raw.content.length > 0) {
        content = m.raw.content as BetaContentBlockParam[]
      } else {
        content = []
        if (m.text.trim().length > 0) content.push({ type: 'text', text: m.text })
        for (const tc of m.toolCalls ?? []) {
          content.push({ type: 'tool_use', id: sanitizeToolId(tc.id), name: tc.name, input: toolInputObject(tc.input) })
        }
      }
      if (content.length === 0) continue
      out.push({ role: 'assistant', content })
      pending = content.filter((b) => b.type === 'tool_use').map((b) => (b as { id: string }).id)
      continue
    }

    // user
    const blocks: BetaContentBlockParam[] = []
    const answered = new Set<string>()
    const orphanTexts: string[] = []
    for (const r of m.toolResults ?? []) {
      const id = sanitizeToolId(r.toolCallId)
      if (pending.includes(id) && !answered.has(id)) {
        answered.add(id)
        blocks.push({ type: 'tool_result', tool_use_id: id, content: r.content || '(empty)', is_error: r.isError })
      } else {
        orphanTexts.push(`Tool result${r.isError ? ' (error)' : ''}:\n${r.content}`)
      }
    }
    blocks.push(...missingResults(answered))
    pending = []
    for (const part of m.content) {
      if (part.type === 'image') {
        blocks.push({ type: 'image', source: { type: 'base64', media_type: part.mediaType, data: part.data } })
      }
    }
    for (const t of orphanTexts) blocks.push({ type: 'text', text: t })
    for (const part of m.content) {
      if (part.type === 'text' && part.text.trim().length > 0) blocks.push({ type: 'text', text: part.text })
    }
    if (blocks.length === 0) blocks.push({ type: 'text', text: '(mensaje vacío)' })
    out.push({ role: 'user', content: blocks })
  }
  if (pending.length > 0) out.push({ role: 'user', content: missingResults(new Set()) })
  return out
}

// ---------------------------------------------------------------------------
// Stream event mapping
// ---------------------------------------------------------------------------

type AccBlock =
  | { kind: 'text'; text: string }
  | { kind: 'thinking'; thinking: string; signature: string }
  | { kind: 'tool_use'; id: string; name: string; json: string; input?: unknown }
  | { kind: 'other'; block: unknown }

const PROGRESS_STEP = 256

/**
 * Maps raw stream events to ChatStreamEvents and keeps its own copy of the content (used when the stream
 * is cancelled or the SDK cannot parse a streamed tool input).
 */
export class AnthropicStreamMapper {
  readonly blocks: AccBlock[] = []
  started = false
  stopReason: string | null = null
  model: string | undefined
  usage: TokenUsage = {}
  private lastProgress = new Map<number, number>()
  private textEmitted = false

  constructor(
    private readonly emit: (e: StreamEventBody) => void,
    private readonly showThinking: boolean,
  ) {}

  handle(event: BetaRawMessageStreamEvent): void {
    this.started = true
    switch (event.type) {
      case 'message_start': {
        this.model = event.message.model
        const u = event.message.usage
        this.usage = {
          inputTokens: u.input_tokens,
          outputTokens: u.output_tokens,
          cacheReadTokens: u.cache_read_input_tokens ?? undefined,
          cacheWriteTokens: u.cache_creation_input_tokens ?? undefined,
        }
        break
      }
      case 'content_block_start': {
        const b = event.content_block
        if (b.type === 'text') {
          if (this.textEmitted) this.emit({ type: 'text_delta', text: '\n\n' })
          this.blocks[event.index] = { kind: 'text', text: b.text }
          if (b.text) this.emitText(b.text)
        } else if (b.type === 'thinking') {
          this.blocks[event.index] = { kind: 'thinking', thinking: b.thinking, signature: b.signature }
          if (b.thinking && this.showThinking) this.emit({ type: 'thinking_delta', text: b.thinking })
        } else if (b.type === 'tool_use') {
          this.blocks[event.index] = { kind: 'tool_use', id: b.id, name: b.name, json: '' }
          this.emit({ type: 'tool_progress', name: b.name, bytes: 0 })
        } else {
          this.blocks[event.index] = { kind: 'other', block: b }
        }
        break
      }
      case 'content_block_delta': {
        const acc = this.blocks[event.index]
        const d = event.delta
        if (d.type === 'text_delta') {
          if (acc?.kind === 'text') acc.text += d.text
          this.emitText(d.text)
        } else if (d.type === 'thinking_delta') {
          if (acc?.kind === 'thinking') acc.thinking += d.thinking
          if (this.showThinking && d.thinking) this.emit({ type: 'thinking_delta', text: d.thinking })
        } else if (d.type === 'signature_delta') {
          if (acc?.kind === 'thinking') acc.signature = d.signature
        } else if (d.type === 'input_json_delta') {
          if (acc?.kind === 'tool_use') {
            acc.json += d.partial_json
            const bytes = acc.json.length
            const last = this.lastProgress.get(event.index) ?? 0
            if (bytes - last >= PROGRESS_STEP) {
              this.lastProgress.set(event.index, bytes)
              this.emit({ type: 'tool_progress', name: acc.name, bytes })
            }
          }
        }
        break
      }
      case 'content_block_stop': {
        const acc = this.blocks[event.index]
        if (acc?.kind === 'tool_use') {
          this.emit({ type: 'tool_progress', name: acc.name, bytes: acc.json.length })
          try {
            acc.input = acc.json.trim() ? JSON.parse(acc.json) : {}
          } catch {
            acc.input = undefined
          }
        }
        break
      }
      case 'message_delta': {
        this.stopReason = event.delta.stop_reason ?? this.stopReason
        const u = event.usage
        if (u.output_tokens != null) this.usage.outputTokens = u.output_tokens
        if (u.input_tokens != null) this.usage.inputTokens = u.input_tokens
        if (u.cache_read_input_tokens != null) this.usage.cacheReadTokens = u.cache_read_input_tokens
        if (u.cache_creation_input_tokens != null) this.usage.cacheWriteTokens = u.cache_creation_input_tokens
        break
      }
      default:
        break
    }
  }

  private emitText(text: string): void {
    if (!text) return
    this.textEmitted = true
    this.emit({ type: 'text_delta', text })
  }

  receivedText(): string {
    return this.blocks
      .filter((b): b is Extract<AccBlock, { kind: 'text' }> => b?.kind === 'text')
      .map((b) => b.text)
      .filter((t) => t.length > 0)
      .join('\n\n')
  }

  receivedThinking(): string {
    return this.blocks
      .filter((b): b is Extract<AccBlock, { kind: 'thinking' }> => b?.kind === 'thinking')
      .map((b) => b.thinking)
      .filter((t) => t.length > 0)
      .join('\n\n')
  }

  /** Content rebuilt from the stream (tool inputs that failed to parse are passed as the raw JSON string). */
  toolCalls(): ToolCall[] {
    return this.blocks
      .filter((b): b is Extract<AccBlock, { kind: 'tool_use' }> => b?.kind === 'tool_use')
      .map((b) => ({ id: b.id, name: b.name, input: b.input !== undefined ? b.input : b.json }))
  }

  /** Raw content for replay, rebuilt from the stream. */
  rawContent(): BetaContentBlockParam[] {
    const out: BetaContentBlockParam[] = []
    for (const b of this.blocks) {
      if (!b) continue
      if (b.kind === 'text') {
        if (b.text) out.push({ type: 'text', text: b.text })
      } else if (b.kind === 'thinking') {
        if (b.signature) out.push({ type: 'thinking', thinking: b.thinking, signature: b.signature })
      } else if (b.kind === 'tool_use') {
        out.push({ type: 'tool_use', id: b.id, name: b.name, input: toolInputObject(b.input !== undefined ? b.input : b.json) })
      } else {
        out.push(b.block as BetaContentBlockParam)
      }
    }
    return out
  }
}

// ---------------------------------------------------------------------------
// Final message -> AssistantMessage
// ---------------------------------------------------------------------------

export function usageFromMessage(msg: BetaMessage): TokenUsage {
  const u = msg.usage
  return {
    inputTokens: u.input_tokens,
    outputTokens: u.output_tokens,
    cacheReadTokens: u.cache_read_input_tokens ?? undefined,
    cacheWriteTokens: u.cache_creation_input_tokens ?? undefined,
  }
}

export function assistantFromContent(
  content: ReadonlyArray<BetaContentBlock | BetaContentBlockParam>,
  model: string,
  showThinking: boolean,
  overrideToolCalls?: ToolCall[],
): AssistantMessage {
  const texts: string[] = []
  const thinking: string[] = []
  const toolCalls: ToolCall[] = []
  for (const b of content) {
    if (b.type === 'text') {
      if (b.text) texts.push(b.text)
    } else if (b.type === 'thinking') {
      if (b.thinking) thinking.push(b.thinking)
    } else if (b.type === 'tool_use') {
      toolCalls.push({ id: b.id, name: b.name, input: b.input })
    }
  }
  const calls = overrideToolCalls ?? toolCalls
  const msg: AssistantMessage = { role: 'assistant', text: texts.join('\n\n') }
  if (showThinking && thinking.length > 0) msg.thinking = thinking.join('\n\n')
  if (calls.length > 0) msg.toolCalls = calls
  msg.raw = { providerKind: 'anthropic', model, content: content as unknown }
  return msg
}

export function mapStopReason(reason: string | null | undefined, hasToolCalls: boolean): StopReason {
  if (hasToolCalls) return 'tool_use'
  switch (reason) {
    case 'end_turn':
    case 'stop_sequence':
      return 'end_turn'
    case 'tool_use':
      return 'tool_use'
    case 'max_tokens':
      return 'max_tokens'
    case 'refusal':
      return 'refusal'
    default:
      return 'other'
  }
}

export function refusalText(language: 'es' | 'en'): string {
  return language === 'en'
    ? 'Sorry, I can’t help with this request. Try rephrasing it or describing the part differently.'
    : 'Lo siento, no puedo ayudar con esta petición. Prueba a reformularla o a describir la pieza de otra manera.'
}

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

export function mapAnthropicError(err: unknown, label = 'Anthropic'): ChatError {
  const detail = err instanceof APIError ? apiErrorDetail(err) : errorText(err)
  if (err instanceof AuthenticationError) return messageForStatus(401, label, detail)
  if (err instanceof PermissionDeniedError) return messageForStatus(403, label, detail)
  if (err instanceof NotFoundError) return messageForStatus(404, label, detail)
  if (err instanceof RateLimitError) return messageForStatus(429, label, detail)
  if (err instanceof BadRequestError) return messageForStatus(400, label, detail)
  if (err instanceof APIConnectionTimeoutError) {
    return { code: 'timeout', message: `${label} tardó demasiado en responder. Inténtalo de nuevo.`, retryable: true }
  }
  if (err instanceof APIConnectionError) {
    return { code: 'network', message: `No se pudo conectar con ${label}. Comprueba tu conexión a internet o el proxy.`, retryable: true }
  }
  if (err instanceof OverloadedError) return messageForStatus(529, label, detail)
  if (err instanceof InternalServerError) return messageForStatus(err.status, label, detail)
  if (err instanceof APIError) {
    if (err.status === undefined && /overloaded/i.test(detail)) return messageForStatus(529, label, detail)
    if (err.status === undefined) {
      return { code: 'stream', message: `La conexión con ${label} se interrumpió durante la respuesta. Inténtalo de nuevo.${detail ? ` Detalle: ${truncate(detail, 200)}` : ''}`, retryable: true }
    }
    return messageForStatus(err.status, label, detail)
  }
  if (err instanceof AnthropicError) {
    return { code: 'stream', message: `Respuesta inválida de ${label}: ${truncate(err.message, 300)}`, retryable: true }
  }
  return { code: 'unknown', message: `Error inesperado con ${label}: ${truncate(errorText(err), 300)}`, retryable: false }
}

function apiErrorDetail(err: APIError): string {
  const body = err.error as { error?: { message?: string } } | undefined
  return body?.error?.message ?? err.message
}

/** Error raised by the SDK stream when a streamed tool input is not valid JSON. */
function isToolJsonParseError(err: unknown): boolean {
  return err instanceof AnthropicError && !(err instanceof APIError) && /tool parameter JSON/i.test(err.message)
}

// ---------------------------------------------------------------------------
// Chat
// ---------------------------------------------------------------------------

export async function runAnthropicChat(ctx: ProviderRunContext, factory: AnthropicTransportFactory = sdkAnthropicTransport): Promise<void> {
  const { provider, model, settings, quirks, emit, signal } = ctx
  const showThinking = settings.ai.showThinking
  const transport = factory(ctx.apiKey ?? '')

  let strict = !quirks.has('no-strict', provider.id, model)
  let eager = !quirks.has('no-eager-streaming', provider.id, model)
  let fallbacks = settings.ai.refusalFallback && FALLBACK_MODELS.has(model) && !quirks.has('no-fallbacks', provider.id, model)

  emit({ type: 'start', model })

  for (let attempt = 0; attempt < 4; attempt++) {
    const mapper = new AnthropicStreamMapper(emit, showThinking)
    let final: BetaMessage | undefined
    try {
      const params = buildAnthropicParams({ model, messages: ctx.request.messages, ai: settings.ai, strict, eager, fallbacks })
      const stream = transport.stream(params, { signal })
      const onAbort = () => stream.abort()
      signal.addEventListener('abort', onAbort, { once: true })
      try {
        for await (const event of stream) mapper.handle(event)
        final = await stream.finalMessage()
      } finally {
        signal.removeEventListener('abort', onAbort)
      }
    } catch (err) {
      if (signal.aborted || err instanceof APIUserAbortError) {
        emitCancelled(ctx, mapper)
        return
      }
      if (!mapper.started && err instanceof BadRequestError) {
        const text = errorText(err)
        if (fallbacks && looksLikeFallbackRejection(text)) {
          fallbacks = false
          quirks.set('no-fallbacks', provider.id, model)
          continue
        }
        if (eager && looksLikeEagerStreamingRejection(text)) {
          eager = false
          quirks.set('no-eager-streaming', provider.id, model)
          continue
        }
        if (strict && looksLikeSchemaRejection(text)) {
          strict = false
          quirks.set('no-strict', provider.id, model)
          continue
        }
      }
      if (isToolJsonParseError(err)) {
        // Streamed tool input was not valid JSON: hand the raw text to the renderer, whose validation reports it
        // back to the model as INVALID so it can retry.
        const msg = assistantFromContent(mapper.rawContent(), mapper.model ?? model, showThinking, mapper.toolCalls())
        emit({ type: 'done', message: msg, stopReason: 'tool_use', usage: mapper.usage })
        return
      }
      emit({ type: 'error', error: mapAnthropicError(err, provider.label) })
      return
    }
    finishAnthropic(ctx, final, mapper)
    return
  }
  emit({ type: 'error', error: { code: 'bad_request', message: `${provider.label} rechazó la petición repetidamente.`, retryable: false } })
}

function emitCancelled(ctx: ProviderRunContext, mapper: AnthropicStreamMapper): void {
  const message: AssistantMessage = { role: 'assistant', text: mapper.receivedText() }
  const thinking = mapper.receivedThinking()
  if (ctx.settings.ai.showThinking && thinking) message.thinking = thinking
  ctx.emit({ type: 'done', message, stopReason: 'cancelled', usage: mapper.usage })
}

export function finishAnthropic(ctx: ProviderRunContext, final: BetaMessage, mapper?: AnthropicStreamMapper): void {
  const { settings, emit, model } = ctx
  const usage = usageFromMessage(final)
  const hasToolUse = final.content.some((b) => b.type === 'tool_use')
  const reason = final.stop_reason

  if (reason === 'refusal') {
    const received = final.content
      .filter((b) => b.type === 'text')
      .map((b) => (b as { text: string }).text)
      .join('\n\n')
      .trim()
    const text = [received, refusalText(settings.language)].filter(Boolean).join('\n\n')
    emit({ type: 'done', message: { role: 'assistant', text }, stopReason: 'refusal', usage })
    return
  }
  if (reason === 'max_tokens' && hasToolUse) {
    emit({
      type: 'error',
      error: {
        code: 'max_tokens',
        message: 'La respuesta alcanzó el límite de longitud mientras se generaba el modelo y quedó incompleta. Pide un modelo más sencillo o divide el diseño en pasos.',
        retryable: true,
      },
    })
    return
  }
  if (reason === 'model_context_window_exceeded') {
    emit({
      type: 'error',
      error: { code: 'context_window', message: 'La conversación es demasiado larga para el modelo. Empieza una conversación nueva (el modelo actual se conserva).', retryable: false },
    })
    return
  }
  const message = assistantFromContent(final.content, final.model || mapper?.model || model, settings.ai.showThinking)
  emit({ type: 'done', message, stopReason: mapStopReason(reason, (message.toolCalls?.length ?? 0) > 0), usage })
}

// ---------------------------------------------------------------------------
// Connection test
// ---------------------------------------------------------------------------

export async function testAnthropic(apiKey: string, model: string, timeoutMs: number, factory: AnthropicTransportFactory = sdkAnthropicTransport): Promise<string> {
  const transport = factory(apiKey)
  const params: MessageCreateParamsNonStreaming = {
    model,
    max_tokens: 512,
    messages: [{ role: 'user', content: 'Reply with OK' }],
  }
  if (supportsAdaptiveThinking(model)) params.output_config = { effort: 'low' }
  const msg = await transport.create(params, { timeout: timeoutMs })
  return msg.content
    .filter((b) => b.type === 'text')
    .map((b) => (b as { text: string }).text)
    .join('')
    .trim()
}
