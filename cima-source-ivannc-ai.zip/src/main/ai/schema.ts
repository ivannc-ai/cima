/**
 * JSON Schema of the CAD tool (`emit_cad_model`) derived from the Zod contract, plus the sanitizers that
 * make it acceptable for each provider family:
 *
 *  - 'anthropic'     strict tool use: additionalProperties:false everywhere, no numeric/string/array
 *                    constraint keywords (their information is appended to `description`), oneOf -> anyOf.
 *                    Large repeated sub-schemas are hoisted into `$defs` (the inline schema is ~120 KB).
 *  - 'openai-strict' same + every property required, optional ones nullable (`anyOf: [S, {type:"null"}]`),
 *                    `const` -> single-value `enum`. The renderer runs stripNulls() before validation.
 *  - 'openai'        non-strict OpenAI function schema (optional properties stay optional), with $defs.
 *  - 'compat'        Gemini / Ollama / custom OpenAI-compatible servers: fully inlined (no $ref), no
 *                    additionalProperties, `const` -> `enum`. The most widely understood subset.
 */
import { z } from 'zod'
import { TEMPLATES } from '../../shared/templates'
import {
  CadModelSchema,
  Dir3Schema,
  EdgeSelectorSchema,
  ExprSchema,
  FaceSelectorSchema,
  FeatureSchema,
  InstanceSchema,
  OnPlaneSchema,
  ParameterSchema,
  PartSchema,
  PathSegmentSchema,
  PlaneSchema,
  ProfileRepeatSchema,
  ProfileSchema,
  RotationStepSchema,
  SketchSchema,
  Vec2Schema,
  Vec3Schema,
} from '../../shared/model/schema'

export type JsonSchema = Record<string, unknown>
export type SchemaVariant = 'anthropic' | 'openai-strict' | 'openai' | 'compat'

/** Keywords removed from every variant (unsupported by strict structured outputs / function calling). */
const DROP_KEYWORDS = new Set([
  '$schema',
  '$id',
  'id',
  'title',
  'default',
  'examples',
  'minimum',
  'maximum',
  'exclusiveMinimum',
  'exclusiveMaximum',
  'multipleOf',
  'minLength',
  'maxLength',
  'pattern',
  'minItems',
  'maxItems',
  'uniqueItems',
  'minProperties',
  'maxProperties',
  'format',
  'contentEncoding',
  'contentMediaType',
])

/** String formats accepted by Anthropic strict mode (kept); every other format is dropped. */
const SUPPORTED_FORMATS = new Set(['date-time', 'time', 'date', 'duration', 'email', 'hostname', 'uri', 'ipv4', 'ipv6', 'uuid'])

/** Keys whose value is a map name -> schema. */
const SCHEMA_MAP_KEYS = new Set(['properties', '$defs', 'definitions', 'patternProperties'])
/** Keys whose value is an array of schemas. */
const SCHEMA_ARRAY_KEYS = new Set(['anyOf', 'oneOf', 'allOf', 'prefixItems'])
/** Keys whose value is a single schema. */
const SCHEMA_SINGLE_KEYS = new Set(['items', 'not', 'additionalProperties', 'contains'])

/** Integers beyond this magnitude are zod's "safe integer" bounds, not real constraints. */
const HUGE = 1e15

/** The long description of ExprSchema is repeated hundreds of times inline; it is explained once in the tool description. */
const EXPR_DESCRIPTION = ExprSchema.description ?? ''

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v)

function constraintNotes(node: Record<string, unknown>): string[] {
  const notes: string[] = []
  const num = (k: string) => (typeof node[k] === 'number' ? (node[k] as number) : undefined)
  const minItems = num('minItems')
  const maxItems = num('maxItems')
  if (minItems !== undefined && minItems === maxItems) notes.push(`exactly ${minItems} items`)
  else {
    if (minItems !== undefined && minItems > 0) notes.push(`at least ${minItems} item${minItems === 1 ? '' : 's'}`)
    if (maxItems !== undefined) notes.push(`at most ${maxItems} items`)
  }
  const min = num('minimum')
  const max = num('maximum')
  const xmin = num('exclusiveMinimum')
  const xmax = num('exclusiveMaximum')
  if (min !== undefined && Math.abs(min) < HUGE) notes.push(`>= ${min}`)
  if (xmin !== undefined && Math.abs(xmin) < HUGE) notes.push(`> ${xmin}`)
  if (max !== undefined && Math.abs(max) < HUGE) notes.push(`<= ${max}`)
  if (xmax !== undefined && Math.abs(xmax) < HUGE) notes.push(`< ${xmax}`)
  const mult = num('multipleOf')
  if (mult !== undefined) notes.push(`multiple of ${mult}`)
  const minLength = num('minLength')
  const maxLength = num('maxLength')
  if (minLength !== undefined && minLength > 1) notes.push(`at least ${minLength} characters`)
  if (maxLength !== undefined) notes.push(`at most ${maxLength} characters`)
  if (typeof node.pattern === 'string') notes.push(`must match the regex ${node.pattern}`)
  if (typeof node.format === 'string' && !SUPPORTED_FORMATS.has(node.format)) notes.push(`format ${node.format}`)
  return notes
}

function withNotes(description: unknown, notes: string[]): string | undefined {
  const base = typeof description === 'string' && description.length > 0 ? description : undefined
  if (notes.length === 0) return base
  const extra = notes.join('; ')
  if (!base) return extra.charAt(0).toUpperCase() + extra.slice(1) + '.'
  return `${base} (${extra})`
}

/**
 * Base sanitizer shared by every variant (Anthropic strict compatible): additionalProperties:false and a
 * `required` array on every object, constraint keywords folded into descriptions, oneOf -> anyOf.
 */
export function sanitizeSchema(schema: JsonSchema): JsonSchema {
  return sanitizeNode(schema) as JsonSchema
}

function sanitizeNode(node: unknown): unknown {
  if (Array.isArray(node)) return node.map(sanitizeNode)
  if (!isObj(node)) return node
  const out: Record<string, unknown> = {}
  const notes = constraintNotes(node)
  for (const [key, value] of Object.entries(node)) {
    if (key === 'format' && typeof value === 'string' && SUPPORTED_FORMATS.has(value)) {
      out.format = value
      continue
    }
    if (DROP_KEYWORDS.has(key)) continue
    if (key === 'description') continue
    if (SCHEMA_MAP_KEYS.has(key) && isObj(value)) {
      const m: Record<string, unknown> = {}
      for (const [k, v] of Object.entries(value)) m[k] = sanitizeNode(v)
      out[key] = m
    } else if (SCHEMA_ARRAY_KEYS.has(key) && Array.isArray(value)) {
      const target = key === 'oneOf' ? 'anyOf' : key
      out[target] = value.map(sanitizeNode)
    } else if (SCHEMA_SINGLE_KEYS.has(key) && isObj(value)) {
      out[key] = sanitizeNode(value)
    } else {
      out[key] = value
    }
  }
  const description = withNotes(node.description === EXPR_DESCRIPTION ? undefined : node.description, notes)
  if (description) out.description = description
  if (out.type === 'object' || isObj(out.properties)) {
    if (!isObj(out.properties)) out.properties = {}
    out.additionalProperties = false
    if (!Array.isArray(out.required)) out.required = []
  }
  return out
}

/** Recursively replaces `const: v` with `enum: [v]` (some function-calling dialects ignore const). */
export function constToEnum(node: unknown): unknown {
  if (Array.isArray(node)) return node.map(constToEnum)
  if (!isObj(node)) return node
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(node)) {
    if (k === 'const') out.enum = [v]
    else if (k === 'properties' || k === '$defs') {
      const m: Record<string, unknown> = {}
      for (const [pk, pv] of Object.entries(v as Record<string, unknown>)) m[pk] = constToEnum(pv)
      out[k] = m
    } else out[k] = typeof v === 'object' && v !== null ? constToEnum(v) : v
  }
  return out
}

/**
 * OpenAI strict function calling: every property must be listed in `required`; originally optional
 * properties become `anyOf: [<schema>, {type: "null"}]` (description kept on the wrapper).
 */
export function toOpenAIStrict(node: unknown): unknown {
  if (Array.isArray(node)) return node.map(toOpenAIStrict)
  if (!isObj(node)) return node
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(node)) {
    if (k === 'properties' && isObj(v)) continue
    out[k] = typeof v === 'object' && v !== null ? toOpenAIStrict(v) : v
  }
  if (isObj(node.properties)) {
    const required = new Set(Array.isArray(node.required) ? (node.required as string[]) : [])
    const props: Record<string, unknown> = {}
    for (const [name, sub] of Object.entries(node.properties)) {
      const s = toOpenAIStrict(sub) as Record<string, unknown>
      props[name] = required.has(name) ? s : nullable(s)
    }
    out.properties = props
    out.required = Object.keys(props)
  }
  return out
}

function nullable(s: Record<string, unknown>): Record<string, unknown> {
  const { description, ...rest } = s
  let wrapped: Record<string, unknown>
  if (Array.isArray(rest.anyOf) && Object.keys(rest).length === 1) {
    const variants = rest.anyOf as unknown[]
    wrapped = variants.some((v) => isObj(v) && v.type === 'null') ? { anyOf: variants } : { anyOf: [...variants, { type: 'null' }] }
  } else {
    wrapped = { anyOf: [rest, { type: 'null' }] }
  }
  if (description !== undefined) wrapped.description = description
  return wrapped
}

/** Removes `additionalProperties` (servers with partial JSON Schema support sometimes reject it). */
function dropAdditionalProperties(node: unknown): unknown {
  if (Array.isArray(node)) return node.map(dropAdditionalProperties)
  if (!isObj(node)) return node
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(node)) {
    if (k === 'additionalProperties' && v === false) continue
    if (k === 'properties' && isObj(v)) {
      const m: Record<string, unknown> = {}
      for (const [pk, pv] of Object.entries(v)) m[pk] = dropAdditionalProperties(pv)
      out[k] = m
    } else out[k] = typeof v === 'object' && v !== null ? dropAdditionalProperties(v) : v
  }
  return out
}

// ---------------------------------------------------------------------------
// $defs hoisting
// ---------------------------------------------------------------------------

/** Deterministic JSON (sorted keys). */
export function stableStringify(v: unknown): string {
  if (Array.isArray(v)) return `[${v.map(stableStringify).join(',')}]`
  if (isObj(v)) {
    return `{${Object.keys(v)
      .sort()
      .map((k) => `${JSON.stringify(k)}:${stableStringify(v[k])}`)
      .join(',')}}`
  }
  return JSON.stringify(v)
}

const withoutDescription = (n: Record<string, unknown>): Record<string, unknown> => {
  const { description: _d, ...rest } = n
  return rest
}

/** Calls `visit` on every sub-schema position (not on the root itself), with a setter to replace it. */
function forEachSubschema(root: Record<string, unknown>, visit: (node: Record<string, unknown>, replace: (n: unknown) => void) => void): void {
  const walk = (node: Record<string, unknown>) => {
    for (const [key, value] of Object.entries(node)) {
      if (SCHEMA_MAP_KEYS.has(key) && isObj(value)) {
        for (const [k, v] of Object.entries(value)) {
          if (isObj(v)) {
            visit(v, (n) => (value[k] = n))
            if (isObj(value[k])) walk(value[k] as Record<string, unknown>)
          }
        }
      } else if (SCHEMA_ARRAY_KEYS.has(key) && Array.isArray(value)) {
        value.forEach((v, i) => {
          if (isObj(v)) {
            visit(v, (n) => (value[i] = n))
            if (isObj(value[i])) walk(value[i] as Record<string, unknown>)
          }
        })
      } else if (SCHEMA_SINGLE_KEYS.has(key) && isObj(value)) {
        visit(value, (n) => (node[key] = n))
        if (isObj(node[key])) walk(node[key] as Record<string, unknown>)
      }
    }
  }
  walk(root)
}

export interface HoistOptions {
  /** Minimum serialized size (chars) of a sub-schema worth hoisting. */
  minSize?: number
  /** Known sub-schema shapes (key = stableStringify without description) -> $defs name. */
  names?: ReadonlyMap<string, string>
  /** How a hoisted occurrence that carried its own description is written. */
  describedRef?: 'sibling' | 'anyOf'
}

/**
 * Hoists sub-schemas that appear at least twice (ignoring their own description) into `$defs`,
 * largest first. Occurrence descriptions are preserved next to the `$ref`.
 */
export function hoistDefs(schema: JsonSchema, opts: HoistOptions = {}): JsonSchema {
  const minSize = opts.minSize ?? 200
  const root = structuredClone(schema) as Record<string, unknown>
  const defs: Record<string, unknown> = isObj(root.$defs) ? (root.$defs as Record<string, unknown>) : {}
  const usedNames = new Set(Object.keys(defs))
  let fallback = 1
  for (let guard = 0; guard < 200; guard++) {
    const counts = new Map<string, { count: number; size: number }>()
    const scan = (node: Record<string, unknown>) => {
      if (typeof node.$ref === 'string') return
      const key = stableStringify(withoutDescription(node))
      const c = counts.get(key)
      if (c) c.count++
      else counts.set(key, { count: 1, size: key.length })
    }
    forEachSubschema(root, (n) => scan(n))
    let best: string | undefined
    let bestSize = 0
    for (const [key, c] of counts) {
      if (c.count >= 2 && c.size >= minSize && c.size > bestSize) {
        best = key
        bestSize = c.size
      }
    }
    if (!best) break
    let name = opts.names?.get(best)
    if (!name || usedNames.has(name)) {
      while (usedNames.has(`Def${fallback}`)) fallback++
      name = `Def${fallback++}`
    }
    usedNames.add(name)
    const ref = `#/$defs/${name}`
    let def: unknown
    forEachSubschema(root, (node, replace) => {
      if (typeof node.$ref === 'string') return
      const plain = withoutDescription(node)
      if (stableStringify(plain) !== best) return
      if (def === undefined) def = plain
      if (typeof node.description === 'string') {
        replace(opts.describedRef === 'anyOf' ? { anyOf: [{ $ref: ref }], description: node.description } : { $ref: ref, description: node.description })
      } else replace({ $ref: ref })
    })
    defs[name] = def
    root.$defs = defs
  }
  // Keep $defs last for readability.
  if (isObj(root.$defs)) {
    const d = root.$defs
    delete root.$defs
    root.$defs = d
  }
  return root
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/** Zod schemas whose JSON shapes get readable `$defs` names when hoisted. */
const NAMED_SCHEMAS: ReadonlyArray<[string, z.ZodType]> = [
  ['Expr', ExprSchema],
  ['Vec2', Vec2Schema],
  ['Vec3', Vec3Schema],
  ['Dir3', Dir3Schema],
  ['Parameter', ParameterSchema],
  ['Plane', PlaneSchema],
  ['ProfileRepeat', ProfileRepeatSchema],
  ['PathSegment', PathSegmentSchema],
  ['Profile', ProfileSchema],
  ['Sketch', SketchSchema],
  ['OnPlane', OnPlaneSchema],
  ['EdgeSelector', EdgeSelectorSchema],
  ['FaceSelector', FaceSelectorSchema],
  ['Feature', FeatureSchema],
  ['Part', PartSchema],
  ['RotationStep', RotationStepSchema],
  ['Instance', InstanceSchema],
  ['Parameters', z.array(ParameterSchema)],
]

/** Raw JSON Schema of the CAD model as produced by Zod v4. */
export function rawCadJsonSchema(): JsonSchema {
  return z.toJSONSchema(CadModelSchema) as JsonSchema
}

function transform(raw: JsonSchema, variant: SchemaVariant): JsonSchema {
  let s = sanitizeSchema(raw)
  if (variant === 'openai-strict') s = toOpenAIStrict(s) as JsonSchema
  if (variant !== 'anthropic') s = constToEnum(s) as JsonSchema
  if (variant === 'compat') s = dropAdditionalProperties(s) as JsonSchema
  return s
}

const cache = new Map<SchemaVariant, JsonSchema>()

/** Input schema of the CAD tool for the given provider variant (computed once, cached). */
export function cadToolSchema(variant: SchemaVariant): JsonSchema {
  const hit = cache.get(variant)
  if (hit) return hit
  const s = transform(rawCadJsonSchema(), variant)
  let result: JsonSchema
  if (variant === 'compat') {
    result = s
  } else {
    const names = new Map<string, string>()
    for (const [name, zs] of NAMED_SCHEMAS) {
      const js = transform(z.toJSONSchema(zs) as JsonSchema, variant)
      names.set(stableStringify(withoutDescription(js)), name)
      if (variant === 'openai-strict') names.set(stableStringify(withoutDescription(nullable(js))), `${name}OrNull`)
    }
    result = hoistDefs(s, { names, describedRef: variant === 'anthropic' ? 'sibling' : 'anyOf' })
  }
  cache.set(variant, result)
  return result
}

/** Tool description shared by every provider. */
export const CAD_TOOL_DESCRIPTION =
  'Emit the COMPLETE CIMA parametric CAD model (a single part or an assembly) so the application can validate it, ' +
  'preview it in 3D and build it in CATIA. Always send the whole model, never a partial patch. ' +
  'Units: mm and degrees. Numeric dimension fields ("Expr") accept a number or an arithmetic expression string over ' +
  'parameter names, e.g. 25, "width/2", "2*wall + 5" (operators + - * / ^ ( ), functions sin cos tan asin acos atan ' +
  'atan2 sqrt abs min max round floor ceil, constant pi; trigonometric functions use degrees). ' +
  'The tool result reports "OK", "INVALID" (schema/semantic errors) or "BUILD_ERRORS" (geometry kernel failures); ' +
  'on INVALID or BUILD_ERRORS fix the problems and call the tool again with the full corrected model.'

// ---------------------------------------------------------------------------
// Template tool (small schema: easy even for weak models)
// ---------------------------------------------------------------------------

/** Tool description of use_cad_template. */
export const TEMPLATE_TOOL_DESCRIPTION =
  'Create the model from one of the proven parametric templates listed in the system prompt. Prefer this tool whenever a ' +
  'template fits the request: give the template id, a model name and only the parameter values you want to change ' +
  '(omitted parameters keep their defaults; out-of-range values are clamped). The tool result reports "OK", "INVALID", ' +
  '"BUILD_ERRORS" or "AUDIT" like emit_cad_model.'

/** Input schema of use_cad_template. `compat` drops additionalProperties (Gemini / local servers). */
export function templateToolSchema(variant: SchemaVariant): JsonSchema {
  const strictObj = variant === 'compat' ? {} : { additionalProperties: false }
  return {
    type: 'object',
    ...strictObj,
    required: ['template', 'name', 'params'],
    properties: {
      template: { type: 'string', enum: TEMPLATES.map((t) => t.id), description: 'Template id from the catalog.' },
      name: { type: 'string', description: 'Name of the model (user language, underscores instead of spaces).' },
      params: {
        type: 'array',
        description: 'Parameter values to set (by parameter name). Omitted parameters keep their defaults.',
        items: {
          type: 'object',
          ...strictObj,
          required: ['name', 'value'],
          properties: {
            name: { type: 'string', description: 'Template parameter name.' },
            value: { anyOf: [{ type: 'number' }, { type: 'boolean' }, { type: 'string' }], description: 'Value (mm, degrees, count, true/false or option).' },
          },
        },
      },
    },
  } as JsonSchema
}
