/**
 * AI service: provider-neutral chat streaming with provider dispatch by ProviderConfig.kind.
 *
 *  - anthropic                                  -> ./anthropic (Messages API, beta endpoint)
 *  - openai | gemini | ollama | openai-compatible -> ./openai (Chat Completions)
 */
import type { ChatRequest, ChatStreamEvent, ProviderConfig } from '@shared/ai/types'
import type { ProviderTestResult } from '@shared/ipc'
import type { AppSettings } from '@shared/settings'
import { mapAnthropicError, runAnthropicChat, sdkAnthropicTransport, testAnthropic, type AnthropicTransportFactory } from './anthropic'
import { SessionQuirks, errorText, truncate, type ChatError, type StreamEventBody } from './common'
import { mapOpenAIError, runOpenAIChat, sdkOpenAITransport, testOpenAI, type OpenAITransportFactory } from './openai'
import { appLog } from '../logs'

export { buildSystemPrompt, SYSTEM_PROMPT } from './prompt'
export { cadToolSchema } from './schema'

export interface AiServiceDeps {
  getSettings(): AppSettings
  getApiKey(providerId: string): string | null
}

export interface AiService {
  /** Streams one assistant turn; events are delivered through `emit`. Never throws: errors become 'error' events. */
  chat(request: ChatRequest, emit: (event: ChatStreamEvent) => void): Promise<void>
  cancel(requestId: string): void
  testProvider(providerId: string): Promise<ProviderTestResult>
}

/** SDK transports (overridable in tests). */
export interface AiTransports {
  anthropic: AnthropicTransportFactory
  openai: OpenAITransportFactory
}

export const TEST_TIMEOUT_MS = 60_000

export function createAiService(deps: AiServiceDeps): AiService {
  return createAiServiceWithTransports(deps, { anthropic: sdkAnthropicTransport, openai: sdkOpenAITransport })
}

type Resolved = { ok: true; provider: ProviderConfig; apiKey: string | null; settings: AppSettings } | { ok: false; error: ChatError }

function resolveProvider(deps: AiServiceDeps, providerId: string, forChat: boolean): Resolved {
  const settings = deps.getSettings()
  const provider = settings.providers.find((p) => p.id === providerId)
  if (!provider) return { ok: false, error: { code: 'unknown_provider', message: `Proveedor desconocido: "${providerId}".`, retryable: false } }
  if (forChat && !provider.enabled) {
    return { ok: false, error: { code: 'disabled', message: `El proveedor ${provider.label} está desactivado. Actívalo en Ajustes.`, retryable: false } }
  }
  const apiKey = deps.getApiKey(provider.id)
  if (provider.requiresApiKey && !apiKey) {
    return { ok: false, error: { code: 'auth', message: `Falta la clave API de ${provider.label}. Configúrala en Ajustes.`, retryable: false } }
  }
  if (provider.kind === 'openai-compatible' && !provider.baseURL?.trim()) {
    return { ok: false, error: { code: 'config', message: `Falta la URL base del proveedor ${provider.label}.`, retryable: false } }
  }
  return { ok: true, provider, apiKey, settings }
}

export function createAiServiceWithTransports(deps: AiServiceDeps, transports: AiTransports): AiService {
  const controllers = new Map<string, AbortController>()
  const quirks = new SessionQuirks()

  return {
    async chat(request, emit) {
      const { requestId } = request
      let finished = false
      const send = (body: StreamEventBody) => {
        if (finished) return
        if (body.type === 'done' || body.type === 'error') finished = true
        if (body.type === 'error') appLog('error', 'ai', `chat [${request.providerId}] ${(body.error.code ?? 'error')}: ${body.error.message}`)
        try {
          emit({ ...body, requestId } as ChatStreamEvent)
        } catch {
          /* the renderer may be gone; never throw from chat() */
        }
      }

      const controller = new AbortController()
      controllers.get(requestId)?.abort()
      controllers.set(requestId, controller)
      try {
        const r = resolveProvider(deps, request.providerId, true)
        if (!r.ok) {
          send({ type: 'error', error: r.error })
          return
        }
        const model = (request.model ?? '').trim() || r.provider.model
        if (!model) {
          send({ type: 'error', error: { code: 'config', message: `No hay ningún modelo configurado para ${r.provider.label}.`, retryable: false } })
          return
        }
        const ctx = {
          request,
          provider: r.provider,
          model,
          apiKey: r.apiKey,
          settings: r.settings,
          signal: controller.signal,
          quirks,
          emit: send,
        }
        if (r.provider.kind === 'anthropic') await runAnthropicChat(ctx, transports.anthropic)
        else await runOpenAIChat(ctx, transports.openai)
      } catch (err) {
        appLog('error', 'ai', `chat [${request.providerId}] internal: ${truncate(errorText(err), 300)}`)
        send({ type: 'error', error: { code: 'internal', message: `Error interno del servicio de IA: ${truncate(errorText(err), 300)}`, retryable: false } })
      } finally {
        if (controllers.get(requestId) === controller) controllers.delete(requestId)
        if (!finished) {
          if (controller.signal.aborted) send({ type: 'done', message: { role: 'assistant', text: '' }, stopReason: 'cancelled' })
          else send({ type: 'error', error: { code: 'internal', message: 'La respuesta terminó sin resultado.', retryable: true } })
        }
      }
    },

    cancel(requestId) {
      controllers.get(requestId)?.abort()
    },

    async testProvider(providerId) {
      const r = resolveProvider(deps, providerId, false)
      if (!r.ok) {
        return { ok: false, message: r.error.code === 'auth' ? 'Falta la clave API' : r.error.message }
      }
      const { provider, apiKey } = r
      const model = provider.model
      const t0 = Date.now()
      try {
        const reply =
          provider.kind === 'anthropic'
            ? await testAnthropic(apiKey ?? '', model, TEST_TIMEOUT_MS, transports.anthropic)
            : await testOpenAI(provider, apiKey, model, TEST_TIMEOUT_MS, transports.openai)
        const latencyMs = Date.now() - t0
        const said = reply ? ` Respuesta: "${truncate(reply, 40)}".` : ''
        return { ok: true, message: `Conexión correcta con ${provider.label} (${model}) en ${latencyMs} ms.${said}`, latencyMs }
      } catch (err) {
        const latencyMs = Date.now() - t0
        const e = provider.kind === 'anthropic' ? mapAnthropicError(err, provider.label) : mapOpenAIError(err, provider.label, provider.kind)
        appLog('error', 'ai', `test [${providerId}]: ${e.message}`)
        return { ok: false, message: e.message, latencyMs }
      }
    },
  }
}
