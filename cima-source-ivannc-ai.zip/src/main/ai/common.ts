/**
 * Shared plumbing for the provider adapters: run context, session memory of provider quirks, error mapping helpers.
 */
import type { ChatRequest, ChatStreamEvent, ProviderConfig } from '../../shared/ai/types'
import type { AppSettings } from '../../shared/settings'

/** Event without the requestId (added by the emitter). */
type DistributiveOmit<T, K extends PropertyKey> = T extends unknown ? Omit<T, K> : never
export type StreamEventBody = DistributiveOmit<ChatStreamEvent, 'requestId'>

export interface ChatError {
  message: string
  code?: string
  retryable?: boolean
}

/** Per-session memory of what a provider+model rejected, so the next requests skip the failing option. */
export class SessionQuirks {
  private readonly flags = new Set<string>()
  has(flag: QuirkFlag, providerId: string, model: string): boolean {
    return this.flags.has(`${flag}|${providerId}|${model}`)
  }
  set(flag: QuirkFlag, providerId: string, model: string): void {
    this.flags.add(`${flag}|${providerId}|${model}`)
  }
}

export type QuirkFlag = 'no-strict' | 'no-fallbacks' | 'no-tools' | 'no-reasoning' | 'no-stream-usage' | 'no-eager-streaming' | 'no-tool-choice'

export interface ProviderRunContext {
  request: ChatRequest
  provider: ProviderConfig
  model: string
  apiKey: string | null
  settings: AppSettings
  signal: AbortSignal
  quirks: SessionQuirks
  emit: (event: StreamEventBody) => void
}

/** Tool call ids must match ^[a-zA-Z0-9_-]+$ (Anthropic) and stay short (OpenAI: 40 chars). Deterministic. */
export function sanitizeToolId(id: string, maxLength = 64): string {
  let s = (id || 'call').replace(/[^a-zA-Z0-9_-]/g, '_')
  if (s.length > maxLength) {
    // Keep it unique: prefix + hash of the full id.
    let h = 0
    for (let i = 0; i < id.length; i++) h = (Math.imul(31, h) + id.charCodeAt(i)) | 0
    const tail = (h >>> 0).toString(36)
    s = s.slice(0, maxLength - tail.length - 1) + '_' + tail
  }
  return s
}

export function randomId(prefix: string): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 12)}${Date.now().toString(36)}`
}

/** Text of an unknown error (message + nested API error message when present). */
export function errorText(err: unknown): string {
  if (err instanceof Error) {
    const anyErr = err as Error & { error?: unknown }
    const nested = anyErr.error ? safeJson(anyErr.error) : ''
    return `${err.message} ${nested}`.trim()
  }
  return String(err)
}

function safeJson(v: unknown): string {
  try {
    return JSON.stringify(v)
  } catch {
    return ''
  }
}

/** HTTP 400 that complains about the tool schema / strict mode / grammar compilation. */
export function looksLikeSchemaRejection(text: string): boolean {
  return /strict|schema|grammar|too complex|compil|additionalProperties|\$ref|\$defs|input_schema|anyOf|function parameters/i.test(text)
}

export function looksLikeFallbackRejection(text: string): boolean {
  return /fallback|server-side-fallback/i.test(text)
}

export function looksLikeNoToolsSupport(text: string): boolean {
  return /does not support tools|tools? (are|is) not supported|tool[_ ]?(use|calling|choice)? (is )?not supported|function calling is not (enabled|supported)/i.test(text)
}

export function looksLikeReasoningRejection(text: string): boolean {
  return /reasoning[_ .]?effort|reasoning is not supported|unsupported.*reasoning/i.test(text)
}

export function looksLikeStreamOptionsRejection(text: string): boolean {
  return /stream_options|include_usage/i.test(text)
}

export function looksLikeEagerStreamingRejection(text: string): boolean {
  return /eager_input_streaming/i.test(text)
}

/** Human message (Spanish) for an HTTP status without a more specific SDK class. */
export function messageForStatus(status: number | undefined, providerLabel: string, detail: string): ChatError {
  const d = detail ? ` Detalle: ${truncate(detail, 300)}` : ''
  switch (status) {
    case 400:
      return { code: 'bad_request', message: `${providerLabel} rechazó la petición (400).${d}`, retryable: false }
    case 401:
      return { code: 'auth', message: `La clave API de ${providerLabel} no es válida o ha caducado. Revísala en Ajustes.`, retryable: false }
    case 402:
      return { code: 'billing', message: `${providerLabel} indica un problema de facturación o saldo insuficiente.${d}`, retryable: false }
    case 403:
      return { code: 'permission', message: `La clave API de ${providerLabel} no tiene permiso para este modelo o recurso.${d}`, retryable: false }
    case 404:
      return { code: 'not_found', message: `${providerLabel} no encuentra el modelo o el endpoint. Comprueba el nombre del modelo y la URL base.${d}`, retryable: false }
    case 408:
      return { code: 'timeout', message: `${providerLabel} tardó demasiado en responder. Inténtalo de nuevo.`, retryable: true }
    case 413:
      return { code: 'too_large', message: `La petición es demasiado grande para ${providerLabel} (imágenes o conversación muy largas).`, retryable: false }
    case 422:
      return { code: 'bad_request', message: `${providerLabel} no pudo procesar la petición (422).${d}`, retryable: false }
    case 429:
      return { code: 'rate_limit', message: `Límite de uso de ${providerLabel} alcanzado. Espera unos segundos y vuelve a intentarlo.`, retryable: true }
    case 503:
    case 529:
      return {
        code: 'overloaded',
        message: `${providerLabel} está sobrecargado en este momento (${status}); CIMA ya lo ha reintentado varias veces. Pulsa Reintentar en unos segundos o elige otro modelo en Ajustes (p. ej. uno «flash-lite» o «2.5-flash» en Gemini).`,
        retryable: true,
      }
    default:
      if (status !== undefined && status >= 500) {
        return { code: 'server', message: `Error del servidor de ${providerLabel} (${status}). Inténtalo de nuevo.`, retryable: true }
      }
      return { code: 'unknown', message: `Error inesperado con ${providerLabel}.${d}`, retryable: false }
  }
}

export function truncate(s: string, n: number): string {
  return s.length > n ? s.slice(0, n - 1) + '…' : s
}

/** Joins non-empty text parts. */
export function joinText(parts: ReadonlyArray<string>): string {
  return parts.filter((p) => p.length > 0).join('\n\n')
}
