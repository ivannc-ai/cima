/** File dialogs: projects (.cima) and generic exports. */
import { dialog, type BrowserWindow } from 'electron'
import fs from 'node:fs'
import path from 'node:path'
import type { FileFilter, SaveResult } from '@shared/ipc'
import { PROJECT_EXTENSION, isCimaProject, type CimaProject } from '@shared/project'

const PROJECT_FILTERS = [{ name: 'Proyecto CIMA', extensions: [PROJECT_EXTENSION] }]

export async function openProject(win: BrowserWindow | null): Promise<{ path: string; project: CimaProject } | null> {
  const opts = { title: 'Abrir proyecto', filters: PROJECT_FILTERS, properties: ['openFile' as const] }
  const res = win ? await dialog.showOpenDialog(win, opts) : await dialog.showOpenDialog(opts)
  if (res.canceled || res.filePaths.length === 0) return null
  const file = res.filePaths[0]!
  const data = JSON.parse(fs.readFileSync(file, 'utf8')) as unknown
  if (!isCimaProject(data)) throw new Error('El archivo no es un proyecto CIMA válido.')
  return { path: file, project: data }
}

export async function saveProject(
  win: BrowserWindow | null,
  project: CimaProject,
  options: { path?: string; saveAs?: boolean } = {},
): Promise<SaveResult> {
  let target = options.saveAs ? undefined : options.path
  if (!target) {
    const opts = {
      title: 'Guardar proyecto',
      defaultPath: `${sanitizeFileName(project.name || 'proyecto')}.${PROJECT_EXTENSION}`,
      filters: PROJECT_FILTERS,
    }
    const res = win ? await dialog.showSaveDialog(win, opts) : await dialog.showSaveDialog(opts)
    if (res.canceled || !res.filePath) return { ok: false, canceled: true }
    target = res.filePath
  }
  try {
    fs.writeFileSync(target, JSON.stringify({ ...project, updatedAt: new Date().toISOString() }, null, 2), 'utf8')
    return { ok: true, path: target }
  } catch (e) {
    return { ok: false, error: (e as Error).message }
  }
}

export async function saveFile(
  win: BrowserWindow | null,
  req: { title?: string; defaultName: string; filters: FileFilter[]; data: string | Uint8Array },
): Promise<SaveResult> {
  const opts = { title: req.title ?? 'Exportar', defaultPath: sanitizeFileName(req.defaultName), filters: req.filters }
  const res = win ? await dialog.showSaveDialog(win, opts) : await dialog.showSaveDialog(opts)
  if (res.canceled || !res.filePath) return { ok: false, canceled: true }
  try {
    fs.writeFileSync(res.filePath, typeof req.data === 'string' ? req.data : Buffer.from(req.data))
    return { ok: true, path: res.filePath }
  } catch (e) {
    return { ok: false, error: (e as Error).message }
  }
}

export function sanitizeFileName(name: string): string {
  const base = path.basename(name)
  return base.replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_').trim() || 'cima'
}
