/**
 * Content of the Help page ("Ayuda"). Plain data so it is easy to edit: every text field accepts the
 * small markdown subset of the chat (**negrita**, `código`, listas con "- ").
 */

export interface HelpSection {
  id: string
  title: string
}

/** Table of contents (order of the page). */
export const HELP_SECTIONS: HelpSection[] = [
  { id: 'inicio', title: 'Inicio' },
  { id: 'como-funciona', title: 'Cómo funciona' },
  { id: 'capacidades', title: 'Qué puede hacer' },
  { id: 'prompts', title: 'Escribir buenos prompts' },
  { id: 'parametros', title: 'Parámetros y versiones' },
  { id: 'plantillas', title: 'Plantillas y auditoría' },
  { id: 'catia', title: 'Conector CATIA' },
  { id: 'proveedores', title: 'Proveedores de IA y claves' },
  { id: 'exportar', title: 'Exportar' },
  { id: 'atajos', title: 'Atajos de teclado' },
  { id: 'faq', title: 'Preguntas frecuentes' },
]

export const HERO = {
  title: 'Diseño CAD paramétrico con IA, directo a CATIA',
  subtitle:
    'Describe una pieza en lenguaje natural. CIMA genera un modelo paramétrico, lo muestra en 3D con deslizadores y lo construye en CATIA V5 o 3DEXPERIENCE con operaciones nativas.',
}

export const STEPS = [
  {
    icon: 'sparkle',
    title: 'Describe',
    text: 'Escribe qué necesitas (medidas, material, taladros…) o adjunta un croquis o una foto. La IA genera un modelo paramétrico.',
  },
  {
    icon: 'sliders',
    title: 'Ajusta parámetros',
    text: 'Mueve los deslizadores y la vista 3D se actualiza al momento. Pide cambios en el chat: cada respuesta crea una versión nueva.',
  },
  {
    icon: 'bolt',
    title: 'Envía a CATIA',
    text: 'Con un clic CIMA crea el Part o el Product en CATIA con parámetros, fórmulas y operaciones de Part Design editables.',
  },
]

export const CAPABILITIES = [
  { icon: 'cube', title: 'Piezas y ensamblajes', text: 'Una pieza o varias piezas colocadas como instancias de un ensamblaje.' },
  { icon: 'layers', title: 'Árbol de operaciones', text: 'Extrusión, cajera, revolución, ranura, taladro, redondeo, chaflán, vaciado, simetría y patrones.' },
  { icon: 'sliders', title: 'Parámetros vivos', text: 'Parámetros con unidades, rangos y expresiones derivadas, como en las fórmulas de CATIA.' },
  { icon: 'refresh', title: 'Reparación automática', text: 'Si el modelo no es válido o no se construye, la IA recibe los errores y lo corrige sola.' },
  { icon: 'image', title: 'Imágenes de referencia', text: 'Adjunta croquis, planos o fotos (PNG, JPEG o WebP de hasta 5 MB).' },
  { icon: 'export', title: 'Exportación', text: 'STEP y STL sin CATIA, macros de CATIA (.catvbs) y scripts VBS, y el modelo en JSON.' },
]

export interface PromptExample {
  label: string
  text: string
}

export const PROMPT_TIPS = [
  'Da **medidas concretas** y unidades (mm, grados). Si no las sabes, dilo: la IA propondrá valores razonables.',
  'Indica **qué debe ser paramétrico** (“quiero poder cambiar el número de taladros”).',
  'Describe la **orientación**: qué cara apoya en el plano XY, dónde está el origen, qué es la cara superior.',
  'Para modificar, pide **un cambio cada vez** y nombra el elemento (“la pared”, “los taladros de fijación”).',
]

export const PROMPT_EXAMPLES: PromptExample[] = [
  { label: 'Brida', text: 'Brida circular de 160 mm de diámetro y 16 mm de espesor, agujero central de 60 mm y 6 taladros de 13.5 mm en un círculo de 110 mm, con los bordes exteriores redondeados a 2 mm.' },
  { label: 'Escuadra con nervio', text: 'Escuadra en L de aluminio de 80x60x50 mm y 6 mm de espesor, con un nervio triangular de refuerzo en el centro y dos taladros avellanados M6 en cada ala.' },
  { label: 'Eje con chavetero', text: 'Eje escalonado de 200 mm de largo con tramos de Ø30 y Ø20 mm, chaflanes de 1 mm en los extremos y un chavetero de 6x3.5 mm y 40 mm de largo en el tramo de Ø20.' },
  { label: 'Caja con tapa', text: 'Ensamblaje de una caja de 120x80x40 mm vaciada con pared de 2.5 mm y una tapa de 3 mm con pestaña interior que encaje en la caja; esquinas redondeadas de 6 mm.' },
  { label: 'Soporte de rodamiento', text: 'Soporte de pie para un rodamiento 6204 (Ø47 mm): base de 120x40x12 mm con dos colisos para tornillos M10 y cuerpo con alojamiento de Ø47 mm a 50 mm de altura.' },
  { label: 'Placa y columnas', text: 'Ensamblaje de dos placas de 200x140x10 mm unidas por cuatro columnas de Ø20 mm y 120 mm de alto situadas a 20 mm de los bordes.' },
  { label: 'Editar: pared', text: 'Haz la pared de 3 mm.' },
  { label: 'Editar: taladros', text: 'Pon 8 taladros en lugar de 6 y aumenta su diámetro a 14 mm.' },
]

export const PARAMS_TEXT = [
  'El panel **Parámetros** agrupa los parámetros del modelo y de cada pieza. Los deslizadores cambian la vista 3D al instante sin llamar a la IA; los parámetros derivados (con expresión) se muestran en gris.',
  '**Aplicar como valores por defecto** guarda los valores actuales en una versión nueva. Cuando escribes al chat, CIMA adjunta el modelo con tus valores para que la IA parta de ellos.',
  'Cada respuesta de la IA, edición del JSON o activación/desactivación de una operación en el **Árbol** crea una versión (v1, v2…). Puedes **restaurar** cualquiera desde su tarjeta en el chat o desde el Árbol.',
  'La pestaña **JSON** muestra el modelo completo: puedes editarlo, validarlo y aplicarlo como versión nueva.',
]

export const TEMPLATES_TEXT = {
  templates: [
    'Las **plantillas paramétricas** son modelos probados (brida, placa con taladros, escuadra, eje escalonado, caja, soporte de rodamiento, casquillo, separador hexagonal y ensamblaje de placas con columnas) que se generan a partir de unas pocas medidas.',
    'Úsalas sin IA desde **Plantillas** (barra superior o pantalla de inicio): eliges la plantilla, ajustas las medidas y pulsas **Crear**. Las medidas quedan como parámetros editables.',
    'La IA también puede usarlas: cuando tu petición encaja con una plantilla, solo envía los valores en lugar del modelo completo. Es más rápido y fiable, sobre todo con **modelos pequeños o locales** (Gemini Flash, Ollama).',
  ],
  audit: [
    'La **auditoría** revisa cada modelo generado frente a tu petición: medidas generales escritas como `AxBxC`, número de taladros, diámetros y espesores pedidos, y la geometría (sólidos separados, operaciones sin efecto, interferencias o piezas flotando en ensamblajes).',
    'Si algo no cumple, CIMA se lo envía a la IA para que lo corrija automáticamente (cuenta como intento de reparación). La tarjeta de cada versión muestra **Auditoría OK** o los avisos encontrados.',
    'En la pestaña **Árbol**, el botón **Auditar** revisa el modelo actual cuando lo editas a mano.',
  ],
  toggle: 'Ambas funciones se activan o desactivan en **Ajustes › Opciones de IA**.',
}

export const CATIA_TEXT = {
  intro:
    'CIMA genera un script que CATIA ejecuta por automatización COM (solo Windows). El resultado es un documento **nuevo**: tu documento activo no se modifica.',
  targets: [
    { title: 'CATIA V5', text: 'Crea un **CATPart** (o un **CATProduct** con sus piezas para ensamblajes) con parámetros de usuario, fórmulas y operaciones de Part Design. Puede guardar los archivos y exportar STEP.' },
    { title: '3DEXPERIENCE', text: 'Crea una **3D Shape** por pieza con parámetros y operaciones nativas. Los ensamblajes todavía no se crean como Physical Product.' },
  ],
  usage: [
    'Abre CATIA, ve a la pestaña **CATIA** y pulsa **Enviar a CATIA**. El registro muestra cada operación creada o con error.',
    'Opciones: destino (automático, V5 o 3DEXPERIENCE), adjuntar a la sesión abierta o iniciar CATIA, crear parámetros, fórmulas, colores, carpeta de guardado y STEP.',
    '**Modelo de inicio**: en lugar de un documento vacío, CIMA puede partir de una plantilla local tuya (`.CATPart` para piezas, `.CATProduct` para ensamblajes) con sus tablas y geometrical sets. El desplegable se rellena con las plantillas del **catálogo automático** del programa (línea `Mmaterial;…` de su `DLNames` de MODLOCAL) filtrando por naturaleza del modelo. Al elegir plantilla puedes poner el **nombre que quieras** al Part/Product resultante (PartNumber y nombre de archivo al guardar). Sin plantilla elegida se crea un documento vacío; sin acceso a MODLOCAL/DLNames o a la carpeta de red no hay plantillas y, si la plantilla no abre al generar, el trabajo falla con un error claro.',
    '**Leer documento activo** lista los parámetros del documento abierto; **Enviar valores** actualiza los que tienen el mismo nombre que los parámetros de CIMA.',
    '**Exportar macro** guarda el script como `.catvbs` (macro VBScript: en CATIA, Herramientas › Macro › Macros › bibliotecas VBScript › `CATMain`) o `.vbs` (se ejecuta con cscript con CATIA abierto).',
    'Si CATIA se ejecuta como administrador, abre también CIMA como administrador.',
  ],
  native: [
    'Parámetros de usuario y fórmulas que gobiernan las cotas',
    'Bocetos sobre planos de origen o desplazados',
    'Pad, Pocket, Shaft, Groove y Hole',
    'Fillet, Chamfer, Shell y Mirror',
    'Products con instancias colocadas (V5)',
  ],
  limits: [
    'Las cotas internas de los bocetos son numéricas; las fórmulas actúan sobre las operaciones.',
    'Los patrones se crean como copias individuales (desenrollados).',
    'Los redondeos y chaflanes dependen de la búsqueda de aristas por topología y pueden fallar en geometrías complejas.',
    'En 3DEXPERIENCE se crean 3D Shapes sueltas, sin ensamblaje.',
  ],
}

export const PROVIDERS = [
  { name: 'Anthropic Claude', badge: 'Recomendado', text: 'La mejor calidad de modelado. Necesita una clave de console.anthropic.com.' },
  {
    name: 'Google Gemini',
    badge: 'Nivel gratuito',
    text: 'Crea una clave gratuita en Google AI Studio (empieza por `AIza`) y usa un modelo como `gemini-flash-latest`. En el nivel gratuito Google puede usar los datos para mejorar sus modelos.',
  },
  { name: 'Ollama (local)', badge: 'Gratis y local', text: 'Modelos en tu equipo, sin enviar datos. Requiere una GPU potente y aumentar `num_ctx` (contexto) para modelos grandes.' },
  { name: 'OpenAI y compatibles', badge: '', text: 'OpenAI, o cualquier servicio compatible (OpenRouter, Groq, tus proxies internos…) añadiendo su URL base en Ajustes. En cada proveedor puedes **definir la lista de modelos disponibles** que quieras: todos comparten el mismo endpoint, proxy y clave, y aparecen en el selector de modelo del chat.' },
]

export const KEYS_NOTE = 'Las claves API se guardan cifradas en este equipo y nunca se muestran de nuevo. Configúralas en **Ajustes › Proveedores de IA**.'

export const EXPORTS = [
  { format: 'STEP (.step)', text: 'Sólido exacto para cualquier CAD. No necesita CATIA.' },
  { format: 'STL (.stl)', text: 'Malla triangulada para impresión 3D o visualización.' },
  { format: 'Macro (.catvbs / .vbs)', text: 'Script que reconstruye el modelo en CATIA en otro equipo.' },
  { format: 'Modelo (.json)', text: 'El modelo paramétrico CIMA con los valores actuales.' },
  { format: 'Proyecto (.cima)', text: 'Modelo, versiones y conversación completa (Guardar / Abrir).' },
]

export const SHORTCUTS: Array<[string, string]> = [
  ['Ctrl+N', 'Nuevo proyecto'],
  ['Ctrl+O', 'Abrir proyecto'],
  ['Ctrl+S', 'Guardar'],
  ['Ctrl+Mayús+S', 'Guardar como'],
  ['Intro', 'Enviar mensaje'],
  ['Mayús+Intro', 'Nueva línea en el mensaje'],
  ['F', 'Encuadrar el modelo'],
  ['0 · 1 · 2 · 3', 'Vista Iso · Frente · Superior · Derecha'],
  ['F1', 'Abrir esta ayuda'],
  ['Esc', 'Cerrar ayuda o diálogos'],
  ['F12', 'Herramientas de desarrollo'],
]

export const FAQ: Array<{ q: string; a: string }> = [
  {
    q: '¿Se crean operaciones o un sólido en CATIA?',
    a: 'Operaciones nativas: parámetros, fórmulas, bocetos y operaciones de Part Design que puedes editar en el árbol de CATIA. No se importa un sólido muerto.',
  },
  {
    q: '¿Necesito CATIA para usar CIMA?',
    a: 'No. El modelado, la vista 3D, los parámetros y la exportación a STEP y STL funcionan sin CATIA. CATIA solo hace falta para crear el modelo nativo.',
  },
  {
    q: '¿Incluye chapa / Aerospace Sheet Metal?',
    a: 'Todavía no: CIMA modela sólidos de Part Design. Una chapa se puede aproximar como sólido de espesor constante con pads y redondeos, pero no se crean operaciones de Sheet Metal / Aerospace Sheet Metal Design ni desarrollos planos. Está previsto como ampliación.',
  },
  {
    q: '¿Mis datos salen del equipo?',
    a: 'Solo los mensajes (y las imágenes adjuntas) que envías al proveedor de IA elegido. Los proyectos, el modelo y CATIA se quedan en tu equipo. Con Ollama todo es 100 % local.',
  },
  {
    q: '¿Qué hace la auditoría?',
    a: 'Tras cada generación compara el modelo con tu petición (medidas generales, número de taladros, diámetros y espesores) y comprueba la geometría. Lo que no cumple se envía a la IA para que lo corrija; el resto se muestra como aviso en la tarjeta de la versión. Puedes desactivarla en Ajustes › Opciones de IA.',
  },
  {
    q: '¿Qué hago si el modelo sale con errores?',
    a: 'CIMA envía los errores a la IA y reintenta automáticamente (configurable en Ajustes). Si persisten, describe el problema en el chat, desactiva la operación conflictiva en el Árbol o restaura una versión anterior.',
  },
  {
    q: '¿Dónde están los registros de errores?',
    a: 'Todo lo que falla (generación de la IA, construcción del modelo, envío a CATIA, errores internos) se escribe en `%APPDATA%\\CIMA\\logs\\` en un fichero diario `cima-AAAA-MM-DD.log`. Ábrelo desde el botón **Abrir carpeta de registros** de esta ayuda. Los ficheros de más de 14 días se borran solos.',
  },
  {
    q: '¿Cómo funcionan los modelos de inicio de CATIA?',
    a: 'El desplegable se rellena con las plantillas del **catálogo automático** del programa: CIMA lee el `DLNames` de MODLOCAL (`%USERPROFILE%\\MODLOCAL\\{programa}\\CATSettingsRefV5R{versión}\\{programa}_DLNames.txt`), toma la ruta de la línea `Mmaterial;…` y lista sus `.CATPart` (piezas) y `.CATProduct` (ensamblajes) según la naturaleza del modelo. **No hay fallback**: sin acceso a MODLOCAL, al DLNames o a la carpeta de red no se muestran plantillas. Al elegir una plantilla puedes **poner el nombre que quieras** al Part/Product: ese nombre se usa como PartNumber y como nombre de archivo al guardar. Sin plantilla se crea un documento vacío; si la plantilla elegida no puede abrirse al generar, el trabajo falla con un error claro en el registro.',
  },
  {
    q: '¿Puedo usarlo sin clave API?',
    a: 'Sí, en modo demostración: carga cualquiera de los ejemplos para probar el visor, los parámetros, la exportación y el envío a CATIA.',
  },
]
