import { useEffect, useRef, useState } from 'react'
import { useUi } from '../store/ui'
import { Icon } from '../components/Icon'
import { Markdown } from '../components/Markdown'
import { cima } from '../lib/bridge'
import { BRAND_TAGLINE } from '../branding/Brand'
import logoUrl from '../assets/logo.png'
import {
  CAPABILITIES,
  CATIA_TEXT,
  EXPORTS,
  FAQ,
  HELP_SECTIONS,
  HERO,
  KEYS_NOTE,
  PARAMS_TEXT,
  PROMPT_EXAMPLES,
  PROMPT_TIPS,
  PROVIDERS,
  SHORTCUTS,
  STEPS,
  TEMPLATES_TEXT,
} from './content'

function HeroArt() {
  return (
    <div className="hero-art" aria-hidden>
      <div className="hero-glow" />
      <div className="wire-cube">
        {['front', 'back', 'right', 'left', 'top', 'bottom'].map((f) => (
          <div key={f} className={`wc-face wc-${f}`} />
        ))}
      </div>
      <img className="hero-logo" src={logoUrl} alt="" />
    </div>
  )
}

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false)
  return (
    <div className={`faq-item ${open ? 'open' : ''}`}>
      <button className="faq-q" onClick={() => setOpen(!open)} aria-expanded={open}>
        <span>{q}</span>
        <Icon name="chevronDown" size={14} />
      </button>
      {open && (
        <div className="faq-a">
          <Markdown text={a} />
        </div>
      )}
    </div>
  )
}

export function HelpOverlay() {
  const open = useUi((s) => s.helpOpen)
  const setOpen = useUi((s) => s.setHelpOpen)
  const insertPrompt = useUi((s) => s.insertPrompt)
  const scrollRef = useRef<HTMLDivElement>(null)
  const [active, setActive] = useState(HELP_SECTIONS[0]!.id)

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, setOpen])

  // Scroll-spy for the table of contents.
  useEffect(() => {
    const root = scrollRef.current
    if (!open || !root) return
    const obs = new IntersectionObserver(
      (entries) => {
        const vis = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0]
        if (vis) setActive(vis.target.id)
      },
      { root, rootMargin: '0px 0px -65% 0px', threshold: 0 },
    )
    root.querySelectorAll('section[id]').forEach((s) => obs.observe(s))
    return () => obs.disconnect()
  }, [open])

  if (!open) return null

  const go = (id: string) => {
    const el = scrollRef.current?.querySelector(`#${id}`)
    el?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    setActive(id)
  }

  return (
    <div className="help-overlay" role="dialog" aria-label="Ayuda">
      <header className="help-top">
        <div className="logo">
          <img src={logoUrl} alt="" />
          <span>CIMA</span>
          <span className="help-top-sub">Ayuda</span>
        </div>
        <div className="spacer" />
        <button className="btn btn-sm pill" onClick={() => setOpen(false)}>
          <Icon name="close" size={13} /> Cerrar <kbd>Esc</kbd>
        </button>
      </header>
      <div className="help-body">
        <nav className="help-toc">
          <div className="help-toc-title">Contenido</div>
          {HELP_SECTIONS.map((s) => (
            <button key={s.id} className={active === s.id ? 'on' : ''} onClick={() => go(s.id)}>
              {s.title}
            </button>
          ))}
        </nav>
        <div className="help-scroll" ref={scrollRef}>
          <div className="help-content">
            <section id="inicio" className="help-hero">
              <div className="hero-text">
                <span className="eyebrow">
                  <Icon name="sparkle" size={12} /> Texto a CAD para CATIA
                </span>
                <h1>{HERO.title}</h1>
                <div className="hero-tagline">{BRAND_TAGLINE}</div>
                <p>{HERO.subtitle}</p>
                <div className="hero-actions">
                  <button className="btn btn-primary pill" onClick={() => insertPrompt('')}>
                    Empezar a diseñar <Icon name="send" size={13} />
                  </button>
                  <button className="btn pill" onClick={() => go('prompts')}>
                    Ver ejemplos de prompts
                  </button>
                </div>
              </div>
              <HeroArt />
            </section>

            <section id="como-funciona">
              <h2>Cómo funciona</h2>
              <div className="steps">
                {STEPS.map((s, i) => (
                  <div key={s.title} className="step-card">
                    <div className="step-num">{i + 1}</div>
                    <div className="step-icon">
                      <Icon name={s.icon} size={18} />
                    </div>
                    <h3>{s.title}</h3>
                    <p>{s.text}</p>
                  </div>
                ))}
              </div>
            </section>

            <section id="capacidades">
              <h2>Qué puede hacer</h2>
              <div className="cap-grid">
                {CAPABILITIES.map((c) => (
                  <div key={c.title} className="cap-card">
                    <Icon name={c.icon} size={18} />
                    <h3>{c.title}</h3>
                    <p>{c.text}</p>
                  </div>
                ))}
              </div>
            </section>

            <section id="prompts">
              <h2>Escribir buenos prompts</h2>
              <ul className="help-list">
                {PROMPT_TIPS.map((t) => (
                  <li key={t}>
                    <Markdown text={t} />
                  </li>
                ))}
              </ul>
              <p className="muted small">Pulsa un ejemplo para copiarlo en el chat:</p>
              <div className="pills">
                {PROMPT_EXAMPLES.map((p) => (
                  <button key={p.label} className="pill-btn" title={p.text} onClick={() => insertPrompt(p.text)}>
                    <Icon name="sparkle" size={12} /> {p.label}
                  </button>
                ))}
              </div>
            </section>

            <section id="parametros">
              <h2>Parámetros y versiones</h2>
              {PARAMS_TEXT.map((t) => (
                <Markdown key={t} text={t} />
              ))}
            </section>

            <section id="plantillas">
              <h2>Plantillas y auditoría</h2>
              <div className="two-col">
                <div className="cap-card">
                  <Icon name="layers" size={18} />
                  <h3>Plantillas paramétricas</h3>
                  {TEMPLATES_TEXT.templates.map((t) => (
                    <Markdown key={t} text={t} />
                  ))}
                </div>
                <div className="cap-card">
                  <Icon name="shield" size={18} />
                  <h3>Auditoría de la generación</h3>
                  {TEMPLATES_TEXT.audit.map((t) => (
                    <Markdown key={t} text={t} />
                  ))}
                </div>
              </div>
              <div className="info-card">
                <h3>
                  <Icon name="gear" size={14} /> Activar o desactivar
                </h3>
                <Markdown text={TEMPLATES_TEXT.toggle} />
              </div>
            </section>

            <section id="catia">
              <h2>Conector CATIA</h2>
              <Markdown text={CATIA_TEXT.intro} />
              <div className="two-col">
                {CATIA_TEXT.targets.map((t) => (
                  <div key={t.title} className="cap-card">
                    <Icon name="bolt" size={18} />
                    <h3>{t.title}</h3>
                    <Markdown text={t.text} />
                  </div>
                ))}
              </div>
              <ul className="help-list">
                {CATIA_TEXT.usage.map((t) => (
                  <li key={t}>
                    <Markdown text={t} />
                  </li>
                ))}
              </ul>
              <div className="two-col">
                <div className="info-card ok">
                  <h3>
                    <Icon name="check" size={14} /> Se crea de forma nativa
                  </h3>
                  <ul>
                    {CATIA_TEXT.native.map((t) => (
                      <li key={t}>{t}</li>
                    ))}
                  </ul>
                </div>
                <div className="info-card warn">
                  <h3>
                    <Icon name="warn" size={14} /> Limitaciones actuales
                  </h3>
                  <ul>
                    {CATIA_TEXT.limits.map((t) => (
                      <li key={t}>{t}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </section>

            <section id="proveedores">
              <h2>Proveedores de IA y claves</h2>
              <div className="cap-grid two">
                {PROVIDERS.map((p) => (
                  <div key={p.name} className="cap-card">
                    <div className="cap-head">
                      <h3>{p.name}</h3>
                      {p.badge && <span className="tag tag-accent">{p.badge}</span>}
                    </div>
                    <Markdown text={p.text} />
                  </div>
                ))}
              </div>
              <div className="info-card">
                <h3>
                  <Icon name="shield" size={14} /> Claves
                </h3>
                <Markdown text={KEYS_NOTE} />
              </div>
            </section>

            <section id="exportar">
              <h2>Exportar</h2>
              <div className="kv-table">
                {EXPORTS.map((e) => (
                  <div key={e.format} className="kv-row">
                    <span className="kv-k mono">{e.format}</span>
                    <span className="kv-v">{e.text}</span>
                  </div>
                ))}
              </div>
            </section>

            <section id="atajos">
              <h2>Atajos de teclado</h2>
              <div className="kv-table">
                {SHORTCUTS.map(([k, v]) => (
                  <div key={k} className="kv-row">
                    <span className="kv-k">
                      {k.split(' · ').map((x, i) => (
                        <kbd key={i}>{x}</kbd>
                      ))}
                    </span>
                    <span className="kv-v">{v}</span>
                  </div>
                ))}
              </div>
            </section>

            <section id="faq">
              <h2>Preguntas frecuentes</h2>
              <div className="info-card">
                <h3>
                  <Icon name="folder" size={14} /> Registros de errores
                </h3>
                <p className="small muted">
                  Todo lo que falla (IA, construcción del modelo, CATIA, errores internos) queda en un fichero diario en
                  <code> %APPDATA%\CIMA\logs\</code>.
                </p>
                <button className="btn btn-sm" onClick={() => void cima.app.openLogsFolder()}>
                  <Icon name="folder" size={13} /> Abrir carpeta de registros
                </button>
              </div>
              <div className="faq">
                {FAQ.map((f) => (
                  <FaqItem key={f.q} q={f.q} a={f.a} />
                ))}
              </div>
            </section>
            <div className="help-end muted small">
              CIMA · asistente de modelado CAD con IA para CATIA
              <div className="help-end-tagline">{BRAND_TAGLINE}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
