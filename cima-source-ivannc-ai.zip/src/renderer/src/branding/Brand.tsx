/**
 * Corporate branding (Airbus Defence & Space — Métodos, Procesos y Herramientas CAD).
 *
 * The official Airbus logo is NOT bundled in the source code: place the official white logo file in
 * src/renderer/src/branding/assets/ as "airbus-logo.svg" (preferred) or "airbus-logo.png" and rebuild.
 * Until then a plain-text wordmark is shown as a placeholder.
 */
import { useEffect, useState } from 'react'

const found = import.meta.glob('./assets/airbus-logo.{svg,png,webp}', { eager: true, query: '?url', import: 'default' }) as Record<
  string,
  string
>
/** URL of the official logo, if the file is present at build time. */
export const AIRBUS_LOGO_URL: string | null =
  found['./assets/airbus-logo.svg'] ?? found['./assets/airbus-logo.png'] ?? found['./assets/airbus-logo.webp'] ?? null

export const BRAND_DIVISION = 'Airbus Defence & Space'
export const BRAND_DEPARTMENT = 'Métodos, Procesos y Herramientas CAD'
export const BRAND_TAGLINE = 'CAD INTELLIGENT MODELER FOR AIRBUS D&S'

/** Airbus logo (official file) or a text placeholder of the same height. */
export function AirbusLogo({ height, className }: { height: number; className?: string }) {
  if (AIRBUS_LOGO_URL) {
    return <img src={AIRBUS_LOGO_URL} alt="Airbus" className={className} style={{ height, width: 'auto', display: 'block' }} draggable={false} />
  }
  return (
    <span
      className={`brand-wordmark ${className ?? ''}`}
      style={{ fontSize: height, lineHeight: 1 }}
      title="Coloca el logotipo oficial en src/renderer/src/branding/assets/airbus-logo.svg"
    >
      AIRBUS
    </span>
  )
}

/** Welcome screen shown when the application starts (click or any key skips it). */
export function SplashScreen({ minMs = 2600 }: { minMs?: number }) {
  const [phase, setPhase] = useState<'show' | 'fade' | 'gone'>('show')

  useEffect(() => {
    const fade = window.setTimeout(() => setPhase('fade'), minMs)
    const skip = () => setPhase((p) => (p === 'show' ? 'fade' : p))
    window.addEventListener('keydown', skip, { once: true })
    return () => {
      window.clearTimeout(fade)
      window.removeEventListener('keydown', skip)
    }
  }, [minMs])

  useEffect(() => {
    if (phase !== 'fade') return
    const t = window.setTimeout(() => setPhase('gone'), 550)
    return () => window.clearTimeout(t)
  }, [phase])

  if (phase === 'gone') return null
  return (
    <div className={`splash ${phase === 'fade' ? 'splash-fade' : ''}`} onClick={() => setPhase('fade')} role="presentation">
      <div className="splash-content">
        <AirbusLogo height={96} className="splash-logo" />
        <div className="splash-division">{BRAND_DIVISION}</div>
        <div className="splash-department">{BRAND_DEPARTMENT}</div>
      </div>
      <div className="splash-footer">
        <div className="splash-app">CIMA</div>
        <div className="splash-tagline">{BRAND_TAGLINE}</div>
      </div>
    </div>
  )
}
