import { useEffect, type PointerEvent as ReactPointerEvent } from 'react'
import { TopBar } from './components/TopBar'
import { ChatPanel } from './components/ChatPanel'
import { Viewport } from './components/Viewport'
import { RightPanel } from './components/RightPanel'
import { StatusBar } from './components/StatusBar'
import { SettingsModal } from './components/SettingsModal'
import { ConfirmDialog, Toasts } from './components/Modal'
import { HelpOverlay } from './help/HelpOverlay'
import { TemplatesModal } from './components/TemplatesModal'
import { SplashScreen } from './branding/Brand'
import { useSettings } from './store/settings'
import { startKernel } from './store/model'
import { startChatEvents } from './store/chat'
import { startCatiaEvents, useCatia } from './store/catia'
import { useUi } from './store/ui'
import { newProject, openProject, saveProject } from './lib/actions'

let booted = false
function boot(): void {
  if (booted) return
  booted = true
  startChatEvents()
  startCatiaEvents()
  startKernel()
  void useSettings.getState().load()
  void useCatia.getState().refresh()
}

function Resizer({ side }: { side: 'left' | 'right' }) {
  const setWidths = useUi((s) => s.setWidths)
  const onDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    e.preventDefault()
    const startX = e.clientX
    const ui = useUi.getState()
    const start = side === 'left' ? ui.leftWidth : ui.rightWidth
    const el = e.currentTarget
    el.setPointerCapture(e.pointerId)
    el.classList.add('dragging')
    const move = (ev: PointerEvent) => {
      const dx = ev.clientX - startX
      const w = side === 'left' ? start + dx : start - dx
      const max = side === 'left' ? 640 : 560
      const clamped = Math.max(300, Math.min(max, w))
      setWidths(side === 'left' ? { left: clamped } : { right: clamped })
    }
    const up = () => {
      el.classList.remove('dragging')
      el.removeEventListener('pointermove', move)
      el.removeEventListener('pointerup', up)
      el.removeEventListener('pointercancel', up)
    }
    el.addEventListener('pointermove', move)
    el.addEventListener('pointerup', up)
    el.addEventListener('pointercancel', up)
  }
  return <div className={`resizer resizer-${side}`} onPointerDown={onDown} />
}

export function App() {
  const leftWidth = useUi((s) => s.leftWidth)
  const rightWidth = useUi((s) => s.rightWidth)

  useEffect(() => {
    boot()
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'F1') {
        e.preventDefault()
        const ui = useUi.getState()
        ui.setHelpOpen(!ui.helpOpen)
        return
      }
      if (!(e.ctrlKey || e.metaKey) || e.altKey) return
      const k = e.key.toLowerCase()
      if (k === 's') {
        e.preventDefault()
        void saveProject(e.shiftKey)
      } else if (k === 'o') {
        e.preventDefault()
        void openProject()
      } else if (k === 'n') {
        e.preventDefault()
        void newProject()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  return (
    <div className="app" style={{ gridTemplateColumns: `8px ${leftWidth}px 8px minmax(0, 1fr) 8px ${rightWidth}px 8px` }}>
      <TopBar />
      <aside className="left">
        <ChatPanel />
      </aside>
      <Resizer side="left" />
      <main className="center">
        <Viewport />
      </main>
      <Resizer side="right" />
      <aside className="right">
        <RightPanel />
      </aside>
      <StatusBar />
      <HelpOverlay />
      <TemplatesModal />
      <SettingsModal />
      <ConfirmDialog />
      <Toasts />
      <SplashScreen />
    </div>
  )
}
