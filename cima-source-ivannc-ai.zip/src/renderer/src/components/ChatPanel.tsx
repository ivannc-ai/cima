import { useEffect, useLayoutEffect, useMemo, useRef, useState, type ClipboardEvent, type KeyboardEvent, type ReactNode } from 'react'
import type { AssistantMessage, ImageMediaType, ToolCall, ToolResult, UserMessage } from '@shared/ai/types'
import { EXAMPLES } from '@shared/model/examples'
import { useChat, type Notice, type PendingImage } from '../store/chat'
import { useModel, type UiVersion } from '../store/model'
import { activeProvider, providerReady, useSettings } from '../store/settings'
import { toast, useUi } from '../store/ui'
import { isAuditRepair, isModelTool, isNudgeMessage, isRepairMessage, resultKind, splitUserText, userText } from '../lib/agent'
import { AuditBadge, AuditList, problemCount } from './Audit'
import { loadExample } from '../lib/actions'
import { fmtBytes } from '../lib/params'
import { uid } from '../lib/labels'
import { Markdown } from './Markdown'
import { Icon } from './Icon'
import logoUrl from '../assets/logo.png'

const MAX_IMAGE_BYTES = 5 * 1024 * 1024
const IMAGE_TYPES: ImageMediaType[] = ['image/png', 'image/jpeg', 'image/webp']

/** Quick edit suggestions shown above the composer once a model exists. */
const EDIT_SUGGESTIONS = ['Aumenta el espesor un 20 %', 'Redondea las aristas exteriores', 'Añade un taladro pasante centrado']

function readImage(file: File): Promise<PendingImage> {
  return new Promise((resolve, reject) => {
    if (!IMAGE_TYPES.includes(file.type as ImageMediaType)) return reject(new Error(`Formato no admitido (${file.type || 'desconocido'}). Usa PNG, JPEG o WebP.`))
    if (file.size > MAX_IMAGE_BYTES) return reject(new Error(`La imagen supera 5 MB (${fmtBytes(file.size)}).`))
    const r = new FileReader()
    r.onerror = () => reject(new Error('No se pudo leer la imagen.'))
    r.onload = () => {
      const url = String(r.result)
      const comma = url.indexOf(',')
      resolve({ id: uid('img'), mediaType: file.type as ImageMediaType, data: url.slice(comma + 1), name: file.name || 'imagen', size: file.size })
    }
    r.readAsDataURL(file)
  })
}

// ---------------------------------------------------------------------------

function NoticeRow({ n }: { n: Notice }) {
  const retry = useChat((s) => s.retry)
  const busy = useChat((s) => s.busy)
  const dismiss = useChat((s) => s.dismissNotice)
  const openSettings = useUi((s) => s.setSettingsOpen)
  const icon = n.kind === 'error' ? 'error' : n.kind === 'info' ? 'info' : 'warn'
  return (
    <div className={`notice notice-${n.kind}`}>
      <Icon name={icon} />
      <div className="notice-body">
        <div className="notice-text">{n.text}</div>
        {(n.retry || n.openSettings) && (
          <div className="notice-actions">
            {n.retry && (
              <button className="btn btn-sm pill" disabled={busy} onClick={() => void retry()}>
                <Icon name="refresh" size={13} /> Reintentar
              </button>
            )}
            {n.openSettings && (
              <button className="btn btn-sm pill" onClick={() => openSettings(true)}>
                <Icon name="gear" size={13} /> Abrir ajustes
              </button>
            )}
          </div>
        )}
      </div>
      <button className="icon-btn ghost xs" data-tip="Descartar" aria-label="Descartar" onClick={() => dismiss(n.id)}>
        <Icon name="close" size={12} />
      </button>
    </div>
  )
}

function UserBubble({ msg }: { msg: UserMessage }) {
  const { text, hasModel } = splitUserText(userText(msg))
  const images = msg.content.filter((p) => p.type === 'image')
  return (
    <div className="msg msg-user">
      <div className="bubble">
        {images.length > 0 && (
          <div className="thumbs">
            {images.map((im, i) =>
              im.type === 'image' ? <img key={i} src={`data:${im.mediaType};base64,${im.data}`} alt={im.name ?? 'imagen'} title={im.name} /> : null,
            )}
          </div>
        )}
        {text && <div className="user-text">{text}</div>}
        {hasModel && (
          <div className="attach-chip" title="Se adjuntó el modelo actual (con los valores de los deslizadores) para que la IA lo modifique">
            <Icon name="cube" size={11} /> modelo actual adjunto
          </div>
        )}
      </div>
    </div>
  )
}

const KIND_LABEL: Record<ReturnType<typeof resultKind>, string> = {
  ok: 'Construido',
  invalid: 'Inválido',
  build_errors: 'Con errores',
  audit: 'Revisión',
  cancelled: 'Cancelado',
  other: 'Aviso',
  pending: 'Procesando…',
}

function ModelCard({ call, result, version, index }: { call: ToolCall; result?: ToolResult; version?: UiVersion; index: number }) {
  const currentId = useModel((s) => s.currentVersionId)
  const restore = useModel((s) => s.restoreVersion)
  const thumb = useModel((s) => (version ? s.thumbs[version.id] : undefined))
  const [open, setOpen] = useState(false)
  const [auditOpen, setAuditOpen] = useState(false)
  const kind = resultKind(result)
  if (!isModelTool(call.name)) {
    return (
      <div className="model-card card-other">
        <div className="model-card-row">
          <Icon name="warn" size={14} /> Herramienta desconocida: <code>{call.name}</code>
        </div>
      </div>
    )
  }
  const m = version?.model
  const nFeat = m?.parts.reduce((n, p) => n + p.features.length, 0) ?? 0
  const nParams = m ? m.parameters.length + m.parts.reduce((n, p) => n + p.parameters.length, 0) : 0
  const details = result && result.isError ? result.content.split('\n').slice(1).join('\n') : ''
  const active = !!version && currentId === version.id
  return (
    <div className={`model-card card-${kind} ${active ? 'active' : ''}`}>
      <div className="model-card-row">
        <div className="model-thumb">{thumb ? <img src={thumb} alt="" /> : <Icon name="cube" size={20} />}</div>
        <div className="model-card-main">
          <div className="model-card-title">
            <span className="ellipsis">{version ? m?.name : 'Modelo no válido'}</span>
            {version && <span className="v-badge">v{index}</span>}
          </div>
          {m ? (
            <div className="model-card-meta">
              {version?.note && <span className="card-note">{version.note} · </span>}
              {m.kind === 'assembly' ? `Ensamblaje · ${m.parts.length} piezas` : 'Pieza'} · {nFeat} operaciones · {nParams} parámetros
            </div>
          ) : (
            <div className="model-card-meta">La IA está corrigiendo el modelo</div>
          )}
          <div className="model-card-actions">
            {!(kind === 'audit' && version?.audit?.length) && <span className={`badge badge-${kind}`}>{KIND_LABEL[kind]}</span>}
            {version?.audit && <AuditBadge findings={version.audit} open={auditOpen} onToggle={() => setAuditOpen(!auditOpen)} />}
            <div className="spacer" />
            {details && (
              <button className="btn btn-xs ghost" onClick={() => setOpen(!open)}>
                Detalles <Icon name={open ? 'chevronDown' : 'chevron'} size={11} />
              </button>
            )}
            {version && (
              <button className="btn btn-xs pill" disabled={active} onClick={() => restore(version.id)}>
                {active ? 'Actual' : 'Restaurar'}
              </button>
            )}
          </div>
        </div>
      </div>
      {auditOpen && version?.audit && version.audit.length > 0 && (
        <div className="card-audit-list">
          <AuditList findings={version.audit} />
        </div>
      )}
      {open && details && <pre className="card-details">{details}</pre>}
    </div>
  )
}

function Thinking({ text, live }: { text: string; live?: boolean }) {
  const [open, setOpen] = useState(false)
  return (
    <div className={`thinking ${open ? 'open' : ''}`}>
      <button className="thinking-head" onClick={() => setOpen(!open)}>
        <Icon name="brain" size={13} /> {live ? 'Razonando…' : 'Razonamiento'}
        <Icon name={open ? 'chevronDown' : 'chevron'} size={11} />
      </button>
      {open && <div className="thinking-body">{text}</div>}
    </div>
  )
}

function AssistantShell({ children, live }: { children: ReactNode; live?: boolean }) {
  return (
    <div className={`msg msg-assistant ${live ? 'streaming' : ''}`}>
      <img className="avatar" src={logoUrl} alt="" />
      <div className="assistant-body">{children}</div>
    </div>
  )
}

function AssistantBlock({
  msg,
  results,
  versionFor,
}: {
  msg: AssistantMessage
  results: ToolResult[]
  versionFor: (tc: ToolCall) => { v?: UiVersion; index: number }
}) {
  const showThinking = useSettings((s) => s.settings.ai.showThinking)
  return (
    <AssistantShell>
      {showThinking && msg.thinking && <Thinking text={msg.thinking} />}
      {msg.text.trim() && <Markdown text={msg.text} />}
      {msg.toolCalls?.map((tc) => {
        const { v, index } = versionFor(tc)
        return <ModelCard key={tc.id} call={tc} result={results.find((r) => r.toolCallId === tc.id)} version={v} index={index} />
      })}
    </AssistantShell>
  )
}

function RepairRow({ msg }: { msg: UserMessage }) {
  const [open, setOpen] = useState(false)
  const r = msg.toolResults ?? []
  const n = r.reduce((acc, x) => acc + problemCount(x.content), 0)
  const audit = isAuditRepair(msg)
  const what = `${n} problema${n === 1 ? '' : 's'} enviado${n === 1 ? '' : 's'} a la IA`
  return (
    <div className="repair-row">
      <button className={`repair-head ${audit ? 'audit' : ''}`} onClick={() => setOpen(!open)}>
        <Icon name={audit ? 'shield' : 'refresh'} size={12} /> {audit ? `Auditoría: ${what}` : `Reparación automática · ${what}`}
        <Icon name={open ? 'chevronDown' : 'chevron'} size={11} />
      </button>
      {open && <pre className="card-details">{r.map((x) => x.content).join('\n\n')}</pre>}
    </div>
  )
}

function StreamingBlock() {
  const stream = useChat((s) => s.stream)
  const repairing = useChat((s) => s.repairing)
  const showThinking = useSettings((s) => s.settings.ai.showThinking)
  if (!stream) return null
  return (
    <AssistantShell live>
      {repairing > 0 && <div className="repair-tag">Reparación automática {repairing}</div>}
      {showThinking && stream.thinking && <Thinking text={stream.thinking} live={!stream.text && !stream.toolActive} />}
      {stream.text && <Markdown text={stream.text} />}
      {stream.toolActive ? (
        <div className="model-card active tool-progress">
          <div className="model-card-row">
            <div className="model-thumb building">
              <Icon name="cube" size={20} />
            </div>
            <div className="model-card-main">
              <div className="model-card-title">Construyendo CAD…</div>
              <div className="model-card-meta">{fmtBytes(stream.toolBytes)} recibidos</div>
              <div className="progress indeterminate">
                <div />
              </div>
            </div>
          </div>
        </div>
      ) : (
        !stream.text && (
          <div className="typing">
            <span />
            <span />
            <span />
          </div>
        )
      )}
    </AssistantShell>
  )
}

function EmptyState() {
  const provider = useSettings((s) => activeProvider(s.settings))
  const ready = providerReady(provider)
  const openSettings = useUi((s) => s.setSettingsOpen)
  const insertPrompt = useUi((s) => s.insertPrompt)
  const openTemplates = useUi((s) => s.setTemplatesOpen)
  return (
    <div className="chat-empty">
      <img className="empty-logo" src={logoUrl} alt="" />
      <h1>¿Qué diseñamos hoy?</h1>
      <p className="muted">Describe una pieza o un ensamblaje. CIMA genera un modelo paramétrico, lo previsualiza y lo envía a CATIA.</p>
      {!ready && (
        <div className="demo-banner">
          <Icon name="info" size={14} />
          <span>
            Sin clave API para <strong>{provider?.label ?? 'el proveedor'}</strong>. Carga un ejemplo para probar el visor y CATIA.
          </span>
          <button className="btn btn-xs pill" onClick={() => openSettings(true)}>
            Configurar
          </button>
        </div>
      )}
      {ready && (
        <div className="pills">
          {EXAMPLES.map((ex) => (
            <button key={ex.id} className="pill-btn" onClick={() => insertPrompt(ex.prompt)} title={ex.prompt}>
              {ex.prompt}
            </button>
          ))}
        </div>
      )}
      <div className="section-label">{ready ? 'O empieza desde un ejemplo o una plantilla' : 'Ejemplos y plantillas'}</div>
      <div className="pills">
        <button className="pill-btn template-pill" onClick={() => openTemplates(true)}>
          <Icon name="layers" size={12} />
          Plantillas paramétricas
        </button>
        {EXAMPLES.map((ex) => (
          <button key={ex.id} className="pill-btn example" onClick={() => loadExample(ex.id)} title={ex.prompt}>
            <Icon name="cube" size={12} />
            {ex.title}
          </button>
        ))}
      </div>
    </div>
  )
}

function ModelSelect() {
  const settings = useSettings((s) => s.settings)
  const update = useSettings((s) => s.update)
  const provider = activeProvider(settings)
  const value = provider ? `${provider.id}::${provider.model}` : ''
  return (
    <label className="model-select" data-tip={provider ? `${provider.label} · ${provider.model}` : 'Proveedor de IA'} data-tip-pos="top">
      <Icon name="brain" size={13} />
      <span className="model-select-text">{provider?.model || 'Elegir modelo'}</span>
      <Icon name="chevronDown" size={11} />
      <select
        value={value}
        onChange={(e) => {
          const [id, model] = e.target.value.split('::')
          if (!id) return
          void update({ activeProviderId: id, providers: model ? [{ id, model }] : undefined })
        }}
      >
        {settings.providers
          .filter((p) => p.enabled)
          .map((p) => (
            <optgroup key={p.id} label={`${p.label}${p.requiresApiKey && !p.hasApiKey ? ' (sin clave)' : ''}`}>
              {[...new Set([p.model, ...p.models].filter(Boolean))].map((m) => (
                <option key={m} value={`${p.id}::${m}`}>
                  {m}
                </option>
              ))}
            </optgroup>
          ))}
      </select>
    </label>
  )
}

function Composer() {
  const busy = useChat((s) => s.busy)
  const send = useChat((s) => s.send)
  const stop = useChat((s) => s.stop)
  const draft = useUi((s) => s.draft)
  const setDraft = useUi((s) => s.setDraft)
  const focusTick = useUi((s) => s.focusTick)
  const [images, setImages] = useState<PendingImage[]>([])
  const fileRef = useRef<HTMLInputElement>(null)
  const taRef = useRef<HTMLTextAreaElement>(null)

  useLayoutEffect(() => {
    const ta = taRef.current
    if (!ta) return
    ta.style.height = 'auto'
    ta.style.height = `${Math.min(ta.scrollHeight, 220)}px`
  }, [draft])

  useEffect(() => {
    if (!focusTick) return
    const ta = taRef.current
    if (!ta) return
    ta.focus()
    ta.setSelectionRange(ta.value.length, ta.value.length)
  }, [focusTick])

  const addFiles = async (files: Iterable<File>) => {
    for (const f of files) {
      try {
        const img = await readImage(f)
        setImages((cur) => (cur.length >= 6 ? cur : [...cur, img]))
      } catch (e) {
        toast('error', (e as Error).message)
      }
    }
  }

  const submit = async () => {
    if (busy || (!draft.trim() && !images.length)) return
    const text = draft
    const imgs = images
    setDraft('')
    setImages([])
    const ok = await send(text, imgs)
    if (!ok) {
      setDraft(text)
      setImages(imgs)
      taRef.current?.focus()
    }
  }

  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault()
      void submit()
    }
  }

  const onPaste = (e: ClipboardEvent<HTMLTextAreaElement>) => {
    const files = [...e.clipboardData.files].filter((f) => f.type.startsWith('image/'))
    if (files.length) {
      e.preventDefault()
      void addFiles(files)
    }
  }

  return (
    <div className="composer">
      {images.length > 0 && (
        <div className="composer-images">
          {images.map((im) => (
            <div key={im.id} className="composer-thumb" title={`${im.name} · ${fmtBytes(im.size)}`}>
              <img src={`data:${im.mediaType};base64,${im.data}`} alt={im.name} />
              <button className="thumb-remove" onClick={() => setImages(images.filter((x) => x.id !== im.id))} aria-label="Quitar">
                <Icon name="close" size={10} />
              </button>
            </div>
          ))}
        </div>
      )}
      <textarea
        ref={taRef}
        value={draft}
        rows={2}
        placeholder="Describe la pieza o el cambio…"
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={onKey}
        onPaste={onPaste}
      />
      <div className="composer-bar">
        <button className="icon-btn ghost" data-tip="Adjuntar imagen (PNG, JPEG, WebP ≤ 5 MB)" data-tip-pos="top" onClick={() => fileRef.current?.click()}>
          <Icon name="image" />
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/png,image/jpeg,image/webp"
          multiple
          hidden
          onChange={(e) => {
            if (e.target.files) void addFiles([...e.target.files])
            e.target.value = ''
          }}
        />
        <span className="composer-hint">Intro envía · Mayús+Intro nueva línea</span>
        <div className="spacer" />
        <ModelSelect />
        {busy ? (
          <button className="send-btn stop" onClick={stop} data-tip="Detener" data-tip-pos="top" aria-label="Detener">
            <Icon name="stop" size={13} />
          </button>
        ) : (
          <button
            className="send-btn"
            disabled={!draft.trim() && !images.length}
            onClick={() => void submit()}
            data-tip="Enviar (Intro)"
            data-tip-pos="top"
            aria-label="Enviar"
          >
            <Icon name="arrowUp" size={15} />
          </button>
        )}
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------

function countLabel(n: number): string {
  return n === 0 ? '' : n === 1 ? '1 mensaje' : `${n} mensajes`
}

export function ChatPanel() {
  const messages = useChat((s) => s.messages)
  const pending = useChat((s) => s.pendingToolResults)
  const notices = useChat((s) => s.notices)
  const stream = useChat((s) => s.stream)
  const busy = useChat((s) => s.busy)
  const versions = useModel((s) => s.versions)
  const hasModel = useModel((s) => !!s.model)
  const insertPrompt = useUi((s) => s.insertPrompt)
  const listRef = useRef<HTMLDivElement>(null)
  const stick = useRef(true)

  const versionFor = useMemo(() => {
    const byCall = new Map<string, { v: UiVersion; index: number }>()
    versions.forEach((v, i) => {
      if (v.toolCallId) byCall.set(v.toolCallId, { v, index: i + 1 })
    })
    return (tc: ToolCall) => byCall.get(tc.id) ?? { index: 0 }
  }, [versions])

  const items = useMemo(() => {
    const out: ReactNode[] = []
    const noticesAt = (i: number) => notices.filter((n) => n.afterIndex === i).map((n) => <NoticeRow key={n.id} n={n} />)
    messages.forEach((m, i) => {
      out.push(...noticesAt(i))
      if (m.role === 'user') {
        out.push(
          isRepairMessage(m) ? (
            <RepairRow key={i} msg={m} />
          ) : isNudgeMessage(m) ? (
            <div key={i} className="repair-row">
              <span className="repair-head">
                <Icon name="refresh" size={12} /> La IA no entregó el modelo: CIMA se lo ha pedido automáticamente
              </span>
            </div>
          ) : (
            <UserBubble key={i} msg={m} />
          ),
        )
      } else {
        const next = messages[i + 1]
        const results = next && next.role === 'user' ? (next.toolResults ?? []) : i === messages.length - 1 ? pending : []
        out.push(<AssistantBlock key={i} msg={m} results={results} versionFor={versionFor} />)
      }
    })
    out.push(...notices.filter((n) => n.afterIndex >= messages.length).map((n) => <NoticeRow key={n.id} n={n} />))
    return out
  }, [messages, notices, pending, versionFor])

  useEffect(() => {
    const el = listRef.current
    if (el && stick.current) el.scrollTop = el.scrollHeight
  }, [items, stream])

  const empty = messages.length === 0 && !stream
  return (
    <div className="chat-panel">
      <div className="panel-header">
        <span className="panel-title">Asistente</span>
        <span className="muted small">
          {countLabel(messages.filter((m) => m.role === 'user' && !isRepairMessage(m) && !isNudgeMessage(m)).length)}
        </span>
      </div>
      <div
        className={`chat-list ${empty ? 'is-empty' : ''}`}
        ref={listRef}
        onScroll={(e) => {
          const el = e.currentTarget
          stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 60
        }}
      >
        {empty && <EmptyState />}
        {items}
        <StreamingBlock />
      </div>
      {hasModel && !busy && messages.length > 0 && (
        <div className="suggestions">
          {EDIT_SUGGESTIONS.map((s) => (
            <button key={s} className="pill-btn sm" onClick={() => insertPrompt(s)}>
              {s}
            </button>
          ))}
        </div>
      )}
      <Composer />
    </div>
  )
}
