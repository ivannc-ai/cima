import { useModel } from '../store/model'
import { useCatia } from '../store/catia'
import { activeProvider, providerReady, useSettings } from '../store/settings'
import { useChat } from '../store/chat'
import { useUi } from '../store/ui'
import { isMock } from '../lib/bridge'

export function StatusBar() {
  const kernelState = useModel((s) => s.kernelState)
  const build = useModel((s) => s.build)
  const model = useModel((s) => s.model)
  const status = useCatia((s) => s.status)
  const job = useCatia((s) => s.jobId)
  const provider = useSettings((s) => activeProvider(s.settings))
  const busy = useChat((s) => s.busy)
  const setTab = useUi((s) => s.setRightTab)
  const openSettings = useUi((s) => s.setSettingsOpen)

  let kernel: { tone: string; text: string }
  if (kernelState === 'starting') kernel = { tone: 'busy', text: 'Motor: iniciando…' }
  else if (kernelState === 'error') kernel = { tone: 'error', text: 'Motor: error' }
  else if (build.status === 'building') kernel = { tone: 'busy', text: 'Motor: construyendo…' }
  else if (build.status === 'error') kernel = { tone: 'error', text: 'Motor: error de construcción' }
  else if (build.result && model) {
    const nErr = build.result.parts.reduce((n, p) => n + p.features.filter((f) => f.status === 'error').length, 0)
    kernel = {
      tone: nErr ? 'warn' : 'ok',
      text: `Motor: ${Math.round(build.result.durationMs)} ms${nErr ? ` · ${nErr} error${nErr === 1 ? '' : 'es'}` : ''}`,
    }
  } else kernel = { tone: 'ok', text: 'Motor listo' }

  let catia: { tone: string; text: string }
  if (job) catia = { tone: 'busy', text: 'CATIA: enviando…' }
  else if (!status) catia = { tone: 'muted', text: 'CATIA: comprobando…' }
  else if (!status.platformSupported) catia = { tone: 'muted', text: 'CATIA: no disponible' }
  else if (status.running) catia = { tone: 'ok', text: `CATIA ${status.target === '3dx' ? '3DEXPERIENCE' : 'V5'}${status.version ? ` · ${status.version}` : ''}` }
  else catia = { tone: 'warn', text: 'CATIA no detectado' }

  const ready = providerReady(provider)
  return (
    <footer className="statusbar">
      <span className="sb-item">
        <span className={`dot dot-${kernel.tone}`} />
        {kernel.text}
      </span>
      <button className="sb-item sb-btn" onClick={() => setTab('catia')}>
        <span className={`dot dot-${catia.tone}`} />
        {catia.text}
      </button>
      <div className="spacer" />
      {isMock && <span className="sb-item muted">Modo navegador (simulado)</span>}
      <button className="sb-item sb-btn" onClick={() => openSettings(true)}>
        <span className={`dot dot-${busy ? 'busy' : ready ? 'ok' : 'warn'}`} />
        {provider ? `${provider.label} · ${provider.model || '—'}` : 'Sin proveedor'}
        {!ready && provider && ' · sin clave'}
      </button>
    </footer>
  )
}
