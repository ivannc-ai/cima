import { useEffect, useMemo, useRef, useState } from 'react'
import { Viewer, type Projection, type ViewName } from '../viewer/Viewer'
import { useModel } from '../store/model'
import { useSettings } from '../store/settings'
import { useChat } from '../store/chat'
import { PALETTE, featureLabel } from '../lib/labels'
import { placedBounds } from '../lib/bounds'
import { fmt } from '../lib/params'
import { Icon } from './Icon'

const VIEWS: Array<{ id: ViewName; label: string; key: string }> = [
  { id: 'iso', label: 'Iso', key: '0' },
  { id: 'front', label: 'Frente', key: '1' },
  { id: 'top', label: 'Superior', key: '2' },
  { id: 'right', label: 'Derecha', key: '3' },
]

function loadProjection(): Projection {
  try {
    return localStorage.getItem('cima.projection') === 'persp' ? 'persp' : 'ortho'
  } catch {
    return 'ortho'
  }
}

export function Viewport() {
  const hostRef = useRef<HTMLDivElement>(null)
  const viewerRef = useRef<Viewer | null>(null)
  const lastModelKey = useRef<string | null>(null)
  const model = useModel((s) => s.model)
  const build = useModel((s) => s.build)
  const kernelState = useModel((s) => s.kernelState)
  const kernelError = useModel((s) => s.kernelError)
  const selected = useModel((s) => s.selectedInstance)
  const select = useModel((s) => s.select)
  const currentVersionId = useModel((s) => s.currentVersionId)
  const viewerSettings = useSettings((s) => s.settings.viewer)
  const updateSettings = useSettings((s) => s.update)
  const busy = useChat((s) => s.busy)
  const [errorsOpen, setErrorsOpen] = useState(true)
  const [projection, setProjection] = useState<Projection>(loadProjection)

  // Create / dispose the three.js viewer.
  useEffect(() => {
    const host = hostRef.current
    if (!host) return
    const v = new Viewer(host)
    v.setProjection(loadProjection())
    viewerRef.current = v
    v.onSelect = (id) => useModel.getState().select(id)
    return () => {
      v.dispose()
      viewerRef.current = null
      lastModelKey.current = null
    }
  }, [])

  // Push the build result to the viewer (fit on first load or when another model is loaded).
  const result = build.result
  const forModel = build.forModel
  const hasModel = !!model
  useEffect(() => {
    const v = viewerRef.current
    if (!v) return
    if (!hasModel) {
      v.setBuild(null, new Map(), false)
      lastModelKey.current = null
      return
    }
    if (!result || !forModel) return
    const colors = new Map<string, string>()
    forModel.parts.forEach((p, i) => colors.set(p.id, p.color ?? PALETTE[i % PALETTE.length]!))
    const key = `${forModel.name}|${forModel.parts.map((p) => p.id).join(',')}`
    const fit = lastModelKey.current !== key
    lastModelKey.current = key
    v.setBuild(result, colors, fit)
    setErrorsOpen(true)
    // Thumbnail for the version card (only for the unmodified version geometry).
    const st = useModel.getState()
    const vid = st.currentVersionId
    if (vid && !st.thumbs[vid] && Object.keys(st.overrides).length === 0 && st.model === forModel) {
      requestAnimationFrame(() => {
        const url = viewerRef.current?.snapshot()
        if (url) useModel.getState().setThumb(vid, url)
      })
    }
  }, [result, forModel, hasModel])

  useEffect(() => {
    viewerRef.current?.setOptions({ edges: viewerSettings.showEdges, grid: viewerSettings.showGrid, axes: viewerSettings.showAxes })
  }, [viewerSettings.showEdges, viewerSettings.showGrid, viewerSettings.showAxes])

  useEffect(() => {
    viewerRef.current?.setSelected(selected)
  }, [selected, result])

  // Keyboard: F = fit, 0-3 = standard views (when not typing).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null
      if (e.ctrlKey || e.altKey || e.metaKey || (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)))
        return
      if (e.key === 'f' || e.key === 'F') viewerRef.current?.fit()
      const v = VIEWS.find((x) => x.key === e.key)
      if (v) viewerRef.current?.view(v.id)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const changeProjection = (p: Projection) => {
    viewerRef.current?.setProjection(p)
    setProjection(p)
    try {
      localStorage.setItem('cima.projection', p)
    } catch {
      /* storage unavailable */
    }
  }

  const failures = useMemo(() => {
    if (!result) return []
    const out: Array<{ key: string; text: string; detail?: string }> = []
    for (const p of result.parts) {
      for (const f of p.features) {
        if (f.status === 'error') out.push({ key: `${p.partId}/${f.id}`, text: `${p.partId} / ${f.name ?? f.id} (${featureLabel(f.type)})`, detail: f.message })
      }
      if (p.error && !p.features.some((f) => f.status === 'error')) out.push({ key: p.partId, text: p.partId, detail: p.error })
    }
    result.errors.forEach((e, i) => out.push({ key: `e${i}`, text: e }))
    return out
  }, [result])

  const bounds = useMemo(() => (result && hasModel ? placedBounds(result) : null), [result, hasModel])

  const selectedPlacement = result?.placements.find((p) => p.instanceId === selected)
  const selectedPart = selectedPlacement ? model?.parts.find((p) => p.id === selectedPlacement.partId) : undefined
  const isAssembly = model?.kind === 'assembly'
  const versionNo = useModel((s) => (currentVersionId ? s.versions.findIndex((v) => v.id === currentVersionId) + 1 : 0))

  const toggle = (k: 'showEdges' | 'showGrid' | 'showAxes') => void updateSettings({ viewer: { [k]: !viewerSettings[k] } })

  const firstBuild = !!model && !result && (build.status === 'building' || build.status === 'idle') && kernelState !== 'error'

  return (
    <div className="viewport">
      <div className="viewport-host" ref={hostRef} />

      <div className="viewport-toolbar">
        <div className="seg seg-floating">
          {VIEWS.map((v) => (
            <button key={v.id} onClick={() => viewerRef.current?.view(v.id)} data-tip={`Vista ${v.label} (${v.key})`}>
              {v.label}
            </button>
          ))}
        </div>
        <div className="seg seg-floating">
          <button onClick={() => viewerRef.current?.fit()} data-tip="Encuadrar (F)">
            <Icon name="fit" />
          </button>
        </div>
        <div className="seg seg-floating">
          <button className={viewerSettings.showEdges ? 'on' : ''} onClick={() => toggle('showEdges')} data-tip="Aristas">
            <Icon name="edges" />
          </button>
          <button className={viewerSettings.showGrid ? 'on' : ''} onClick={() => toggle('showGrid')} data-tip="Rejilla">
            <Icon name="grid" />
          </button>
          <button className={viewerSettings.showAxes ? 'on' : ''} onClick={() => toggle('showAxes')} data-tip="Triedro de ejes" data-tip-pos="bottom-end">
            <Icon name="axes" />
          </button>
        </div>
      </div>

      <div className="projection-switch seg seg-floating seg-xs">
        <button className={projection === 'ortho' ? 'on' : ''} onClick={() => changeProjection('ortho')} data-tip="Proyección ortográfica" data-tip-pos="top">
          Orto
        </button>
        <button className={projection === 'persp' ? 'on' : ''} onClick={() => changeProjection('persp')} data-tip="Proyección en perspectiva" data-tip-pos="top">
          Persp
        </button>
      </div>

      {model && (
        <div className="viewport-title">
          <div className="vt-name">
            {model.name}
            {versionNo > 0 && <span className="v-badge">v{versionNo}</span>}
          </div>
          <div className="vt-meta">
            {isAssembly ? `Ensamblaje · ${model.instances?.length ?? 0} instancias` : 'Pieza'}
            {build.status === 'building' && result && <span className="vt-building"> · actualizando…</span>}
          </div>
        </div>
      )}

      {bounds && (
        <div className={`bbox-chip ${viewerSettings.showAxes ? '' : 'no-triad'}`} data-tip="Dimensiones de la caja envolvente" data-tip-pos="top">
          <Icon name="cube" size={13} />
          <span className="mono">
            {fmt(bounds.max[0] - bounds.min[0], 1)} × {fmt(bounds.max[1] - bounds.min[1], 1)} × {fmt(bounds.max[2] - bounds.min[2], 1)}
          </span>
          <span className="muted">mm</span>
        </div>
      )}

      {selectedPlacement && (
        <div className="selection-chip">
          <span className="swatch" style={{ background: selectedPlacement.color ?? selectedPart?.color ?? '#9aa7b8' }} />
          <span>
            <strong>{selectedPlacement.name || selectedPlacement.instanceId}</strong>
            {isAssembly && selectedPart && <span className="muted"> · {selectedPart.name}</span>}
          </span>
          <button className="icon-btn ghost xs" onClick={() => select(null)} data-tip="Quitar selección" aria-label="Quitar selección">
            <Icon name="close" size={12} />
          </button>
        </div>
      )}

      {!model && (
        <div className="viewport-empty">
          <div className="empty-ring">
            <Icon name="cube" size={30} />
          </div>
          <div>Describe una pieza en el chat o carga un ejemplo</div>
          {busy && <div className="muted small">La IA está generando el modelo…</div>}
        </div>
      )}

      {(firstBuild || (kernelState === 'starting' && !!model && !result)) && (
        <div className="viewport-overlay">
          <div className="spinner" />
          <div>{kernelState === 'starting' ? 'Iniciando motor geométrico…' : 'Construyendo CAD…'}</div>
        </div>
      )}

      {(kernelState === 'error' || build.status === 'error') && (
        <div className="viewport-overlay error">
          <Icon name="error" size={28} />
          <div>{kernelState === 'error' ? 'El motor geométrico no se pudo iniciar' : 'Error al construir el modelo'}</div>
          <div className="muted small mono">{kernelError ?? build.error}</div>
        </div>
      )}

      {failures.length > 0 && (
        <div className="build-errors">
          <button className="build-errors-head" onClick={() => setErrorsOpen(!errorsOpen)}>
            <Icon name="warn" size={14} /> {failures.length} operación{failures.length === 1 ? '' : 'es'} con errores
            <Icon name={errorsOpen ? 'chevronDown' : 'chevron'} size={12} />
          </button>
          {errorsOpen && (
            <ul>
              {failures.map((f) => (
                <li key={f.key}>
                  <strong>{f.text}</strong>
                  {f.detail && <div className="muted">{f.detail}</div>}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  )
}
