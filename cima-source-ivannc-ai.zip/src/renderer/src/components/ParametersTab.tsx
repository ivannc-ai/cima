import { useEffect, useMemo, useState } from 'react'
import { resolveModelParameters, type ResolvedParameter } from '@shared/model/evaluate'
import { useModel } from '../store/model'
import { fmt, sliderRange, unitLabel } from '../lib/params'
import { Icon } from './Icon'
import { Section } from './Section'

function NumberInput({ value, onCommit }: { value: number; onCommit: (v: number) => void }) {
  const [text, setText] = useState(fmt(value, 4))
  useEffect(() => setText(fmt(value, 4)), [value])
  const commit = () => {
    const v = Number(text.replace(',', '.'))
    if (Number.isFinite(v) && text.trim() !== '') onCommit(v)
    else setText(fmt(value, 4))
  }
  return (
    <input
      className="num-input"
      value={text}
      onChange={(e) => setText(e.target.value)}
      onBlur={commit}
      onFocus={(e) => e.target.select()}
      onKeyDown={(e) => {
        if (e.key === 'Enter') (e.target as HTMLInputElement).blur()
        if (e.key === 'Escape') setText(fmt(value, 4))
      }}
    />
  )
}

function ParamLabel({ p }: { p: ResolvedParameter }) {
  const title = [p.name, p.def.description, p.scope === 'part' ? `Clave: ${p.key}` : undefined].filter(Boolean).join('\n')
  return (
    <div className="param-label" title={title}>
      <span className="param-desc">{p.def.description || p.name}</span>
      {p.def.description && <span className="param-name">{p.name}</span>}
    </div>
  )
}

function ParamRow({ p, overridden }: { p: ResolvedParameter; overridden: boolean }) {
  const setOverride = useModel((s) => s.setOverride)
  const resetOverride = useModel((s) => s.resetOverride)
  const range = sliderRange(p.def, p.value)
  const unit = unitLabel(p.unit)
  if (p.derived) {
    return (
      <div className="param-row derived">
        <ParamLabel p={p} />
        <div className="param-expr mono" title={`= ${p.def.expression}`}>
          = {p.def.expression}
        </div>
        <span className="param-value mono">{fmt(p.value)}</span>
        <span className="unit">{unit}</span>
        <span />
      </div>
    )
  }
  const clamped = Math.min(range.max, Math.max(range.min, p.value))
  const pct = ((clamped - range.min) / (range.max - range.min)) * 100
  return (
    <div className={`param-row ${overridden ? 'modified' : ''}`}>
      <ParamLabel p={p} />
      <input
        type="range"
        min={range.min}
        max={range.max}
        step={range.step}
        value={clamped}
        style={{ ['--pct' as string]: `${pct}%` }}
        onChange={(e) => setOverride(p.key, Number(e.target.value))}
      />
      <NumberInput value={p.value} onCommit={(v) => setOverride(p.key, v)} />
      <span className="unit">{unit}</span>
      {overridden ? (
        <button className="icon-btn ghost xs reset" data-tip={`Restablecer (${fmt(p.def.value)})`} aria-label="Restablecer" onClick={() => resetOverride(p.key)}>
          <Icon name="reset" size={12} />
        </button>
      ) : (
        <span />
      )}
    </div>
  )
}

export function ParametersTab() {
  const model = useModel((s) => s.model)
  const overrides = useModel((s) => s.overrides)
  const resetOverrides = useModel((s) => s.resetOverrides)
  const applyDefaults = useModel((s) => s.applyDefaults)
  const res = useMemo(() => (model ? resolveModelParameters(model, overrides) : null), [model, overrides])
  if (!model || !res) return <div className="tab-empty">No hay modelo. Pide uno en el chat o carga un ejemplo.</div>

  const groups: Array<{ id: string; title: string; params: ResolvedParameter[] }> = []
  const modelParams = res.params.filter((p) => p.scope === 'model')
  if (modelParams.length) groups.push({ id: '_model', title: model.kind === 'assembly' ? 'Ensamblaje' : 'Modelo', params: modelParams })
  for (const part of model.parts) {
    const ps = res.params.filter((p) => p.partId === part.id)
    if (ps.length) groups.push({ id: part.id, title: part.name, params: ps })
  }
  const nOverrides = Object.keys(overrides).length

  return (
    <div className="params-tab">
      {res.errors.length > 0 && (
        <div className="inline-error">
          {res.errors.map((e, i) => (
            <div key={i}>{e}</div>
          ))}
        </div>
      )}
      {groups.length === 0 && <div className="tab-empty">Este modelo no tiene parámetros.</div>}
      {groups.map((g) => (
        <Section key={g.id} title={g.title} count={g.params.length}>
          {g.params.map((p) => (
            <ParamRow key={p.key} p={p} overridden={overrides[p.key] !== undefined && overrides[p.key] !== p.def.value} />
          ))}
        </Section>
      ))}
      <div className="panel-footer">
        <button className="btn btn-sm" disabled={!nOverrides} onClick={resetOverrides} data-tip="Volver a los valores del modelo" data-tip-pos="top">
          <Icon name="reset" size={13} /> Restablecer todo
        </button>
        <button
          className="btn btn-sm btn-primary grow"
          disabled={!nOverrides}
          onClick={applyDefaults}
          data-tip="Aplicar como valores por defecto (nueva versión)"
          data-tip-pos="top"
        >
          <Icon name="check" size={13} /> Aplicar por defecto
        </button>
      </div>
    </div>
  )
}
