import { useEffect, useRef } from 'react'

/**
 * Clickable color swatch backed by a native color picker. The color is committed when the picker
 * closes (native "change" event), not on every drag step. Right click resets to the default color.
 */
export function ColorSwatch({
  color,
  onPick,
  onReset,
  title,
  size = 14,
}: {
  color: string
  onPick: (hex: string) => void
  onReset?: () => void
  title?: string
  size?: number
}) {
  const ref = useRef<HTMLInputElement>(null)
  const pick = useRef(onPick)
  pick.current = onPick

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const onChange = () => pick.current(el.value)
    el.addEventListener('change', onChange)
    return () => el.removeEventListener('change', onChange)
  }, [])

  useEffect(() => {
    if (ref.current && ref.current.value.toLowerCase() !== color.toLowerCase()) ref.current.value = color
  }, [color])

  return (
    <label
      className="color-swatch"
      style={{ width: size, height: size, background: color }}
      data-tip={title ?? 'Cambiar color (clic derecho: color por defecto)'}
      onClick={(e) => e.stopPropagation()}
      onContextMenu={(e) => {
        e.preventDefault()
        e.stopPropagation()
        onReset?.()
      }}
    >
      <input ref={ref} type="color" defaultValue={color} aria-label={title ?? 'Color'} />
    </label>
  )
}
