import { useEffect, type ReactNode } from 'react'
import { Icon } from './Icon'
import { useUi } from '../store/ui'

export function Modal({
  title,
  onClose,
  children,
  footer,
  wide,
}: {
  title: string
  onClose: () => void
  children: ReactNode
  footer?: ReactNode
  wide?: boolean
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])
  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-label={title}>
        <div className="modal-head">
          <span>{title}</span>
          <button className="icon-btn ghost" onClick={onClose} title="Cerrar">
            <Icon name="close" />
          </button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  )
}

export function ConfirmDialog() {
  const c = useUi((s) => s.confirm)
  const close = useUi((s) => s.closeConfirm)
  if (!c) return null
  return (
    <Modal
      title={c.title}
      onClose={() => close(false)}
      footer={
        <>
          <button className="btn" onClick={() => close(false)}>
            Cancelar
          </button>
          <button className={`btn ${c.danger ? 'btn-danger' : 'btn-primary'}`} autoFocus onClick={() => close(true)}>
            {c.okLabel}
          </button>
        </>
      }
    >
      <p>{c.message}</p>
    </Modal>
  )
}

export function Toasts() {
  const toasts = useUi((s) => s.toasts)
  const dismiss = useUi((s) => s.dismissToast)
  return (
    <div className="toasts">
      {toasts.map((t) => (
        <div key={t.id} className={`toast toast-${t.kind}`}>
          <Icon name={t.kind === 'success' ? 'check' : t.kind === 'error' ? 'error' : t.kind === 'warning' ? 'warn' : 'info'} />
          <span className="toast-text">{t.text}</span>
          {t.action && (
            <button
              className="btn btn-sm ghost"
              onClick={() => {
                t.action!.run()
                dismiss(t.id)
              }}
            >
              {t.action.label}
            </button>
          )}
          <button className="icon-btn ghost xs" onClick={() => dismiss(t.id)}>
            <Icon name="close" size={12} />
          </button>
        </div>
      ))}
    </div>
  )
}
