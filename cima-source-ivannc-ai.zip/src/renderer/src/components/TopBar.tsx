import { useEffect, useRef, useState } from 'react'
import { useModel } from '../store/model'
import { useSettings } from '../store/settings'
import { useCatia } from '../store/catia'
import { useUi } from '../store/ui'
import { exportAs, newProject, openProject, saveProject, type ExportKind } from '../lib/actions'
import { Icon } from './Icon'
import { AirbusLogo, BRAND_TAGLINE } from '../branding/Brand'
import logoUrl from '../assets/logo.png'

const EXPORTS: Array<{ kind: ExportKind; label: string; ext: string; hint: string }> = [
  { kind: 'step', label: 'STEP', ext: '.step', hint: 'Sólido B-rep para cualquier CAD' },
  { kind: 'stl', label: 'STL', ext: '.stl', hint: 'Malla para impresión 3D' },
  { kind: 'catscript', label: 'Macro de CATIA (VBScript)', ext: '.catvbs', hint: 'Se ejecuta dentro de CATIA' },
  { kind: 'vbs', label: 'Script VBS', ext: '.vbs', hint: 'Script externo (cscript)' },
  { kind: 'json', label: 'Modelo JSON', ext: '.json', hint: 'Modelo paramétrico CIMA' },
]

function ExportMenu() {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const hasModel = useModel((s) => !!s.model)
  const settings = useSettings((s) => s.settings)
  const status = useCatia((s) => s.status)
  useEffect(() => {
    if (!open) return
    const onDown = (e: MouseEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false)
    }
    window.addEventListener('mousedown', onDown)
    return () => window.removeEventListener('mousedown', onDown)
  }, [open])
  return (
    <div className="menu-wrap" ref={ref}>
      <button className="btn btn-sm pill" disabled={!hasModel} onClick={() => setOpen(!open)}>
        <Icon name="export" size={14} /> Exportar <Icon name="chevronDown" size={11} />
      </button>
      {open && (
        <div className="menu">
          {EXPORTS.map((x) => (
            <button
              key={x.kind}
              onClick={() => {
                setOpen(false)
                void exportAs(x.kind, settings, status)
              }}
            >
              <span className="menu-main">
                <span>{x.label}</span>
                <span className="muted small">{x.hint}</span>
              </span>
              <span className="menu-ext mono">{x.ext}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

export function TopBar() {
  const name = useModel((s) => s.projectName)
  const dirty = useModel((s) => s.dirty)
  const setName = useModel((s) => s.setProjectName)
  const openSettings = useUi((s) => s.setSettingsOpen)
  const openHelp = useUi((s) => s.setHelpOpen)
  const openTemplates = useUi((s) => s.setTemplatesOpen)
  return (
    <header className="topbar">
      <div className="logo">
        <img src={logoUrl} alt="" />
        <div className="logo-text">
          <span>CIMA</span>
          <span className="logo-tagline">{BRAND_TAGLINE}</span>
        </div>
      </div>
      <div className="project-name">
        <input value={name} onChange={(e) => setName(e.target.value)} spellCheck={false} aria-label="Nombre del proyecto" />
        {dirty && <span className="dirty-dot" data-tip="Cambios sin guardar" />}
      </div>
      <div className="tb-group">
        <button className="tb-btn icon" onClick={() => void newProject()} data-tip="Nuevo (Ctrl+N)" aria-label="Nuevo">
          <Icon name="plus" />
        </button>
        <button className="tb-btn icon" onClick={() => void openProject()} data-tip="Abrir (Ctrl+O)" aria-label="Abrir">
          <Icon name="open" />
        </button>
        <button className="tb-btn icon" onClick={() => void saveProject(false)} data-tip="Guardar (Ctrl+S)" aria-label="Guardar">
          <Icon name="save" />
        </button>
        <button className="tb-btn icon" onClick={() => void saveProject(true)} data-tip="Guardar como (Ctrl+Mayús+S)" aria-label="Guardar como">
          <Icon name="saveAs" />
        </button>
      </div>
      <button className="btn btn-sm pill" onClick={() => openTemplates(true)} data-tip="Crear un modelo desde una plantilla paramétrica">
        <Icon name="layers" size={14} /> Plantillas
      </button>
      <ExportMenu />
      <div className="spacer" />
      <div className="topbar-brand" title="Airbus Defence & Space · Métodos, Procesos y Herramientas CAD">
        <AirbusLogo height={16} />
      </div>
      <button className="tb-btn icon" onClick={() => openHelp(true)} data-tip="Ayuda (F1)" data-tip-pos="bottom-end" aria-label="Ayuda">
        <Icon name="help" />
      </button>
      <button className="tb-btn icon" onClick={() => openSettings(true)} data-tip="Ajustes" data-tip-pos="bottom-end" aria-label="Ajustes">
        <Icon name="gear" />
      </button>
    </header>
  )
}
