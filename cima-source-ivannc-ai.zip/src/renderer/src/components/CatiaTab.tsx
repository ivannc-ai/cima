import { useEffect, useMemo, useState } from 'react'
import type { CatiaScriptOptions } from '@shared/catia/types'
import type { CatiaStartModel } from '@shared/catia/types'
import { resolveModelParameters } from '@shared/model/evaluate'
import { useCatia } from '../store/catia'
import { useModel } from '../store/model'
import { useSettings } from '../store/settings'
import { toast } from '../store/ui'
import { cima } from '../lib/bridge'
import { catiaOptions, exportAs } from '../lib/actions'
import { errorText } from '../lib/labels'
import { fmt } from '../lib/params'
import { Icon } from './Icon'
import { Modal } from './Modal'
import { Section } from './Section'

function StatusCard() {
  const status = useCatia((s) => s.status)
  const checking = useCatia((s) => s.checking)
  const statusError = useCatia((s) => s.statusError)
  const refresh = useCatia((s) => s.refresh)

  let tone = 'muted'
  let title = 'Comprobando CATIA…'
  let hint: string | null = null
  if (statusError) {
    tone = 'error'
    title = 'No se pudo comprobar CATIA'
    hint = statusError
  } else if (status) {
    if (!status.platformSupported) {
      tone = 'warn'
      title = 'Plataforma no compatible'
      hint = 'La conexión con CATIA solo funciona en Windows. Puedes exportar la macro y ejecutarla en un equipo con CATIA.'
    } else if (status.running) {
      tone = 'ok'
      title = `Conectado a ${status.target === '3dx' ? '3DEXPERIENCE' : 'CATIA V5'}`
      hint = status.version ?? null
    } else {
      tone = 'warn'
      title = 'CATIA no detectado'
      hint = 'Abre CATIA V5 o 3DEXPERIENCE y pulsa Actualizar, o elige «Iniciar CATIA» en Conexión.'
    }
    if (status.platformSupported && !status.cscriptAvailable) hint = `${hint ? `${hint} · ` : ''}cscript.exe no disponible.`
    if (status.error && !status.running) hint = `${hint ? `${hint} · ` : ''}${status.error}`
  }
  return (
    <div className={`status-card tone-${tone}`}>
      <span className={`dot dot-${tone}`} />
      <div className="status-main">
        <div className="status-title">{title}</div>
        {hint && <div className="muted small">{hint}</div>}
        {status?.activeDocument && (
          <div className="small">
            Documento activo: <strong>{status.activeDocument.name}</strong> <span className="muted">({status.activeDocument.type})</span>
          </div>
        )}
        {status?.running && (status.docPath || status.program || status.user || status.host) && (
          <div className="small muted catia-session-info">
            {status.docPath && <div className="ellipsis" title={status.docPath}>{status.docPath}</div>}
            {(status.program || status.department || status.user || status.host) && (
              <div>
                {status.program && <>Programa: <strong>{status.program}</strong></>}
                {status.department && <> · {status.department}</>}
                {(status.user || status.host) && <> · {status.user ?? '—'}@{status.host ?? '—'}</>}
              </div>
            )}
          </div>
        )}
      </div>
      <button className="icon-btn ghost" onClick={() => void refresh()} disabled={checking} data-tip="Actualizar estado" aria-label="Actualizar estado">
        <Icon name="refresh" className={checking ? 'spin' : ''} />
      </button>
    </div>
  )
}

function Options() {
  const c = useSettings((s) => s.settings.catia)
  const update = useSettings((s) => s.update)
  const set = (patch: Partial<typeof c>) => void update({ catia: patch })
  const chooseDir = async () => {
    try {
      const d = await cima.settings.chooseDirectory('Carpeta de guardado de CATIA')
      if (d) set({ saveDirectory: d })
    } catch (e) {
      toast('error', errorText(e))
    }
  }
  return (
    <div className="form-grid">
      <label>Destino</label>
      <select value={c.target} onChange={(e) => set({ target: e.target.value as typeof c.target })}>
        <option value="auto">Automático (detectar)</option>
        <option value="v5">CATIA V5</option>
        <option value="3dx">3DEXPERIENCE</option>
      </select>
      <label>Conexión</label>
      <select value={c.connect} onChange={(e) => set({ connect: e.target.value as typeof c.connect })}>
        <option value="attach">Adjuntar a la sesión abierta</option>
        <option value="launch">Iniciar CATIA si no está abierto</option>
      </select>
      <div className="form-span checks">
        <label className="check">
          <input type="checkbox" checked={c.createParameters} onChange={(e) => set({ createParameters: e.target.checked })} />
          Crear parámetros de usuario
        </label>
        <label className={`check ${!c.createParameters ? 'disabled' : ''}`}>
          <input
            type="checkbox"
            disabled={!c.createParameters}
            checked={c.createFormulas && c.createParameters}
            onChange={(e) => set({ createFormulas: e.target.checked })}
          />
          Fórmulas (cotas ligadas a parámetros)
        </label>
        <label className="check">
          <input type="checkbox" checked={c.applyColors} onChange={(e) => set({ applyColors: e.target.checked })} />
          Aplicar colores
        </label>
      </div>
      <label>Guardar en</label>
      <div className="dir-picker">
        <span className={`dir-path ${c.saveDirectory ? 'rtl' : 'muted'}`} title={c.saveDirectory}>
          {c.saveDirectory || 'Sin guardar (solo crear en CATIA)'}
        </span>
        <button className="btn btn-sm" onClick={() => void chooseDir()}>
          <Icon name="folder" size={14} />
        </button>
        {c.saveDirectory && (
          <button className="btn btn-sm ghost" onClick={() => set({ saveDirectory: '' })} title="No guardar">
            <Icon name="close" size={12} />
          </button>
        )}
      </div>
      <div className="form-span checks">
        <label className={`check ${!c.saveDirectory ? 'disabled' : ''}`}>
          <input type="checkbox" disabled={!c.saveDirectory} checked={c.exportStep} onChange={(e) => set({ exportStep: e.target.checked })} />
          Exportar también STEP (V5)
        </label>
      </div>
    </div>
  )
}

function StartModelSelect() {
  const kind = useModel((s) => s.model?.kind ?? 'part')
  const program = useCatia((s) => s.status?.program ?? null)
  const status = useCatia((s) => s.status)
  const startModel = useCatia((s) => s.startModel)
  const setStartModel = useCatia((s) => s.setStartModel)
  const startModelName = useCatia((s) => s.startModelName)
  const setStartModelName = useCatia((s) => s.setStartModelName)
  const [catalog, setCatalog] = useState<{ models: CatiaStartModel[]; error?: string } | null>(null)

  useEffect(() => {
    if (!status?.running) return
    let alive = true
    const release = /R(\d+)/i.exec(status.version ?? '')?.[1] ?? null
    cima.catia
      .listStartModels(program, release)
      .then((c) => alive && setCatalog(c))
      .catch(() => alive && setCatalog({ models: [] }))
    return () => {
      alive = false
    }
  }, [status?.running, status?.version, program])

  const wanted = kind === 'assembly' ? 'product' : 'part'
  const models = (catalog?.models ?? []).filter((m) => m.type === wanted)
  const valid = startModel && models.some((m) => m.path === startModel) ? startModel : null
  const type = startModel && /\.catproduct$/i.test(startModel) ? 'product' : startModel ? 'part' : null

  return (
    <Section title="Modelo de inicio" defaultOpen={false}>
      <div className="form-grid">
        <label>{wanted === 'product' ? 'Plantilla CATProduct' : 'Plantilla CATPart'}</label>
        <select
          value={valid ?? ''}
          onChange={(e) => setStartModel(e.target.value || null)}
          disabled={models.length === 0}
          title={startModel ?? ''}
        >
          <option value="">{models.length === 0 ? 'Sin plantillas disponibles' : 'Ninguno (documento vacío)'}</option>
          {models.map((m) => (
            <option key={m.path} value={m.path}>
              {m.name}
            </option>
          ))}
        </select>
        {catalog && models.length === 0 && (
          <p className="muted small form-span">
            {catalog.error ??
              `Sin plantillas en la carpeta de modelos de ${program ?? 'tu programa'} (o CATIA no está conectado).`}
          </p>
        )}
        {startModel && (
          <>
            <label>Nombre del {kind === 'assembly' ? 'Product' : 'Part'}</label>
            <input
              type="text"
              value={startModelName}
              onChange={(e) => setStartModelName(e.target.value)}
              placeholder={`${type === 'product' ? 'Product' : 'Part'} (vacío = nombre del modelo CIMA)`}
              spellCheck={false}
            />
            <p className="muted small form-span">
              Se usa como PartNumber del {type === 'product' ? 'CATProduct' : 'CATPart'} en CATIA y como nombre de
              archivo al guardar.
            </p>
          </>
        )}
      </div>
    </Section>
  )
}

function ScriptModal({ onClose }: { onClose: () => void }) {
  const model = useModel((s) => s.model)
  const overrides = useModel((s) => s.overrides)
  const settings = useSettings((s) => s.settings)
  const status = useCatia((s) => s.status)
  const startModel = useCatia((s) => s.startModel)
  const startModelName = useCatia((s) => s.startModelName)
  const [flavor, setFlavor] = useState<CatiaScriptOptions['flavor']>('vbs')
  const [script, setScript] = useState<string>('')
  const [error, setError] = useState<string | null>(null)
  useEffect(() => {
    if (!model) return
    let alive = true
    setError(null)
    cima.catia
      .generateScript({ model, overrides, options: catiaOptions(settings, status, flavor, startModel, startModelName) })
      .then((s) => alive && setScript(s))
      .catch((e) => alive && setError(errorText(e)))
    return () => {
      alive = false
    }
  }, [model, overrides, settings, status, flavor, startModel, startModelName])
  return (
    <Modal
      title="Script de CATIA"
      wide
      onClose={onClose}
      footer={
        <>
          <div className="seg">
            <button className={flavor === 'vbs' ? 'on' : ''} onClick={() => setFlavor('vbs')}>
              VBScript (.vbs)
            </button>
            <button className={flavor === 'catscript' ? 'on' : ''} onClick={() => setFlavor('catscript')}>
              Macro CATIA (.catvbs)
            </button>
          </div>
          <div className="spacer" />
          <span className="muted small">{script ? `${script.split('\n').length} líneas` : ''}</span>
          <button
            className="btn"
            disabled={!script}
            onClick={() =>
              void navigator.clipboard.writeText(script).then(
                () => toast('success', 'Script copiado.'),
                () => toast('error', 'No se pudo copiar.'),
              )
            }
          >
            <Icon name="copy" size={14} /> Copiar
          </button>
        </>
      }
    >
      {error ? <div className="inline-error">{error}</div> : <pre className="script-view mono">{script || 'Generando…'}</pre>}
    </Modal>
  )
}

function Inspector() {
  const model = useModel((s) => s.model)
  const overrides = useModel((s) => s.overrides)
  const inspection = useCatia((s) => s.inspection)
  const inspecting = useCatia((s) => s.inspecting)
  const inspect = useCatia((s) => s.inspect)
  const sendValues = useCatia((s) => s.sendValues)

  const matches = useMemo(() => {
    if (!inspection?.ok || !model) return new Map<string, number>()
    const res = resolveModelParameters(model, overrides)
    const byName = new Map<string, number>()
    for (const p of res.params) if (!p.derived && !byName.has(p.name)) byName.set(p.name, p.value)
    const out = new Map<string, number>()
    for (const cp of inspection.parameters) {
      const short = cp.name.split(/[\\/]/).pop() ?? cp.name
      const v = byName.get(short)
      if (v !== undefined && cp.numeric !== undefined) out.set(cp.name, v)
    }
    return out
  }, [inspection, model, overrides])

  const diffs = [...matches].filter(([name, v]) => {
    const cp = inspection?.parameters.find((p) => p.name === name)
    return cp?.numeric === undefined || Math.abs(cp.numeric - v) > 1e-9
  })

  return (
    <Section title="Documento activo" count={inspection?.ok ? inspection.parameters.length : undefined} defaultOpen={false}>
      <button className="btn btn-sm" onClick={() => void inspect()} disabled={inspecting}>
        <Icon name="refresh" size={13} className={inspecting ? 'spin' : ''} /> Leer documento activo
      </button>
      {inspection && !inspection.ok && <div className="inline-error">{inspection.error ?? 'No se pudo leer el documento.'}</div>}
      {inspection?.ok && (
        <>
          <div className="small">
            <strong>{inspection.documentName}</strong> <span className="muted">{inspection.documentType}</span> ·{' '}
            {inspection.parameters.length} parámetros
          </div>
          <div className="param-table-wrap">
            <table className="param-table">
              <thead>
                <tr>
                  <th>Parámetro</th>
                  <th>CATIA</th>
                  <th>CIMA</th>
                </tr>
              </thead>
              <tbody>
                {inspection.parameters
                  .filter((p) => p.userParameter || matches.has(p.name))
                  .concat(inspection.parameters.filter((p) => !p.userParameter && !matches.has(p.name)).slice(0, 60))
                  .map((p) => {
                    const v = matches.get(p.name)
                    const differs = v !== undefined && (p.numeric === undefined || Math.abs(p.numeric - v) > 1e-9)
                    return (
                      <tr key={p.name} className={v !== undefined ? (differs ? 'differs' : 'match') : ''}>
                        <td className="mono ellipsis" title={p.name}>
                          {p.name}
                        </td>
                        <td className="mono">{p.value}</td>
                        <td className="mono">{v !== undefined ? fmt(v) : ''}</td>
                      </tr>
                    )
                  })}
              </tbody>
            </table>
          </div>
          <button
            className="btn btn-sm btn-primary"
            disabled={!diffs.length}
            onClick={() => void sendValues(diffs.map(([name, value]) => ({ name, value })))}
            title="Envía a CATIA los valores de los parámetros con el mismo nombre"
          >
            <Icon name="send" size={14} /> Enviar valores ({diffs.length})
          </button>
        </>
      )}
    </Section>
  )
}

export function CatiaTab() {
  const model = useModel((s) => s.model)
  const status = useCatia((s) => s.status)
  const jobId = useCatia((s) => s.jobId)
  const log = useCatia((s) => s.log)
  const result = useCatia((s) => s.result)
  const push = useCatia((s) => s.push)
  const cancel = useCatia((s) => s.cancel)
  const clearLog = useCatia((s) => s.clearLog)
  const refresh = useCatia((s) => s.refresh)
  const settings = useSettings((s) => s.settings)
  const [showScript, setShowScript] = useState(false)

  useEffect(() => {
    if (!status) void refresh()
  }, [status, refresh])

  const canPush = !!model && !jobId && status?.platformSupported !== false
  const failed = result?.features.filter((f) => f.status === 'error') ?? []

  return (
    <div className="catia-tab">
      <StatusCard />
      <Section title="Opciones de envío">
        <Options />
      </Section>
      <StartModelSelect />

      <div className="push-row">
        {jobId ? (
          <>
            <button className="btn btn-big" disabled>
              <span className="spinner sm" /> Enviando a CATIA…
            </button>
            <button className="btn btn-danger" onClick={cancel}>
              <Icon name="stop" size={14} /> Cancelar
            </button>
          </>
        ) : (
          <button className="btn btn-big btn-primary" disabled={!canPush} onClick={() => void push()}>
            <Icon name="bolt" /> Enviar a CATIA
          </button>
        )}
      </div>
      <div className="btn-row">
        <button className="btn btn-sm pill" disabled={!model} onClick={() => setShowScript(true)}>
          <Icon name="code" size={13} /> Ver script
        </button>
        <button className="btn btn-sm pill" disabled={!model} onClick={() => void exportAs('catscript', settings, status)} data-tip="Macro para ejecutar dentro de CATIA">
          <Icon name="download" size={13} /> .catvbs
        </button>
        <button className="btn btn-sm pill" disabled={!model} onClick={() => void exportAs('vbs', settings, status)} data-tip="Script externo (cscript)">
          <Icon name="download" size={13} /> .vbs
        </button>
      </div>

      {(log.length > 0 || result) && (
        <Section
          title="Registro"
          count={log.length}
          actions={
            !jobId && (
              <button className="icon-btn ghost xs" onClick={clearLog} data-tip="Limpiar registro" aria-label="Limpiar registro">
                <Icon name="trash" size={12} />
              </button>
            )
          }
        >
          {result && (
            <div className={`result-summary ${result.ok ? 'ok' : 'error'}`}>
              <Icon name={result.ok ? 'check' : 'error'} />
              <div>
                <strong>{result.ok ? 'Modelo creado en CATIA' : result.cancelled ? 'Cancelado' : 'Terminado con errores'}</strong>
                <div className="small muted">
                  {result.features.filter((f) => f.status === 'ok').length} operaciones correctas · {failed.length} con error ·{' '}
                  {(result.durationMs / 1000).toFixed(1)} s
                </div>
                {failed.map((f) => (
                  <div key={`${f.part}/${f.feature}`} className="small feat-error">
                    {f.part}/{f.feature}: {f.msg ?? 'error'}
                  </div>
                ))}
                {result.errors.map((e, i) => (
                  <div key={i} className="small feat-error">
                    {e}
                  </div>
                ))}
                {result.savedFiles.map((p) => (
                  <button key={p} className="link-btn small" onClick={() => void cima.app.showItemInFolder(p)}>
                    <Icon name="folder" size={12} /> {p}
                  </button>
                ))}
              </div>
            </div>
          )}
          <div className="log mono">
            {log.map((l) => (
              <div key={l.id} className={`log-line log-${l.level}`}>
                {l.text}
              </div>
            ))}
          </div>
        </Section>
      )}

      <Inspector />
      {showScript && <ScriptModal onClose={() => setShowScript(false)} />}
    </div>
  )
}
