import { memo, useMemo, type ReactNode } from 'react'
import { parseMarkdown, type Inline } from '../lib/markdown'

function inlines(nodes: Inline[], key = ''): ReactNode[] {
  return nodes.map((n, i) => {
    const k = `${key}${i}`
    switch (n.t) {
      case 'text':
        return n.v
      case 'bold':
        return <strong key={k}>{inlines(n.c, k)}</strong>
      case 'italic':
        return <em key={k}>{inlines(n.c, k)}</em>
      case 'code':
        return <code key={k}>{n.v}</code>
      case 'link':
        return (
          <span key={k} className="md-link" title={n.href}>
            {n.text}
          </span>
        )
    }
  })
}

export const Markdown = memo(function Markdown({ text }: { text: string }) {
  const blocks = useMemo(() => parseMarkdown(text), [text])
  return (
    <div className="md">
      {blocks.map((b, i) => {
        switch (b.t) {
          case 'p':
            return <p key={i}>{inlines(b.c)}</p>
          case 'h':
            return (
              <p key={i} className={`md-h md-h${Math.min(b.level, 3)}`}>
                {inlines(b.c)}
              </p>
            )
          case 'code':
            return (
              <pre key={i} className="md-pre">
                <code>{b.v}</code>
              </pre>
            )
          case 'ul':
            return (
              <ul key={i}>
                {b.items.map((it, j) => (
                  <li key={j}>{inlines(it)}</li>
                ))}
              </ul>
            )
          case 'ol':
            return (
              <ol key={i} start={b.start}>
                {b.items.map((it, j) => (
                  <li key={j}>{inlines(it)}</li>
                ))}
              </ol>
            )
          case 'hr':
            return <hr key={i} />
        }
      })}
    </div>
  )
})
