import { useUi, type RightTab } from '../store/ui'
import { useModel } from '../store/model'
import { useCatia } from '../store/catia'
import { ParametersTab } from './ParametersTab'
import { TreeTab } from './TreeTab'
import { CatiaTab } from './CatiaTab'
import { JsonTab } from './JsonTab'
import { Icon } from './Icon'

const TABS: Array<{ id: RightTab; label: string; icon: string }> = [
  { id: 'params', label: 'Parámetros', icon: 'sliders' },
  { id: 'tree', label: 'Árbol', icon: 'tree' },
  { id: 'catia', label: 'CATIA', icon: 'bolt' },
  { id: 'json', label: 'JSON', icon: 'braces' },
]

export function RightPanel() {
  const tab = useUi((s) => s.rightTab)
  const setTab = useUi((s) => s.setRightTab)
  const nOverrides = useModel((s) => Object.keys(s.overrides).length)
  const hasErrors = useModel((s) => s.build.result?.parts.some((p) => p.features.some((f) => f.status === 'error')) ?? false)
  const jobRunning = useCatia((s) => !!s.jobId)
  return (
    <div className="right-panel">
      <div className="tabs">
        {TABS.map((t) => (
          <button key={t.id} className={`tab ${tab === t.id ? 'on' : ''}`} onClick={() => setTab(t.id)}>
            <Icon name={t.icon} size={14} />
            {t.label}
            {t.id === 'params' && nOverrides > 0 && <span className="tab-badge">{nOverrides}</span>}
            {t.id === 'tree' && hasErrors && <span className="tab-dot error" />}
            {t.id === 'catia' && jobRunning && <span className="tab-dot busy" />}
          </button>
        ))}
      </div>
      <div className="tab-body">
        {tab === 'params' && <ParametersTab />}
        {tab === 'tree' && <TreeTab />}
        {tab === 'catia' && <CatiaTab />}
        {tab === 'json' && <JsonTab />}
      </div>
    </div>
  )
}
