import { useMemo, useState } from 'react'
import { TEMPLATES, type CadTemplate, type TemplateParam, type TemplateValue } from '@shared/templates'
import { useUi } from '../store/ui'
import { createFromTemplate } from '../lib/actions'
import { CATEGORY_ORDER, templateIcon, templateSubtitle } from '../lib/templateInfo'
import { fmt } from '../lib/params'
import { Icon } from './Icon'
import { Modal } from './Modal'

const UNIT: Record<TemplateParam['kind'], string> = { length: 'mm', angle: '°', count: 'uds', bool: '', enum: '' }

function defaults(t: CadTemplate): Record<string, TemplateValue> {
  return Object.fromEntries(t.params.map((p) => [p.name, p.default]))
}

function ParamField({ p, value, onChange }: { p: TemplateParam; value: TemplateValue; onChange: (v: TemplateValue) => void }) {
  if (p.kind === 'bool') {
    return (
      <label className="tpl-field tpl-check" title={p.description}>
        <input type="checkbox" checked={value === true} onChange={(e) => onChange(e.target.checked)} />
        <span>{p.label}</span>
      </label>
    )
  }
  if (p.kind === 'enum') {
    return (
      <label className="tpl-field" title={p.description}>
        <span className="tpl-label">{p.label}</span>
        <select value={String(value)} onChange={(e) => onChange(e.target.value)}>
          {(p.options ?? []).map((o) => (
            <option key={o} value={o}>
              {o}
            </option>
          ))}
        </select>
      </label>
    )
  }
  const n = Number(value)
  const min = p.min ?? 0
  const max = p.max ?? Math.max(10, n * 3)
  const pct = ((Math.min(max, Math.max(min, n)) - min) / (max - min || 1)) * 100
  return (
    <div className="tpl-field" title={p.description}>
      <div className="tpl-label-row">
        <span className="tpl-label">{p.label}</span>
        <span className="muted small mono">
          {fmt(min)}–{fmt(max)} {UNIT[p.kind]}
        </span>
      </div>
      <div className="tpl-input-row">
        <input
          type="range"
          min={min}
          max={max}
          step={p.step ?? (p.kind === 'count' ? 1 : 0.5)}
          value={Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : min}
          style={{ ['--pct' as string]: `${pct}%` }}
          onChange={(e) => onChange(Number(e.target.value))}
        />
        <input
          type="number"
          className="num-input"
          value={Number.isFinite(n) ? n : ''}
          min={min}
          max={max}
          step={p.step ?? (p.kind === 'count' ? 1 : 0.5)}
          onChange={(e) => onChange(e.target.value === '' ? p.default : Number(e.target.value))}
        />
        <span className="unit">{UNIT[p.kind]}</span>
      </div>
    </div>
  )
}

function TemplateForm({ t, onBack, onDone }: { t: CadTemplate; onBack: () => void; onDone: () => void }) {
  const [values, setValues] = useState<Record<string, TemplateValue>>(() => defaults(t))
  const [name, setName] = useState(t.title.replace(/[^\p{L}\p{N}]+/gu, '_'))
  const structural = t.params.filter((p) => p.structural || p.kind === 'bool' || p.kind === 'enum')
  const numeric = t.params.filter((p) => !structural.includes(p))
  const create = () => {
    if (createFromTemplate(t, values, name)) onDone()
  }
  return (
    <div className="tpl-form">
      <div className="tpl-form-head">
        <button className="btn btn-sm ghost" onClick={onBack}>
          <Icon name="chevron" size={12} className="flip" /> Plantillas
        </button>
        <div className="tpl-form-title">
          <span className="tpl-icon">
            <Icon name={templateIcon(t)} size={18} />
          </span>
          <div>
            <strong>{t.title}</strong>
            <div className="muted small">{templateSubtitle(t)}</div>
          </div>
        </div>
      </div>
      <label className="tpl-field tpl-name">
        <span className="tpl-label">Nombre del modelo</span>
        <input value={name} onChange={(e) => setName(e.target.value)} spellCheck={false} />
      </label>
      {structural.length > 0 && (
        <div className="tpl-group">
          <div className="tpl-group-title">Opciones</div>
          <div className="tpl-grid">
            {structural.map((p) => (
              <ParamField key={p.name} p={p} value={values[p.name] ?? p.default} onChange={(v) => setValues({ ...values, [p.name]: v })} />
            ))}
          </div>
        </div>
      )}
      <div className="tpl-group">
        <div className="tpl-group-title">
          Dimensiones <span className="count">{numeric.length}</span>
          <div className="spacer" />
          <button className="btn btn-xs ghost" onClick={() => setValues(defaults(t))}>
            <Icon name="reset" size={11} /> Valores por defecto
          </button>
        </div>
        <div className="tpl-grid">
          {numeric.map((p) => (
            <ParamField key={p.name} p={p} value={values[p.name] ?? p.default} onChange={(v) => setValues({ ...values, [p.name]: v })} />
          ))}
        </div>
      </div>
      <div className="tpl-actions">
        <span className="muted small">Las dimensiones se convierten en parámetros editables (deslizadores y parámetros de CATIA).</span>
        <div className="spacer" />
        <button className="btn" onClick={onBack}>
          Cancelar
        </button>
        <button className="btn btn-primary" onClick={create}>
          <Icon name="check" size={14} /> Crear
        </button>
      </div>
    </div>
  )
}

export function TemplatesModal() {
  const open = useUi((s) => s.templatesOpen)
  const setOpen = useUi((s) => s.setTemplatesOpen)
  const [selected, setSelected] = useState<string | null>(null)
  const [query, setQuery] = useState('')
  const groups = useMemo(() => {
    const q = query.trim().toLowerCase()
    const list = TEMPLATES.filter(
      (t) => !q || t.title.toLowerCase().includes(q) || t.keywords.some((k) => k.toLowerCase().includes(q)) || templateSubtitle(t).toLowerCase().includes(q),
    )
    return CATEGORY_ORDER.map((c) => ({ category: c, items: list.filter((t) => t.category === c) })).filter((g) => g.items.length)
  }, [query])
  if (!open) return null
  const close = () => {
    setOpen(false)
    setSelected(null)
  }
  const t = selected ? TEMPLATES.find((x) => x.id === selected) : undefined
  return (
    <Modal title="Plantillas paramétricas" wide onClose={close}>
      {t ? (
        <TemplateForm key={t.id} t={t} onBack={() => setSelected(null)} onDone={close} />
      ) : (
        <div className="tpl-gallery">
          <div className="tpl-intro">
            <p className="muted">
              Modelos probados que se generan al instante a partir de unas pocas medidas, sin IA. La IA también las usa cuando encajan con tu
              petición.
            </p>
            <input className="tpl-search" placeholder="Buscar (brida, eje, caja…)" value={query} onChange={(e) => setQuery(e.target.value)} autoFocus />
          </div>
          {groups.map((g) => (
            <section key={g.category} className="tpl-category">
              <div className="tpl-group-title">
                {g.category} <span className="count">{g.items.length}</span>
              </div>
              <div className="tpl-cards">
                {g.items.map((x) => (
                  <button key={x.id} className="tpl-card" onClick={() => setSelected(x.id)}>
                    <span className="tpl-icon">
                      <Icon name={templateIcon(x)} size={18} />
                    </span>
                    <span className="tpl-card-text">
                      <strong>{x.title}</strong>
                      <span className="muted small">{templateSubtitle(x)}</span>
                      <span className="tpl-card-meta">{x.params.length} parámetros</span>
                    </span>
                  </button>
                ))}
              </div>
            </section>
          ))}
          {groups.length === 0 && <div className="tab-empty">No hay plantillas que coincidan.</div>}
        </div>
      )}
    </Modal>
  )
}
