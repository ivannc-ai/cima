import { useState, type ReactNode } from 'react'
import { Icon } from './Icon'

/** Collapsible panel section with a count badge (e.g. "Brida (7)"). */
export function Section({
  title,
  count,
  actions,
  children,
  defaultOpen = true,
  className,
}: {
  title: ReactNode
  count?: number
  actions?: ReactNode
  children: ReactNode
  defaultOpen?: boolean
  className?: string
}) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <section className={`section ${open ? 'open' : 'closed'} ${className ?? ''}`}>
      <div className="section-head">
        <button className="section-toggle" onClick={() => setOpen(!open)} aria-expanded={open}>
          <Icon name={open ? 'chevronDown' : 'chevron'} size={12} />
          <span className="section-title">{title}</span>
          {count !== undefined && <span className="count">{count}</span>}
        </button>
        {actions && <div className="section-actions">{actions}</div>}
      </div>
      {open && <div className="section-body">{children}</div>}
    </section>
  )
}
