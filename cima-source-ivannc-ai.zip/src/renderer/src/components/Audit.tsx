import type { AuditFinding } from '../kernel/protocol'
import { Icon } from './Icon'

const SEVERITY_ICON = { error: 'error', warning: 'warn', info: 'info' } as const

/** List of audit findings (Spanish messages). */
export function AuditList({ findings }: { findings: ReadonlyArray<AuditFinding> }) {
  return (
    <ul className="audit-list">
      {findings.map((f, i) => (
        <li key={i} className={`audit-item sev-${f.severity}`}>
          <Icon name={SEVERITY_ICON[f.severity]} size={13} />
          <span>
            {f.part && <strong>{f.part}: </strong>}
            {f.message}
            {f.fix && <span className="tag tag-warn">enviado a la IA</span>}
          </span>
        </li>
      ))}
    </ul>
  )
}

/** Compact "Auditoría OK" / "N avisos" badge; the caller renders <AuditList> when open. */
export function AuditBadge({ findings, open, onToggle }: { findings: ReadonlyArray<AuditFinding>; open: boolean; onToggle: () => void }) {
  if (!findings.length) {
    return (
      <span className="badge badge-ok audit-badge" data-tip="Cumple la petición y no hay problemas geométricos" data-tip-pos="top">
        <Icon name="check" size={11} /> Auditoría OK
      </span>
    )
  }
  const severe = findings.some((f) => f.severity === 'error')
  return (
    <button className={`badge audit-badge ${severe ? 'badge-invalid' : 'badge-build_errors'}`} onClick={onToggle} data-tip="Auditoría del modelo frente a la petición" data-tip-pos="top">
      <Icon name="warn" size={11} /> {findings.length} aviso{findings.length === 1 ? '' : 's'}
      <Icon name={open ? 'chevronDown' : 'chevron'} size={10} />
    </button>
  )
}

/** Number of "- " problem lines of a tool result (before any "Notes:" block). */
export function problemCount(content: string): number {
  let n = 0
  for (const line of content.split('\n').slice(1)) {
    if (line === 'Notes:') break
    if (line.startsWith('- ')) n++
  }
  return n
}
