import { useEffect, useState } from 'react'
import { useModel } from '../store/model'
import { useChat } from '../store/chat'
import { kernel } from '../kernel/client'
import type { AuditFinding } from '../kernel/protocol'
import { lastUserRequest } from '../lib/agent'
import { errorText } from '../lib/labels'
import { toast } from '../store/ui'
import { AuditList } from './Audit'
import { FEATURE_GLYPHS, PALETTE, featureLabel } from '../lib/labels'
import { fmtVolume } from '../lib/params'
import type { FeatureType } from '@shared/model/schema'
import { Icon } from './Icon'
import { Section } from './Section'
import { ColorSwatch } from './ColorSwatch'

const SOURCE_LABEL = { ai: 'IA', user: 'Edición', example: 'Ejemplo', import: 'Importado' } as const

export function TreeTab() {
  const model = useModel((s) => s.model)
  const result = useModel((s) => s.build.result)
  const selected = useModel((s) => s.selectedInstance)
  const select = useModel((s) => s.select)
  const toggleSuppress = useModel((s) => s.toggleSuppress)
  const setColor = useModel((s) => s.setColor)
  const versions = useModel((s) => s.versions)
  const thumbs = useModel((s) => s.thumbs)
  const currentVersionId = useModel((s) => s.currentVersionId)
  const restore = useModel((s) => s.restoreVersion)
  const overrides = useModel((s) => s.overrides)
  const [audit, setAudit] = useState<{ findings: AuditFinding[]; request: string } | null>(null)
  const [auditing, setAuditing] = useState(false)

  // A manual audit belongs to the model it was run on.
  useEffect(() => setAudit(null), [model, overrides])

  if (!model) return <div className="tab-empty">No hay modelo.</div>

  const runAudit = async () => {
    setAuditing(true)
    try {
      const request = lastUserRequest(useChat.getState().messages)
      const findings = await kernel.audit(model, overrides, request || undefined)
      setAudit({ findings, request })
    } catch (e) {
      toast('error', `No se pudo auditar el modelo: ${errorText(e)}`)
    } finally {
      setAuditing(false)
    }
  }

  const placements = result?.placements ?? []
  return (
    <div className="tree-tab">
      <div className="tree-root">
        <ColorSwatch
          color={model.parts[0]?.color ?? PALETTE[0]!}
          onPick={(c) => setColor({ kind: 'model' }, c)}
          onReset={() => setColor({ kind: 'model' }, null)}
          title={model.kind === 'assembly' ? 'Color de todo el ensamblaje (clic derecho: colores por defecto)' : 'Color de la pieza (clic derecho: color por defecto)'}
          size={16}
        />
        <strong className="ellipsis">{model.name}</strong>
        <span className="tag">{model.kind === 'assembly' ? 'Ensamblaje' : 'Pieza'}</span>
        <div className="spacer" />
        <button
          className="btn btn-xs pill"
          disabled={auditing}
          onClick={() => void runAudit()}
          data-tip="Comprueba medidas pedidas, taladros y geometría"
          data-tip-pos="bottom-end"
        >
          {auditing ? <span className="spinner sm" /> : <Icon name="shield" size={12} />} Auditar
        </button>
      </div>
      {audit && (
        <Section
          title="Auditoría"
          count={audit.findings.length}
          actions={
            <button className="icon-btn ghost xs" onClick={() => setAudit(null)} data-tip="Cerrar" data-tip-pos="bottom-end" aria-label="Cerrar">
              <Icon name="close" size={12} />
            </button>
          }
          className="audit-section"
        >
          <div className="muted small">
            {audit.request ? `Frente a la petición: «${audit.request.length > 120 ? `${audit.request.slice(0, 120)}…` : audit.request}»` : 'Sin petición de referencia: solo comprobaciones geométricas.'}
          </div>
          {audit.findings.length ? (
            <AuditList findings={audit.findings} />
          ) : (
            <div className="audit-ok">
              <Icon name="check" size={13} />{' '}
              {audit.request ? 'Sin problemas: el modelo cumple las medidas pedidas y su geometría es coherente.' : 'Sin problemas geométricos.'}
            </div>
          )}
        </Section>
      )}
      {model.parts.map((part, pi) => {
        const built = result?.parts.find((p) => p.partId === part.id)
        const firstInstance = placements.find((p) => p.partId === part.id)?.instanceId
        const isSel = placements.some((p) => p.partId === part.id && p.instanceId === selected)
        return (
          <Section
            key={part.id}
            className={isSel ? 'selected' : ''}
            title={
              <span className="part-title">
                <ColorSwatch
                  color={part.color ?? PALETTE[pi % PALETTE.length]!}
                  onPick={(c) => setColor({ kind: 'part', id: part.id }, c)}
                  onReset={() => setColor({ kind: 'part', id: part.id }, null)}
                  title={
                    model.kind === 'assembly'
                      ? 'Color de la pieza en todas sus instancias (clic derecho: por defecto)'
                      : 'Color de la pieza (clic derecho: color por defecto)'
                  }
                />
                {part.name}
              </span>
            }
            count={part.features.length}
            actions={
              <>
                <span className="muted small" data-tip="Volumen">
                  {fmtVolume(built?.volume)}
                </span>
                <button className="icon-btn ghost xs" data-tip="Seleccionar en la vista" data-tip-pos="bottom-end" aria-label="Seleccionar" onClick={() => select(firstInstance ?? null)}>
                  <Icon name="fit" size={12} />
                </button>
              </>
            }
          >
            {part.material && <div className="tree-sub muted small">Material: {part.material}</div>}
            <ul className="feature-list">
              {part.features.map((f) => {
                const st = built?.features.find((x) => x.id === f.id)
                const status = f.suppressed ? 'suppressed' : (st?.status ?? 'pending')
                return (
                  <li key={f.id} className={`feature status-${status}`} title={st?.message ?? ''}>
                    <span className="feat-glyph">{FEATURE_GLYPHS[f.type as FeatureType] ?? '•'}</span>
                    <div className="feat-main">
                      <div className="feat-name">
                        {f.name ?? f.id} <span className="muted small">{featureLabel(f.type)}</span>
                      </div>
                      {status === 'error' && st?.message && <div className="feat-error">{st.message}</div>}
                    </div>
                    <span className={`feat-status st-${status}`}>
                      {status === 'ok' ? (
                        <Icon name="check" size={12} />
                      ) : status === 'error' ? (
                        <Icon name="error" size={12} />
                      ) : status === 'suppressed' ? (
                        'desact.'
                      ) : status === 'skipped' ? (
                        'omitida'
                      ) : (
                        '…'
                      )}
                    </span>
                    <button
                      className="icon-btn ghost xs"
                      data-tip={f.suppressed ? 'Activar operación' : 'Desactivar operación'}
                      aria-label={f.suppressed ? 'Activar operación' : 'Desactivar operación'}
                      onClick={() => toggleSuppress(part.id, f.id)}
                    >
                      <Icon name={f.suppressed ? 'eyeOff' : 'eye'} size={12} />
                    </button>
                  </li>
                )
              })}
            </ul>
          </Section>
        )
      })}

      {model.kind === 'assembly' && (
        <Section title="Instancias" count={model.instances?.length ?? 0}>
          <ul className="instance-list">
            {(model.instances ?? []).map((inst) => {
              const part = model.parts.find((p) => p.id === inst.part)
              return (
                <li key={inst.id} className="instance-row">
                  <ColorSwatch
                    color={inst.color ?? part?.color ?? PALETTE[Math.max(0, model.parts.indexOf(part!)) % PALETTE.length]!}
                    onPick={(c) => setColor({ kind: 'instance', id: inst.id }, c)}
                    onReset={() => setColor({ kind: 'instance', id: inst.id }, null)}
                    title="Color solo de esta instancia (clic derecho: usar el color de la pieza)"
                  />
                  <button className={`instance ${selected === inst.id ? 'selected' : ''}`} onClick={() => select(selected === inst.id ? null : inst.id)}>
                    <span className="ellipsis">{inst.name ?? inst.id}</span>
                    <span className="muted small">{part?.name ?? inst.part}</span>
                    {inst.fixed && <span className="tag">fija</span>}
                  </button>
                </li>
              )
            })}
          </ul>
        </Section>
      )}

      {versions.length > 0 && (
        <Section title="Versiones" count={versions.length}>
          <ul className="version-list">
            {[...versions].reverse().map((v) => {
              const n = versions.indexOf(v) + 1
              const current = v.id === currentVersionId
              return (
                <li key={v.id} className={current ? 'current' : ''}>
                  <div className="version-thumb">{thumbs[v.id] ? <img src={thumbs[v.id]} alt="" /> : <Icon name="cube" size={14} />}</div>
                  <div className="version-main">
                    <div className="version-title">
                      <span className="v-badge">v{n}</span>
                      <span className="tag">{v.note?.startsWith('Plantilla') ? 'Plantilla' : SOURCE_LABEL[v.source]}</span>
                      <span className="muted small">{new Date(v.createdAt).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <div className="muted small ellipsis" title={v.prompt}>
                      {v.prompt ?? v.model.name}
                    </div>
                  </div>
                  <button className="btn btn-xs pill" disabled={current} onClick={() => restore(v.id)}>
                    {current ? 'Actual' : 'Restaurar'}
                  </button>
                </li>
              )
            })}
          </ul>
        </Section>
      )}
    </div>
  )
}
