import { useEffect, useMemo, useState } from 'react'
import { validateModel, type Issue } from '@shared/model/validate'
import { effectiveModel, useModel } from '../store/model'
import { toast } from '../store/ui'
import { Icon } from './Icon'

export function JsonTab() {
  const model = useModel((s) => s.model)
  const overrides = useModel((s) => s.overrides)
  const addVersion = useModel((s) => s.addVersion)
  const source = useMemo(() => (model ? JSON.stringify(effectiveModel(model, overrides), null, 2) : ''), [model, overrides])
  const [text, setText] = useState(source)
  const [edited, setEdited] = useState(false)
  const [issues, setIssues] = useState<Issue[] | null>(null)

  useEffect(() => {
    if (!edited) setText(source)
  }, [source, edited])

  const validate = () => {
    const r = validateModel(text)
    setIssues(r.issues)
    return r
  }

  const apply = () => {
    const r = validate()
    if (!r.ok || !r.model) {
      toast('error', 'El JSON tiene errores; corrígelos antes de aplicar.')
      return
    }
    addVersion(r.model, model ? 'user' : 'import')
    setEdited(false)
    toast('success', 'Modelo aplicado como nueva versión.')
  }

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text)
      toast('success', 'JSON copiado al portapapeles.')
    } catch {
      toast('error', 'No se pudo copiar.')
    }
  }

  const errors = issues?.filter((i) => i.severity === 'error') ?? []
  const warnings = issues?.filter((i) => i.severity === 'warning') ?? []

  return (
    <div className="json-tab">
      <div className="tab-actions">
        <button className="btn btn-sm" onClick={validate} disabled={!text.trim()}>
          <Icon name="check" size={14} /> Validar
        </button>
        <button className="btn btn-sm btn-primary" onClick={apply} disabled={!text.trim() || (!edited && !!model)}>
          <Icon name="play" size={14} /> Aplicar
        </button>
        <div className="spacer" />
        {edited && (
          <button
            className="btn btn-sm ghost"
            onClick={() => {
              setEdited(false)
              setIssues(null)
              setText(source)
            }}
            title="Descartar cambios"
          >
            <Icon name="reset" size={14} />
          </button>
        )}
        <button className="btn btn-sm ghost" onClick={() => void copy()} title="Copiar">
          <Icon name="copy" size={14} />
        </button>
      </div>
      {issues && (
        <div className={`issues ${errors.length ? 'has-errors' : 'ok'}`}>
          {issues.length === 0 ? (
            <div className="issue ok">
              <Icon name="check" size={13} /> Modelo válido
            </div>
          ) : (
            [...errors, ...warnings].map((i, k) => (
              <div key={k} className={`issue ${i.severity}`}>
                <Icon name={i.severity === 'error' ? 'error' : 'warn'} size={13} />
                <span className="mono">{i.path}</span>: {i.message}
              </div>
            ))
          )}
        </div>
      )}
      <textarea
        className="json-editor mono"
        spellCheck={false}
        value={text}
        placeholder="Pega aquí un modelo CIMA en JSON y pulsa Aplicar."
        onChange={(e) => {
          setText(e.target.value)
          setEdited(true)
          setIssues(null)
        }}
      />
      <div className="muted small json-hint">Incluye los valores actuales de los deslizadores como valores por defecto.</div>
    </div>
  )
}
