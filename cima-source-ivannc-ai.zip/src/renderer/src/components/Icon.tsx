/** Minimal stroke icon set (inline SVG, 16px grid). */
const PATHS: Record<string, string> = {
  plus: 'M8 3v10M3 8h10',
  open: 'M2 4.5h4l1.5 1.5H14v6.5H2z',
  save: 'M3 2.5h8l2.5 2.5v8.5h-11zM5 2.5v3.5h5V2.5M5 13.5V9.5h6v4',
  saveAs: 'M3 2.5h8l2.5 2.5v4M3 2.5v11h5M5 2.5v3.5h5V2.5M11 11h4M13 9v4',
  export: 'M8 10V2.5M5 5.5l3-3 3 3M3 9.5v4h10v-4',
  gear:
    'M6.9 1.5h2.2l.4 1.8 1.3.6 1.6-1 1.5 1.5-1 1.6.6 1.3 1.8.4v2.2l-1.8.4-.6 1.3 1 1.6-1.5 1.5-1.6-1-1.3.6-.4 1.8H6.9l-.4-1.8-1.3-.6-1.6 1-1.5-1.5 1-1.6-.6-1.3-1.8-.4V6.9l1.8-.4.6-1.3-1-1.6 1.5-1.5 1.6 1 1.3-.6zM8 5.8a2.2 2.2 0 1 0 0 4.4 2.2 2.2 0 0 0 0-4.4z',
  send: 'M2.5 8h10M8.5 4l4 4-4 4',
  stop: 'M4.5 4.5h7v7h-7z',
  image: 'M2.5 3.5h11v9h-11zM2.5 10.5l3-3 3 3 2-2 3 3M10.5 6.2a.7.7 0 1 0 0 .1',
  close: 'M4 4l8 8M12 4l-8 8',
  chevron: 'M6 4l4 4-4 4',
  chevronDown: 'M4 6l4 4 4-4',
  refresh: 'M13 8a5 5 0 1 1-1.5-3.5M13 2.5v3h-3',
  copy: 'M5.5 5.5h7v8h-7zM3.5 10.5v-8h7',
  reset: 'M3 8a5 5 0 1 0 1.5-3.5M3 2.5v3h3',
  fit: 'M2.5 6V2.5H6M10 2.5h3.5V6M13.5 10v3.5H10M6 13.5H2.5V10',
  cube: 'M8 1.8l5.5 3v6.4L8 14.2l-5.5-3V4.8zM8 8l5.5-3.2M8 8L2.5 4.8M8 8v6.2',
  edges: 'M2.5 4.5l5.5-3 5.5 3v7l-5.5 3-5.5-3zM8 7.5v7M8 7.5l5.5-3M8 7.5l-5.5-3',
  grid: 'M2 5.5h12M2 10.5h12M5.5 2v12M10.5 2v12',
  axes: 'M3 13V3M3 13h10M3 13l6-6',
  eye: 'M1.5 8s2.5-4.5 6.5-4.5S14.5 8 14.5 8 12 12.5 8 12.5 1.5 8 1.5 8zM8 6a2 2 0 1 0 0 4 2 2 0 0 0 0-4z',
  eyeOff: 'M2 2l12 12M6.5 4c.5-.2 1-.3 1.5-.3 4 0 6.5 4.3 6.5 4.3s-.7 1.3-2 2.5M4 5.5C2.4 6.7 1.5 8 1.5 8S4 12.5 8 12.5c1 0 1.9-.3 2.7-.7',
  check: 'M3 8.5l3 3 7-7',
  warn: 'M8 2l6.5 11.5h-13zM8 6.5v3.5M8 11.8v.2',
  error: 'M8 1.8a6.2 6.2 0 1 0 0 12.4A6.2 6.2 0 0 0 8 1.8zM5.8 5.8l4.4 4.4M10.2 5.8l-4.4 4.4',
  info: 'M8 1.8a6.2 6.2 0 1 0 0 12.4A6.2 6.2 0 0 0 8 1.8zM8 7v4.5M8 4.8v.2',
  play: 'M5 3l8 5-8 5z',
  code: 'M5.5 4.5L2 8l3.5 3.5M10.5 4.5L14 8l-3.5 3.5',
  download: 'M8 2.5V10M5 7l3 3 3-3M3 13.5h10',
  folder: 'M2 4.5h4l1.5 1.5H14v6.5H2z',
  trash: 'M3 4.5h10M6 4.5V3h4v1.5M4.5 4.5l.7 9h5.6l.7-9',
  bolt: 'M9 1.5L3.5 9H8l-1 5.5L12.5 7H8z',
  link: 'M6.5 9.5l3-3M7 4.5l1-1a2.5 2.5 0 0 1 3.5 3.5l-1 1M9 11.5l-1 1a2.5 2.5 0 0 1-3.5-3.5l1-1',
  undo: 'M5 6.5H10a3 3 0 0 1 0 6H6M5 6.5l2.5-2.5M5 6.5L7.5 9',
  brain: 'M6 3a2 2 0 0 0-2 2 2 2 0 0 0-1 3.5A2 2 0 0 0 5 12a2 2 0 0 0 3 1V3.5A2 2 0 0 0 6 3zM10 3a2 2 0 0 1 2 2 2 2 0 0 1 1 3.5A2 2 0 0 1 11 12a2 2 0 0 1-3 1',
  list: 'M5.5 4h8M5.5 8h8M5.5 12h8M2.5 4h.5M2.5 8h.5M2.5 12h.5',
  sliders: 'M2.5 4.5h11M2.5 11.5h11M5.5 3v3M10.5 10v3',
  tree: 'M3 2.5v9h4M3 6.5h4M9 5h4.5M9 8h4.5M9 11.5h4.5',
  braces: 'M6 2.5c-1.5 0-2 .5-2 2v1.5c0 1-.5 2-1.5 2 1 0 1.5 1 1.5 2v1.5c0 1.5.5 2 2 2M10 2.5c1.5 0 2 .5 2 2v1.5c0 1 .5 2 1.5 2-1 0-1.5 1-1.5 2v1.5c0 1.5-.5 2-2 2',
  arrowUp: 'M8 13V3.5M4 7.5l4-4 4 4',
  help: 'M8 1.8a6.2 6.2 0 1 0 0 12.4A6.2 6.2 0 0 0 8 1.8zM6.2 6.3a1.9 1.9 0 0 1 3.7.4c0 1.3-1.9 1.6-1.9 2.8M8 11.6v.2',
  keyboard: 'M1.8 4.5h12.4v7H1.8zM4 6.8h.5M6.5 6.8H7M9 6.8h.5M11.5 6.8h.5M5 9.3h6',
  sparkle: 'M8 1.5l1.6 4.9L14.5 8l-4.9 1.6L8 14.5l-1.6-4.9L1.5 8l4.9-1.6z',
  shield: 'M8 1.8l5 2v4c0 3-2.2 5.3-5 6.4-2.8-1.1-5-3.4-5-6.4v-4z',
  layers: 'M8 2l6 3-6 3-6-3zM2 8l6 3 6-3M2 11l6 3 6-3',
  plug: 'M6 2v3.5M10 2v3.5M4 5.5h8v2.5a4 4 0 0 1-8 0zM8 12v2.5',
}

export function Icon({ name, size = 16, className }: { name: keyof typeof PATHS | string; size?: number; className?: string }) {
  return (
    <svg
      className={`icon ${className ?? ''}`}
      width={size}
      height={size}
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.4}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d={PATHS[name] ?? ''} />
    </svg>
  )
}
