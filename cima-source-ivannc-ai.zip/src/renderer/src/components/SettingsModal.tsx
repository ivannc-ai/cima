import { useEffect, useState } from 'react'
import type { Effort, ProviderConfig } from '@shared/ai/types'
import type { ProviderTestResult } from '@shared/ipc'
import { useSettings } from '../store/settings'
import { useUi } from '../store/ui'
import { cima, isMock } from '../lib/bridge'
import { errorText } from '../lib/labels'
import { Icon } from './Icon'
import { Modal } from './Modal'

const KIND_LABEL: Record<ProviderConfig['kind'], string> = {
  anthropic: 'Anthropic',
  openai: 'OpenAI',
  gemini: 'Gemini',
  ollama: 'Ollama',
  'openai-compatible': 'Compatible OpenAI',
}

const EFFORTS: Array<{ id: Effort; label: string }> = [
  { id: 'low', label: 'Bajo' },
  { id: 'medium', label: 'Medio' },
  { id: 'high', label: 'Alto' },
  { id: 'xhigh', label: 'Muy alto' },
  { id: 'max', label: 'Máximo' },
]

/** Text input that commits on blur / Enter. */
function LazyInput({
  value,
  onCommit,
  placeholder,
  list,
  type = 'text',
}: {
  value: string
  onCommit: (v: string) => void
  placeholder?: string
  list?: string
  type?: string
}) {
  const [v, setV] = useState(value)
  useEffect(() => setV(value), [value])
  return (
    <input
      type={type}
      value={v}
      list={list}
      placeholder={placeholder}
      onChange={(e) => setV(e.target.value)}
      onBlur={() => v !== value && onCommit(v.trim())}
      onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
    />
  )
}

function ProviderCard({ p, active }: { p: ProviderConfig; active: boolean }) {
  const update = useSettings((s) => s.update)
  const setApiKey = useSettings((s) => s.setApiKey)
  const ask = useUi((s) => s.ask)
  const [open, setOpen] = useState(active)
  const [key, setKey] = useState('')
  const [newModel, setNewModel] = useState('')
  const [test, setTest] = useState<ProviderTestResult | null>(null)
  const [testing, setTesting] = useState(false)
  const custom = p.kind === 'openai-compatible'
  const patch = (x: Partial<ProviderConfig>) => void update({ providers: [{ id: p.id, ...x }] })

  const addModel = () => {
    const m = newModel.trim()
    if (!m || p.models.includes(m)) return
    patch({ models: [...p.models, m] })
    setNewModel('')
  }
  const removeModel = (m: string) => {
    patch({
      models: p.models.filter((x) => x !== m),
      ...(p.model === m && p.models.length > 1 ? { model: p.models.find((x) => x !== m) ?? p.model } : {}),
    })
  }

  const saveKey = async () => {
    if (!key.trim()) return
    if (await setApiKey(p.id, key.trim())) setKey('')
  }
  const runTest = async () => {
    setTesting(true)
    setTest(null)
    try {
      setTest(await cima.ai.testProvider(p.id))
    } catch (e) {
      setTest({ ok: false, message: errorText(e) })
    } finally {
      setTesting(false)
    }
  }
  const remove = async () => {
    if (await ask({ title: 'Eliminar proveedor', message: `¿Eliminar «${p.label}»?`, okLabel: 'Eliminar', danger: true }))
      void update({ removeProviders: [p.id] })
  }

  return (
    <div className={`provider-card ${active ? 'active' : ''} ${p.enabled ? '' : 'disabled'}`}>
      <div className="provider-head" onClick={() => setOpen(!open)}>
        <Icon name={open ? 'chevronDown' : 'chevron'} size={12} />
        <strong>{p.label}</strong>
        <span className="tag">{KIND_LABEL[p.kind]}</span>
        {active && <span className="tag tag-accent">activo</span>}
        <div className="spacer" />
        {p.requiresApiKey ? (
          p.hasApiKey ? (
            <span className="key-ok">
              <Icon name="check" size={12} /> clave guardada
            </span>
          ) : (
            <span className="key-missing">sin clave</span>
          )
        ) : (
          <span className="muted small">sin clave necesaria</span>
        )}
      </div>
      {open && (
        <div className="provider-body form-grid">
          <label>Estado</label>
          <div className="row">
            <label className="check">
              <input type="checkbox" checked={p.enabled} onChange={(e) => patch({ enabled: e.target.checked })} /> Habilitado
            </label>
            <button className="btn btn-sm" disabled={active || !p.enabled} onClick={() => void update({ activeProviderId: p.id })}>
              Usar este proveedor
            </button>
          </div>
          {custom && (
            <>
              <label>Nombre</label>
              <LazyInput value={p.label} onCommit={(v) => v && patch({ label: v })} />
            </>
          )}
          {(p.requiresApiKey || custom) && (
            <>
              <label>Clave API</label>
              <div className="row">
                <input
                  type="password"
                  value={key}
                  autoComplete="off"
                  placeholder={p.hasApiKey ? 'guardada ✓ — escribe para reemplazarla' : 'Pega aquí la clave API'}
                  onChange={(e) => setKey(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && void saveKey()}
                />
                <button className="btn btn-sm btn-primary" disabled={!key.trim()} onClick={() => void saveKey()}>
                  Guardar
                </button>
                {p.hasApiKey && (
                  <button className="btn btn-sm ghost" title="Borrar clave" onClick={() => void setApiKey(p.id, null)}>
                    <Icon name="trash" size={13} />
                  </button>
                )}
              </div>
            </>
          )}
          <label>Modelo</label>
          <div className="row">
            <LazyInput value={p.model} list={`models-${p.id}`} placeholder="id del modelo" onCommit={(v) => v && patch({ model: v })} />
            <datalist id={`models-${p.id}`}>
              {p.models.map((m) => (
                <option key={m} value={m} />
              ))}
            </datalist>
          </div>
          <label>Modelos disponibles</label>
          <div className="models-editor">
            <div className="row">
              <input
                type="text"
                value={newModel}
                placeholder="Añadir un modelo… teclea y pulsa Intro o Añadir"
                spellCheck={false}
                onChange={(e) => setNewModel(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addModel()}
              />
              <button className="btn btn-sm" disabled={!newModel.trim()} onClick={addModel}>
                <Icon name="plus" size={13} /> Añadir
              </button>
            </div>
            {p.models.length > 0 && (
              <div className="model-chips">
                {p.models.map((m) => (
                  <span key={m} className={`tag ${m === p.model ? 'tag-accent' : ''}`} title={m === p.model ? `${m} (modelo activo)` : m}>
                    <span>{m}</span>
                    <button className="chip-x" onClick={() => removeModel(m)} title="Quitar de la lista" aria-label={`Quitar ${m}`}>
                      <Icon name="close" size={10} />
                    </button>
                  </span>
                ))}
              </div>
            )}
            <p className="muted small">
              Todos los modelos figuran en el selector de modelo del chat y como sugerencias del campo Modelo. Bajo el mismo
              endpoint, proxy y clave puedes usar aquí los modelos que quieras.
            </p>
          </div>
          {(p.kind === 'ollama' || p.kind === 'gemini' || custom) && (
            <>
              <label>URL base</label>
              <LazyInput value={p.baseURL ?? ''} placeholder="https://…/v1" onCommit={(v) => patch({ baseURL: v || undefined })} />
            </>
          )}
          {p.kind !== 'anthropic' && (
            <>
              <label>Proxy</label>
              <LazyInput
                value={p.proxy ?? ''}
                placeholder="http://usuario:clave@proxy:3128 (opcional)"
                onCommit={(v) => patch({ proxy: v || undefined })}
              />
              <label>Certificado CA</label>
              <LazyInput
                value={p.caCertificate ?? ''}
                placeholder="Ruta a un .pem/.crt para validar el TLS (opcional)"
                onCommit={(v) => patch({ caCertificate: v || undefined })}
              />
            </>
          )}
          {custom && (
            <>
              <label />
              <label className="check">
                <input type="checkbox" checked={p.requiresApiKey} onChange={(e) => patch({ requiresApiKey: e.target.checked })} /> Requiere
                clave API
              </label>
            </>
          )}
          <label />
          <div className="row">
            <button className="btn btn-sm" disabled={testing} onClick={() => void runTest()}>
              {testing ? <span className="spinner sm" /> : <Icon name="plug" size={14} />} Probar conexión
            </button>
            {test && (
              <span className={`small ${test.ok ? 'text-ok' : 'text-error'}`}>
                {test.ok ? '✓' : '✗'} {test.message}
                {test.latencyMs != null && ` (${Math.round(test.latencyMs)} ms)`}
              </span>
            )}
            <div className="spacer" />
            {custom && (
              <button className="btn btn-sm ghost danger" onClick={() => void remove()}>
                <Icon name="trash" size={13} /> Eliminar
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

type Section = 'providers' | 'ai' | 'viewer'

export function SettingsModal() {
  const open = useUi((s) => s.settingsOpen)
  const setOpen = useUi((s) => s.setSettingsOpen)
  const settings = useSettings((s) => s.settings)
  const update = useSettings((s) => s.update)
  const [section, setSection] = useState<Section>('providers')
  const [version, setVersion] = useState('')
  useEffect(() => {
    if (open) void cima.app.info().then((i) => setVersion(`${i.name} ${i.version}${isMock ? ' · modo navegador' : ''}`), () => {})
  }, [open])
  if (!open) return null

  const addCustom = () =>
    void update({
      providers: [
        {
          id: `custom-${Date.now()}`,
          kind: 'openai-compatible',
          label: 'Proveedor personalizado',
          baseURL: 'http://localhost:8000/v1',
          model: '',
          models: [],
          hasApiKey: false,
          requiresApiKey: true,
          enabled: true,
        },
      ],
    })

  return (
    <Modal title="Ajustes" wide onClose={() => setOpen(false)} footer={<span className="muted small">{version}</span>}>
      <div className="settings">
        <nav className="settings-nav">
          <button className={section === 'providers' ? 'on' : ''} onClick={() => setSection('providers')}>
            <Icon name="plug" size={14} /> Proveedores de IA
          </button>
          <button className={section === 'ai' ? 'on' : ''} onClick={() => setSection('ai')}>
            <Icon name="brain" size={14} /> Opciones de IA
          </button>
          <button className={section === 'viewer' ? 'on' : ''} onClick={() => setSection('viewer')}>
            <Icon name="cube" size={14} /> Visor
          </button>
        </nav>
        <div className="settings-content">
          {section === 'providers' && (
            <>
              <p className="muted small">
                Las claves API se guardan cifradas en este equipo y nunca se muestran. Elige el proveedor activo y su modelo.
              </p>
              {settings.providers.map((p) => (
                <ProviderCard key={p.id} p={p} active={p.id === settings.activeProviderId} />
              ))}
              <button className="btn btn-sm" onClick={addCustom}>
                <Icon name="plus" size={14} /> Añadir proveedor compatible con OpenAI
              </button>
            </>
          )}
          {section === 'ai' && (
            <div className="form-grid">
              <label>Esfuerzo de razonamiento</label>
              <select value={settings.ai.effort} onChange={(e) => void update({ ai: { effort: e.target.value as Effort } })}>
                {EFFORTS.map((x) => (
                  <option key={x.id} value={x.id}>
                    {x.label}
                  </option>
                ))}
              </select>
              <label>Intentos de reparación</label>
              <input
                type="number"
                min={0}
                max={10}
                value={settings.ai.maxRepairAttempts}
                onChange={(e) => {
                  const n = Math.max(0, Math.min(10, Math.round(Number(e.target.value))))
                  if (Number.isFinite(n)) void update({ ai: { maxRepairAttempts: n } })
                }}
              />
              <label />
              <label className="check">
                <input type="checkbox" checked={settings.ai.refusalFallback} onChange={(e) => void update({ ai: { refusalFallback: e.target.checked } })} />
                Alternativa automática ante rechazos (Anthropic)
              </label>
              <label />
              <label className="check">
                <input type="checkbox" checked={settings.ai.showThinking} onChange={(e) => void update({ ai: { showThinking: e.target.checked } })} />
                Mostrar el razonamiento en el chat
              </label>
              <label />
              <label className="check">
                <input type="checkbox" checked={settings.ai.templates} onChange={(e) => void update({ ai: { templates: e.target.checked } })} />
                Usar plantillas paramétricas (recomendado para modelos pequeños)
              </label>
              <label />
              <label className="check">
                <input type="checkbox" checked={settings.ai.audit} onChange={(e) => void update({ ai: { audit: e.target.checked } })} />
                Auditar el modelo frente a la petición
              </label>
              <label />
              <p className="muted small settings-hint">
                Las plantillas permiten a la IA crear piezas habituales con unos pocos valores. La auditoría comprueba medidas, taladros y
                geometría tras cada generación y pide a la IA que corrija lo que no cumpla (cuenta como intento de reparación).
              </p>
            </div>
          )}
          {section === 'viewer' && (
            <div className="form-grid">
              <label />
              <label className="check">
                <input type="checkbox" checked={settings.viewer.showEdges} onChange={(e) => void update({ viewer: { showEdges: e.target.checked } })} />
                Mostrar aristas
              </label>
              <label />
              <label className="check">
                <input type="checkbox" checked={settings.viewer.showGrid} onChange={(e) => void update({ viewer: { showGrid: e.target.checked } })} />
                Mostrar rejilla
              </label>
              <label />
              <label className="check">
                <input type="checkbox" checked={settings.viewer.showAxes} onChange={(e) => void update({ viewer: { showAxes: e.target.checked } })} />
                Mostrar triedro de ejes
              </label>
            </div>
          )}
        </div>
      </div>
    </Modal>
  )
}
