/**
 * Plain three.js CAD viewer (Z-up world, render on demand).
 *
 * - One THREE.Mesh per placement; geometry is shared between the placements of the same part.
 * - Orthographic (default) or perspective camera, OrbitControls, RoomEnvironment reflections.
 * - Fading shader grid on the XY plane, axis triad (bottom-left) and a clickable ViewCube (bottom-right).
 * - The background is transparent: the CSS gradient of the container shows through.
 */
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js'
import type { BuildResponse } from '../kernel/protocol'
import type { RigidTransform } from '@shared/model/geometry'
import { niceStep } from '../lib/params'

export type ViewName = 'iso' | 'front' | 'top' | 'right' | 'back' | 'left' | 'bottom'
export type Projection = 'ortho' | 'persp'

const EDGE_COLOR = new THREE.Color('#0a0c0f')
const SELECT_COLOR = new THREE.Color('#4c8dff')
const CUBE_SIZE = 108
const CUBE_MARGIN = 14
const TRIAD_SIZE = 96

/** Eye directions (model centre → camera). Front looks from -Y, right from +X, top from +Z. */
export const VIEW_DIRS: Record<ViewName, THREE.Vector3> = {
  iso: new THREE.Vector3(1, -1, 0.82).normalize(),
  front: new THREE.Vector3(0, -1, 0),
  back: new THREE.Vector3(0, 1, 0),
  right: new THREE.Vector3(1, 0, 0),
  left: new THREE.Vector3(-1, 0, 0),
  top: new THREE.Vector3(0, 0, 1),
  bottom: new THREE.Vector3(0, 0, -1),
}

interface InstanceView {
  instanceId: string
  partId: string
  mesh: THREE.Mesh
  edges: THREE.LineSegments | null
  material: THREE.MeshStandardMaterial
  edgeMaterial: THREE.LineBasicMaterial
}

/** Builds a Matrix4 from a row-major 3x3 rotation + translation (world = R * local + t). */
export function matrixFromRigid(T: RigidTransform, out = new THREE.Matrix4()): THREE.Matrix4 {
  const R = T.R
  // Matrix4.set takes its arguments in row-major order.
  return out.set(R[0], R[1], R[2], T.t[0], R[3], R[4], R[5], T.t[1], R[6], R[7], R[8], T.t[2], 0, 0, 0, 1)
}

function labelTexture(text: string, opts: { color: string; bg?: string; size?: number; font?: string }): THREE.CanvasTexture {
  const size = opts.size ?? 128
  const c = document.createElement('canvas')
  c.width = c.height = size
  const g = c.getContext('2d')!
  if (opts.bg) {
    g.fillStyle = opts.bg
    g.fillRect(0, 0, size, size)
  }
  g.font = opts.font ?? `600 ${Math.round(size * 0.2)}px "Segoe UI Variable", "Segoe UI", sans-serif`
  g.textAlign = 'center'
  g.textBaseline = 'middle'
  g.fillStyle = opts.color
  g.fillText(text, size / 2, size / 2 + 2)
  const tex = new THREE.CanvasTexture(c)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.anisotropy = 4
  return tex
}

const GRID_VERT = /* glsl */ `
varying vec3 vWorld;
void main() {
  vec4 w = modelMatrix * vec4(position, 1.0);
  vWorld = w.xyz;
  gl_Position = projectionMatrix * viewMatrix * w;
}`

const GRID_FRAG = /* glsl */ `
uniform float uCell;
uniform float uMajor;
uniform vec2 uCenter;
uniform float uFade;
uniform vec3 uMinorColor;
uniform vec3 uMajorColor;
varying vec3 vWorld;
float line(vec2 p, float size) {
  vec2 q = p / size;
  vec2 g = abs(fract(q - 0.5) - 0.5) / max(fwidth(q), vec2(1e-6));
  return 1.0 - min(min(g.x, g.y), 1.0);
}
void main() {
  vec2 p = vWorld.xy;
  float density = max(fwidth(p.x), fwidth(p.y)) / uCell;
  float minor = line(p, uCell) * (1.0 - smoothstep(0.18, 0.45, density));
  float major = line(p, uCell * uMajor);
  float d = length(p - uCenter);
  float fade = 1.0 - smoothstep(uFade * 0.25, uFade, d);
  vec3 col = mix(uMinorColor, uMajorColor, major);
  float a = max(minor * 0.55, major * 0.85);
  vec2 fw = max(fwidth(p), vec2(1e-6));
  float ax = 1.0 - min(abs(p.y) / (fw.y * 1.4), 1.0);
  float ay = 1.0 - min(abs(p.x) / (fw.x * 1.4), 1.0);
  col = mix(col, vec3(0.86, 0.36, 0.36), ax);
  col = mix(col, vec3(0.36, 0.78, 0.48), ay);
  a = max(a, max(ax, ay) * 0.6);
  a *= fade;
  if (a < 0.004) discard;
  gl_FragColor = vec4(col, a);
}`

export class Viewer {
  readonly renderer: THREE.WebGLRenderer
  readonly scene = new THREE.Scene()
  private readonly persp = new THREE.PerspectiveCamera(32, 1, 0.1, 100000)
  private readonly ortho = new THREE.OrthographicCamera(-100, 100, 100, -100, -100000, 100000)
  private camera: THREE.PerspectiveCamera | THREE.OrthographicCamera = this.ortho
  private projection: Projection = 'ortho'
  /** Half height of the orthographic frustum at zoom 1. */
  private orthoHalf = 100
  readonly controls: OrbitControls
  onSelect: ((instanceId: string | null) => void) | null = null

  private readonly root = new THREE.Group()
  private readonly grid: THREE.Mesh<THREE.PlaneGeometry, THREE.ShaderMaterial>
  private readonly keyLight = new THREE.DirectionalLight(0xffffff, 0.75)
  private readonly envTexture: THREE.Texture
  private readonly triadScene = new THREE.Scene()
  private readonly cubeScene = new THREE.Scene()
  private readonly hudCamera = new THREE.OrthographicCamera(-1.55, 1.55, 1.55, -1.55, 0.1, 10)
  private readonly cubeFaces: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshBasicMaterial>[] = []
  private hoveredFace: THREE.Mesh | null = null
  private readonly raycaster = new THREE.Raycaster()
  private geometries: THREE.BufferGeometry[] = []
  private instances: InstanceView[] = []
  private selected: string | null = null
  private frame = 0
  private showEdges = true
  private showGrid = true
  private showAxes = true
  private down: { x: number; y: number } | null = null
  private readonly resizeObserver: ResizeObserver
  private disposed = false
  private lastRadius = 100

  constructor(private readonly container: HTMLElement) {
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' })
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2))
    this.renderer.autoClear = false
    this.renderer.setClearColor(0x000000, 0)
    this.renderer.toneMapping = THREE.NeutralToneMapping
    this.renderer.toneMappingExposure = 0.95
    const canvas = this.renderer.domElement
    canvas.className = 'viewport-canvas'
    container.appendChild(canvas)

    // Soft studio reflections.
    const pmrem = new THREE.PMREMGenerator(this.renderer)
    const room = new RoomEnvironment()
    this.envTexture = pmrem.fromScene(room, 0.04).texture
    room.dispose()
    pmrem.dispose()
    this.scene.environment = this.envTexture
    this.scene.environmentIntensity = 0.55

    for (const cam of [this.persp, this.ortho]) {
      cam.up.set(0, 0, 1)
      cam.position.set(200, -200, 170)
      this.scene.add(cam)
    }
    // Head light that follows the active camera + a faint sky fill.
    this.keyLight.position.set(0.5, 0.8, 1)
    this.camera.add(this.keyLight)
    this.scene.add(new THREE.HemisphereLight(0xe8eeff, 0x202328, 0.4))

    this.grid = new THREE.Mesh(
      new THREE.PlaneGeometry(1, 1),
      new THREE.ShaderMaterial({
        vertexShader: GRID_VERT,
        fragmentShader: GRID_FRAG,
        transparent: true,
        depthWrite: false,
        side: THREE.DoubleSide,
        uniforms: {
          uCell: { value: 10 },
          uMajor: { value: 5 },
          uCenter: { value: new THREE.Vector2() },
          uFade: { value: 500 },
          uMinorColor: { value: new THREE.Color('#465063') },
          uMajorColor: { value: new THREE.Color('#65728a') },
        },
      }),
    )
    this.grid.renderOrder = -1
    this.grid.raycast = () => {}
    this.scene.add(this.grid)
    this.scene.add(this.root)

    this.controls = new OrbitControls(this.camera, canvas)
    this.controls.enableDamping = false
    this.controls.zoomToCursor = true
    this.controls.screenSpacePanning = true
    this.controls.addEventListener('change', () => this.requestRender())

    this.buildTriad()
    this.buildViewCube()
    this.layoutGrid(new THREE.Box3(new THREE.Vector3(-50, -50, 0), new THREE.Vector3(50, 50, 20)))

    canvas.addEventListener('pointerdown', this.onPointerDown, true)
    canvas.addEventListener('pointerup', this.onPointerUp)
    canvas.addEventListener('pointermove', this.onPointerMove)
    canvas.addEventListener('pointerleave', this.onPointerLeave)

    this.resizeObserver = new ResizeObserver(() => this.resize())
    this.resizeObserver.observe(container)
    this.resize()
    this.view('iso')
  }

  // ---------------------------------------------------------------- rendering

  requestRender(): void {
    if (this.frame || this.disposed) return
    this.frame = requestAnimationFrame(() => {
      this.frame = 0
      this.render()
    })
  }

  private size(): THREE.Vector2 {
    return this.renderer.getSize(new THREE.Vector2())
  }

  private cubeRect(): { x: number; y: number; s: number } {
    const size = this.size()
    // In CSS pixels, origin bottom-left (WebGL convention).
    return { x: size.x - CUBE_SIZE - CUBE_MARGIN, y: CUBE_MARGIN + 30, s: CUBE_SIZE }
  }

  private render(withHud = true): void {
    const r = this.renderer
    const size = this.size()
    r.setScissorTest(false)
    r.setViewport(0, 0, size.x, size.y)
    r.clear()
    this.grid.visible = this.showGrid
    r.render(this.scene, this.camera)
    if (!withHud) return
    const dir = new THREE.Vector3().subVectors(this.camera.position, this.controls.target).normalize()
    this.hudCamera.position.copy(dir).multiplyScalar(4)
    this.hudCamera.up.copy(this.camera.up)
    this.hudCamera.lookAt(0, 0, 0)
    r.setScissorTest(true)
    const c = this.cubeRect()
    r.setScissor(c.x, c.y, c.s, c.s)
    r.setViewport(c.x, c.y, c.s, c.s)
    r.clearDepth()
    r.render(this.cubeScene, this.hudCamera)
    if (this.showAxes) {
      r.setScissor(6, 6, TRIAD_SIZE, TRIAD_SIZE)
      r.setViewport(6, 6, TRIAD_SIZE, TRIAD_SIZE)
      r.clearDepth()
      r.render(this.triadScene, this.hudCamera)
    }
    r.setScissorTest(false)
  }

  private resize(): void {
    const w = Math.max(1, this.container.clientWidth)
    const h = Math.max(1, this.container.clientHeight)
    this.renderer.setSize(w, h)
    const aspect = w / h
    this.persp.aspect = aspect
    this.persp.updateProjectionMatrix()
    this.updateOrthoFrustum()
    this.render()
  }

  private updateOrthoFrustum(): void {
    const s = this.size()
    const aspect = s.x / Math.max(1, s.y)
    this.ortho.left = -this.orthoHalf * aspect
    this.ortho.right = this.orthoHalf * aspect
    this.ortho.top = this.orthoHalf
    this.ortho.bottom = -this.orthoHalf
    this.ortho.updateProjectionMatrix()
  }

  // ---------------------------------------------------------------- HUD widgets

  private buildTriad(): void {
    const axes: Array<[THREE.Vector3, string, string]> = [
      [new THREE.Vector3(1, 0, 0), '#ff6b6b', 'X'],
      [new THREE.Vector3(0, 1, 0), '#5fd98a', 'Y'],
      [new THREE.Vector3(0, 0, 1), '#6aa2ff', 'Z'],
    ]
    for (const [dir, color, label] of axes) {
      this.triadScene.add(new THREE.ArrowHelper(dir, new THREE.Vector3(), 1, new THREE.Color(color).getHex(), 0.26, 0.13))
      const s = new THREE.Sprite(
        new THREE.SpriteMaterial({ map: labelTexture(label, { color, size: 64, font: '700 44px "Segoe UI", sans-serif' }), depthTest: false }),
      )
      s.scale.setScalar(0.62)
      s.position.copy(dir).multiplyScalar(1.28)
      this.triadScene.add(s)
    }
  }

  private buildViewCube(): void {
    const faces: Array<{ view: ViewName; n: THREE.Vector3; up: THREE.Vector3; label: string }> = [
      { view: 'top', n: new THREE.Vector3(0, 0, 1), up: new THREE.Vector3(0, 1, 0), label: 'SUPERIOR' },
      { view: 'bottom', n: new THREE.Vector3(0, 0, -1), up: new THREE.Vector3(0, -1, 0), label: 'INFERIOR' },
      { view: 'front', n: new THREE.Vector3(0, -1, 0), up: new THREE.Vector3(0, 0, 1), label: 'FRENTE' },
      { view: 'back', n: new THREE.Vector3(0, 1, 0), up: new THREE.Vector3(0, 0, 1), label: 'ATRÁS' },
      { view: 'right', n: new THREE.Vector3(1, 0, 0), up: new THREE.Vector3(0, 0, 1), label: 'DERECHA' },
      { view: 'left', n: new THREE.Vector3(-1, 0, 0), up: new THREE.Vector3(0, 0, 1), label: 'IZQUIERDA' },
    ]
    const size = 1.5
    for (const f of faces) {
      const tex = labelTexture(f.label, {
        color: '#c9d2df',
        bg: '#262b33',
        size: 128,
        font: `700 ${f.label.length > 7 ? 21 : 25}px "Segoe UI Variable", "Segoe UI", sans-serif`,
      })
      const mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.94 })
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(size, size), mat)
      const x = new THREE.Vector3().crossVectors(f.up, f.n)
      mesh.matrix.makeBasis(x, f.up, f.n).setPosition(f.n.clone().multiplyScalar(size / 2))
      mesh.matrixAutoUpdate = false
      mesh.userData.view = f.view
      this.cubeScene.add(mesh)
      this.cubeFaces.push(mesh)
    }
    const edges = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.BoxGeometry(size * 1.002, size * 1.002, size * 1.002)),
      new THREE.LineBasicMaterial({ color: 0x5a6578 }),
    )
    this.cubeScene.add(edges)
  }

  /** Returns the view direction for a hit on the cube (faces, edges and corners). */
  private cubeHit(clientX: number, clientY: number): { dir: THREE.Vector3; face: THREE.Mesh } | null {
    const rect = this.renderer.domElement.getBoundingClientRect()
    const c = this.cubeRect()
    const px = clientX - rect.left
    const py = rect.height - (clientY - rect.top)
    if (px < c.x || px > c.x + c.s || py < c.y || py > c.y + c.s) return null
    const ndc = new THREE.Vector2(((px - c.x) / c.s) * 2 - 1, ((py - c.y) / c.s) * 2 - 1)
    this.raycaster.setFromCamera(ndc, this.hudCamera)
    const hit = this.raycaster.intersectObjects(this.cubeFaces, false)[0]
    if (!hit) return null
    const p = hit.point.clone().divideScalar(0.75) // cube half size → [-1, 1]
    const dir = new THREE.Vector3(...p.toArray().map((v) => (Math.abs(v) > 0.55 ? Math.sign(v) : 0)))
    if (dir.lengthSq() === 0) return null
    return { dir: dir.normalize(), face: hit.object as THREE.Mesh }
  }

  // ---------------------------------------------------------------- content

  /** Replaces the displayed model. `colors` maps partId → hex color (fallbacks resolved by the caller). */
  setBuild(build: BuildResponse | null, colors: Map<string, string>, fit: boolean): void {
    this.clearModel()
    if (build) {
      const geoByPart = new Map<string, { geo: THREE.BufferGeometry; edges: THREE.BufferGeometry | null }>()
      for (const part of build.parts) {
        if (!part.mesh || part.mesh.triangles.length === 0) continue
        const geo = new THREE.BufferGeometry()
        geo.setAttribute('position', new THREE.BufferAttribute(part.mesh.vertices, 3))
        geo.setAttribute('normal', new THREE.BufferAttribute(part.mesh.normals, 3))
        geo.setIndex(new THREE.BufferAttribute(part.mesh.triangles, 1))
        geo.computeBoundingBox()
        geo.computeBoundingSphere()
        let edges: THREE.BufferGeometry | null = null
        if (part.mesh.edges.length >= 6) {
          edges = new THREE.BufferGeometry()
          edges.setAttribute('position', new THREE.BufferAttribute(part.mesh.edges, 3))
          this.geometries.push(edges)
        }
        this.geometries.push(geo)
        geoByPart.set(part.partId, { geo, edges })
      }
      const m = new THREE.Matrix4()
      for (const pl of build.placements) {
        const g = geoByPart.get(pl.partId)
        if (!g) continue
        const color = pl.color ?? colors.get(pl.partId) ?? '#9aa7b8'
        const material = new THREE.MeshStandardMaterial({
          color,
          metalness: 0.3,
          roughness: 0.45,
          side: THREE.DoubleSide,
          polygonOffset: true,
          polygonOffsetFactor: 1,
          polygonOffsetUnits: 1,
        })
        const mesh = new THREE.Mesh(g.geo, material)
        mesh.matrixAutoUpdate = false
        matrixFromRigid(pl.transform, m)
        mesh.matrix.copy(m)
        mesh.userData.instanceId = pl.instanceId
        this.root.add(mesh)
        const edgeMaterial = new THREE.LineBasicMaterial({ color: EDGE_COLOR })
        let edges: THREE.LineSegments | null = null
        if (g.edges) {
          edges = new THREE.LineSegments(g.edges, edgeMaterial)
          edges.matrixAutoUpdate = false
          edges.matrix.copy(m)
          edges.visible = this.showEdges
          edges.raycast = () => {}
          this.root.add(edges)
        }
        this.instances.push({ instanceId: pl.instanceId, partId: pl.partId, mesh, edges, material, edgeMaterial })
      }
    }
    this.root.updateMatrixWorld(true)
    const box = this.modelBox()
    this.layoutGrid(box ?? new THREE.Box3(new THREE.Vector3(-50, -50, 0), new THREE.Vector3(50, 50, 20)))
    this.applySelection()
    if (fit && box) this.fit()
    this.requestRender()
  }

  private clearModel(): void {
    for (const iv of this.instances) {
      iv.material.dispose()
      iv.edgeMaterial.dispose()
    }
    for (const g of this.geometries) g.dispose()
    this.root.clear()
    this.instances = []
    this.geometries = []
  }

  private modelBox(): THREE.Box3 | null {
    if (!this.instances.length) return null
    const box = new THREE.Box3()
    for (const iv of this.instances) {
      const b = iv.mesh.geometry.boundingBox
      if (b) box.union(b.clone().applyMatrix4(iv.mesh.matrixWorld))
    }
    return box.isEmpty() ? null : box
  }

  private layoutGrid(box: THREE.Box3): void {
    const size = box.getSize(new THREE.Vector3())
    const center = box.getCenter(new THREE.Vector3())
    const extent = Math.max(size.x, size.y, size.z, 10)
    const cell = niceStep(extent / 10)
    const u = this.grid.material.uniforms
    u.uCell!.value = cell
    u.uFade!.value = extent * 3
    ;(u.uCenter!.value as THREE.Vector2).set(center.x, center.y)
    const span = extent * 8
    this.grid.scale.set(span, span, 1)
    this.grid.position.set(Math.round(center.x / cell) * cell, Math.round(center.y / cell) * cell, Math.min(0, box.min.z) - extent * 1e-4)
  }

  // ---------------------------------------------------------------- camera

  getProjection(): Projection {
    return this.projection
  }

  setProjection(p: Projection): void {
    if (p === this.projection) return
    const from = this.camera
    const target = this.controls.target
    const dist = from.position.distanceTo(target)
    const to = p === 'ortho' ? this.ortho : this.persp
    to.position.copy(from.position)
    to.quaternion.copy(from.quaternion)
    if (p === 'ortho') {
      // Match the visible height at the target distance.
      this.orthoHalf = dist * Math.tan(THREE.MathUtils.degToRad(this.persp.fov / 2))
      this.ortho.zoom = 1
      this.updateOrthoFrustum()
    } else {
      const visibleHalf = this.orthoHalf / this.ortho.zoom
      const d = visibleHalf / Math.tan(THREE.MathUtils.degToRad(this.persp.fov / 2))
      const dir = new THREE.Vector3().subVectors(from.position, target).normalize()
      to.position.copy(target).addScaledVector(dir, d)
      this.persp.near = Math.max(0.01, this.lastRadius / 200)
      this.persp.far = this.lastRadius * 400 + d
      this.persp.updateProjectionMatrix()
    }
    from.remove(this.keyLight)
    to.add(this.keyLight)
    this.camera = to
    this.projection = p
    this.controls.object = to
    this.controls.update()
    this.requestRender()
  }

  fit(): void {
    const dir = new THREE.Vector3().subVectors(this.camera.position, this.controls.target)
    if (dir.lengthSq() < 1e-12) dir.copy(VIEW_DIRS.iso)
    this.frame3(dir.normalize())
  }

  view(name: ViewName): void {
    this.frame3(VIEW_DIRS[name].clone())
  }

  private frame3(dir: THREE.Vector3): void {
    const box = this.modelBox() ?? new THREE.Box3(new THREE.Vector3(-50, -50, 0), new THREE.Vector3(50, 50, 20))
    const sphere = box.getBoundingSphere(new THREE.Sphere())
    const r = Math.max(sphere.radius, 1)
    this.lastRadius = r
    const center = sphere.center
    // Camera up stays +Z (OrbitControls caches it); straight top/bottom views get a tiny tilt so that
    // screen-up is +Y.
    if (Math.abs(dir.z) > 0.9999) dir.set(0, -1e-3, Math.sign(dir.z)).normalize()
    const vfov = THREE.MathUtils.degToRad(this.persp.fov)
    const hfov = 2 * Math.atan(Math.tan(vfov / 2) * this.persp.aspect)
    const dist = (r / Math.sin(Math.min(vfov, hfov) / 2)) * 1.05
    this.controls.target.copy(center)
    for (const cam of [this.persp, this.ortho]) {
      cam.position.copy(center).addScaledVector(dir, dist)
      cam.lookAt(center)
    }
    this.persp.near = Math.max(0.01, r / 200)
    this.persp.far = r * 400 + dist
    this.persp.updateProjectionMatrix()
    const s = this.size()
    const aspect = s.x / Math.max(1, s.y)
    this.orthoHalf = r * 1.12 * Math.max(1, 1 / aspect)
    this.ortho.zoom = 1
    this.ortho.near = -r * 50
    this.ortho.far = dist + r * 50
    this.updateOrthoFrustum()
    this.controls.minDistance = r * 0.02
    this.controls.maxDistance = r * 60
    this.controls.minZoom = 0.02
    this.controls.maxZoom = 60
    this.controls.update()
    this.requestRender()
  }

  // ---------------------------------------------------------------- options

  setOptions(o: { edges: boolean; grid: boolean; axes: boolean }): void {
    this.showEdges = o.edges
    this.showGrid = o.grid
    this.showAxes = o.axes
    for (const iv of this.instances) if (iv.edges) iv.edges.visible = o.edges
    this.requestRender()
  }

  setSelected(instanceId: string | null): void {
    this.selected = instanceId
    this.applySelection()
    this.requestRender()
  }

  private applySelection(): void {
    for (const iv of this.instances) {
      const sel = iv.instanceId === this.selected
      iv.material.emissive.copy(sel ? SELECT_COLOR : new THREE.Color(0, 0, 0))
      iv.material.emissiveIntensity = sel ? 0.42 : 0
      iv.edgeMaterial.color.copy(sel ? new THREE.Color('#9cc0ff') : EDGE_COLOR)
    }
  }

  /** PNG data URL of the model alone (no HUD), downscaled to the given width. */
  snapshot(width = 160, height = 112): string | null {
    if (!this.instances.length) return null
    const showGrid = this.showGrid
    this.showGrid = false
    this.render(false)
    this.showGrid = showGrid
    const src = this.renderer.domElement
    const c = document.createElement('canvas')
    c.width = width
    c.height = height
    const g = c.getContext('2d')
    if (!g) return null
    const scale = Math.max(width / src.width, height / src.height) * 1.15
    const w = src.width * scale
    const h = src.height * scale
    g.drawImage(src, (width - w) / 2, (height - h) / 2, w, h)
    this.requestRender()
    try {
      return c.toDataURL('image/png')
    } catch {
      return null
    }
  }

  // ---------------------------------------------------------------- picking

  private onPointerDown = (e: PointerEvent): void => {
    this.down = e.button === 0 ? { x: e.clientX, y: e.clientY } : null
    // Clicks on the ViewCube must not start an orbit.
    if (e.button === 0 && this.cubeHit(e.clientX, e.clientY)) e.stopImmediatePropagation()
  }

  private onPointerMove = (e: PointerEvent): void => {
    if (e.buttons) return
    const hit = this.cubeHit(e.clientX, e.clientY)
    const face = hit?.face ?? null
    if (face === this.hoveredFace) return
    if (this.hoveredFace) ((this.hoveredFace as THREE.Mesh).material as THREE.MeshBasicMaterial).color.set(0xffffff)
    if (face) (face.material as THREE.MeshBasicMaterial).color.set(0x9cc0ff)
    this.hoveredFace = face
    this.renderer.domElement.style.cursor = face ? 'pointer' : ''
    this.requestRender()
  }

  private onPointerLeave = (): void => {
    if (this.hoveredFace) {
      ;(this.hoveredFace.material as THREE.MeshBasicMaterial).color.set(0xffffff)
      this.hoveredFace = null
      this.renderer.domElement.style.cursor = ''
      this.requestRender()
    }
  }

  private onPointerUp = (e: PointerEvent): void => {
    const d = this.down
    this.down = null
    if (!d || e.button !== 0 || Math.hypot(e.clientX - d.x, e.clientY - d.y) > 4) return
    const cube = this.cubeHit(e.clientX, e.clientY)
    if (cube) {
      this.frame3(cube.dir)
      return
    }
    const rect = this.renderer.domElement.getBoundingClientRect()
    const ndc = new THREE.Vector2(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1)
    this.raycaster.setFromCamera(ndc, this.camera)
    const hit = this.raycaster.intersectObjects(
      this.instances.map((i) => i.mesh),
      false,
    )[0]
    this.onSelect?.((hit?.object.userData.instanceId as string | undefined) ?? null)
  }

  // ---------------------------------------------------------------- lifecycle

  dispose(): void {
    this.disposed = true
    if (this.frame) cancelAnimationFrame(this.frame)
    this.resizeObserver.disconnect()
    const canvas = this.renderer.domElement
    canvas.removeEventListener('pointerdown', this.onPointerDown, true)
    canvas.removeEventListener('pointerup', this.onPointerUp)
    canvas.removeEventListener('pointermove', this.onPointerMove)
    canvas.removeEventListener('pointerleave', this.onPointerLeave)
    this.controls.dispose()
    this.clearModel()
    this.grid.geometry.dispose()
    this.grid.material.dispose()
    this.envTexture.dispose()
    for (const s of [this.triadScene, this.cubeScene]) {
      s.traverse((o) => {
        const m = o as THREE.Mesh
        m.geometry?.dispose()
        const mat = m.material as THREE.Material | undefined
        if (mat && 'map' in mat) (mat as THREE.MeshBasicMaterial).map?.dispose()
        mat?.dispose()
      })
    }
    this.renderer.dispose()
    canvas.remove()
  }
}
