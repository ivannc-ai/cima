import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { App } from './App'
import { cima } from './lib/bridge'
import './styles/global.css'

// Everything that fails in the renderer (uncaught errors, rejected promises and console.error) is
// forwarded to the main process, which appends it to the daily log file.
const log = (level: 'info' | 'warn' | 'error', scope: string, message: string) => {
  try {
    void cima.app.clientLog(level, scope, message)
  } catch {
    /* never throw from logging */
  }
}
const text = (v: unknown): string => (v instanceof Error ? `${v.message}\n${v.stack ?? ''}` : typeof v === 'string' ? v : JSON.stringify(v) ?? String(v))

window.addEventListener('error', (e) => log('error', 'window', `${e.message} (${e.filename}:${e.lineno})`))
window.addEventListener('unhandledrejection', (e) => log('error', 'promise', text(e.reason)))
const consoleError = console.error.bind(console)
console.error = (...args: unknown[]) => {
  consoleError(...args)
  log('error', 'console', args.map(text).join(' | '))
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
