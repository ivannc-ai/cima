/** Pure helpers for parameter sliders and number formatting. */
import type { Parameter } from '@shared/model/schema'

/** 1, 2, 5 × 10^n step closest to (and not above) the given raw value. */
export function niceStep(raw: number): number {
  if (!(raw > 0) || !Number.isFinite(raw)) return 1
  const exp = Math.floor(Math.log10(raw))
  const base = Math.pow(10, exp)
  const f = raw / base
  const m = f >= 5 ? 5 : f >= 2 ? 2 : 1
  return m * base
}

export interface SliderRange {
  min: number
  max: number
  step: number
}

/** Slider range of a parameter: its own min/max/step, otherwise a range derived from the value and unit. */
export function sliderRange(def: Pick<Parameter, 'value' | 'unit' | 'min' | 'max' | 'step'>, current = def.value): SliderRange {
  const v = Number.isFinite(current) ? current : def.value
  const isInt = Number.isInteger(def.value) && def.unit === 'none'
  let min: number
  let max: number
  if (def.unit === 'deg') {
    min = def.min ?? (v < 0 ? -360 : 0)
    max = def.max ?? 360
  } else if (def.unit === 'none') {
    min = def.min ?? (isInt ? Math.min(1, v) : 0)
    max = def.max ?? Math.max(isInt ? 12 : 1, Math.abs(v) * 3)
  } else {
    const mag = Math.abs(v) || 10
    min = def.min ?? (v >= 0 ? 0 : -mag * 3)
    max = def.max ?? Math.max(mag * 3, 10)
  }
  if (min > max) [min, max] = [max, min]
  if (v < min) min = v
  if (v > max) max = v
  if (max === min) max = min + 1
  let step = def.step && def.step > 0 ? def.step : 0
  if (!step) {
    if (isInt) step = 1
    else if (def.unit === 'deg') step = 1
    else step = niceStep((max - min) / 400)
  }
  return { min, max, step }
}

/** Formats a number compactly (up to `digits` decimals, no trailing zeros). */
export function fmt(n: number | null | undefined, digits = 3): string {
  if (n == null || !Number.isFinite(n)) return '—'
  const r = Number(n.toFixed(digits))
  return Object.is(r, -0) ? '0' : String(r)
}

export function unitLabel(unit: Parameter['unit']): string {
  return unit === 'mm' ? 'mm' : unit === 'deg' ? '°' : ''
}

/** Volume in mm³ shown in cm³ when large. */
export function fmtVolume(mm3: number | null | undefined): string {
  if (mm3 == null || !Number.isFinite(mm3)) return '—'
  if (Math.abs(mm3) >= 1000) return `${fmt(mm3 / 1000, 2)} cm³`
  return `${fmt(mm3, 1)} mm³`
}

export function fmtBytes(b: number): string {
  if (b < 1024) return `${b} B`
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`
  return `${(b / 1024 / 1024).toFixed(2)} MB`
}
