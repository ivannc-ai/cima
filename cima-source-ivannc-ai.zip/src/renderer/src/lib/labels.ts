/** Spanish labels and small utilities shared by the UI. */
import type { FeatureType } from '@shared/model/schema'

export const FEATURE_LABELS: Record<FeatureType, string> = {
  pad: 'Extrusión',
  pocket: 'Cajera',
  shaft: 'Revolución',
  groove: 'Ranura',
  hole: 'Taladro',
  fillet: 'Redondeo',
  chamfer: 'Chaflán',
  shell: 'Vaciado',
  mirror: 'Simetría',
  linearPattern: 'Patrón lineal',
  circularPattern: 'Patrón circular',
}

/** Short glyph per feature type (rendered inside a small badge). */
export const FEATURE_GLYPHS: Record<FeatureType, string> = {
  pad: '▲',
  pocket: '▼',
  shaft: '◎',
  groove: '◌',
  hole: '⊙',
  fillet: '◜',
  chamfer: '◸',
  shell: '▢',
  mirror: '⇋',
  linearPattern: '⋯',
  circularPattern: '✲',
}

export function featureLabel(type: string): string {
  return (FEATURE_LABELS as Record<string, string>)[type] ?? type
}

let counter = 0
export function uid(prefix = ''): string {
  counter = (counter + 1) % 1e6
  return `${prefix}${Date.now().toString(36)}${counter.toString(36)}${Math.random().toString(36).slice(2, 7)}`
}

export const PALETTE = ['#8fa3b8', '#d0a85c', '#6fb38a', '#c97a7a', '#8b7fd1', '#5fa9c9', '#c99a6b', '#9fb05a']

export function errorText(e: unknown): string {
  if (e instanceof Error) return e.message.replace(/^Error invoking remote method '[^']+': (Error: )?/, '')
  return String(e)
}
