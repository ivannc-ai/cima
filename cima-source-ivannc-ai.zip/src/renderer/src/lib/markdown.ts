/**
 * Tiny, safe markdown parser for chat messages. Produces a small AST rendered as React elements
 * (never as HTML strings). Supports: paragraphs, headings, bold, italic, inline code, fenced code
 * blocks, bullet / numbered lists, horizontal rules and links (rendered as plain text + url).
 */

export type Inline =
  | { t: 'text'; v: string }
  | { t: 'bold'; c: Inline[] }
  | { t: 'italic'; c: Inline[] }
  | { t: 'code'; v: string }
  | { t: 'link'; text: string; href: string }

export type Block =
  | { t: 'p'; c: Inline[] }
  | { t: 'h'; level: number; c: Inline[] }
  | { t: 'code'; lang: string; v: string }
  | { t: 'ul'; items: Inline[][] }
  | { t: 'ol'; start: number; items: Inline[][] }
  | { t: 'hr' }

export function parseInline(src: string): Inline[] {
  const out: Inline[] = []
  let buf = ''
  const flush = () => {
    if (buf) out.push({ t: 'text', v: buf })
    buf = ''
  }
  let i = 0
  while (i < src.length) {
    const ch = src[i]!
    if (ch === '`') {
      const end = src.indexOf('`', i + 1)
      if (end > i + 1) {
        flush()
        out.push({ t: 'code', v: src.slice(i + 1, end) })
        i = end + 1
        continue
      }
    }
    if ((ch === '*' || ch === '_') && src[i + 1] === ch) {
      const marker = ch + ch
      const end = src.indexOf(marker, i + 2)
      if (end > i + 2) {
        flush()
        out.push({ t: 'bold', c: parseInline(src.slice(i + 2, end)) })
        i = end + 2
        continue
      }
    }
    if (ch === '*' || (ch === '_' && (i === 0 || /\s/.test(src[i - 1]!)))) {
      const end = src.indexOf(ch, i + 1)
      if (end > i + 1 && src[i + 1] !== ' ' && src[end - 1] !== ' ') {
        flush()
        out.push({ t: 'italic', c: parseInline(src.slice(i + 1, end)) })
        i = end + 1
        continue
      }
    }
    if (ch === '[') {
      const m = /^\[([^\]]+)\]\(([^)\s]+)\)/.exec(src.slice(i))
      if (m) {
        flush()
        out.push({ t: 'link', text: m[1]!, href: m[2]! })
        i += m[0].length
        continue
      }
    }
    buf += ch
    i++
  }
  flush()
  return out
}

const UL_RE = /^\s{0,3}[-*+]\s+(.*)$/
const OL_RE = /^\s{0,3}(\d{1,6})[.)]\s+(.*)$/
const H_RE = /^(#{1,6})\s+(.*)$/
const FENCE_RE = /^\s{0,3}(```|~~~)\s*([\w+-]*)\s*$/
const HR_RE = /^\s{0,3}([-*_])(\s*\1){2,}\s*$/

export function parseMarkdown(src: string): Block[] {
  const lines = src.replace(/\r\n?/g, '\n').split('\n')
  const blocks: Block[] = []
  let para: string[] = []
  const flushPara = () => {
    if (para.length) blocks.push({ t: 'p', c: parseInline(para.join('\n')) })
    para = []
  }
  let i = 0
  while (i < lines.length) {
    const line = lines[i]!
    const fence = FENCE_RE.exec(line)
    if (fence) {
      flushPara()
      const code: string[] = []
      i++
      while (i < lines.length && !lines[i]!.trim().startsWith(fence[1]!)) code.push(lines[i++]!)
      i++ // closing fence (or end of input while streaming)
      blocks.push({ t: 'code', lang: fence[2] ?? '', v: code.join('\n') })
      continue
    }
    if (!line.trim()) {
      flushPara()
      i++
      continue
    }
    if (HR_RE.test(line)) {
      flushPara()
      blocks.push({ t: 'hr' })
      i++
      continue
    }
    const h = H_RE.exec(line)
    if (h) {
      flushPara()
      blocks.push({ t: 'h', level: h[1]!.length, c: parseInline(h[2]!) })
      i++
      continue
    }
    if (UL_RE.test(line) || OL_RE.test(line)) {
      flushPara()
      const ordered = !UL_RE.test(line)
      const re = ordered ? OL_RE : UL_RE
      const items: string[] = []
      const start = ordered ? Number(OL_RE.exec(line)![1]) : 1
      while (i < lines.length) {
        const l = lines[i]!
        const m = re.exec(l)
        if (m) {
          items.push(ordered ? m[2]! : m[1]!)
          i++
        } else if (l.trim() && /^\s{2,}/.test(l) && items.length) {
          items[items.length - 1] += ' ' + l.trim()
          i++
        } else break
      }
      const parsed = items.map(parseInline)
      blocks.push(ordered ? { t: 'ol', start, items: parsed } : { t: 'ul', items: parsed })
      continue
    }
    para.push(line)
    i++
  }
  flushPara()
  return blocks
}
