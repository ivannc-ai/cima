/** Project, example and export actions (used by the top bar, shortcuts and the empty state). */
import { PROJECT_FORMAT, PROJECT_VERSION, type CimaProject } from '@shared/project'
import type { CatiaScriptOptions, CatiaStatus } from '@shared/catia/types'
import type { AppSettings } from '@shared/settings'
import { EXAMPLES } from '@shared/model/examples'
import { instantiateTemplate, type CadTemplate, type TemplateValue } from '@shared/templates'
import { validateModel } from '@shared/model/validate'
import { cima } from './bridge'
import { errorText } from './labels'
import { kernel } from '../kernel/client'
import { effectiveModel, useModel, type UiVersion } from '../store/model'
import { useChat } from '../store/chat'
import { useCatia } from '../store/catia'
import { toast, useUi } from '../store/ui'

async function confirmDiscard(): Promise<boolean> {
  if (!useModel.getState().dirty) return true
  return useUi.getState().ask({
    title: 'Cambios sin guardar',
    message: 'El proyecto actual tiene cambios sin guardar. ¿Quieres descartarlos?',
    okLabel: 'Descartar',
    danger: true,
  })
}

export async function newProject(): Promise<void> {
  if (useChat.getState().busy) useChat.getState().stop()
  if (!(await confirmDiscard())) return
  useChat.getState().reset()
  useModel.getState().resetProject()
}

export async function openProject(): Promise<void> {
  if (!(await confirmDiscard())) return
  try {
    const res = await cima.files.openProject()
    if (!res) return
    const p = res.project
    useChat.getState().reset(Array.isArray(p.chat) ? p.chat : [])
    useModel.getState().loadProject({
      name: p.name || 'Proyecto',
      createdAt: p.createdAt || new Date().toISOString(),
      model: p.model ?? null,
      overrides: p.overrides ?? {},
      history: (p.history ?? []) as UiVersion[],
      path: res.path,
    })
    toast('success', `Proyecto abierto: ${p.name}`)
  } catch (e) {
    toast('error', `No se pudo abrir el proyecto: ${errorText(e)}`)
  }
}

export function currentProject(): CimaProject {
  const m = useModel.getState()
  return {
    format: PROJECT_FORMAT,
    version: PROJECT_VERSION,
    name: m.projectName,
    createdAt: m.createdAt,
    updatedAt: new Date().toISOString(),
    model: m.model,
    overrides: m.overrides,
    history: m.versions,
    chat: useChat.getState().messages,
  }
}

export async function saveProject(saveAs = false): Promise<boolean> {
  const m = useModel.getState()
  try {
    const res = await cima.files.saveProject(currentProject(), { path: m.projectPath ?? undefined, saveAs })
    if (res.canceled) return false
    if (!res.ok) throw new Error(res.error ?? 'error desconocido')
    useModel.getState().markSaved(res.path ?? m.projectPath)
    toast('success', `Proyecto guardado${res.path ? `: ${res.path}` : ''}`)
    return true
  } catch (e) {
    toast('error', `No se pudo guardar: ${errorText(e)}`)
    return false
  }
}

export function loadExample(id: string): void {
  const ex = EXAMPLES.find((e) => e.id === id)
  if (!ex) return
  useModel.getState().addVersion(ex.model, 'example', { prompt: ex.prompt })
  const m = useModel.getState()
  if (m.projectName === 'Proyecto sin título' && !m.projectPath) useModel.setState({ projectName: ex.title })
  useChat.getState().addNotice({ kind: 'info', text: `Ejemplo cargado: ${ex.title}` })
}

/** Creates a new version from a parametric template (works without AI). Returns false on failure. */
export function createFromTemplate(t: CadTemplate, values: Record<string, TemplateValue>, name: string): boolean {
  const inst = instantiateTemplate(t.id, values, name)
  if (inst.errors.length || !inst.model) {
    toast('error', `No se pudo crear la plantilla: ${inst.errors.join('; ') || 'sin modelo'}`)
    return false
  }
  const v = validateModel(inst.model)
  if (!v.ok || !v.model) {
    toast('error', `La plantilla generó un modelo no válido: ${v.issues.map((i) => i.message).join('; ')}`)
    return false
  }
  useModel.getState().addVersion(v.model, 'user', { prompt: `Plantilla: ${t.title}`, note: `Plantilla: ${t.title}` })
  const m = useModel.getState()
  if (m.projectName === 'Proyecto sin título' && !m.projectPath) useModel.setState({ projectName: v.model.name.replace(/_/g, ' ') })
  useChat.getState().addNotice({ kind: 'info', text: `Modelo creado desde la plantilla «${t.title}».` })
  if (inst.warnings.length) toast('warning', `Valores ajustados: ${inst.warnings.join('; ')}`)
  else toast('success', `Plantilla «${t.title}» creada.`)
  return true
}

export function catiaOptions(
  s: AppSettings,
  status: CatiaStatus | null,
  flavor: CatiaScriptOptions['flavor'],
  startModel?: string | null,
  startModelName?: string,
): CatiaScriptOptions {
  const c = s.catia
  return {
    target: c.target === 'auto' ? (status?.target ?? 'v5') : c.target,
    flavor,
    connect: c.connect,
    createParameters: c.createParameters,
    createFormulas: c.createFormulas && c.createParameters,
    applyColors: c.applyColors,
    ...(c.saveDirectory ? { saveDirectory: c.saveDirectory, exportStep: c.exportStep } : {}),
    ...(startModel ? { startModel, ...(startModelName?.trim() ? { startModelName: startModelName.trim() } : {}) } : {}),
  }
}

export type ExportKind = 'step' | 'stl' | 'catscript' | 'vbs' | 'json'

export async function exportAs(kind: ExportKind, settings: AppSettings, status: CatiaStatus | null): Promise<void> {
  const { model, overrides } = useModel.getState()
  if (!model) {
    toast('warning', 'No hay ningún modelo que exportar.')
    return
  }
  const name = model.name || 'modelo'
  try {
    let res
    if (kind === 'step' || kind === 'stl') {
      toast('info', `Generando ${kind.toUpperCase()}…`)
      const data = await kernel.export(kind, model, overrides)
      res = await cima.files.saveFile({
        title: `Exportar ${kind.toUpperCase()}`,
        defaultName: `${name}.${kind}`,
        filters: kind === 'step' ? [{ name: 'STEP', extensions: ['step', 'stp'] }] : [{ name: 'STL', extensions: ['stl'] }],
        data,
      })
    } else if (kind === 'json') {
      res = await cima.files.saveFile({
        title: 'Exportar modelo JSON',
        defaultName: `${name}.json`,
        filters: [{ name: 'JSON', extensions: ['json'] }],
        data: JSON.stringify(effectiveModel(model, overrides), null, 2),
      })
    } else {
      res = await cima.catia.exportMacro(
        { model, overrides, options: catiaOptions(settings, status, kind, useCatia.getState().startModel, useCatia.getState().startModelName) },
        name,
      )
    }
    if (res.canceled) return
    if (!res.ok) throw new Error(res.error ?? 'error desconocido')
    toast('success', `Exportado: ${res.path ?? name}`, res.path ? { label: 'Mostrar', run: () => void cima.app.showItemInFolder(res.path!) } : undefined)
  } catch (e) {
    toast('error', `Error al exportar: ${errorText(e)}`)
  }
}
