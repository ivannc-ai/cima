/**
 * Pure helpers of the renderer-side agent loop (no React, no window access) so they can be unit tested.
 *
 * Tool-result formats sent back to the LLM (always in the NEXT user message's toolResults):
 *   INVALID\n- path: message\n...            (isError: true)  -> automatic repair turn
 *   BUILD_ERRORS\n- part/feature (type): msg  (isError: true)  -> automatic repair turn (model still shown)
 *   AUDIT\n- [code] message                    (isError: true)  -> automatic repair turn (audit enabled only)
 *   OK\nModel built: ...[\nNotes:\n- ...]      (isError: false) -> loop stops
 * Template calls (use_cad_template) are instantiated first and then follow the same path; their warnings
 * and non-blocking audit findings are appended as "Notes:".
 */
import type { ChatContentPart, ChatMessage, ToolCall, ToolResult, UserMessage } from '@shared/ai/types'
import { CAD_TOOL_NAME, TOOL_NUDGE_TEXT } from '../../../shared/ai/types'
import type { Issue } from '@shared/model/validate'
import type { CadModel } from '@shared/model/schema'
import type { AuditFinding, BuildResponse } from '../kernel/protocol'
import { TEMPLATE_TOOL_NAME } from '../../../shared/templates/index'
import { cima } from './bridge'

export const CURRENT_MODEL_OPEN = '<current_model>'
export const CURRENT_MODEL_CLOSE = '</current_model>'

/** Text of the automatic repair turn (English: it is addressed to the model). */
export const REPAIR_TEXT =
  `The ${CAD_TOOL_NAME} tool result above reports problems. Fix every reported problem and call ${CAD_TOOL_NAME} again ` +
  'with the complete corrected model (all parameters, parts and features, not only the changed ones).'

/** Appends the current model (as JSON) to the user's text. */
export function withCurrentModel(text: string, modelJson: string): string {
  return `${text}\n\n${CURRENT_MODEL_OPEN}\n\`\`\`json\n${modelJson}\n\`\`\`\n${CURRENT_MODEL_CLOSE}`
}

/** Splits a stored user text into what the user typed and whether a current_model block was attached. */
export function splitUserText(text: string): { text: string; hasModel: boolean } {
  const i = text.lastIndexOf(`\n\n${CURRENT_MODEL_OPEN}`)
  const j = i >= 0 ? i : text.startsWith(CURRENT_MODEL_OPEN) ? 0 : -1
  if (j < 0 || !text.trimEnd().endsWith(CURRENT_MODEL_CLOSE)) return { text, hasModel: false }
  return { text: text.slice(0, j), hasModel: true }
}

export function userText(msg: UserMessage): string {
  return msg.content
    .filter((p): p is Extract<ChatContentPart, { type: 'text' }> => p.type === 'text')
    .map((p) => p.text)
    .join('\n')
}

/** Repair text used after a template call (the model may fix the values or switch to the full JSON). */
export const REPAIR_TEXT_TEMPLATE =
  `The tool result above reports problems. Fix every reported problem: call ${TEMPLATE_TOOL_NAME} again with corrected ` +
  `values, or call ${CAD_TOOL_NAME} with the complete corrected model (start from the <current_model> JSON).`

export function isRepairMessage(msg: ChatMessage): boolean {
  if (msg.role !== 'user' || !msg.toolResults?.length) return false
  const t = splitUserText(userText(msg)).text
  return t === REPAIR_TEXT || t === REPAIR_TEXT_TEMPLATE
}

/** True when the repair turn was triggered by the generation audit. */
export function isAuditRepair(msg: ChatMessage): boolean {
  return isRepairMessage(msg) && msg.role === 'user' && !!msg.toolResults?.some((r) => r.content.startsWith('AUDIT\n'))
}

/** Tools through which the model delivers a CAD model. */
export function isModelTool(name: string): boolean {
  return name === CAD_TOOL_NAME || name === TEMPLATE_TOOL_NAME
}

/**
 * Text of the latest real user request (not repair / nudge turns), without the attached <current_model>.
 * Used as the reference for the generation audit.
 */
export function lastUserRequest(messages: ReadonlyArray<ChatMessage>): string {
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i]!
    if (m.role !== 'user' || isRepairMessage(m) || isNudgeMessage(m)) continue
    const t = splitUserText(userText(m)).text.trim()
    if (t) return t
  }
  return ''
}

export interface TemplateCall {
  template: string
  name?: string
  params: Array<{ name: string; value: unknown }> | Record<string, unknown>
}

/**
 * Parses the input of a use_cad_template call. Tolerant: the input may be a JSON string, the id may come as
 * "template" / "template_id" / "id", and params may be an array of {name, value}, an object map or a JSON string.
 */
export function parseTemplateCall(input: unknown): TemplateCall | { error: string } {
  let raw = input
  if (typeof raw === 'string') {
    try {
      raw = JSON.parse(raw)
    } catch (e) {
      return { error: `input is not valid JSON: ${(e as Error).message}` }
    }
  }
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { error: 'input must be an object {template, name, params}' }
  const o = raw as Record<string, unknown>
  const id = [o.template, o.template_id, o.templateId, o.id].find((x) => typeof x === 'string' && x.trim()) as string | undefined
  if (!id) return { error: 'missing "template" (template id)' }
  let params: unknown = o.params ?? o.parameters ?? o.values ?? []
  if (typeof params === 'string') {
    try {
      params = JSON.parse(params)
    } catch {
      return { error: '"params" is not valid JSON' }
    }
  }
  let out: TemplateCall['params']
  if (Array.isArray(params)) {
    out = params
      .filter((p): p is Record<string, unknown> => !!p && typeof p === 'object')
      .map((p) => ({ name: String(p.name ?? p.param ?? ''), value: p.value }))
      .filter((p) => p.name)
  } else if (params && typeof params === 'object') {
    out = { ...(params as Record<string, unknown>) }
  } else {
    out = []
  }
  const name = typeof o.name === 'string' && o.name.trim() ? o.name.trim() : undefined
  return { template: id.trim(), ...(name ? { name } : {}), params: out }
}

export function templateErrorResult(toolCallId: string, errors: string[]): ToolResult {
  return { toolCallId, isError: true, content: `INVALID\n${errors.map((e) => `- template: ${e}`).join('\n')}` }
}

/** Same format as auditText() in src/kernel/audit.ts (kept here so the renderer does not bundle the kernel). */
export function auditLines(findings: ReadonlyArray<Pick<AuditFinding, 'code' | 'llm'>>): string {
  return findings
    .filter((f) => f.llm)
    .map((f) => `- [${f.code}] ${f.llm}`)
    .join('\n')
}

export function auditResult(toolCallId: string, findings: ReadonlyArray<AuditFinding>): ToolResult {
  return { toolCallId, isError: true, content: `AUDIT\n${auditLines(findings)}` }
}

/** Appends "Notes:" (template warnings, non-blocking audit findings) to a tool result. */
export function withNotes(r: ToolResult, notes: ReadonlyArray<string>): ToolResult {
  const list = notes.map((n) => n.trim()).filter(Boolean)
  if (!list.length) return r
  return { ...r, content: `${r.content}\nNotes:\n${list.map((n) => (n.startsWith('- ') ? n : `- ${n}`)).join('\n')}` }
}

/** Automatic "call the tool now" follow-up (see TOOL_NUDGE_TEXT). */
export function isNudgeMessage(msg: ChatMessage): boolean {
  return msg.role === 'user' && userText(msg).startsWith(TOOL_NUDGE_TEXT)
}

/**
 * True when an assistant answer without tool call looks like a finished design description rather than
 * a clarifying question for the user (in that case the renderer nudges the model to emit the model).
 */
export function looksLikeDesignWithoutModel(text: string): boolean {
  const t = text.trim()
  if (t.length < 40) return false
  const lastPart = t.slice(-300)
  // Clarifying questions end with "?" or contain an opening "¿" near the end.
  if (/[?？]\s*$/.test(t) || /¿[^¿]*\?/.test(lastPart)) return false
  return true
}

export function invalidResult(toolCallId: string, issues: Issue[]): ToolResult {
  const errors = issues.filter((i) => i.severity === 'error')
  const list = (errors.length ? errors : issues).map((i) => `- ${i.path}: ${i.message}`)
  void cima.app.clientLog('error', 'cad-generation', `modelo inválido (${toolCallId}): ${list.join(' | ') || 'invalid model'}`)
  return { toolCallId, isError: true, content: `INVALID\n${list.join('\n') || '- (root): invalid model'}` }
}

/** Lines describing every failure of a build ("partId/featureId (type): message"). Empty = success. */
export function buildFailures(build: BuildResponse): string[] {
  const lines: string[] = []
  for (const part of build.parts) {
    for (const f of part.features) {
      if (f.status === 'error') lines.push(`${part.partId}/${f.id} (${f.type}): ${f.message ?? 'error'}`)
    }
    if (part.error && !part.features.some((f) => f.status === 'error')) lines.push(`${part.partId}: ${part.error}`)
  }
  for (const e of build.errors) lines.push(e)
  return lines
}

export function buildErrorsResult(toolCallId: string, failures: string[]): ToolResult {
  void cima.app.clientLog('error', 'cad-generation', `errores de construcción (${toolCallId}): ${failures.join(' | ')}`)
  return { toolCallId, isError: true, content: `BUILD_ERRORS\n${failures.map((l) => `- ${l}`).join('\n')}` }
}

export function okResult(toolCallId: string, model: CadModel, build: BuildResponse | null, note?: string): ToolResult {
  const ids = model.parts.map((p) => p.id)
  const nFeatures = model.parts.reduce((n, p) => n + p.features.length, 0)
  const partsTxt = `${ids.length} part${ids.length === 1 ? '' : 's'} (${ids.join(', ')})`
  let content = `OK\nModel built: ${partsTxt}, ${nFeatures} features`
  if (build) {
    const vols = build.parts.map((p) => `${p.partId}=${p.volume == null ? '?' : p.volume.toFixed(1)} mm3`)
    content += `, volumes: ${vols.join(', ')}`
    const suppressed = build.parts.reduce((n, p) => n + p.features.filter((f) => f.status === 'suppressed').length, 0)
    if (suppressed) content += `, ${suppressed} suppressed`
    if (model.kind === 'assembly') content += `, ${build.placements.length} instances`
  }
  if (note) content += `\n${note}`
  return { toolCallId, isError: false, content }
}

export function cancelledResult(toolCallId: string): ToolResult {
  return { toolCallId, isError: true, content: 'CANCELLED\nThe user stopped the generation before the model was applied.' }
}

export function unknownToolResult(call: ToolCall): ToolResult {
  return { toolCallId: call.id, isError: true, content: `Unknown tool "${call.name}". The only tool available is ${CAD_TOOL_NAME}.` }
}

export function ignoredToolResult(call: ToolCall): ToolResult {
  return {
    toolCallId: call.id,
    isError: true,
    content:
      call.name === CAD_TOOL_NAME
        ? `IGNORED\nOnly one ${CAD_TOOL_NAME} call per turn is processed; this call was ignored.`
        : `IGNORED\nOnly one model call (${CAD_TOOL_NAME} or ${TEMPLATE_TOOL_NAME}) per turn is processed; this call was ignored.`,
  }
}

/**
 * Tool results that still must be attached to the next user message: every tool call of the trailing
 * assistant message that has no result yet in `pending` gets a neutral result.
 */
export function completeToolResults(messages: ReadonlyArray<ChatMessage>, pending: ReadonlyArray<ToolResult>): ToolResult[] {
  const last = messages[messages.length - 1]
  if (!last || last.role !== 'assistant' || !last.toolCalls?.length) return []
  const byId = new Map(pending.map((r) => [r.toolCallId, r] as const))
  return last.toolCalls.map(
    (tc) => byId.get(tc.id) ?? { toolCallId: tc.id, isError: false, content: 'OK\nModel accepted (session restored).' },
  )
}

/** Result kind as shown in the UI. */
export function resultKind(r: ToolResult | undefined): 'ok' | 'invalid' | 'build_errors' | 'audit' | 'cancelled' | 'other' | 'pending' {
  if (!r) return 'pending'
  const head = r.content.split('\n', 1)[0]
  if (head === 'OK') return 'ok'
  if (head === 'AUDIT') return 'audit'
  if (head === 'INVALID') return 'invalid'
  if (head === 'BUILD_ERRORS') return 'build_errors'
  if (head === 'CANCELLED') return 'cancelled'
  return 'other'
}

/** Assistant messages that carry nothing replayable are not stored (providers reject empty turns). */
export function isStorableAssistant(msg: { text: string; toolCalls?: ToolCall[] }): boolean {
  return msg.text.trim().length > 0 || (msg.toolCalls?.length ?? 0) > 0
}
