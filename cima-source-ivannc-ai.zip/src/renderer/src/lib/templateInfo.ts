/** Spanish subtitles and icons for the template gallery (the catalog descriptions are in English for the LLM). */
import type { CadTemplate } from '@shared/templates'

const INFO: Record<string, { subtitle: string; icon: string }> = {
  flange: { subtitle: 'Disco con agujero central, taladros en círculo y cubo opcional.', icon: 'cube' },
  plate_holes: { subtitle: 'Placa rectangular con matriz de taladros y esquinas redondeadas.', icon: 'grid' },
  l_bracket: { subtitle: 'Escuadra de chapa gruesa con pliegue, nervio y taladros en ambas alas.', icon: 'axes' },
  stepped_shaft: { subtitle: 'Eje de revolución con tramos, chavetero, ranura y chaflanes.', icon: 'layers' },
  enclosure: { subtitle: 'Caja vaciada con esquinas redondeadas y torretas para tornillos.', icon: 'cube' },
  pillow_block: { subtitle: 'Soporte de pie con alojamiento de rodamiento y base con taladros.', icon: 'bolt' },
  spacer: { subtitle: 'Tubo corto con diámetro interior y chaflanes.', icon: 'layers' },
  hex_standoff: { subtitle: 'Separador hexagonal con taladro pasante o roscado en los extremos.', icon: 'cube' },
  plate_columns: { subtitle: 'Ensamblaje de dos placas unidas por cuatro columnas.', icon: 'layers' },
}

export function templateSubtitle(t: CadTemplate): string {
  const info = INFO[t.id]
  if (info) return info.subtitle
  const labels = t.params.slice(0, 4).map((p) => p.label.toLowerCase())
  return `Parámetros: ${labels.join(', ')}${t.params.length > 4 ? '…' : ''}.`
}

export function templateIcon(t: CadTemplate): string {
  return INFO[t.id]?.icon ?? 'cube'
}

export const CATEGORY_ORDER: ReadonlyArray<CadTemplate['category']> = ['Piezas', 'Chapa y placas', 'Ejes y revolución', 'Carcasas', 'Ensamblajes']
