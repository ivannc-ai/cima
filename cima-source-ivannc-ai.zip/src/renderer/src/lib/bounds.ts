/** Axis-aligned bounds of a built model in world coordinates (placements applied). */
import type { BuildResponse } from '../kernel/protocol'

export type V3 = [number, number, number]

export function placedBounds(build: Pick<BuildResponse, 'parts' | 'placements'>): { min: V3; max: V3 } | null {
  const min: V3 = [Infinity, Infinity, Infinity]
  const max: V3 = [-Infinity, -Infinity, -Infinity]
  let any = false
  for (const pl of build.placements) {
    const bb = build.parts.find((p) => p.partId === pl.partId)?.bbox
    if (!bb) continue
    const { R, t } = pl.transform
    for (let i = 0; i < 8; i++) {
      const p: V3 = [bb[i & 1 ? 1 : 0][0], bb[i & 2 ? 1 : 0][1], bb[i & 4 ? 1 : 0][2]]
      for (let k = 0; k < 3; k++) {
        const v = R[k * 3]! * p[0] + R[k * 3 + 1]! * p[1] + R[k * 3 + 2]! * p[2] + t[k]!
        if (v < min[k]!) min[k] = v
        if (v > max[k]!) max[k] = v
      }
      any = true
    }
  }
  return any ? { min, max } : null
}
