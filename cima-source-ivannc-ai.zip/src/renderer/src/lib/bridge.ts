/**
 * Access to the `window.cima` bridge. When the renderer runs outside Electron (plain browser during
 * development) a small in-memory mock is used instead so the UI can be previewed: the AI replies
 * with one of the example models, CATIA reports "not available" and files are downloaded.
 */
import type { CimaApi, ProviderTestResult, SaveResult } from '@shared/ipc'
import type { ChatRequest, ChatStreamEvent, UserMessage } from '@shared/ai/types'
import { CAD_TOOL_NAME } from '@shared/ai/types'
import type { CatiaJobEvent, CatiaStatus } from '@shared/catia/types'
import { DEFAULT_SETTINGS, type AppSettings, type SettingsPatch } from '@shared/settings'
import { EXAMPLES } from '@shared/model/examples'

export const isMock = typeof window === 'undefined' || !(window as { cima?: CimaApi }).cima

function download(name: string, data: string | Uint8Array, type = 'application/octet-stream'): SaveResult {
  const blob = new Blob([typeof data === 'string' ? data : new Uint8Array(data)], { type })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = name
  a.click()
  setTimeout(() => URL.revokeObjectURL(url), 2000)
  return { ok: true, path: name }
}

function applyPatch(s: AppSettings, patch: SettingsPatch): AppSettings {
  const next = structuredClone(s)
  if (patch.language) next.language = patch.language
  if (patch.activeProviderId) next.activeProviderId = patch.activeProviderId
  if (patch.ai) Object.assign(next.ai, patch.ai)
  if (patch.catia) Object.assign(next.catia, patch.catia)
  if (patch.viewer) Object.assign(next.viewer, patch.viewer)
  for (const p of patch.providers ?? []) {
    const cur = next.providers.find((x) => x.id === p.id)
    if (cur) Object.assign(cur, p)
    else
      next.providers.push({
        kind: 'openai-compatible',
        label: p.label ?? p.id,
        model: p.model ?? '',
        models: p.models ?? [],
        hasApiKey: false,
        requiresApiKey: p.requiresApiKey ?? true,
        enabled: p.enabled ?? true,
        ...p,
      })
  }
  if (patch.removeProviders) next.providers = next.providers.filter((p) => !patch.removeProviders!.includes(p.id))
  if (!next.providers.some((p) => p.id === next.activeProviderId)) next.activeProviderId = next.providers[0]?.id ?? ''
  return next
}

function createMock(): CimaApi {
  let settings: AppSettings = structuredClone(DEFAULT_SETTINGS)
  settings.providers = settings.providers.map((p) => (p.id === 'anthropic' ? { ...p, hasApiKey: true } : p))
  const aiListeners = new Set<(e: ChatStreamEvent) => void>()
  const catiaListeners = new Set<(e: CatiaJobEvent) => void>()
  const cancelled = new Set<string>()
  const emit = (e: ChatStreamEvent) => aiListeners.forEach((l) => l(e))
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

  async function chat(req: ChatRequest): Promise<void> {
    const id = req.requestId
    emit({ requestId: id, type: 'start', model: 'simulado' })
    const last = [...req.messages].reverse().find((m): m is UserMessage => m.role === 'user')
    const text = (last?.content.find((p) => p.type === 'text') as { text?: string } | undefined)?.text?.toLowerCase() ?? ''
    const ex =
      EXAMPLES.find((e) => text.includes(e.id) || e.title.toLowerCase().split(' ').some((w) => w.length > 4 && text.includes(w))) ??
      EXAMPLES[Math.floor(Math.random() * EXAMPLES.length)]!
    const reply = `Modo navegador (IA simulada). Te propongo **${ex.title}** como punto de partida:\n\n- Modelo paramétrico \`${ex.model.name}\`\n- Ajusta los parámetros en el panel derecho.`
    for (const chunk of reply.match(/.{1,12}/gs) ?? []) {
      if (cancelled.has(id)) break
      emit({ requestId: id, type: 'text_delta', text: chunk })
      await sleep(25)
    }
    const json = JSON.stringify(ex.model)
    for (let b = 0; b < json.length && !cancelled.has(id); b += 600) {
      emit({ requestId: id, type: 'tool_progress', name: CAD_TOOL_NAME, bytes: b })
      await sleep(30)
    }
    if (cancelled.has(id)) {
      emit({ requestId: id, type: 'done', message: { role: 'assistant', text: reply }, stopReason: 'cancelled' })
      return
    }
    emit({
      requestId: id,
      type: 'done',
      stopReason: 'tool_use',
      message: {
        role: 'assistant',
        text: reply,
        // "plantilla" in the prompt exercises the template tool path of the agent loop.
        toolCalls: text.includes('plantilla')
          ? [{ id: `call_${id}`, name: 'use_cad_template', input: { template: 'flange', name: 'Brida_plantilla', params: [{ name: 'bolt_count', value: 8 }] } }]
          : [{ id: `call_${id}`, name: CAD_TOOL_NAME, input: ex.model }],
      },
    })
  }

  const unavailable = (): never => {
    throw new Error('CATIA no está disponible en el modo navegador.')
  }

  return {
  app: {
    info: async () => ({ name: 'CIMA', version: 'dev', platform: 'browser', isPackaged: false, electron: '', userDataPath: '' }),
    openExternal: async (url) => void window.open(url, '_blank', 'noopener'),
    showItemInFolder: async () => {},
    openLogsFolder: async () => {},
    clientLog: async () => {},
  },
    settings: {
      get: async () => structuredClone(settings),
      update: async (patch) => (settings = applyPatch(settings, patch)),
      setApiKey: async (providerId, key) =>
        (settings = applyPatch(settings, { providers: [{ id: providerId, hasApiKey: !!key }] })),
      chooseDirectory: async () => 'C:\\CIMA\\salida',
    },
    ai: {
      chat,
      cancel: async (id) => void cancelled.add(id),
      onEvent: (l) => {
        aiListeners.add(l)
        return () => aiListeners.delete(l)
      },
      testProvider: async (): Promise<ProviderTestResult> => ({ ok: true, message: 'Simulado (modo navegador)', latencyMs: 42 }),
    },
    catia: {
      status: async (): Promise<CatiaStatus> => ({
        platformSupported: false,
        cscriptAvailable: false,
        running: false,
        error: 'Modo navegador: CATIA no disponible.',
      }),
      generateScript: async (req) =>
        `' Vista previa simulada (modo navegador)\n' Modelo: ${req.model.name}\n' Destino: ${req.options.target} / ${req.options.flavor}\n`,
      push: async () => unavailable(),
      cancel: async () => {},
      onEvent: (l) => {
        catiaListeners.add(l)
        return () => catiaListeners.delete(l)
      },
      exportMacro: async (req, name) =>
        download(`${name}.${req.options.flavor === 'catscript' ? 'catvbs' : 'vbs'}`, `' ${req.model.name}\n`, 'text/plain'),
      inspect: async () => unavailable(),
      setParameters: async () => unavailable(),
      listStartModels: async () => ({ models: [] }),
    },
    files: {
      openProject: async () => null,
      saveProject: async (project, options) =>
        options?.path && !options.saveAs
          ? { ok: true, path: options.path }
          : download(`${project.name || 'proyecto'}.cima`, JSON.stringify(project, null, 2), 'application/json'),
      saveFile: async (req) => download(req.defaultName, req.data),
    },
  }
}

export const cima: CimaApi = isMock ? createMock() : window.cima
