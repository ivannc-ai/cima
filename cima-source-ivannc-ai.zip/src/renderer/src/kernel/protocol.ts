/** Messages exchanged between the renderer and the geometry kernel Web Worker. */
import type { CadModel } from '@shared/model/schema'
import type { ParamOverrides } from '@shared/model/evaluate'
import type { RigidTransform } from '@shared/model/geometry'
import type { FeatureBuildResult } from '@kernel/builder'
import type { AuditFinding } from '@kernel/audit'

export type { AuditFinding }

export interface PartMesh {
  vertices: Float32Array
  normals: Float32Array
  triangles: Uint32Array
  /** Triangle ranges per B-rep face (start/count in triangle-index units). */
  faceGroups: Array<{ start: number; count: number; faceId: number }>
  /** Line segments (pairs of points) of the B-rep edges. */
  edges: Float32Array
}

export interface BuiltPart {
  partId: string
  features: FeatureBuildResult[]
  volume: number | null
  error?: string
  mesh: PartMesh | null
  bbox: [[number, number, number], [number, number, number]] | null
}

export interface BuildResponse {
  parts: BuiltPart[]
  placements: Array<{ instanceId: string; partId: string; name: string; transform: RigidTransform; color?: string }>
  errors: string[]
  durationMs: number
}

export type KernelRequest =
  | { id: number; type: 'init' }
  | { id: number; type: 'build'; model: CadModel; overrides: ParamOverrides }
  | { id: number; type: 'export'; format: 'step' | 'stl'; model: CadModel; overrides: ParamOverrides }
  /** Audits a model (reuses the cached build) against the user's request text. */
  | { id: number; type: 'audit'; model: CadModel; overrides: ParamOverrides; request?: string }

export type KernelResponse =
  | { id: number; ok: true; type: 'init' }
  | { id: number; ok: true; type: 'build'; result: BuildResponse }
  | { id: number; ok: true; type: 'export'; data: ArrayBuffer }
  | { id: number; ok: true; type: 'audit'; findings: AuditFinding[] }
  | { id: number; ok: false; error: string }
