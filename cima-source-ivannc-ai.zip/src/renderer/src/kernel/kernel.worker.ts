/// <reference lib="webworker" />
/** Geometry kernel Web Worker: OpenCascade (replicad) builds, meshes and exports CIMA models. */
import opencascade from 'replicad-opencascadejs'
import wasmUrl from 'replicad-opencascadejs/wasm?url'
import { makeCompound, setOC, type Shape3D } from 'replicad'
import { buildModel, errorMessage, modelToStep, placeShape, type ModelBuildResult } from '@kernel/builder'
import { auditModel } from '@kernel/audit'
import type { CadModel } from '@shared/model/schema'
import type { ParamOverrides } from '@shared/model/evaluate'
import type { BuildResponse, BuiltPart, KernelRequest, KernelResponse } from './protocol'

declare const self: DedicatedWorkerGlobalScope

let ready: Promise<void> | null = null
function init(): Promise<void> {
  if (!ready) {
    ready = (async () => {
      const factory = opencascade as unknown as (opts: object) => Promise<unknown>
      const OC = await factory({ locateFile: () => wasmUrl })
      setOC(OC as Parameters<typeof setOC>[0])
    })()
  }
  return ready
}

let cache: { key: string; built: ModelBuildResult } | null = null

/** Cache key that ignores display colors (a color change must not rebuild the geometry). */
function geometryKey(model: CadModel, overrides: ParamOverrides): string {
  return JSON.stringify([model, overrides], (k, v) => (k === 'color' ? undefined : v))
}

function build(model: CadModel, overrides: ParamOverrides): ModelBuildResult {
  const key = geometryKey(model, overrides)
  if (cache?.key === key) {
    // Same geometry: only refresh the colors of the placements from the new model.
    const parts = new Map(model.parts.map((p) => [p.id, p]))
    const insts = new Map((model.instances ?? []).map((i) => [i.id, i]))
    cache.built.placements = cache.built.placements.map((pl) => ({
      ...pl,
      color: insts.get(pl.instanceId)?.color ?? parts.get(pl.partId)?.color,
    }))
    return cache.built
  }
  const built = buildModel(model, overrides)
  cache = { key, built }
  return built
}

function meshPart(shape: Shape3D | null): Pick<BuiltPart, 'mesh' | 'bbox'> {
  if (!shape) return { mesh: null, bbox: null }
  const m = shape.mesh({ tolerance: 0.05, angularTolerance: 0.2 })
  const e = shape.meshEdges({ tolerance: 0.05, angularTolerance: 0.2 })
  const bb = shape.boundingBox.bounds as BuiltPart['bbox']
  return {
    mesh: {
      vertices: Float32Array.from(m.vertices),
      normals: Float32Array.from(m.normals),
      triangles: Uint32Array.from(m.triangles),
      faceGroups: m.faceGroups.map((g) => ({ start: g.start, count: g.count, faceId: g.faceId })),
      edges: Float32Array.from(e.lines),
    },
    bbox: bb,
  }
}

function reply(msg: KernelResponse, transfer: Transferable[] = []): void {
  self.postMessage(msg, transfer)
}

self.onmessage = async (ev: MessageEvent<KernelRequest>) => {
  const req = ev.data
  try {
    await init()
    if (req.type === 'init') return reply({ id: req.id, ok: true, type: 'init' })
    if (req.type === 'build') {
      const t0 = performance.now()
      const built = build(req.model, req.overrides)
      const transfer: Transferable[] = []
      const parts: BuiltPart[] = built.parts.map((p) => {
        let meshed: Pick<BuiltPart, 'mesh' | 'bbox'> = { mesh: null, bbox: null }
        try {
          meshed = meshPart(p.shape)
        } catch (e) {
          return { partId: p.partId, features: p.features, volume: p.volume, error: `mesh: ${errorMessage(e)}`, mesh: null, bbox: null }
        }
        if (meshed.mesh) {
          const mm = meshed.mesh
          transfer.push(mm.vertices.buffer, mm.normals.buffer, mm.triangles.buffer, mm.edges.buffer)
        }
        return { partId: p.partId, features: p.features, volume: p.volume, error: p.error, ...meshed }
      })
      const result: BuildResponse = { parts, placements: built.placements, errors: built.errors, durationMs: performance.now() - t0 }
      return reply({ id: req.id, ok: true, type: 'build', result }, transfer)
    }
    if (req.type === 'audit') {
      const built = build(req.model, req.overrides)
      return reply({ id: req.id, ok: true, type: 'audit', findings: auditModel(req.model, built, req.request) })
    }
    if (req.type === 'export') {
      const built = build(req.model, req.overrides)
      let blob: Blob
      if (req.format === 'step') blob = modelToStep(req.model, built)
      else {
        const byId = new Map(built.parts.map((p) => [p.partId, p.shape]))
        const shapes = built.placements
          .map((pl) => {
            const s = byId.get(pl.partId)
            return s ? (req.model.kind === 'assembly' ? placeShape(s, pl.transform) : s) : null
          })
          .filter((s): s is Shape3D => !!s)
        if (shapes.length === 0) throw new Error('No hay geometría que exportar')
        const target = shapes.length === 1 ? shapes[0]! : (makeCompound(shapes) as Shape3D)
        blob = target.blobSTL({ binary: true, tolerance: 0.02, angularTolerance: 0.1 } as never)
      }
      const data = await blob.arrayBuffer()
      return reply({ id: req.id, ok: true, type: 'export', data }, [data])
    }
  } catch (e) {
    reply({ id: req.id, ok: false, error: errorMessage(e) })
  }
}
