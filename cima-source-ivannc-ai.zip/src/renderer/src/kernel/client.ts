/** Promise-based client of the geometry kernel worker (single shared instance). */
import type { CadModel } from '@shared/model/schema'
import type { ParamOverrides } from '@shared/model/evaluate'
import type { AuditFinding, BuildResponse, KernelRequest, KernelResponse } from './protocol'

type Pending = { resolve: (v: KernelResponse) => void; reject: (e: Error) => void }
/** Distributive Omit so each request variant keeps its own fields. */
type RequestBody = KernelRequest extends infer R ? (R extends KernelRequest ? Omit<R, 'id'> : never) : never

class KernelClient {
  private worker: Worker | null = null
  private seq = 0
  private pending = new Map<number, Pending>()

  private ensure(): Worker {
    if (!this.worker) {
      this.worker = new Worker(new URL('./kernel.worker.ts', import.meta.url), { type: 'module' })
      this.worker.onmessage = (ev: MessageEvent<KernelResponse>) => {
        const p = this.pending.get(ev.data.id)
        if (!p) return
        this.pending.delete(ev.data.id)
        p.resolve(ev.data)
      }
      this.worker.onerror = (ev) => {
        const err = new Error(`Error del motor geométrico: ${ev.message || 'desconocido'}`)
        for (const p of this.pending.values()) p.reject(err)
        this.pending.clear()
        this.worker?.terminate()
        this.worker = null
      }
    }
    return this.worker
  }

  private send(req: RequestBody): Promise<KernelResponse> {
    const id = ++this.seq
    const w = this.ensure()
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject })
      w.postMessage({ ...req, id } as KernelRequest)
    })
  }

  async init(): Promise<void> {
    const r = await this.send({ type: 'init' })
    if (!r.ok) throw new Error(r.error)
  }

  async build(model: CadModel, overrides: ParamOverrides): Promise<BuildResponse> {
    const r = await this.send({ type: 'build', model, overrides })
    if (!r.ok) throw new Error(r.error)
    if (r.type !== 'build') throw new Error('unexpected kernel response')
    return r.result
  }

  /** Audits a model against the user's request (dimensions, holes, geometry sanity). */
  async audit(model: CadModel, overrides: ParamOverrides, request?: string): Promise<AuditFinding[]> {
    const r = await this.send({ type: 'audit', model, overrides, request })
    if (!r.ok) throw new Error(r.error)
    if (r.type !== 'audit') throw new Error('unexpected kernel response')
    return r.findings
  }

  async export(format: 'step' | 'stl', model: CadModel, overrides: ParamOverrides): Promise<Uint8Array> {
    const r = await this.send({ type: 'export', format, model, overrides })
    if (!r.ok) throw new Error(r.error)
    if (r.type !== 'export') throw new Error('unexpected kernel response')
    return new Uint8Array(r.data)
  }
}

export const kernel = new KernelClient()
