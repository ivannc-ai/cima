/**
 * Conversation + renderer-side agent loop.
 *
 * The conversation (`messages`) is append-only and is sent verbatim to the provider on every turn.
 * Assistant messages are stored exactly as received in the 'done' event (including `raw`).
 * Tool results are always attached to the NEXT user message (automatic repair turn or the user's next
 * message), so every assistant tool call has a result before any new user text.
 */
import { create } from 'zustand'
import type {
  ChatContentPart,
  ChatMessage,
  ChatStreamEvent,
  ImageMediaType,
  StopReason,
  ToolCall,
  ToolResult,
  UserMessage,
  AssistantMessage,
} from '@shared/ai/types'
import { TOOL_NUDGE_TEXT } from '@shared/ai/types'
import { validateModel } from '@shared/model/validate'
import { TEMPLATE_TOOL_NAME, findTemplate, instantiateTemplate } from '@shared/templates'
import { cima } from '../lib/bridge'
import {
  REPAIR_TEXT,
  REPAIR_TEXT_TEMPLATE,
  auditResult,
  isModelTool,
  lastUserRequest,
  parseTemplateCall,
  templateErrorResult,
  withNotes,
  isNudgeMessage,
  looksLikeDesignWithoutModel,
  buildErrorsResult,
  buildFailures,
  cancelledResult,
  completeToolResults,
  ignoredToolResult,
  invalidResult,
  isStorableAssistant,
  okResult,
  unknownToolResult,
  withCurrentModel,
} from '../lib/agent'
import { errorText, uid } from '../lib/labels'
import { kernel } from '../kernel/client'
import type { AuditFinding } from '../kernel/protocol'
import { effectiveModel, useModel } from './model'
import { activeProvider, providerReady, useSettings } from './settings'

export interface PendingImage {
  id: string
  mediaType: ImageMediaType
  data: string
  name: string
  size: number
}

export interface Notice {
  id: string
  /** Rendered after messages[afterIndex - 1]. */
  afterIndex: number
  kind: 'error' | 'info' | 'warning' | 'missing_key'
  text: string
  retry?: boolean
  openSettings?: boolean
}

export interface StreamState {
  requestId: string
  text: string
  thinking: string
  toolBytes: number
  toolActive: boolean
  model?: string
  startedAt: number
}

type Terminal =
  | { type: 'done'; message: AssistantMessage; stopReason: StopReason }
  | { type: 'error'; error: { message: string; code?: string; retryable?: boolean } }

interface ChatState {
  messages: ChatMessage[]
  pendingToolResults: ToolResult[]
  notices: Notice[]
  stream: StreamState | null
  busy: boolean
  repairing: number
  /** Compact JSON of the model the AI last emitted or was last shown (null = unknown to the AI). */
  knownModelJson: string | null
  send(text: string, images: PendingImage[]): Promise<boolean>
  retry(): Promise<void>
  stop(): void
  reset(messages?: ChatMessage[]): void
  addNotice(n: Omit<Notice, 'id' | 'afterIndex'>): void
  dismissNotice(id: string): void
}

const resolvers = new Map<string, (t: Terminal) => void>()
let stopRequested = false
/** Incremented on reset/load so that turns of a discarded conversation are ignored. */
let epoch = 0
let currentPrompt = ''

function finish(requestId: string, t: Terminal): void {
  const r = resolvers.get(requestId)
  if (!r) return
  resolvers.delete(requestId)
  r(t)
}

const AUTH_RE = /api[ _-]?key|401|403|unauthori[sz]ed|authentication|permission/i

export const useChat = create<ChatState>((set, get) => {
  const append = (m: ChatMessage) => {
    set((s) => ({ messages: [...s.messages, m] }))
    useModel.getState().markDirty()
  }

  const notice = (n: Omit<Notice, 'id' | 'afterIndex'>) =>
    set((s) => ({ notices: [...s.notices, { ...n, id: uid('n'), afterIndex: s.messages.length }] }))

  /**
   * Processes the first model tool call of a turn (emit_cad_model or use_cad_template): validation, new
   * version, kernel build and (when enabled) the generation audit.
   */
  async function processModelCall(tc: ToolCall): Promise<{ result: ToolResult; repair: boolean; template: boolean; created: boolean }> {
    const template = tc.name === TEMPLATE_TOOL_NAME
    let input: unknown = tc.input
    let notes: string[] = []
    let note: string | undefined
    if (template) {
      const call = parseTemplateCall(tc.input)
      if ('error' in call) return { result: templateErrorResult(tc.id, [call.error]), repair: true, template, created: false }
      const inst = instantiateTemplate(call.template, call.params, call.name)
      if (inst.errors.length || !inst.model) {
        const errs = inst.errors.length ? inst.errors : ['the template produced no model']
        return { result: withNotes(templateErrorResult(tc.id, errs), inst.warnings), repair: true, template, created: false }
      }
      input = inst.model
      notes = inst.warnings
      note = `Plantilla: ${findTemplate(call.template)?.title ?? call.template}`
    }
    const v = validateModel(input)
    if (!v.ok || !v.model) return { result: withNotes(invalidResult(tc.id, v.issues), notes), repair: true, template, created: false }
    const model = v.model
    const version = useModel.getState().addVersion(model, 'ai', { prompt: currentPrompt || undefined, toolCallId: tc.id, note })
    // The LLM never saw the JSON generated by a template: the next user message must attach <current_model>.
    set({ knownModelJson: template ? null : JSON.stringify(effectiveModel(model, {})) })
    const done = (result: ToolResult, repair: boolean) => ({ result: withNotes(result, notes), repair, template, created: true })
    let build
    try {
      build = await kernel.build(model, {})
    } catch (e) {
      if (useModel.getState().kernelState === 'error') {
        return done(okResult(tc.id, model, null, `Note: preview kernel unavailable (${errorText(e)}); model validated only.`), false)
      }
      return done(buildErrorsResult(tc.id, [`kernel: ${errorText(e)}`]), true)
    }
    const failures = buildFailures(build)
    if (failures.length) return done(buildErrorsResult(tc.id, failures), true)
    const ok = okResult(tc.id, model, build)
    if (!useSettings.getState().settings.ai.audit) return done(ok, false)
    let findings: AuditFinding[]
    try {
      findings = await kernel.audit(model, {}, lastUserRequest(get().messages) || undefined)
    } catch {
      return done(ok, false)
    }
    useModel.getState().setVersionAudit(version.id, findings)
    if (findings.some((f) => f.fix)) return done(auditResult(tc.id, findings), true)
    notes = [...notes, ...findings.filter((f) => f.llm).map((f) => `[${f.code}] ${f.llm}`)]
    return done(ok, false)
  }

  async function handleDone(message: AssistantMessage, stopReason: StopReason): Promise<void> {
    const stored = isStorableAssistant(message)
    if (stored) append(message)
    const calls = stored ? (message.toolCalls ?? []) : []

    if (stopReason === 'cancelled' || stopRequested) {
      set({ pendingToolResults: calls.map((c) => cancelledResult(c.id)), busy: false, repairing: 0 })
      notice({ kind: 'info', text: 'Generación detenida.' })
      return
    }
    if (stopReason === 'refusal') {
      notice({ kind: 'warning', text: 'El proveedor ha rechazado la solicitud. Reformula la petición o prueba con otro modelo.' })
    } else if (stopReason === 'max_tokens') {
      notice({ kind: 'warning', text: 'La respuesta se ha cortado por el límite de tokens del modelo.', retry: !calls.length })
    } else if (!stored) {
      notice({ kind: 'warning', text: 'El modelo devolvió una respuesta vacía.', retry: true })
    }
    if (!calls.length) {
      // Some models (e.g. "lite" ones) describe the design and stop without emitting it: insist once,
      // the provider layer forces the tool call on that follow-up where supported.
      const lastUser = [...get().messages].reverse().find((m) => m.role === 'user')
      const alreadyNudged = !!lastUser && isNudgeMessage(lastUser)
      if (stored && stopReason === 'end_turn' && !alreadyNudged && looksLikeDesignWithoutModel(message.text)) {
        append({ role: 'user', content: [{ type: 'text', text: TOOL_NUDGE_TEXT }] })
        await runTurn()
        return
      }
      if (stored && alreadyNudged) {
        notice({
          kind: 'warning',
          text: 'La IA no ha entregado el modelo 3D. Prueba a pedirlo de nuevo («genera el modelo») o usa un modelo más capaz.',
          retry: true,
        })
      }
      set({ busy: false, repairing: 0 })
      return
    }

    const startEpoch = epoch
    const results: ToolResult[] = []
    let repair = false
    let cadHandled = false
    let viaTemplate = false
    let created = false
    for (const tc of calls) {
      if (!isModelTool(tc.name)) {
        results.push(unknownToolResult(tc))
        continue
      }
      if (cadHandled) {
        results.push(ignoredToolResult(tc))
        continue
      }
      cadHandled = true
      const r = await processModelCall(tc)
      results.push(r.result)
      repair ||= r.repair
      viaTemplate = r.template
      created = r.created
    }
    if (!cadHandled) repair = true
    if (startEpoch !== epoch) return

    const max = useSettings.getState().settings.ai.maxRepairAttempts
    const attempt = get().repairing
    if (repair && !stopRequested && attempt < max) {
      set({ repairing: attempt + 1 })
      let text = viaTemplate ? REPAIR_TEXT_TEMPLATE : REPAIR_TEXT
      const current = useModel.getState().model
      if (viaTemplate && created && current && get().knownModelJson === null) {
        // Give the LLM the JSON generated by the template so that it can also fix it with emit_cad_model.
        const eff = effectiveModel(current, {})
        text = withCurrentModel(text, JSON.stringify(eff, null, 2))
        set({ knownModelJson: JSON.stringify(eff) })
      }
      append({ role: 'user', content: [{ type: 'text', text }], toolResults: results })
      await runTurn()
      return
    }
    set({ pendingToolResults: results, busy: false, repairing: 0 })
    if (repair && !stopRequested) {
      const auditOnly = results.some((r) => r.content.startsWith('AUDIT\n')) && !results.some((r) => /^(INVALID|BUILD_ERRORS)\n/.test(r.content))
      notice({
        kind: 'warning',
        text: auditOnly
          ? `La auditoría sigue encontrando diferencias con la petición${max > 0 ? ` tras ${max} intento${max === 1 ? '' : 's'} automáticos` : ''}. Revisa los avisos de la versión o precisa la petición.`
          : max > 0
            ? `No se pudo corregir el modelo tras ${max} intento${max === 1 ? '' : 's'} automáticos. Describe el problema o pide otro enfoque.`
            : 'El modelo generado tiene errores (reparación automática desactivada).',
      })
    }
  }

  async function runTurn(): Promise<void> {
    const settings = useSettings.getState().settings
    const provider = activeProvider(settings)
    if (!provider || !providerReady(provider)) {
      set({ busy: false, stream: null, repairing: 0 })
      notice({
        kind: 'missing_key',
        text: provider ? `Falta la clave API de ${provider.label}.` : 'No hay ningún proveedor de IA activo.',
        openSettings: true,
        retry: true,
      })
      return
    }
    const requestId = uid('r')
    set({
      busy: true,
      stream: { requestId, text: '', thinking: '', toolBytes: 0, toolActive: false, startedAt: Date.now() },
    })
    const terminal = new Promise<Terminal>((resolve) => resolvers.set(requestId, resolve))
    cima.ai
      .chat({ requestId, providerId: provider.id, model: provider.model || undefined, messages: get().messages })
      .then(() =>
        setTimeout(
          () => finish(requestId, { type: 'error', error: { message: 'La respuesta del proveedor terminó sin completarse.', retryable: true } }),
          400,
        ),
      )
      .catch((e) => finish(requestId, { type: 'error', error: { message: errorText(e), retryable: true } }))

    const myEpoch = epoch
    const t = await terminal
    if (myEpoch !== epoch) return
    set({ stream: null })
    if (t.type === 'error') {
      set({ busy: false, repairing: 0 })
      if (stopRequested) {
        notice({ kind: 'info', text: 'Generación detenida.', retry: true })
        return
      }
      const auth = AUTH_RE.test(`${t.error.code ?? ''} ${t.error.message}`)
      notice({ kind: 'error', text: t.error.message || 'Error desconocido del proveedor.', retry: true, openSettings: auth })
      return
    }
    await handleDone(t.message, t.stopReason)
  }

  return {
    messages: [],
    pendingToolResults: [],
    notices: [],
    stream: null,
    busy: false,
    repairing: 0,
    knownModelJson: null,

    async send(text, images) {
      if (get().busy) return false
      const settings = useSettings.getState().settings
      const provider = activeProvider(settings)
      if (!provider || !providerReady(provider)) {
        notice({
          kind: 'missing_key',
          text: provider
            ? `Configura la clave API de ${provider.label} para chatear con la IA. Mientras tanto puedes cargar un ejemplo.`
            : 'No hay ningún proveedor de IA activo.',
          openSettings: true,
        })
        return false
      }
      const typed = text.trim()
      let full = typed || (images.length ? 'Usa la imagen adjunta como referencia para el modelo.' : '')
      if (!full) return false
      const { model, overrides } = useModel.getState()
      if (model) {
        const eff = effectiveModel(model, overrides)
        const compact = JSON.stringify(eff)
        if (compact !== get().knownModelJson) {
          full = withCurrentModel(full, JSON.stringify(eff, null, 2))
          set({ knownModelJson: compact })
        }
      }
      const toolResults = completeToolResults(get().messages, get().pendingToolResults)
      const content: ChatContentPart[] = [
        ...images.map((im) => ({ type: 'image' as const, mediaType: im.mediaType, data: im.data, name: im.name })),
        { type: 'text', text: full },
      ]
      const msg: UserMessage = toolResults.length ? { role: 'user', content, toolResults } : { role: 'user', content }
      currentPrompt = typed
      stopRequested = false
      set({ pendingToolResults: [], repairing: 0, notices: get().notices.filter((n) => !n.retry) })
      append(msg)
      await runTurn()
      return true
    },

    async retry() {
      if (get().busy) return
      const last = get().messages[get().messages.length - 1]
      set({ notices: get().notices.filter((n) => !n.retry) })
      if (!last || last.role !== 'user') return
      stopRequested = false
      await runTurn()
    },

    stop() {
      stopRequested = true
      const s = get().stream
      if (s) void cima.ai.cancel(s.requestId).catch(() => {})
    },

    reset(messages = []) {
      epoch++
      const s = get().stream
      if (s) {
        stopRequested = true
        void cima.ai.cancel(s.requestId).catch(() => {})
        finish(s.requestId, { type: 'error', error: { message: 'reset' } })
      }
      set({
        messages,
        pendingToolResults: completeToolResults(messages, []),
        notices: [],
        stream: null,
        busy: false,
        repairing: 0,
        knownModelJson: null,
      })
    },

    addNotice: notice,
    dismissNotice(id) {
      set((s) => ({ notices: s.notices.filter((n) => n.id !== id) }))
    },
  }
})

/** Routes provider stream events to the active request. */
let listening = false
export function startChatEvents(): void {
  if (listening) return
  listening = true
  cima.ai.onEvent((ev: ChatStreamEvent) => {
    const st = useChat.getState().stream
    if (ev.type === 'done') return finish(ev.requestId, { type: 'done', message: ev.message, stopReason: ev.stopReason })
    if (ev.type === 'error') return finish(ev.requestId, { type: 'error', error: ev.error })
    if (!st || st.requestId !== ev.requestId) return
    switch (ev.type) {
      case 'start':
        useChat.setState({ stream: { ...st, model: ev.model } })
        break
      case 'text_delta':
        useChat.setState({ stream: { ...st, text: st.text + ev.text } })
        break
      case 'thinking_delta':
        useChat.setState({ stream: { ...st, thinking: st.thinking + ev.text } })
        break
      case 'tool_progress':
        useChat.setState({ stream: { ...st, toolBytes: ev.bytes, toolActive: true } })
        break
    }
  })
}
