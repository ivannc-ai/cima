/** CATIA connection status and push jobs (log survives tab switches). */
import { create } from 'zustand'
import type { CatiaInspection, CatiaJobEvent, CatiaJobResult, CatiaStatus } from '@shared/catia/types'
import { cima } from '../lib/bridge'
import { errorText, uid } from '../lib/labels'
import { catiaOptions } from '../lib/actions'
import { useModel } from './model'
import { useSettings } from './settings'
import { toast } from './ui'

export interface LogLine {
  id: number
  level: 'info' | 'warn' | 'error' | 'ok'
  text: string
}

interface CatiaState {
  status: CatiaStatus | null
  checking: boolean
  statusError: string | null
  jobId: string | null
  log: LogLine[]
  result: CatiaJobResult | null
  jobError: string | null
  inspection: CatiaInspection | null
  inspecting: boolean
  /** Local start model chosen for the next push (path; empty = empty document). */
  startModel: string | null
  setStartModel(path: string | null): void
  /** Custom name for the Part/Product created from the start model (empty = use the model name). */
  startModelName: string
  setStartModelName(name: string): void
  refresh(): Promise<void>
  push(): Promise<void>
  cancel(): void
  inspect(): Promise<void>
  sendValues(values: Array<{ name: string; value: number }>): Promise<void>
  clearLog(): void
}

let lineId = 0

export const useCatia = create<CatiaState>((set, get) => {
  const log = (level: LogLine['level'], text: string) =>
    set((s) => ({ log: [...s.log.slice(-800), { id: ++lineId, level, text }] }))

  return {
    status: null,
    checking: false,
    statusError: null,
    jobId: null,
    log: [],
    result: null,
    jobError: null,
    inspection: null,
    inspecting: false,
    startModel: null,
    startModelName: '',

    setStartModel(path) {
      set({ startModel: path })
    },

    setStartModelName(name) {
      set({ startModelName: name })
    },

    async refresh() {
      if (get().checking) return
      set({ checking: true })
      try {
        set({ status: await cima.catia.status(), statusError: null })
      } catch (e) {
        set({ statusError: errorText(e) })
      } finally {
        set({ checking: false })
      }
    },

    async push() {
      const { model, overrides } = useModel.getState()
      if (!model || get().jobId) return
      const settings = useSettings.getState().settings
      const jobId = uid('job')
      set({ jobId, log: [], result: null, jobError: null })
      log('info', `Enviando «${model.name}» a CATIA…`)
      try {
        const result = await cima.catia.push({
          jobId,
          model,
          overrides,
          options: catiaOptions(settings, get().status, 'vbs', get().startModel, get().startModelName),
          timeoutMs: settings.catia.timeoutSec * 1000,
        })
        set({ result })
        if (result.cancelled) log('warn', 'Trabajo cancelado.')
        else if (result.timedOut) log('error', 'Tiempo de espera agotado.')
        else log(result.ok ? 'ok' : 'error', result.ok ? `Completado en ${(result.durationMs / 1000).toFixed(1)} s` : 'Terminado con errores.')
        if (result.ok) toast('success', 'Modelo enviado a CATIA.')
        else if (!result.cancelled) toast('error', 'CATIA terminó con errores. Revisa el registro.')
      } catch (e) {
        const msg = errorText(e)
        set({ jobError: msg })
        log('error', msg)
        toast('error', `No se pudo enviar a CATIA: ${msg}`)
      } finally {
        set({ jobId: null })
        void get().refresh()
      }
    },

    cancel() {
      const id = get().jobId
      if (id) void cima.catia.cancel(id).catch(() => {})
    },

    async inspect() {
      set({ inspecting: true })
      try {
        const inspection = await cima.catia.inspect()
        set({ inspection })
        if (!inspection.ok) toast('warning', inspection.error ?? 'No se pudo leer el documento activo.')
      } catch (e) {
        set({ inspection: { ok: false, parameters: [], error: errorText(e) } })
      } finally {
        set({ inspecting: false })
      }
    },

    async sendValues(values) {
      if (!values.length) return
      try {
        const r = await cima.catia.setParameters({ values })
        if (r.ok) toast('success', `${values.length} parámetro(s) actualizados en CATIA.`)
        else toast('error', `CATIA devolvió errores: ${r.errors.join('; ') || 'desconocido'}`)
        void get().inspect()
      } catch (e) {
        toast('error', `No se pudieron enviar los valores: ${errorText(e)}`)
      }
    },

    clearLog() {
      set({ log: [], result: null, jobError: null })
    },
  }
})

let listening = false
export function startCatiaEvents(): void {
  if (listening) return
  listening = true
  cima.catia.onEvent((ev: CatiaJobEvent) => {
    const st = useCatia.getState()
    if (!st.jobId || ev.jobId !== st.jobId) return
    const add = (level: LogLine['level'], text: string) =>
      useCatia.setState((s) => ({ log: [...s.log.slice(-800), { id: ++lineId, level, text }] }))
    if (ev.type === 'stderr') return add('error', ev.line)
    if (ev.type === 'stdout') return ev.line.trim() ? add('info', ev.line) : undefined
    const e = ev.event
    switch (e.t) {
      case 'start':
        add('info', `Conectado a CATIA ${e.target === '3dx' ? '3DEXPERIENCE' : 'V5'}${e.version ? ` (${e.version})` : ''}`)
        break
      case 'log':
        add(e.level, e.msg)
        break
      case 'part':
        add(e.status === 'error' ? 'error' : e.status === 'ok' ? 'ok' : 'info', `Pieza ${e.part}: ${e.status === 'start' ? 'creando…' : e.status === 'ok' ? 'creada' : `error${e.msg ? ` — ${e.msg}` : ''}`}`)
        break
      case 'feature':
        add(
          e.status === 'error' ? 'error' : e.status === 'skipped' ? 'warn' : 'ok',
          `${e.part}/${e.feature}: ${e.status === 'ok' ? 'ok' : e.status === 'skipped' ? 'omitida' : 'error'}${e.msg ? ` — ${e.msg}` : ''}`,
        )
        break
      case 'saved':
        add('ok', `Guardado: ${e.path}`)
        break
      case 'end':
        add(e.ok ? 'ok' : 'error', `Fin: ${e.errors} error(es), ${e.warnings} aviso(s)`)
        break
    }
  })
}
