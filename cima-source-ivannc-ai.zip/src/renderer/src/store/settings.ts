/** Settings mirror of the main process (public view, no secrets). */
import { create } from 'zustand'
import type { ProviderConfig } from '@shared/ai/types'
import { DEFAULT_SETTINGS, type AppSettings, type SettingsPatch } from '@shared/settings'
import { cima } from '../lib/bridge'
import { errorText } from '../lib/labels'
import { toast } from './ui'

interface SettingsState {
  settings: AppSettings
  loaded: boolean
  load(): Promise<void>
  update(patch: SettingsPatch): Promise<AppSettings | null>
  setApiKey(providerId: string, key: string | null): Promise<boolean>
}

export const useSettings = create<SettingsState>((set) => ({
  settings: DEFAULT_SETTINGS,
  loaded: false,
  async load() {
    try {
      set({ settings: await cima.settings.get(), loaded: true })
    } catch (e) {
      set({ loaded: true })
      toast('error', `No se pudieron cargar los ajustes: ${errorText(e)}`)
    }
  },
  async update(patch) {
    try {
      const settings = await cima.settings.update(patch)
      set({ settings })
      return settings
    } catch (e) {
      toast('error', `No se pudieron guardar los ajustes: ${errorText(e)}`)
      return null
    }
  },
  async setApiKey(providerId, key) {
    try {
      set({ settings: await cima.settings.setApiKey(providerId, key) })
      return true
    } catch (e) {
      toast('error', `No se pudo guardar la clave: ${errorText(e)}`)
      return false
    }
  },
}))

export function activeProvider(s: AppSettings): ProviderConfig | undefined {
  return s.providers.find((p) => p.id === s.activeProviderId) ?? s.providers.find((p) => p.enabled)
}

export function providerReady(p: ProviderConfig | undefined): boolean {
  return !!p && p.enabled && (!p.requiresApiKey || p.hasApiKey)
}
