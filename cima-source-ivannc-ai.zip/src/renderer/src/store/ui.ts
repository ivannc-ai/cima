/** UI state: toasts, dialogs, active tab, panel sizes. */
import { create } from 'zustand'
import { uid } from '../lib/labels'

export type ToastKind = 'info' | 'success' | 'error' | 'warning'
export interface Toast {
  id: string
  kind: ToastKind
  text: string
  action?: { label: string; run: () => void }
}

export type RightTab = 'params' | 'tree' | 'catia' | 'json'

interface ConfirmState {
  title: string
  message: string
  okLabel: string
  danger?: boolean
  resolve: (ok: boolean) => void
}

interface UiState {
  toasts: Toast[]
  rightTab: RightTab
  settingsOpen: boolean
  helpOpen: boolean
  templatesOpen: boolean
  /** Text of the chat composer (shared so that Help can insert example prompts). */
  draft: string
  /** Incremented to ask the composer to take focus. */
  focusTick: number
  confirm: ConfirmState | null
  leftWidth: number
  rightWidth: number
  toast(kind: ToastKind, text: string, action?: Toast['action']): void
  dismissToast(id: string): void
  setRightTab(t: RightTab): void
  setSettingsOpen(open: boolean): void
  setHelpOpen(open: boolean): void
  setTemplatesOpen(open: boolean): void
  setDraft(text: string): void
  insertPrompt(text: string): void
  ask(opts: Omit<ConfirmState, 'resolve' | 'okLabel'> & { okLabel?: string }): Promise<boolean>
  closeConfirm(ok: boolean): void
  setWidths(w: { left?: number; right?: number }): void
}

function loadWidth(key: string, def: number): number {
  try {
    const v = Number(localStorage.getItem(key))
    return Number.isFinite(v) && v > 200 ? v : def
  } catch {
    return def
  }
}

export const useUi = create<UiState>((set, get) => ({
  toasts: [],
  rightTab: 'params',
  settingsOpen: false,
  helpOpen: false,
  templatesOpen: false,
  draft: '',
  focusTick: 0,
  confirm: null,
  leftWidth: loadWidth('cima.leftWidth', 400),
  rightWidth: loadWidth('cima.rightWidth', 360),
  toast(kind, text, action) {
    const id = uid('t')
    set((s) => ({ toasts: [...s.toasts.slice(-4), { id, kind, text, action }] }))
    setTimeout(() => get().dismissToast(id), kind === 'error' ? 8000 : 4500)
  },
  dismissToast(id) {
    set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }))
  },
  setRightTab(rightTab) {
    set({ rightTab })
  },
  setSettingsOpen(settingsOpen) {
    set({ settingsOpen })
  },
  setHelpOpen(helpOpen) {
    set({ helpOpen })
  },
  setTemplatesOpen(templatesOpen) {
    set({ templatesOpen })
  },
  setDraft(draft) {
    set({ draft })
  },
  insertPrompt(text) {
    set((s) => ({ draft: text, helpOpen: false, focusTick: s.focusTick + 1 }))
  },
  ask(opts) {
    get().confirm?.resolve(false)
    return new Promise<boolean>((resolve) => set({ confirm: { okLabel: 'Aceptar', ...opts, resolve } }))
  },
  closeConfirm(ok) {
    const c = get().confirm
    set({ confirm: null })
    c?.resolve(ok)
  },
  setWidths({ left, right }) {
    set((s) => ({ leftWidth: left ?? s.leftWidth, rightWidth: right ?? s.rightWidth }))
    try {
      if (left) localStorage.setItem('cima.leftWidth', String(Math.round(left)))
      if (right) localStorage.setItem('cima.rightWidth', String(Math.round(right)))
    } catch {
      /* storage unavailable */
    }
  },
}))

export const toast = (kind: ToastKind, text: string, action?: Toast['action']) => useUi.getState().toast(kind, text, action)
