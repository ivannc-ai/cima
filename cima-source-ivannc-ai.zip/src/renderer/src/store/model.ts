/** Model state: current model, slider overrides, version history, kernel build, selection, project. */
import { create } from 'zustand'
import type { CadModel } from '@shared/model/schema'
import { applyOverridesAsDefaults, type ParamOverrides } from '@shared/model/evaluate'
import type { ModelVersion } from '@shared/project'
import { kernel } from '../kernel/client'
import type { AuditFinding, BuildResponse } from '../kernel/protocol'
import { errorText, uid } from '../lib/labels'

/** Version record; `toolCallId` links AI versions to the assistant tool call that produced them. */
export type UiVersion = ModelVersion & {
  toolCallId?: string
  /** Short origin note, e.g. "Plantilla: Brida circular". */
  note?: string
  /** Generation audit of this version (undefined = not audited). */
  audit?: AuditFinding[]
}

export interface BuildState {
  status: 'idle' | 'building' | 'ok' | 'error'
  result: BuildResponse | null
  /** Kernel failure (exception), not feature errors. */
  error: string | null
  /** Model/overrides the result belongs to. */
  forModel: CadModel | null
}

interface ModelState {
  model: CadModel | null
  overrides: Record<string, number>
  versions: UiVersion[]
  currentVersionId: string | null
  build: BuildState
  kernelState: 'starting' | 'ready' | 'error'
  kernelError: string | null
  selectedInstance: string | null
  projectName: string
  projectPath: string | null
  createdAt: string
  dirty: boolean
  /** Viewport thumbnails per version id (session only, not saved). */
  thumbs: Record<string, string>

  setThumb(versionId: string, url: string): void
  addVersion(
    model: CadModel,
    source: ModelVersion['source'],
    opts?: { prompt?: string; toolCallId?: string; keepOverrides?: boolean; note?: string },
  ): UiVersion
  setVersionAudit(versionId: string, findings: AuditFinding[]): void
  setOverride(key: string, value: number): void
  resetOverride(key: string): void
  resetOverrides(): void
  applyDefaults(): void
  restoreVersion(id: string): void
  toggleSuppress(partId: string, featureId: string): void
  /**
   * Changes display colors (cosmetic: no new version, the current version is updated in place).
   * target 'model' = every part (and clears instance colors); color null = back to the default color.
   */
  setColor(target: { kind: 'model' } | { kind: 'part'; id: string } | { kind: 'instance'; id: string }, color: string | null): void
  select(instanceId: string | null): void
  setProjectName(name: string): void
  markDirty(): void
  markSaved(path: string | null): void
  resetProject(): void
  loadProject(p: { name: string; createdAt: string; model: CadModel | null; overrides: ParamOverrides; history: UiVersion[]; path: string | null }): void
}

const emptyBuild: BuildState = { status: 'idle', result: null, error: null, forModel: null }

export const useModel = create<ModelState>((set, get) => ({
  model: null,
  overrides: {},
  versions: [],
  currentVersionId: null,
  build: emptyBuild,
  kernelState: 'starting',
  kernelError: null,
  selectedInstance: null,
  projectName: 'Proyecto sin título',
  projectPath: null,
  createdAt: new Date().toISOString(),
  dirty: false,
  thumbs: {},

  setThumb(versionId, url) {
    set((s) => ({ thumbs: { ...s.thumbs, [versionId]: url } }))
  },
  addVersion(model, source, opts = {}) {
    const v: UiVersion = {
      id: uid('v'),
      createdAt: new Date().toISOString(),
      source,
      model: structuredClone(model),
      ...(opts.prompt ? { prompt: opts.prompt } : {}),
      ...(opts.toolCallId ? { toolCallId: opts.toolCallId } : {}),
      ...(opts.note ? { note: opts.note } : {}),
    }
    set((s) => ({
      model: v.model,
      versions: [...s.versions, v],
      currentVersionId: v.id,
      overrides: opts.keepOverrides ? s.overrides : {},
      dirty: true,
      selectedInstance: null,
    }))
    return v
  },
  setVersionAudit(versionId, findings) {
    set((s) => ({ versions: s.versions.map((v) => (v.id === versionId ? { ...v, audit: findings } : v)) }))
  },
  setOverride(key, value) {
    if (!Number.isFinite(value)) return
    set((s) => ({ overrides: { ...s.overrides, [key]: value }, dirty: true }))
  },
  resetOverride(key) {
    set((s) => {
      const o = { ...s.overrides }
      delete o[key]
      return { overrides: o, dirty: true }
    })
  },
  resetOverrides() {
    set({ overrides: {}, dirty: true })
  },
  applyDefaults() {
    const { model, overrides } = get()
    if (!model || Object.keys(overrides).length === 0) return
    get().addVersion(applyOverridesAsDefaults(model, overrides), 'user')
  },
  restoreVersion(id) {
    const v = get().versions.find((x) => x.id === id)
    if (!v) return
    set({ model: structuredClone(v.model), currentVersionId: v.id, overrides: {}, dirty: true, selectedInstance: null })
  },
  toggleSuppress(partId, featureId) {
    const { model } = get()
    if (!model) return
    const copy = structuredClone(model)
    const f = copy.parts.find((p) => p.id === partId)?.features.find((x) => x.id === featureId)
    if (!f) return
    if (f.suppressed) delete f.suppressed
    else f.suppressed = true
    get().addVersion(copy, 'user', { keepOverrides: true })
  },
  setColor(target, color) {
    const { model, currentVersionId } = get()
    if (!model) return
    const valid = color === null || /^#[0-9a-fA-F]{6}$/.test(color)
    if (!valid) return
    const copy = structuredClone(model)
    const apply = (o: { color?: string }) => {
      if (color === null) delete o.color
      else o.color = color.toLowerCase()
    }
    if (target.kind === 'model') {
      copy.parts.forEach(apply)
      for (const inst of copy.instances ?? []) delete inst.color
    } else if (target.kind === 'part') {
      const p = copy.parts.find((x) => x.id === target.id)
      if (!p) return
      apply(p)
    } else {
      const inst = copy.instances?.find((x) => x.id === target.id)
      if (!inst) return
      apply(inst)
    }
    set((s) => ({
      model: copy,
      versions: s.versions.map((v) => (v.id === currentVersionId ? { ...v, model: structuredClone(copy) } : v)),
      dirty: true,
    }))
  },
  select(selectedInstance) {
    set({ selectedInstance })
  },
  setProjectName(projectName) {
    set({ projectName, dirty: true })
  },
  markDirty() {
    set({ dirty: true })
  },
  markSaved(projectPath) {
    set({ projectPath, dirty: false })
  },
  resetProject() {
    set({
      model: null,
      overrides: {},
      versions: [],
      currentVersionId: null,
      build: emptyBuild,
      selectedInstance: null,
      projectName: 'Proyecto sin título',
      projectPath: null,
      createdAt: new Date().toISOString(),
      dirty: false,
    })
  },
  loadProject(p) {
    const last = [...p.history].reverse().find((v) => p.model && JSON.stringify(v.model) === JSON.stringify(p.model))
    set({
      model: p.model,
      overrides: { ...p.overrides },
      versions: p.history,
      currentVersionId: last?.id ?? null,
      build: emptyBuild,
      selectedInstance: null,
      projectName: p.name,
      projectPath: p.path,
      createdAt: p.createdAt,
      dirty: false,
    })
  },
}))

/** Effective model = model with the slider values applied as defaults (what CATIA / the LLM should see). */
export function effectiveModel(model: CadModel, overrides: ParamOverrides): CadModel {
  return applyOverridesAsDefaults(model, overrides)
}

// ---------------------------------------------------------------------------
// Kernel: init + debounced rebuild (stale results are ignored)
// ---------------------------------------------------------------------------

let seq = 0
let timer: ReturnType<typeof setTimeout> | null = null

async function rebuild(): Promise<void> {
  const { model, overrides } = useModel.getState()
  const mySeq = ++seq
  if (!model) {
    useModel.setState({ build: emptyBuild })
    return
  }
  useModel.setState((s) => ({ build: { ...s.build, status: 'building' } }))
  try {
    const result = await kernel.build(model, overrides)
    if (mySeq !== seq) return
    useModel.setState({ build: { status: 'ok', result, error: null, forModel: model }, kernelState: 'ready', kernelError: null })
  } catch (e) {
    if (mySeq !== seq) return
    useModel.setState((s) => ({ build: { status: 'error', result: s.build.result, error: errorText(e), forModel: model } }))
  }
}

export function scheduleRebuild(delay = 150): void {
  if (timer) clearTimeout(timer)
  timer = setTimeout(() => {
    timer = null
    void rebuild()
  }, delay)
}

let started = false
export function startKernel(): void {
  if (started) return
  started = true
  kernel
    .init()
    .then(() => useModel.setState({ kernelState: 'ready' }))
    .catch((e) => useModel.setState({ kernelState: 'error', kernelError: errorText(e) }))
  useModel.subscribe((s, prev) => {
    if (s.model !== prev.model || s.overrides !== prev.overrides) scheduleRebuild(s.model !== prev.model ? 0 : 150)
  })
  if (useModel.getState().model) scheduleRebuild(0)
}
