/** Preload: exposes the typed `window.cima` bridge (sandboxed, contextIsolation on). */
import { contextBridge, ipcRenderer, type IpcRendererEvent } from 'electron'
import { IPC_CHANNELS as C, type CimaApi } from '../shared/ipc'

function subscribe<T>(channel: string, listener: (event: T) => void): () => void {
  const wrapped = (_e: IpcRendererEvent, payload: T) => listener(payload)
  ipcRenderer.on(channel, wrapped)
  return () => {
    ipcRenderer.removeListener(channel, wrapped)
  }
}

const api: CimaApi = {
  app: {
    info: () => ipcRenderer.invoke(C.appInfo),
    openExternal: (url) => ipcRenderer.invoke(C.appOpenExternal, url),
    showItemInFolder: (p) => ipcRenderer.invoke(C.appShowItemInFolder, p),
    openLogsFolder: () => ipcRenderer.invoke(C.appOpenLogsFolder),
    clientLog: (level, scope, message) => ipcRenderer.invoke(C.appClientLog, level, scope, message),
  },
  settings: {
    get: () => ipcRenderer.invoke(C.settingsGet),
    update: (patch) => ipcRenderer.invoke(C.settingsUpdate, patch),
    setApiKey: (providerId, apiKey) => ipcRenderer.invoke(C.settingsSetApiKey, providerId, apiKey),
    chooseDirectory: (title) => ipcRenderer.invoke(C.settingsChooseDirectory, title),
  },
  ai: {
    chat: (request) => ipcRenderer.invoke(C.aiChat, request),
    cancel: (requestId) => ipcRenderer.invoke(C.aiCancel, requestId),
    onEvent: (listener) => subscribe(C.aiEvent, listener),
    testProvider: (providerId) => ipcRenderer.invoke(C.aiTestProvider, providerId),
  },
  catia: {
    status: () => ipcRenderer.invoke(C.catiaStatus),
    generateScript: (request) => ipcRenderer.invoke(C.catiaGenerateScript, request),
    push: (request) => ipcRenderer.invoke(C.catiaPush, request),
    cancel: (jobId) => ipcRenderer.invoke(C.catiaCancel, jobId),
    onEvent: (listener) => subscribe(C.catiaEvent, listener),
    exportMacro: (request, suggestedName) => ipcRenderer.invoke(C.catiaExportMacro, request, suggestedName),
    inspect: () => ipcRenderer.invoke(C.catiaInspect),
    setParameters: (request) => ipcRenderer.invoke(C.catiaSetParameters, request),
    listStartModels: (program, release) => ipcRenderer.invoke(C.catiaListStartModels, program, release),
  },
  files: {
    openProject: () => ipcRenderer.invoke(C.filesOpenProject),
    saveProject: (project, options) => ipcRenderer.invoke(C.filesSaveProject, project, options),
    saveFile: (request) => ipcRenderer.invoke(C.filesSaveFile, request),
  },
}

contextBridge.exposeInMainWorld('cima', api)
