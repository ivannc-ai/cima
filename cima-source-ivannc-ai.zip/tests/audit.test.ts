import { beforeAll, describe, expect, it } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import opencascade from 'replicad-opencascadejs'
import { setOC } from 'replicad'
import { buildModel } from '../src/kernel/builder'
import { auditModel } from '../src/kernel/audit'
import { extractRequirements } from '../src/shared/audit/requirements'
import { EXAMPLE_ASSEMBLY, EXAMPLE_BOX, EXAMPLE_FLANGE } from '../src/shared/model/examples'
import type { CadModel } from '../src/shared/model/schema'

beforeAll(async () => {
  const wasm = path.resolve('node_modules/replicad-opencascadejs/dist/replicad_single.wasm')
  const OC = await (opencascade as unknown as (o: object) => Promise<unknown>)({ locateFile: () => wasm })
  setOC(OC as Parameters<typeof setOC>[0])
}, 60_000)

const audit = (m: CadModel, prompt?: string) => auditModel(m, buildModel(m), prompt)
const codes = (m: CadModel, prompt?: string) => audit(m, prompt).map((f) => f.code)

describe('requirement extraction', () => {
  it('reads dimensions, holes, diameters and thicknesses', () => {
    expect(extractRequirements('Caja de 120x80x40 vaciada con pared de 2.5 mm')).toMatchObject({ dims: [120, 80, 40], thicknesses: [2.5] })
    expect(extractRequirements('Brida Ø160 con 6 taladros de 13,5 y diámetro interior 60')).toMatchObject({ holeCount: 6, diameters: [160, 60] })
    expect(extractRequirements('placa 200 x 100 con cuatro agujeros y dos taladros')).toMatchObject({ dims: [200, 100], holeCount: 6 })
    expect(extractRequirements('hazla más alta')).toEqual({ diameters: [], thicknesses: [] })
  })
})

describe('generation audit', () => {
  it('accepts the examples with matching requests', () => {
    expect(codes(EXAMPLE_BOX, 'Caja de 120x80x40 vaciada con pared de 2.5 mm')).toEqual([])
    expect(codes(EXAMPLE_FLANGE, 'Brida Ø160 con 6 taladros de 13.5 mm, espesor 16')).toEqual([])
    expect(codes(EXAMPLE_ASSEMBLY)).toEqual([])
    const conj = JSON.parse(fs.readFileSync(path.resolve('examples/conjunto-eje-soportes.json'), 'utf8')) as CadModel
    expect(codes(conj)).toEqual([])
  })

  it('reports dimension, hole and thickness mismatches', () => {
    const f = audit(EXAMPLE_BOX, 'Caja de 120x80x50 con pared de 4 mm')
    expect(f.map((x) => x.code).sort()).toEqual(['dims', 'thickness'])
    expect(f.find((x) => x.code === 'dims')!.message).toMatch(/120 × 80 × 50/)
    expect(codes(EXAMPLE_FLANGE, 'brida con 8 taladros')).toEqual(['holes'])
  })

  it('detects disconnected solids and features without effect', () => {
    const m = structuredClone(EXAMPLE_BOX)
    m.parts[0]!.features.splice(1, 2) // keep only the block
    m.parts[0]!.features.push(
      { id: 'island', type: 'pad', sketch: { plane: { type: 'origin', base: 'XY', offset: 100 }, profiles: [{ type: 'circle', center: [0, 0], diameter: 10 }] }, length: 5 },
      { id: 'inside', type: 'pad', sketch: { plane: { type: 'origin', base: 'XY', offset: 5 }, profiles: [{ type: 'circle', center: [0, 0], diameter: 10 }] }, length: 5 },
    )
    expect(codes(m).sort()).toEqual(['disconnected', 'no_effect'])
  })

  it('detects floating and interfering assembly instances', () => {
    const floating = structuredClone(EXAMPLE_ASSEMBLY)
    floating.instances!.find((i) => i.id === 'top')!.position = [0, 0, 'plate_t + col_h + 10']
    expect(codes(floating)).toEqual(['floating'])
    const clash = structuredClone(EXAMPLE_ASSEMBLY)
    clash.instances!.find((i) => i.id === 'top')!.position = [0, 0, 'plate_t + col_h - 5']
    expect(codes(clash)).toContain('interference')
  })
})
