import { beforeAll, describe, expect, it } from 'vitest'
import path from 'node:path'
import opencascade from 'replicad-opencascadejs'
import { setOC } from 'replicad'
import { buildModel, modelToStep } from '../src/kernel/builder'
import { EXAMPLES } from '../src/shared/model/examples'
import { validateModel } from '../src/shared/model/validate'
import type { CadModel } from '../src/shared/model/schema'

beforeAll(async () => {
  const wasm = path.resolve('node_modules/replicad-opencascadejs/dist/replicad_single.wasm')
  const OC = await (opencascade as unknown as (o: object) => Promise<unknown>)({ locateFile: () => wasm })
  setOC(OC as Parameters<typeof setOC>[0])
}, 60_000)

describe('examples build in the kernel', () => {
  for (const ex of EXAMPLES) {
    it(ex.id, () => {
      const v = validateModel(ex.model)
      expect(v.issues.filter((i) => i.severity === 'error')).toEqual([])
      const built = buildModel(ex.model)
      for (const p of built.parts) {
        const failed = p.features.filter((f) => f.status === 'error')
        expect(failed, `${p.partId}: ${JSON.stringify(failed)}`).toEqual([])
        expect(p.shape).not.toBeNull()
        expect(p.volume).toBeGreaterThan(0)
      }
      expect(built.errors).toEqual([])
      const step = modelToStep(ex.model, built)
      expect(step.size).toBeGreaterThan(1000)
    }, 60_000)
  }
})

describe('geometry semantics', () => {
  const box = (features: CadModel['parts'][0]['features']): CadModel => ({
    schemaVersion: 1,
    name: 't',
    units: 'mm',
    kind: 'part',
    parameters: [],
    parts: [{ id: 'p', name: 'p', parameters: [], features }],
  })
  const block = {
    id: 'b',
    type: 'pad' as const,
    sketch: { plane: { type: 'origin' as const, base: 'XY' as const }, profiles: [{ type: 'rectangle' as const, center: [0, 0], width: 100, height: 50 }] },
    length: 20,
  }

  it('pad volume and pocket default direction (cuts below a top plane)', () => {
    const m = box([
      block,
      {
        id: 'pk',
        type: 'pocket',
        sketch: { plane: { type: 'origin', base: 'XY', offset: 20 }, profiles: [{ type: 'circle', center: [0, 0], diameter: 20 }] },
        depth: 5,
      },
    ])
    const r = buildModel(m).parts[0]!
    expect(r.features.map((f) => f.status)).toEqual(['ok', 'ok'])
    expect(r.volume!).toBeCloseTo(100 * 50 * 20 - Math.PI * 100 * 5, 0)
  })

  it('hole default drills along -normal; counterbore adds head volume', () => {
    const m = box([
      block,
      { id: 'h', type: 'hole', plane: { type: 'origin', base: 'XY', offset: 20 }, positions: [[0, 0]], diameter: 10, depth: 8 },
    ])
    const r = buildModel(m).parts[0]!
    expect(r.features[1]!.status).toBe('ok')
    expect(r.volume!).toBeCloseTo(100 * 50 * 20 - Math.PI * 25 * 8, 0)
  })

  it('nested profiles become holes', () => {
    const m = box([
      {
        ...block,
        sketch: {
          plane: { type: 'origin', base: 'XY' },
          profiles: [
            { type: 'rectangle', center: [0, 0], width: 100, height: 50 },
            { type: 'circle', center: [0, 0], diameter: 20 },
          ],
        },
      },
    ])
    expect(buildModel(m).parts[0]!.volume!).toBeCloseTo(100 * 50 * 20 - Math.PI * 100 * 20, 0)
  })

  it('fillet selector that matches nothing is reported as an error', () => {
    const m = box([block, { id: 'f', type: 'fillet', edges: { radius: 77 }, radius: 1 }])
    const r = buildModel(m).parts[0]!
    expect(r.features[1]!.status).toBe('error')
    expect(r.shape).not.toBeNull()
  })

  it('symmetric pad is centered on the plane', () => {
    const m = box([{ ...block, direction: 'symmetric' as const }])
    const r = buildModel(m).parts[0]!
    const [[, , z0], [, , z1]] = r.shape!.boundingBox.bounds
    expect(z0).toBeCloseTo(-10)
    expect(z1).toBeCloseTo(10)
  })
})
