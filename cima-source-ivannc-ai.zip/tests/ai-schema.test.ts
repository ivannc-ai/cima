import { describe, expect, it } from 'vitest'
import { EXAMPLES } from '../src/shared/model/examples'
import { stripNulls, validateModel } from '../src/shared/model/validate'
import { cadToolSchema, hoistDefs, rawCadJsonSchema, sanitizeSchema, stableStringify, type JsonSchema, type SchemaVariant } from '../src/main/ai/schema'
import { SYSTEM_PROMPT, buildSystemPrompt } from '../src/main/ai/prompt'
import { CAD_TOOL_NAME } from '../src/shared/ai/types'

// ---------------------------------------------------------------------------
// Minimal JSON Schema validator for the keywords the sanitized schemas use.
// ---------------------------------------------------------------------------
type S = Record<string, unknown>

function resolve(schema: S, root: S): S {
  let s = schema
  for (let i = 0; i < 50 && typeof s.$ref === 'string'; i++) {
    const name = (s.$ref as string).replace('#/$defs/', '')
    const target = (root.$defs as Record<string, S> | undefined)?.[name]
    if (!target) throw new Error(`unresolved ref ${s.$ref as string}`)
    const { $ref: _r, ...rest } = s
    s = { ...target, ...rest }
  }
  return s
}

function typeOk(t: string, v: unknown): boolean {
  switch (t) {
    case 'null':
      return v === null
    case 'string':
      return typeof v === 'string'
    case 'number':
      return typeof v === 'number'
    case 'integer':
      return Number.isInteger(v)
    case 'boolean':
      return typeof v === 'boolean'
    case 'array':
      return Array.isArray(v)
    case 'object':
      return typeof v === 'object' && v !== null && !Array.isArray(v)
    default:
      return false
  }
}

function validate(schema0: S, v: unknown, root: S, path = '$'): string[] {
  const schema = resolve(schema0, root)
  if (Array.isArray(schema.anyOf)) {
    const branches = (schema.anyOf as S[]).map((b) => validate(b, v, root, path))
    if (branches.some((e) => e.length === 0)) return []
    return [`${path}: no anyOf branch matches (${branches.map((b) => b[0]).join(' | ')})`]
  }
  const errs: string[] = []
  if (schema.type !== undefined) {
    const types = Array.isArray(schema.type) ? (schema.type as string[]) : [schema.type as string]
    if (!types.some((t) => typeOk(t, v))) return [`${path}: expected ${types.join('|')}`]
  }
  if ('const' in schema && v !== schema.const) errs.push(`${path}: expected const ${JSON.stringify(schema.const)}`)
  if (Array.isArray(schema.enum) && !(schema.enum as unknown[]).includes(v)) errs.push(`${path}: not in enum`)
  if (typeOk('object', v) && (schema.properties || schema.required)) {
    const obj = v as Record<string, unknown>
    const props = (schema.properties ?? {}) as Record<string, S>
    for (const r of (schema.required ?? []) as string[]) if (!(r in obj)) errs.push(`${path}.${r}: required`)
    for (const [k, val] of Object.entries(obj)) {
      if (props[k]) errs.push(...validate(props[k]!, val, root, `${path}.${k}`))
      else if (schema.additionalProperties === false) errs.push(`${path}.${k}: additional property`)
    }
  }
  if (Array.isArray(v) && schema.items) v.forEach((item, i) => errs.push(...validate(schema.items as S, item, root, `${path}[${i}]`)))
  return errs
}

/** Fills every missing optional property with null, following the schema (OpenAI strict form). */
function fillNulls(schema0: S, v: unknown, root: S): unknown {
  const schema = resolve(schema0, root)
  if (Array.isArray(schema.anyOf)) {
    if (v === undefined || v === null) return null
    for (const b of schema.anyOf as S[]) {
      if (resolve(b, root).type === 'null') continue
      const filled = fillNulls(b, v, root)
      if (validate(b, filled, root).length === 0) return filled
    }
    return v
  }
  if (Array.isArray(v)) return v.map((item) => fillNulls(schema.items as S, item, root))
  if (typeOk('object', v) && schema.properties) {
    const out: Record<string, unknown> = {}
    for (const [k, ps] of Object.entries(schema.properties as Record<string, S>)) {
      const val = (v as Record<string, unknown>)[k]
      out[k] = val === undefined ? null : fillNulls(ps, val, root)
    }
    return out
  }
  return v
}

function walk(node: unknown, cb: (n: S, path: string) => void, path = '$'): void {
  if (Array.isArray(node)) return node.forEach((n, i) => walk(n, cb, `${path}[${i}]`))
  if (node && typeof node === 'object') {
    cb(node as S, path)
    for (const [k, v] of Object.entries(node)) walk(v, cb, `${path}.${k}`)
  }
}

/** Every schema node (skipping the property-name maps themselves). */
function schemaNodes(root: S): Array<{ node: S; path: string }> {
  const out: Array<{ node: S; path: string }> = []
  const visit = (n: S, path: string) => {
    out.push({ node: n, path })
    for (const [k, v] of Object.entries(n)) {
      if ((k === 'properties' || k === '$defs') && v && typeof v === 'object') {
        for (const [pk, pv] of Object.entries(v as Record<string, S>)) visit(pv, `${path}.${k}.${pk}`)
      } else if ((k === 'anyOf' || k === 'oneOf' || k === 'allOf') && Array.isArray(v)) {
        v.forEach((b, i) => visit(b as S, `${path}.${k}[${i}]`))
      } else if (k === 'items' && v && typeof v === 'object') visit(v as S, `${path}.items`)
    }
  }
  visit(root, '$')
  return out
}

const FORBIDDEN = ['minimum', 'maximum', 'exclusiveMinimum', 'exclusiveMaximum', 'multipleOf', 'minLength', 'maxLength', 'pattern', 'minItems', 'maxItems', 'oneOf', '$schema', 'format']
const VARIANTS: SchemaVariant[] = ['anthropic', 'openai-strict', 'openai', 'compat']

describe('zod -> JSON Schema (raw)', () => {
  const raw = rawCadJsonSchema()
  it('uses oneOf for discriminated unions, const for literals and omits optionals from required', () => {
    const text = JSON.stringify(raw)
    expect(text).toContain('"oneOf"')
    expect(text).toContain('"const":"pad"')
    expect(raw.$schema).toBeDefined()
    expect(raw.required).toEqual(['schemaVersion', 'name', 'units', 'kind', 'parameters', 'parts'])
    const param = ((raw.properties as Record<string, S>).parameters!.items as S)
    expect(param.required).toEqual(['name', 'value', 'unit'])
    expect(text).toContain('"minItems":2')
    expect(text).toContain('"pattern"')
    expect(text).toContain('9007199254740991')
  })
})

describe('sanitized tool schemas', () => {
  for (const variant of VARIANTS) {
    describe(variant, () => {
      const schema = cadToolSchema(variant)

      it('has no forbidden keywords', () => {
        for (const { node, path } of schemaNodes(schema)) {
          for (const k of FORBIDDEN) expect(k in node, `${path} has ${k}`).toBe(false)
        }
      })

      it('objects are closed (additionalProperties:false) and list required keys that exist', () => {
        for (const { node, path } of schemaNodes(schema)) {
          if (node.type !== 'object') continue
          if (variant === 'compat') expect(node.additionalProperties, path).toBeUndefined()
          else expect(node.additionalProperties, path).toBe(false)
          const props = Object.keys((node.properties ?? {}) as S)
          for (const r of (node.required ?? []) as string[]) expect(props, path).toContain(r)
        }
      })

      it('resolves every $ref and has no recursion', () => {
        const defs = (schema.$defs ?? {}) as Record<string, S>
        if (variant === 'compat') expect(JSON.stringify(schema)).not.toContain('$ref')
        const refsOf = (n: unknown): string[] => {
          const out: string[] = []
          walk(n, (x) => {
            if (typeof x.$ref === 'string') out.push((x.$ref as string).replace('#/$defs/', ''))
          })
          return out
        }
        for (const r of refsOf(schema)) expect(defs[r], r).toBeDefined()
        const visiting = new Set<string>()
        const check = (name: string) => {
          expect(visiting.has(name), `recursive $defs ${name}`).toBe(false)
          visiting.add(name)
          for (const r of refsOf(defs[name])) check(r)
          visiting.delete(name)
        }
        for (const name of Object.keys(defs)) check(name)
      })

      it('keeps the constraint information in descriptions', () => {
        const text = JSON.stringify(schema)
        expect(text).toContain('exactly 2 items')
        expect(text).toContain('exactly 3 items')
        expect(text).toContain('at least 1 item')
        expect(text).toContain('>= 3') // regularPolygon.sides
        expect(text).not.toContain('9007199254740991')
      })

      it('accepts every example model', () => {
        for (const ex of EXAMPLES) {
          const value = variant === 'openai-strict' ? fillNulls(schema, ex.model, schema) : ex.model
          expect(validate(schema, value, schema), ex.id).toEqual([])
          const back = stripNulls(value)
          expect(back).toEqual(ex.model)
          expect(validateModel(back).ok, ex.id).toBe(true)
        }
      })

      it('rejects unknown properties and wrong literals', () => {
        const base = variant === 'openai-strict' ? (fillNulls(schema, EXAMPLES[0]!.model, schema) as S) : EXAMPLES[0]!.model
        const value = { ...base, extra: 1 }
        if (variant !== 'compat') expect(validate(schema, value, schema).length).toBeGreaterThan(0)
        const wrongVersion = { ...EXAMPLES[0]!.model, schemaVersion: 2 }
        const v2 = variant === 'openai-strict' ? fillNulls(schema, wrongVersion, schema) : wrongVersion
        expect(validate(schema, v2, schema).length).toBeGreaterThan(0)
      })
    })
  }

  it('anthropic keeps const; openai variants use single-value enums', () => {
    expect(JSON.stringify(cadToolSchema('anthropic'))).toContain('"const":"pad"')
    for (const v of ['openai-strict', 'openai', 'compat'] as const) {
      const text = JSON.stringify(cadToolSchema(v))
      expect(text).not.toContain('"const"')
      expect(text).toContain('"enum":["pad"]')
    }
  })

  it('openai-strict: every property is required and optional ones are nullable', () => {
    const schema = cadToolSchema('openai-strict')
    let optionalSeen = 0
    for (const { node, path } of schemaNodes(schema)) {
      if (node.type !== 'object') continue
      const props = Object.keys((node.properties ?? {}) as S)
      expect([...((node.required ?? []) as string[])].sort(), path).toEqual([...props].sort())
    }
    // Parameter.min was optional -> nullable.
    const defs = schema.$defs as Record<string, S>
    const paramArray = Object.values(defs).find((d) => d.type === 'array' && JSON.stringify(d).includes('"unit"'))!
    const param = resolve(paramArray.items as S, schema)
    const min = (param.properties as Record<string, S>).min!
    expect(min.anyOf).toEqual([{ type: 'number' }, { type: 'null' }])
    expect(min.description).toBe('Lower bound for the UI slider.')
    walk(schema, (n) => {
      if (Array.isArray(n.anyOf) && (n.anyOf as S[]).some((b) => b.type === 'null')) optionalSeen++
    })
    expect(optionalSeen).toBeGreaterThan(30)
    // Required ones are not nullable.
    const root = schema.properties as Record<string, S>
    expect(JSON.stringify(root.name)).not.toContain('null')
    expect(JSON.stringify(root.description)).toContain('null')
  })

  it('hoists repeated sub-schemas into named $defs and stays compact', () => {
    const anthropic = cadToolSchema('anthropic')
    const defs = Object.keys(anthropic.$defs as S)
    expect(defs).toEqual(expect.arrayContaining(['Sketch', 'Plane', 'ProfileRepeat', 'EdgeSelector', 'Parameters']))
    expect(JSON.stringify(anthropic).length).toBeLessThan(40_000)
    expect(JSON.stringify(rawCadJsonSchema()).length).toBeGreaterThan(100_000)
    // Occurrence descriptions are kept next to the reference.
    expect(JSON.stringify(anthropic)).toContain('"$ref":"#/$defs/Sketch","description":"Half cross-section')
    expect(JSON.stringify(cadToolSchema('openai-strict'))).toContain('{"anyOf":[{"$ref":"#/$defs/Sketch"}],"description":"Half cross-section')
  })

  it('sanitizer converts oneOf, closes objects and folds constraints into descriptions', () => {
    const out = sanitizeSchema({
      $schema: 'x',
      type: 'object',
      properties: {
        a: { type: 'array', items: { type: 'number' }, minItems: 2, maxItems: 4, description: 'Pts' },
        b: { oneOf: [{ type: 'string', minLength: 3, pattern: '^a' }, { type: 'integer', minimum: 1, maximum: 9007199254740991 }] },
        c: { type: 'object', properties: { d: { type: 'string', format: 'email' }, e: { type: 'string', format: 'color' } }, required: ['d'] },
      },
      required: ['a'],
    })
    expect(out).toEqual({
      type: 'object',
      properties: {
        a: { type: 'array', items: { type: 'number' }, description: 'Pts (at least 2 items; at most 4 items)' },
        b: {
          anyOf: [
            { type: 'string', description: 'At least 3 characters; must match the regex ^a.' },
            { type: 'integer', description: '>= 1.' },
          ],
        },
        c: {
          type: 'object',
          properties: { d: { type: 'string', format: 'email' }, e: { type: 'string', description: 'Format color.' } },
          required: ['d'],
          additionalProperties: false,
        },
      },
      required: ['a'],
      additionalProperties: false,
    })
  })

  it('hoistDefs only hoists large repeated nodes', () => {
    const big = { type: 'object', properties: Object.fromEntries(Array.from({ length: 20 }, (_, i) => [`p${i}`, { type: 'number' }])), required: [], additionalProperties: false }
    const s: JsonSchema = { type: 'object', properties: { x: { ...big, description: 'X' }, y: big, z: { type: 'string' }, w: { type: 'string' } }, required: [], additionalProperties: false }
    const h = hoistDefs(s, { names: new Map([[stableStringify(big), 'Big']]) })
    expect(h.properties).toEqual({ x: { $ref: '#/$defs/Big', description: 'X' }, y: { $ref: '#/$defs/Big' }, z: { type: 'string' }, w: { type: 'string' } })
    expect((h.$defs as S).Big).toEqual(big)
  })
})

describe('system prompt', () => {
  it('is static, large and documents the conventions and the protocol', () => {
    expect(buildSystemPrompt()).toBe(SYSTEM_PROMPT)
    expect(SYSTEM_PROMPT.length).toBeGreaterThan(8000)
    for (const s of [CAD_TOOL_NAME, 'ZX: u = +Z, v = +X, normal = +Y', 'YZ: u = +Y, v = +Z, normal = +X', '<current_model>', 'INVALID', 'BUILD_ERRORS', 'expression', 'language']) {
      expect(SYSTEM_PROMPT).toContain(s)
    }
    expect(SYSTEM_PROMPT).toContain('"name":"Brida_DN50"')
    expect(SYSTEM_PROMPT).toContain('"kind":"assembly"')
    expect(SYSTEM_PROMPT).not.toMatch(/\d{4}-\d{2}-\d{2}T/)
  })
})
