import { describe, expect, it } from 'vitest'
import {
  REPAIR_TEXT,
  buildErrorsResult,
  buildFailures,
  completeToolResults,
  invalidResult,
  isRepairMessage,
  isStorableAssistant,
  okResult,
  resultKind,
  splitUserText,
  withCurrentModel,
} from '../src/renderer/src/lib/agent'
import { parseInline, parseMarkdown } from '../src/renderer/src/lib/markdown'
import { fmt, niceStep, sliderRange } from '../src/renderer/src/lib/params'
import type { BuildResponse } from '../src/renderer/src/kernel/protocol'
import type { ChatMessage } from '../src/shared/ai/types'
import { EXAMPLE_FLANGE } from '../src/shared/model/examples'
import { validateModel } from '../src/shared/model/validate'
import { applyOverridesAsDefaults } from '../src/shared/model/evaluate'

const identity = { R: [1, 0, 0, 0, 1, 0, 0, 0, 1] as [number, number, number, number, number, number, number, number, number], t: [0, 0, 0] as [number, number, number] }

function fakeBuild(errors = false): BuildResponse {
  return {
    parts: [
      {
        partId: 'flange',
        volume: 12345.678,
        mesh: null,
        bbox: null,
        features: [
          { id: 'disc', type: 'pad', status: 'ok' },
          errors
            ? { id: 'outer_round', type: 'fillet', status: 'error', message: 'fillet radius too large' }
            : { id: 'outer_round', type: 'fillet', status: 'suppressed' },
        ],
      },
    ],
    placements: [{ instanceId: 'flange', partId: 'flange', name: 'Brida', transform: identity }],
    errors: [],
    durationMs: 10,
  }
}

describe('agent tool results', () => {
  it('formats INVALID results from validation issues', () => {
    const v = validateModel({ schemaVersion: 1, name: 'x', units: 'mm', kind: 'part', parameters: [], parts: [] })
    expect(v.ok).toBe(false)
    const r = invalidResult('c1', v.issues)
    expect(r.isError).toBe(true)
    expect(r.content.startsWith('INVALID\n- ')).toBe(true)
    expect(r.content).toContain('parts')
    expect(resultKind(r)).toBe('invalid')
  })

  it('formats BUILD_ERRORS with partId/featureId (type): message', () => {
    const failures = buildFailures(fakeBuild(true))
    expect(failures).toEqual(['flange/outer_round (fillet): fillet radius too large'])
    const r = buildErrorsResult('c1', failures)
    expect(r).toEqual({ toolCallId: 'c1', isError: true, content: 'BUILD_ERRORS\n- flange/outer_round (fillet): fillet radius too large' })
    expect(resultKind(r)).toBe('build_errors')
  })

  it('formats OK results with parts, features and volumes', () => {
    expect(buildFailures(fakeBuild(false))).toEqual([])
    const r = okResult('c1', EXAMPLE_FLANGE, fakeBuild(false))
    expect(r.isError).toBe(false)
    expect(r.content).toMatch(/^OK\nModel built: 1 part \(flange\), 3 features, volumes: flange=12345\.7 mm3, 1 suppressed$/)
  })

  it('appends and strips the current_model block', () => {
    const json = JSON.stringify(applyOverridesAsDefaults(EXAMPLE_FLANGE, { 'flange.outer_d': 200 }), null, 2)
    expect(json).toContain('"value": 200')
    const text = withCurrentModel('Hazla más gruesa', json)
    expect(text).toMatch(/^Hazla más gruesa\n\n<current_model>\n```json\n\{/)
    expect(text.endsWith('\n```\n</current_model>')).toBe(true)
    expect(splitUserText(text)).toEqual({ text: 'Hazla más gruesa', hasModel: true })
    expect(splitUserText('hola')).toEqual({ text: 'hola', hasModel: false })
  })

  it('completes missing tool results for the trailing assistant message only', () => {
    const msgs: ChatMessage[] = [
      { role: 'user', content: [{ type: 'text', text: 'hola' }] },
      { role: 'assistant', text: '', toolCalls: [{ id: 'a', name: 'emit_cad_model', input: {} }, { id: 'b', name: 'other', input: {} }] },
    ]
    const pending = [{ toolCallId: 'a', isError: true, content: 'INVALID\n- x: y' }]
    const out = completeToolResults(msgs, pending)
    expect(out.map((r) => r.toolCallId)).toEqual(['a', 'b'])
    expect(out[0]).toBe(pending[0])
    expect(out[1]!.content.startsWith('OK')).toBe(true)
    expect(completeToolResults(msgs.slice(0, 1), pending)).toEqual([])
  })

  it('recognises repair messages and storable assistant turns', () => {
    const repair: ChatMessage = {
      role: 'user',
      content: [{ type: 'text', text: REPAIR_TEXT }],
      toolResults: [{ toolCallId: 'a', isError: true, content: 'INVALID' }],
    }
    expect(isRepairMessage(repair)).toBe(true)
    expect(isRepairMessage({ role: 'user', content: [{ type: 'text', text: REPAIR_TEXT }] })).toBe(false)
    expect(isStorableAssistant({ text: '  ' })).toBe(false)
    expect(isStorableAssistant({ text: '', toolCalls: [{ id: 'x', name: 'n', input: {} }] })).toBe(true)
  })
})

describe('markdown', () => {
  it('parses inline formatting', () => {
    expect(parseInline('a **b** `c` *d*')).toEqual([
      { t: 'text', v: 'a ' },
      { t: 'bold', c: [{ t: 'text', v: 'b' }] },
      { t: 'text', v: ' ' },
      { t: 'code', v: 'c' },
      { t: 'text', v: ' ' },
      { t: 'italic', c: [{ t: 'text', v: 'd' }] },
    ])
    expect(parseInline('outer_d y bore_d')).toEqual([{ t: 'text', v: 'outer_d y bore_d' }])
  })

  it('parses blocks: paragraphs, lists, code fences, headings', () => {
    const b = parseMarkdown('# Título\n\nUno\ndos\n\n- a\n- b\n\n1. x\n2. y\n\n```json\n{"a":1}\n```\nfin')
    expect(b.map((x) => x.t)).toEqual(['h', 'p', 'ul', 'ol', 'code', 'p'])
    expect(b[4]).toEqual({ t: 'code', lang: 'json', v: '{"a":1}' })
  })

  it('tolerates an unterminated code fence while streaming', () => {
    const b = parseMarkdown('texto\n```\ncodigo')
    expect(b[1]).toEqual({ t: 'code', lang: '', v: 'codigo' })
  })

  it('never produces raw HTML nodes', () => {
    const b = parseMarkdown('<script>alert(1)</script>')
    expect(b).toEqual([{ t: 'p', c: [{ t: 'text', v: '<script>alert(1)</script>' }] }])
  })
})

describe('slider ranges', () => {
  it('uses the parameter bounds when present', () => {
    expect(sliderRange({ value: 160, unit: 'mm', min: 80, max: 300, step: 1 })).toEqual({ min: 80, max: 300, step: 1 })
  })
  it('derives ranges from the value and unit', () => {
    const r = sliderRange({ value: 40, unit: 'mm' })
    expect(r.min).toBe(0)
    expect(r.max).toBe(120)
    expect(r.step).toBeGreaterThan(0)
    expect(sliderRange({ value: 45, unit: 'deg' })).toEqual({ min: 0, max: 360, step: 1 })
    expect(sliderRange({ value: 6, unit: 'none' })).toEqual({ min: 1, max: 18, step: 1 })
  })
  it('always contains the current value', () => {
    const r = sliderRange({ value: 10, unit: 'mm', min: 5, max: 20 }, 50)
    expect(r.max).toBe(50)
  })
  it('formats numbers', () => {
    expect(niceStep(0.37)).toBe(0.2)
    expect(fmt(1.23456)).toBe('1.235')
    expect(fmt(-0.0001)).toBe('0')
  })
})

describe('placed bounds', () => {
  it('applies placements (rotation + translation) to part boxes', async () => {
    const { placedBounds } = await import('../src/renderer/src/lib/bounds')
    const b = placedBounds({
      parts: [{ partId: 'p', features: [], volume: 1, mesh: null, bbox: [[0, 0, 0], [10, 20, 30]] }],
      placements: [
        { instanceId: 'a', partId: 'p', name: 'a', transform: identity },
        // 90° about Z, moved +100 in X
        { instanceId: 'b', partId: 'p', name: 'b', transform: { R: [0, -1, 0, 1, 0, 0, 0, 0, 1], t: [100, 0, 0] } },
      ],
    })
    expect(b).toEqual({ min: [0, 0, 0], max: [100, 20, 30] })
    expect(placedBounds({ parts: [], placements: [] })).toBeNull()
  })
})
