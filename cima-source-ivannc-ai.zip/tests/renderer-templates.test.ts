import { describe, expect, it } from 'vitest'
import {
  REPAIR_TEXT,
  REPAIR_TEXT_TEMPLATE,
  auditLines,
  auditResult,
  ignoredToolResult,
  isAuditRepair,
  isModelTool,
  isRepairMessage,
  lastUserRequest,
  okResult,
  parseTemplateCall,
  resultKind,
  templateErrorResult,
  withCurrentModel,
  withNotes,
} from '../src/renderer/src/lib/agent'
import { auditText, type AuditFinding } from '../src/kernel/audit'
import { CAD_TOOL_NAME, TOOL_NUDGE_TEXT, type ChatMessage } from '../src/shared/ai/types'
import { TEMPLATE_TOOL_NAME, TEMPLATES, instantiateTemplate } from '../src/shared/templates'
import { validateModel } from '../src/shared/model/validate'
import { EXAMPLE_FLANGE } from '../src/shared/model/examples'

const user = (text: string, extra: Partial<Extract<ChatMessage, { role: 'user' }>> = {}): ChatMessage => ({
  role: 'user',
  content: [{ type: 'text', text }],
  ...extra,
})

describe('template tool calls', () => {
  it('parses the canonical input', () => {
    expect(parseTemplateCall({ template: 'flange', name: 'Brida_A', params: [{ name: 'outer_d', value: 200 }] })).toEqual({
      template: 'flange',
      name: 'Brida_A',
      params: [{ name: 'outer_d', value: 200 }],
    })
  })

  it('is tolerant: JSON string input, params as object or JSON string, alternative id keys', () => {
    expect(parseTemplateCall(JSON.stringify({ template: 'spacer', params: { od: 20 } }))).toEqual({ template: 'spacer', params: { od: 20 } })
    expect(parseTemplateCall({ template_id: ' flange ', params: '[{"name":"thickness","value":"12"}]' })).toEqual({
      template: 'flange',
      params: [{ name: 'thickness', value: '12' }],
    })
    expect(parseTemplateCall({ id: 'flange' })).toEqual({ template: 'flange', params: [] })
    expect(parseTemplateCall({ template: 'flange', params: [null, { value: 3 }, { name: 'bolt_count', value: 8 }] })).toEqual({
      template: 'flange',
      params: [{ name: 'bolt_count', value: 8 }],
    })
  })

  it('reports unusable input', () => {
    expect(parseTemplateCall('{not json')).toHaveProperty('error')
    expect(parseTemplateCall([1, 2])).toHaveProperty('error')
    expect(parseTemplateCall({ name: 'x' })).toEqual({ error: 'missing "template" (template id)' })
    expect(parseTemplateCall({ template: 'flange', params: '{bad' })).toEqual({ error: '"params" is not valid JSON' })
  })

  it('parsed calls instantiate valid models for every template', () => {
    for (const t of TEMPLATES) {
      const call = parseTemplateCall(JSON.stringify({ template: t.id, name: `T_${t.id}`, params: [] }))
      if ('error' in call) throw new Error(call.error)
      const inst = instantiateTemplate(call.template, call.params, call.name)
      expect(inst.errors).toEqual([])
      expect(validateModel(inst.model).ok).toBe(true)
    }
  })

  it('formats template errors as INVALID and recognises model tools', () => {
    const r = templateErrorResult('c1', ['unknown template "x"'])
    expect(r).toEqual({ toolCallId: 'c1', isError: true, content: 'INVALID\n- template: unknown template "x"' })
    expect(resultKind(r)).toBe('invalid')
    expect(isModelTool(CAD_TOOL_NAME)).toBe(true)
    expect(isModelTool(TEMPLATE_TOOL_NAME)).toBe(true)
    expect(isModelTool('other')).toBe(false)
  })

  it('keeps the IGNORED text of emit_cad_model unchanged and names both tools otherwise', () => {
    expect(ignoredToolResult({ id: 'a', name: CAD_TOOL_NAME, input: {} }).content).toBe(
      `IGNORED\nOnly one ${CAD_TOOL_NAME} call per turn is processed; this call was ignored.`,
    )
    expect(ignoredToolResult({ id: 'b', name: TEMPLATE_TOOL_NAME, input: {} }).content).toContain(TEMPLATE_TOOL_NAME)
  })
})

describe('audit and notes', () => {
  const findings: AuditFinding[] = [
    { severity: 'error', code: 'dims', message: 'Medidas', llm: 'Overall size is 100x50x10, requested 120x50x10.', fix: true },
    { severity: 'info', code: 'skipped', message: 'Omitido', llm: '', fix: false },
    { severity: 'warning', code: 'holes', message: 'Taladros', llm: 'Requested 6 holes, model has 4.', fix: true },
  ]

  it('formats AUDIT results exactly like the kernel auditText()', () => {
    expect(auditLines(findings)).toBe(auditText(findings))
    const r = auditResult('c1', findings)
    expect(r).toEqual({ toolCallId: 'c1', isError: true, content: `AUDIT\n${auditText(findings)}` })
    expect(resultKind(r)).toBe('audit')
  })

  it('appends Notes: and is a no-op without notes', () => {
    const ok = okResult('c1', EXAMPLE_FLANGE, null)
    expect(withNotes(ok, [])).toBe(ok)
    expect(withNotes(ok, ['  ', ''])).toBe(ok)
    const n = withNotes(ok, ['outer_d: 900 is above the maximum, 800 used', '- [dims] already listed'])
    expect(n.content).toBe(`${ok.content}\nNotes:\n- outer_d: 900 is above the maximum, 800 used\n- [dims] already listed`)
    expect(resultKind(n)).toBe('ok')
  })
})

describe('request text and repair messages', () => {
  const toolResults = [{ toolCallId: 'a', isError: true, content: 'AUDIT\n- [dims] x' }]

  it('takes the latest real user request, without the current_model block', () => {
    const msgs: ChatMessage[] = [
      user('Brida de 200 mm'),
      { role: 'assistant', text: 'ok', toolCalls: [{ id: 'a', name: TEMPLATE_TOOL_NAME, input: {} }] },
      user(withCurrentModel('Hazla de 12 mm de espesor', '{}')),
      { role: 'assistant', text: 'ok', toolCalls: [{ id: 'b', name: CAD_TOOL_NAME, input: {} }] },
      user(REPAIR_TEXT, { toolResults }),
      { role: 'assistant', text: 'describe' },
      user(TOOL_NUDGE_TEXT),
    ]
    expect(lastUserRequest(msgs)).toBe('Hazla de 12 mm de espesor')
    expect(lastUserRequest([])).toBe('')
  })

  it('recognises template repairs (also with an attached current_model) and audit repairs', () => {
    expect(isRepairMessage(user(REPAIR_TEXT, { toolResults }))).toBe(true)
    expect(isRepairMessage(user(withCurrentModel(REPAIR_TEXT_TEMPLATE, '{}'), { toolResults }))).toBe(true)
    expect(isRepairMessage(user(REPAIR_TEXT_TEMPLATE))).toBe(false)
    expect(isAuditRepair(user(REPAIR_TEXT, { toolResults }))).toBe(true)
    expect(isAuditRepair(user(REPAIR_TEXT, { toolResults: [{ toolCallId: 'a', isError: true, content: 'BUILD_ERRORS\n- x' }] }))).toBe(false)
  })
})
