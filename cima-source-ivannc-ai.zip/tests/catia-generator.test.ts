import { describe, expect, it } from 'vitest'
import { execFileSync } from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { generateScript } from '../src/main/catia/generator'
import { inspectScript, setParametersScript, statusScript } from '../src/main/catia/aux-scripts'
import { writeScript, parseLine } from '../src/main/catia/runner'
import { EXAMPLES } from '../src/shared/model/examples'
import type { CatiaScriptOptions } from '../src/shared/catia/types'

const isWin = process.platform === 'win32'
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'cima-gen-'))

const opts = (o: Partial<CatiaScriptOptions> = {}): CatiaScriptOptions => ({
  target: 'v5',
  flavor: 'vbs',
  connect: 'attach',
  createParameters: true,
  createFormulas: true,
  applyColors: true,
  ...o,
})

/** Compiles (and runs the harmless top-level part of) a script with the real VBScript engine. */
function compile(name: string, text: string, args: string[] = []): void {
  const file = path.join(tmp, name)
  writeScript(file, text)
  try {
    execFileSync('cscript.exe', ['//nologo', '//U', file, ...args], { windowsHide: true, timeout: 20000 })
  } catch (e) {
    const err = e as { stdout?: Buffer; stderr?: Buffer }
    const out = Buffer.concat([err.stdout ?? Buffer.alloc(0), err.stderr ?? Buffer.alloc(0)]).toString('utf16le')
    throw new Error(`cscript failed for ${name}:\n${out}`)
  }
}

describe('CATIA script generator', () => {
  for (const ex of EXAMPLES) {
    for (const target of ['v5', '3dx'] as const) {
      it(`${ex.id} (${target}) generates valid VBScript`, () => {
        const text = generateScript({ model: ex.model, overrides: {}, options: opts({ target, saveDirectory: 'C:\\Temp\\CIMA out', exportStep: true }) })
        expect(text).toContain('Sub CimaRun()')
        expect(text).not.toMatch(/\bNaN\b|undefined|Infinity/)
        if (isWin) compile(`${ex.id}-${target}.vbs`, text, ['--check'])
        const macro = generateScript({ model: ex.model, overrides: {}, options: opts({ target, flavor: 'catscript' }) })
        expect(macro).toContain('Sub CATMain()')
        expect(macro).not.toContain('WScript')
        if (isWin) compile(`${ex.id}-${target}.catvbs.vbs`, macro)
      })
    }
  }

  it('sets explicit sketch axes and formulas', () => {
    const text = generateScript({ model: EXAMPLES[0]!.model, overrides: { 'flange.thickness': 20 }, options: opts() })
    // Pad on XY with explicit absolute axis
    expect(text).toContain('CimaSketch(0, 0, 0, 1, 0, 0, 0, 1, 0)')
    expect(text).toContain('G_SF.AddNewPad(sk, 20)')
    expect(text).toMatch(/CimaFormula "CIMA_disc_length_\d+", feat\.FirstLimit\.Dimension, "thickness", "`thickness`"/)
    // Derived parameter formula, with units on literals
    expect(text).toMatch(/CimaFormula "CIMA_param_pcd_\d+", prm\(\d+\), "\(outer_d \+ bore_d\) \/ 2"/)
    // 6 hole features from the circular repeat
    expect(text.match(/G_SF\.AddNewHoleFromSketch\(/g)?.length).toBe(6)
  })

  it('start model: NewFrom; si la plantilla no abre, error sin fallback a documento vacío', () => {
    const part = EXAMPLES[0]!.model
    const withStart = generateScript({ model: part, overrides: {}, options: opts({ startModel: 'C:\\Plantillas\\MD-INI.CATPart' }) })
    expect(withStart).toMatch(/G_STARTMODEL = "C:\\Plantillas\\MD-INI\.CATPart"/)
    expect(withStart).toContain('Set doc = G_APP.Documents.NewFrom(G_STARTMODEL)')
    expect(withStart).toContain('No se pudo abrir el modelo de inicio (sin acceso a la plantilla)')
    // el fallback Documents.Add("Part") solo aparece en la rama sin plantilla (G_STARTMODEL = "")
    const plain = generateScript({ model: part, overrides: {}, options: opts() })
    expect(plain).toContain('G_STARTMODEL = ""')
    expect(plain).toContain('Set doc = G_APP.Documents.Add("Part")')
    // 3DEXPERIENCE ignora el start model
    const t3dx = generateScript({ model: part, overrides: {}, options: opts({ target: '3dx', startModel: 'C:\\Plantillas\\MD-INI.CATPart' }) })
    expect(t3dx).toContain('G_STARTMODEL = ""')
    // assembly usa la plantilla para el CATProduct y falla sin fallback si no abre
    const asm = EXAMPLES.find((e) => e.model.kind === 'assembly')!
    const withAsm = generateScript({ model: asm.model, overrides: {}, options: opts({ startModel: 'C:\\Plantillas\\ENSAM-INI.CATProduct' }) })
    expect(withAsm).toContain('Set pdoc = G_APP.Documents.NewFrom(G_STARTMODEL)')
    expect(withAsm).toContain('No se pudo abrir el modelo de inicio (sin acceso a la plantilla)')
    if (isWin) {
      compile('startmodel-part.vbs', withStart, ['--check'])
      compile('startmodel-asm.vbs', withAsm, ['--check'])
    }
  })

  it('start model: el nombre personalizado del Part/Product se usa como PartNumber y en el guardado', () => {
    const part = EXAMPLES[0]!.model
    const named = generateScript({
      model: part,
      overrides: {},
      options: opts({ startModel: 'C:\\Plantillas\\MD-INI.CATPart', startModelName: 'Soporte X-127', saveDirectory: 'C:\\Temp\\CIMA out' }),
    })
    expect(named).toContain('doc.Product.PartNumber = "Soporte X-127"')
    expect(named).toContain('sp = "C:\\Temp\\CIMA out" & "\\" & "Soporte X-127" & ".CATPart"')
    // sin nombre personalizado se usa el nombre del modelo de CIMA
    const plain = generateScript({ model: part, overrides: {}, options: opts({ startModel: 'C:\\Plantillas\\MD-INI.CATPart' }) })
    expect(plain).toContain('doc.Product.PartNumber = "Brida_DN50"')
    // el ensamblaje también usa el nombre personalizado para el CATProduct raíz
    const asm = EXAMPLES.find((e) => e.model.kind === 'assembly')!
    const namedAsm = generateScript({
      model: asm.model,
      overrides: {},
      options: opts({ startModel: 'C:\\Plantillas\\ENSAM-INI.CATProduct', startModelName: 'Conjunto 1', saveDirectory: 'C:\\Temp\\CIMA out' }),
    })
    expect(namedAsm).toContain('root.PartNumber = "Conjunto 1"')
    expect(namedAsm).toContain('sp = "C:\\Temp\\CIMA out" & "\\" & "Conjunto 1" & ".CATProduct"')
    if (isWin) {
      compile('startmodel-named-part.vbs', named, ['--check'])
      compile('startmodel-named-asm.vbs', namedAsm, ['--check'])
    }
  })

  it('assembly positions use columns of R and translation', () => {
    const ex = EXAMPLES.find((e) => e.id === 'assembly')!
    const text = generateScript({ model: ex.model, overrides: {}, options: opts() })
    expect(text).toContain('root.Products.AddComponent(PDOC0.Product)')
    expect(text).toContain('inst.Position.SetComponents arr')
    expect(text).toContain('arr(11) = 130') // top plate z = plate_t + col_h
    expect(text).toContain('cons.AddMonoEltCst 0, rf')
  })

  it('aux scripts compile', () => {
    if (!isWin) return
    compile('status.vbs', statusScript().replace('On Error Resume Next', 'WScript.Quit 0\nOn Error Resume Next'))
    compile('inspect.vbs', inspectScript().replace('On Error Resume Next', 'WScript.Quit 0\nOn Error Resume Next'))
    compile('setparams.vbs', setParametersScript([{ name: 'width', value: 12.5 }]).replace('On Error Resume Next', 'WScript.Quit 0\nOn Error Resume Next'))
  })

  it('parses machine-readable lines', () => {
    expect(parseLine('@@CIMA@@{"t":"saved","path":"C:\\\\a.CATPart"}')).toEqual({ t: 'saved', path: 'C:\\a.CATPart' })
    expect(parseLine('hello')).toBeNull()
  })
})
