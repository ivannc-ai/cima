import { describe, expect, it } from 'vitest'
import { AnthropicError, APIError, APIUserAbortError } from '@anthropic-ai/sdk'
import type { BetaMessage, BetaMessageStreamParams, BetaRawMessageStreamEvent } from '@anthropic-ai/sdk/resources/beta/messages/messages'
import {
  ANTHROPIC_MAX_TOKENS,
  buildAnthropicParams,
  supportsAdaptiveThinking,
  toAnthropicMessages,
  type AnthropicStreamLike,
  type AnthropicTransport,
} from '../src/main/ai/anthropic'
import { createAiServiceWithTransports, type AiTransports } from '../src/main/ai'
import { SYSTEM_PROMPT } from '../src/main/ai/prompt'
import { cadToolSchema } from '../src/main/ai/schema'
import { CAD_TOOL_NAME, type ChatMessage, type ChatStreamEvent } from '../src/shared/ai/types'
import { EXAMPLE_FLANGE } from '../src/shared/model/examples'
import { DEFAULT_SETTINGS, type AppSettings } from '../src/shared/settings'

// ---------------------------------------------------------------------------
// Fakes
// ---------------------------------------------------------------------------

function usage(extra: Partial<BetaMessage['usage']> = {}): BetaMessage['usage'] {
  return {
    cache_creation: null,
    cache_creation_input_tokens: 120,
    cache_read_input_tokens: 9000,
    fallback_credit: null,
    inference_geo: null,
    input_tokens: 50,
    iterations: null,
    output_tokens: 1,
    ...extra,
  } as BetaMessage['usage']
}

function message(content: BetaMessage['content'], stop_reason: BetaMessage['stop_reason'], model = 'claude-opus-5-5'): BetaMessage {
  return {
    id: 'msg_1',
    container: null,
    content,
    context_management: null,
    diagnostics: null,
    model,
    role: 'assistant',
    stop_details: null,
    stop_reason,
    stop_sequence: null,
    type: 'message',
    usage: usage({ output_tokens: 777 }),
  } as BetaMessage
}

/** Builds the raw event sequence of a message (blocks streamed in small fragments). */
function eventsFor(final: BetaMessage, opts: { invalidToolJson?: string } = {}): BetaRawMessageStreamEvent[] {
  const ev: unknown[] = [{ type: 'message_start', message: { ...final, content: [], stop_reason: null, usage: usage() } }]
  final.content.forEach((b, index) => {
    if (b.type === 'text') {
      ev.push({ type: 'content_block_start', index, content_block: { type: 'text', text: '', citations: null } })
      for (const piece of b.text.match(/.{1,7}/gs) ?? []) ev.push({ type: 'content_block_delta', index, delta: { type: 'text_delta', text: piece } })
    } else if (b.type === 'thinking') {
      ev.push({ type: 'content_block_start', index, content_block: { type: 'thinking', thinking: '', signature: '' } })
      ev.push({ type: 'content_block_delta', index, delta: { type: 'thinking_delta', thinking: b.thinking, estimated_tokens: null } })
      ev.push({ type: 'content_block_delta', index, delta: { type: 'signature_delta', signature: b.signature } })
    } else if (b.type === 'tool_use') {
      ev.push({ type: 'content_block_start', index, content_block: { type: 'tool_use', id: b.id, name: b.name, input: {} } })
      const json = opts.invalidToolJson ?? JSON.stringify(b.input)
      for (const piece of json.match(/.{1,300}/gs) ?? []) ev.push({ type: 'content_block_delta', index, delta: { type: 'input_json_delta', partial_json: piece } })
    } else {
      ev.push({ type: 'content_block_start', index, content_block: b })
    }
    ev.push({ type: 'content_block_stop', index })
  })
  ev.push({ type: 'message_delta', delta: { stop_reason: final.stop_reason, stop_sequence: null, container: null }, usage: { output_tokens: 777 }, context_management: null })
  ev.push({ type: 'message_stop' })
  return ev as BetaRawMessageStreamEvent[]
}

type Script = (params: BetaMessageStreamParams, signal: AbortSignal) => { events: BetaRawMessageStreamEvent[]; final?: BetaMessage; throwAfter?: unknown; throwFirst?: unknown; hang?: boolean }

function fakeTransports(script: Script, calls: BetaMessageStreamParams[]): AiTransports {
  const transport: AnthropicTransport = {
    stream(params, { signal }) {
      calls.push(structuredClone(params))
      const plan = script(params, signal)
      let aborted = false
      const s: AnthropicStreamLike = {
        abort() {
          aborted = true
        },
        async finalMessage() {
          if (!plan.final) throw new Error('no final')
          return plan.final
        },
        async *[Symbol.asyncIterator]() {
          if (plan.throwFirst) throw plan.throwFirst
          for (const e of plan.events) {
            await Promise.resolve()
            if (aborted || signal.aborted) throw new APIUserAbortError()
            yield e
          }
          if (plan.throwAfter) throw plan.throwAfter
          if (plan.hang) {
            await new Promise<void>((resolve) => signal.addEventListener('abort', () => resolve(), { once: true }))
            throw new APIUserAbortError()
          }
        },
      }
      return s
    },
    async create() {
      return message([{ type: 'text', text: 'OK', citations: null }], 'end_turn')
    },
  }
  return {
    anthropic: () => transport,
    openai: () => {
      throw new Error('not used')
    },
  }
}

function settingsWith(ai: Partial<AppSettings['ai']> = {}): AppSettings {
  return {
    ...DEFAULT_SETTINGS,
    ai: { ...DEFAULT_SETTINGS.ai, templates: false, audit: false, ...ai },
    providers: DEFAULT_SETTINGS.providers.map((p) => ({ ...p, hasApiKey: p.id === 'anthropic' })),
  }
}

async function runChat(transports: AiTransports, opts: { settings?: AppSettings; messages?: ChatMessage[]; model?: string; cancelAfterMs?: number } = {}) {
  const events: ChatStreamEvent[] = []
  const service = createAiServiceWithTransports({ getSettings: () => opts.settings ?? settingsWith(), getApiKey: () => 'sk-test' }, transports)
  const request = {
    requestId: 'r1',
    providerId: 'anthropic',
    model: opts.model,
    messages: opts.messages ?? [{ role: 'user', content: [{ type: 'text', text: 'Una brida' }] }],
  } satisfies Parameters<typeof service.chat>[0]
  const p = service.chat(request, (e) => events.push(e))
  if (opts.cancelAfterMs !== undefined) setTimeout(() => service.cancel('r1'), opts.cancelAfterMs)
  await p
  return { events, service }
}

const terminal = (events: ChatStreamEvent[]) => events.filter((e) => e.type === 'done' || e.type === 'error')

const TOOL_FINAL = message(
  [
    { type: 'thinking', thinking: 'Plan: disc + holes.', signature: 'sig123' },
    { type: 'text', text: 'Diseño una brida DN50 con seis taladros.', citations: null },
    { type: 'tool_use', id: 'toolu_01', name: CAD_TOOL_NAME, input: EXAMPLE_FLANGE },
  ] as BetaMessage['content'],
  'tool_use',
)

// ---------------------------------------------------------------------------
// Message conversion
// ---------------------------------------------------------------------------

describe('toAnthropicMessages', () => {
  it('puts tool results first, then images, then text', () => {
    const msgs: ChatMessage[] = [
      { role: 'user', content: [{ type: 'text', text: 'Hola' }] },
      { role: 'assistant', text: 'Aquí está', toolCalls: [{ id: 'toolu_A', name: CAD_TOOL_NAME, input: { schemaVersion: 1 } }] },
      {
        role: 'user',
        content: [
          { type: 'text', text: 'Más grande' },
          { type: 'image', mediaType: 'image/png', data: 'AAAA' },
        ],
        toolResults: [{ toolCallId: 'toolu_A', content: 'INVALID: parts: required', isError: true }],
      },
    ]
    const out = toAnthropicMessages(msgs)
    expect(out).toHaveLength(3)
    expect(out[1]).toEqual({
      role: 'assistant',
      content: [
        { type: 'text', text: 'Aquí está' },
        { type: 'tool_use', id: 'toolu_A', name: CAD_TOOL_NAME, input: { schemaVersion: 1 } },
      ],
    })
    expect(out[2]).toEqual({
      role: 'user',
      content: [
        { type: 'tool_result', tool_use_id: 'toolu_A', content: 'INVALID: parts: required', is_error: true },
        { type: 'image', source: { type: 'base64', media_type: 'image/png', data: 'AAAA' } },
        { type: 'text', text: 'Más grande' },
      ],
    })
  })

  it('replays raw Anthropic content verbatim (thinking + fallback blocks)', () => {
    const raw = [
      { type: 'fallback', from: { model: 'claude-opus-5-5' }, to: { model: 'claude-opus-4-8' }, trigger: { type: 'refusal' } },
      { type: 'thinking', thinking: 'secret summary', signature: 'abc' },
      { type: 'text', text: 'Hecho' },
      { type: 'tool_use', id: 'toolu_X', name: CAD_TOOL_NAME, input: { a: 1 } },
    ]
    const out = toAnthropicMessages([
      { role: 'user', content: [{ type: 'text', text: 'x' }] },
      { role: 'assistant', text: 'ignored', toolCalls: [{ id: 'toolu_X', name: CAD_TOOL_NAME, input: {} }], raw: { providerKind: 'anthropic', model: 'claude-opus-5-5', content: raw } },
      { role: 'user', content: [], toolResults: [{ toolCallId: 'toolu_X', content: 'OK', isError: false }] },
    ])
    expect(out[1]!.content).toBe(raw)
    expect(out[2]!.content).toEqual([{ type: 'tool_result', tool_use_id: 'toolu_X', content: 'OK', is_error: false }])
  })

  it('rebuilds messages from other providers (ids sanitized, string inputs parsed) and repairs missing/orphan results', () => {
    const out = toAnthropicMessages([
      { role: 'user', content: [{ type: 'text', text: 'x' }] },
      {
        role: 'assistant',
        text: '',
        toolCalls: [{ id: 'call:1/abc', name: CAD_TOOL_NAME, input: '{"schemaVersion":1}' }],
        raw: { providerKind: 'openai', model: 'gpt-5.1', content: { role: 'assistant' } },
      },
      { role: 'user', content: [{ type: 'text', text: 'sigue' }], toolResults: [{ toolCallId: 'other', content: 'OK', isError: false }] },
      { role: 'assistant', text: 'respuesta', toolCalls: [{ id: 'call_2', name: CAD_TOOL_NAME, input: {} }] },
    ])
    expect(out[1]!.content).toEqual([{ type: 'tool_use', id: 'call_1_abc', name: CAD_TOOL_NAME, input: { schemaVersion: 1 } }])
    expect(out[2]!.content).toEqual([
      { type: 'tool_result', tool_use_id: 'call_1_abc', content: 'No result was returned for this tool call.', is_error: true },
      { type: 'text', text: 'Tool result:\nOK' },
      { type: 'text', text: 'sigue' },
    ])
    // trailing assistant tool call gets a synthetic result so the request stays valid
    expect(out[4]).toEqual({ role: 'user', content: [{ type: 'tool_result', tool_use_id: 'call_2', content: 'No result was returned for this tool call.', is_error: true }] })
  })
})

describe('buildAnthropicParams', () => {
  const base = { messages: [{ role: 'user', content: [{ type: 'text', text: 'x' }] }] as ChatMessage[], ai: { ...DEFAULT_SETTINGS.ai, templates: false, audit: false } }

  it('uses adaptive summarized thinking, effort, caching, a strict eager tool and auto tool choice', () => {
    const p = buildAnthropicParams({ ...base, model: 'claude-opus-5-5', strict: true, eager: true, fallbacks: true })
    expect(p.max_tokens).toBe(ANTHROPIC_MAX_TOKENS)
    expect(p.thinking).toEqual({ type: 'adaptive', display: 'summarized' })
    expect(p.output_config).toEqual({ effort: 'high' })
    expect(p.tool_choice).toEqual({ type: 'auto' })
    expect(p.cache_control).toEqual({ type: 'ephemeral' })
    expect(p.system).toEqual([{ type: 'text', text: SYSTEM_PROMPT, cache_control: { type: 'ephemeral' } }])
    expect(p.betas).toEqual(['server-side-fallback-2026-07-01'])
    expect(p.fallbacks).toBe('default')
    const tool = p.tools![0] as { name: string; strict?: boolean; eager_input_streaming?: boolean; input_schema: unknown }
    expect(tool.name).toBe(CAD_TOOL_NAME)
    expect(tool.strict).toBe(true)
    expect(tool.eager_input_streaming).toBe(true)
    expect(tool.input_schema).toBe(cadToolSchema('anthropic'))
  })

  it('omits strict / fallbacks when disabled and thinking params on older models', () => {
    const p = buildAnthropicParams({ ...base, model: 'claude-haiku-4-5', strict: false, eager: true, fallbacks: false })
    expect(p.thinking).toBeUndefined()
    expect(p.output_config).toBeUndefined()
    expect(p.betas).toBeUndefined()
    expect((p.tools![0] as { strict?: boolean }).strict).toBeUndefined()
  })

  it('knows which models support adaptive thinking', () => {
    for (const m of ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-5-5', 'claude-fable-5-2', 'claude-opus-4-6', 'claude-fable-5']) expect(supportsAdaptiveThinking(m), m).toBe(true)
    for (const m of ['claude-haiku-4-5', 'claude-sonnet-4-5', 'claude-3-7-sonnet-latest', 'gpt-5']) expect(supportsAdaptiveThinking(m), m).toBe(false)
  })
})

// ---------------------------------------------------------------------------
// Streaming
// ---------------------------------------------------------------------------

describe('Anthropic streaming chat', () => {
  it('maps stream events and returns the assistant message with raw content', async () => {
    const calls: BetaMessageStreamParams[] = []
    const { events } = await runChat(fakeTransports(() => ({ events: eventsFor(TOOL_FINAL), final: TOOL_FINAL }), calls))
    expect(events[0]).toEqual({ requestId: 'r1', type: 'start', model: 'claude-opus-5-5' })
    expect(events.every((e) => e.requestId === 'r1')).toBe(true)
    const text = events.filter((e) => e.type === 'text_delta').map((e) => (e as { text: string }).text).join('')
    expect(text).toBe('Diseño una brida DN50 con seis taladros.')
    expect(events.filter((e) => e.type === 'thinking_delta').map((e) => (e as { text: string }).text).join('')).toBe('Plan: disc + holes.')
    const progress = events.filter((e) => e.type === 'tool_progress') as Array<{ bytes: number; name?: string }>
    expect(progress.length).toBeGreaterThan(2)
    expect(progress.at(-1)!.bytes).toBe(JSON.stringify(EXAMPLE_FLANGE).length)
    expect(progress.at(-1)!.name).toBe(CAD_TOOL_NAME)
    const term = terminal(events)
    expect(term).toHaveLength(1)
    const done = term[0] as Extract<ChatStreamEvent, { type: 'done' }>
    expect(done.type).toBe('done')
    expect(done.stopReason).toBe('tool_use')
    expect(done.message.text).toBe('Diseño una brida DN50 con seis taladros.')
    expect(done.message.thinking).toBe('Plan: disc + holes.')
    expect(done.message.toolCalls).toEqual([{ id: 'toolu_01', name: CAD_TOOL_NAME, input: EXAMPLE_FLANGE }])
    expect(done.message.raw).toEqual({ providerKind: 'anthropic', model: 'claude-opus-5-5', content: TOOL_FINAL.content })
    expect(done.usage).toEqual({ inputTokens: 50, outputTokens: 777, cacheReadTokens: 9000, cacheWriteTokens: 120 })
    expect(calls).toHaveLength(1)
    expect(calls[0]!.model).toBe('claude-opus-5-5')
  })

  it('hides thinking when showThinking is off and honours the model override', async () => {
    const calls: BetaMessageStreamParams[] = []
    const { events } = await runChat(fakeTransports(() => ({ events: eventsFor(TOOL_FINAL), final: TOOL_FINAL }), calls), {
      settings: settingsWith({ showThinking: false, refusalFallback: false }),
      model: 'claude-haiku-5-5',
    })
    expect(events.some((e) => e.type === 'thinking_delta')).toBe(false)
    const done = terminal(events)[0] as Extract<ChatStreamEvent, { type: 'done' }>
    expect(done.message.thinking).toBeUndefined()
    expect(calls[0]!.model).toBe('claude-haiku-5-5')
    expect(calls[0]!.betas).toBeUndefined()
  })

  it('reports an error instead of a truncated tool call on max_tokens', async () => {
    const final = message(TOOL_FINAL.content, 'max_tokens')
    const { events } = await runChat(fakeTransports(() => ({ events: eventsFor(final), final }), []))
    const term = terminal(events)
    expect(term).toHaveLength(1)
    expect(term[0]!.type).toBe('error')
    expect((term[0] as Extract<ChatStreamEvent, { type: 'error' }>).error.code).toBe('max_tokens')
  })

  it('turns a refusal into a friendly done event without tool calls', async () => {
    const final = message([{ type: 'text', text: '', citations: null }], 'refusal')
    const { events } = await runChat(fakeTransports(() => ({ events: eventsFor(final), final }), []))
    const done = terminal(events)[0] as Extract<ChatStreamEvent, { type: 'done' }>
    expect(done.stopReason).toBe('refusal')
    expect(done.message.toolCalls).toBeUndefined()
    expect(done.message.raw).toBeUndefined()
    expect(done.message.text).toMatch(/no puedo ayudar/)
  })

  it('retries once without strict when the schema is rejected and remembers it for the session', async () => {
    const calls: BetaMessageStreamParams[] = []
    let n = 0
    const transports = fakeTransports((params) => {
      n++
      const strict = (params.tools![0] as { strict?: boolean }).strict
      if (strict) return { events: [], throwFirst: APIError.generate(400, { type: 'error', error: { type: 'invalid_request_error', message: 'Schema is too complex for compilation' } }, undefined, new Headers()) }
      return { events: eventsFor(TOOL_FINAL), final: TOOL_FINAL }
    }, calls)
    const service = createAiServiceWithTransports({ getSettings: () => settingsWith(), getApiKey: () => 'k' }, transports)
    const events: ChatStreamEvent[] = []
    await service.chat({ requestId: 'a', providerId: 'anthropic', messages: [{ role: 'user', content: [{ type: 'text', text: 'x' }] }] }, (e) => events.push(e))
    expect(n).toBe(2)
    expect((calls[0]!.tools![0] as { strict?: boolean }).strict).toBe(true)
    expect((calls[1]!.tools![0] as { strict?: boolean }).strict).toBeUndefined()
    expect(terminal(events).map((e) => e.type)).toEqual(['done'])
    await service.chat({ requestId: 'b', providerId: 'anthropic', messages: [{ role: 'user', content: [{ type: 'text', text: 'x' }] }] }, () => {})
    expect(n).toBe(3)
    expect((calls[2]!.tools![0] as { strict?: boolean }).strict).toBeUndefined()
  })

  it('retries without fallbacks when the API rejects them', async () => {
    const calls: BetaMessageStreamParams[] = []
    const transports = fakeTransports((params) => {
      if (params.fallbacks) return { events: [], throwFirst: APIError.generate(400, { error: { type: 'invalid_request_error', message: 'fallbacks: not available for this organization' } }, undefined, new Headers()) }
      return { events: eventsFor(TOOL_FINAL), final: TOOL_FINAL }
    }, calls)
    const { events } = await runChat(transports)
    expect(calls).toHaveLength(2)
    expect(calls[1]!.fallbacks).toBeUndefined()
    expect(calls[1]!.betas).toBeUndefined()
    expect(terminal(events).map((e) => e.type)).toEqual(['done'])
  })

  it('maps typed SDK errors to Spanish messages', async () => {
    const cases: Array<[number, string, boolean]> = [
      [401, 'auth', false],
      [429, 'rate_limit', true],
      [400, 'bad_request', false],
      [529, 'overloaded', true],
      [500, 'server', true],
    ]
    for (const [status, code, retryable] of cases) {
      const err = APIError.generate(status, { error: { type: 'x', message: 'boom' } }, undefined, new Headers())
      const { events } = await runChat(fakeTransports(() => ({ events: [], throwFirst: err }), []))
      const term = terminal(events)
      expect(term).toHaveLength(1)
      const e = term[0] as Extract<ChatStreamEvent, { type: 'error' }>
      expect(e.error.code, String(status)).toBe(code)
      expect(e.error.retryable).toBe(retryable)
    }
    const { events } = await runChat(fakeTransports(() => ({ events: [], throwFirst: APIError.generate(undefined, undefined, 'Connection error.', undefined) }), []))
    expect((terminal(events)[0] as Extract<ChatStreamEvent, { type: 'error' }>).error).toMatchObject({ code: 'network', retryable: true })
  })

  it('cancels: done with stopReason cancelled and the partial text', async () => {
    const partial = eventsFor(TOOL_FINAL).slice(0, 8)
    const { events } = await runChat(fakeTransports(() => ({ events: partial, hang: true }), []), { cancelAfterMs: 30 })
    const term = terminal(events)
    expect(term).toHaveLength(1)
    const done = term[0] as Extract<ChatStreamEvent, { type: 'done' }>
    expect(done.stopReason).toBe('cancelled')
    expect(done.message.text.length).toBeGreaterThan(0)
    expect(done.message.toolCalls).toBeUndefined()
    expect(done.message.raw).toBeUndefined()
  })

  it('passes unparseable streamed tool JSON to the renderer as a string for validation', async () => {
    const bad = '{"schemaVersion":1,"name":"x" "oops"'
    const evs = eventsFor(TOOL_FINAL, { invalidToolJson: bad }).slice(0, -2)
    const { events } = await runChat(
      fakeTransports(() => ({ events: evs, throwAfter: new AnthropicError('Unable to parse tool parameter JSON from model. Please retry your request or adjust your prompt.') }), []),
    )
    const done = terminal(events)[0] as Extract<ChatStreamEvent, { type: 'done' }>
    expect(done.type).toBe('done')
    expect(done.stopReason).toBe('tool_use')
    expect(done.message.toolCalls).toEqual([{ id: 'toolu_01', name: CAD_TOOL_NAME, input: bad }])
    const raw = done.message.raw!.content as Array<{ type: string; input?: unknown; signature?: string }>
    expect(raw.find((b) => b.type === 'tool_use')!.input).toEqual({ INVALID_JSON: bad })
    expect(raw.find((b) => b.type === 'thinking')!.signature).toBe('sig123')
  })
})
