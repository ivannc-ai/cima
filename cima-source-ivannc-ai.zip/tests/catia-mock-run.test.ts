/**
 * Executes generated scripts end to end under cscript against a JScript CATIA mock
 * (tests/fixtures/mock-catia.js). Catches runtime errors in the VBScript runtime and generator:
 * wrong argument counts, missing helpers, bad array sizes, non-orthonormal sketch axes...
 */
import { describe, expect, it } from 'vitest'
import { execFileSync } from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { generateScript } from '../src/main/catia/generator'
import { parseLine } from '../src/main/catia/runner'
import { EXAMPLES } from '../src/shared/model/examples'
import { TEMPLATES, instantiateTemplate } from '../src/shared/templates'
import type { CatiaScriptEvent } from '../src/shared/catia/types'

const isWin = process.platform === 'win32'
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'cima-mock-'))
const mockJs = fs.readFileSync(path.resolve('tests/fixtures/mock-catia.js'), 'utf8')

function runWithMock(name: string, vbs: string) {
  const patched = vbs
    .replace('Set G_APP = GetObject(, "CATIA.Application")', 'Set G_APP = MockCATIA()')
    .replace(/CimaRun\r\nIf CIMA_ERRORS > 0 Then WScript\.Quit 1/, 'CimaRun\r\nMockReport\r\nWScript.Quit 0')
  const wsf = `<job id="cima"><script language="JScript">\r\n${mockJs}\r\n</script><script language="VBScript">\r\n${patched}\r\n</script></job>`
  const file = path.join(tmp, `${name}.wsf`)
  fs.writeFileSync(file, Buffer.from(wsf.replace(/[^\u0000-ÿ]/g, '?'), 'latin1'))
  let out: string
  try {
    out = execFileSync('cscript.exe', ['//nologo', file], { windowsHide: true, timeout: 60000 }).toString('latin1')
  } catch (e) {
    const err = e as { stdout?: Buffer; stderr?: Buffer }
    throw new Error(`cscript failed:\n${err.stdout?.toString('latin1')}\n${err.stderr?.toString('latin1')}`)
  }
  const lines = out.split(/\r?\n/)
  const events = lines.map(parseLine).filter((e): e is CatiaScriptEvent => !!e)
  const mockLine = lines.find((l) => l.startsWith('@@MOCK@@'))
  if (!mockLine) throw new Error(`no mock report:\n${out}`)
  const report = JSON.parse(mockLine.slice(8)) as { sketches: number; features: number; formulas: number; params: number; saved: number; positions: number; problems: string[] }
  report.problems = report.problems.filter(Boolean)
  return { events, report, out }
}

const TOPOLOGY = new Set(['fillet', 'chamfer', 'shell'])

describe.skipIf(!isWin)('generated scripts run against a CATIA mock', () => {
  for (const ex of EXAMPLES) {
    it(ex.id, () => {
      const vbs = generateScript({
        model: ex.model,
        overrides: {},
        options: { target: 'v5', flavor: 'vbs', connect: 'attach', createParameters: true, createFormulas: true, applyColors: true, saveDirectory: 'C:\\out', exportStep: true },
      })
      const { events, report, out } = runWithMock(ex.id, vbs)
      expect(report.problems, out).toEqual([])
      const end = events.find((e) => e.t === 'end')
      expect(end, out).toBeTruthy()
      const typeOf = new Map<string, string>()
      for (const p of ex.model.parts) for (const f of p.features) typeOf.set(`${p.id}/${f.id}`, f.type)
      const feats = events.filter((e): e is Extract<CatiaScriptEvent, { t: 'feature' }> => e.t === 'feature')
      expect(feats.length).toBeGreaterThan(0)
      for (const f of feats) {
        const baseId = f.feature.split(/[.#]/)[0]!
        const type = typeOf.get(`${f.part}/${baseId}`)
        if (type && TOPOLOGY.has(type)) expect(f.status, `${f.part}/${f.feature}`).toBe('error')
        else expect(f.status, `${f.part}/${f.feature}: ${f.msg}`).toBe('ok')
      }
      // The shaft example only drives topology features (chamfers) with parameters.
      if (ex.id !== 'shaft') expect(report.formulas).toBeGreaterThan(0)
      expect(report.saved).toBeGreaterThan(0)
      if (ex.model.kind === 'assembly') expect(report.positions).toBe(ex.model.instances!.length)
      const logErrors = events.filter((e) => e.t === 'log' && e.level === 'error')
      expect(logErrors, out).toEqual([])
    })
  }
})

describe.skipIf(!isWin)('template models generate valid CATIA scripts', () => {
  for (const t of TEMPLATES) {
    it(t.id, () => {
      const inst = instantiateTemplate(t.id, {})
      const model = inst.model!
      const opts = { target: 'v5' as const, connect: 'attach' as const, createParameters: true, createFormulas: true, applyColors: true }
      // Macro flavor must compile too (inside-CATIA VBScript).
      const macro = generateScript({ model, overrides: {}, options: { ...opts, flavor: 'catscript' } })
      expect(macro).toContain('Sub CATMain()')
      const { events, report, out } = runWithMock(`tpl-${t.id}`, generateScript({ model, overrides: {}, options: { ...opts, flavor: 'vbs' } }))
      expect(report.problems, out).toEqual([])
      expect(events.find((e) => e.t === 'end'), out).toBeTruthy()
      const typeOf = new Map<string, string>()
      for (const p of model.parts) for (const f of p.features) typeOf.set(`${p.id}/${f.id}`, f.type)
      for (const f of events.filter((e): e is Extract<CatiaScriptEvent, { t: 'feature' }> => e.t === 'feature')) {
        const type = typeOf.get(`${f.part}/${f.feature.split(/[.#]/)[0]!}`)
        if (!(type && TOPOLOGY.has(type))) expect(f.status, `${f.part}/${f.feature}: ${f.msg}`).toBe('ok')
      }
      expect(events.filter((e) => e.t === 'log' && e.level === 'error'), out).toEqual([])
      if (model.kind === 'assembly') expect(report.positions).toBe(model.instances!.length)
    })
  }
})

describe.skipIf(!isWin)('instance colors reach CATIA', () => {
  it('colored instance runs cleanly', () => {
    const ex = EXAMPLES.find((e) => e.id === 'assembly')!
    const model = structuredClone(ex.model)
    model.instances!.find((i) => i.id === 'top')!.color = '#2bb3a3'
    const vbs = generateScript({ model, overrides: {}, options: { target: 'v5', flavor: 'vbs', connect: 'attach', createParameters: true, createFormulas: true, applyColors: true } })
    expect(vbs).toContain('G_SEL.VisProperties.SetRealColor 43, 179, 163, 1')
    const { events, report, out } = runWithMock('inst-color', vbs)
    expect(report.problems, out).toEqual([])
    expect(events.filter((e) => e.t === 'log' && e.level !== 'info'), out).toEqual([])
  })
})
