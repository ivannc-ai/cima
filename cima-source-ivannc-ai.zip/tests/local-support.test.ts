import { describe, expect, it } from 'vitest'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { parseCatiaCaption } from '../src/main/catia/caption'
import { findDlNamesFile, listStartModels, readMmaterialDir } from '../src/main/start-models'
import { appLog, initLogs, logsDir } from '../src/main/logs'

describe('caption de la ventana de CATIA', () => {
  it('extrae programa, departamento y usuario (mismo layout que el puente interno)', () => {
    const cap = 'AIRBUS | CATIA.V5R27 | DERIVAIR | TADAS7 | ... | User C01073@PC-0173 |'
    expect(parseCatiaCaption(cap)).toEqual({ program: 'DERIVAIR', department: 'TADAS7', user: 'C01073' })
  })

  it('caption real del título de ventana de cnext (PowerShell MainWindowTitle)', () => {
    const real =
      ' Airbus Defence and Space S.A.U. | CATIA.V5R27 | DERIVAIR | TADAS7 | SOPORTECAD | dps |  User C01073@ESNBI480816 |'
    expect(parseCatiaCaption(real)).toEqual({ program: 'DERIVAIR', department: 'TADAS7', user: 'C01073' })
  })

  it('tolera captions vacíos o sin el formato esperado', () => {
    expect(parseCatiaCaption('')).toEqual({ program: null, department: null, user: null })
    expect(parseCatiaCaption(undefined)).toEqual({ program: null, department: null, user: null })
    expect(parseCatiaCaption('Part1.CATPart')).toEqual({ program: null, department: null, user: null })
  })

  it('usuario con @ y host', () => {
    expect(parseCatiaCaption('A | B | PROG | DEP | User u1@h1 |').user).toBe('u1')
  })
})

describe('modelos de inicio (DLNames automático, sin fallback)', () => {
  const mk = (): string => fs.mkdtempSync(path.join(os.tmpdir(), 'cima-start-'))
  const HOME = (dir: string): string => path.join(dir, 'home')

  it('localiza el DLNames del programa (release concreta y fallback a cualquier CATSettingsRefV5R*)', async () => {
    const dir = mk()
    const home = HOME(dir)
    const exact = path.join(home, 'MODLOCAL', 'DERIVAIR', 'CATSettingsRefV5R27', 'DERIVAIR_DLNames.txt')
    fs.mkdirSync(path.dirname(exact), { recursive: true })
    fs.writeFileSync(exact, 'Mmaterial;R:\\cadlib\\MTAD\\Mmaterial', 'utf8')
    expect(await findDlNamesFile('DERIVAIR', 'R27', home)).toBe(exact)
    expect(await findDlNamesFile('DERIVAIR', 27, home)).toBe(exact)
    expect(await findDlNamesFile('DERIVAIR', null, home)).toBe(exact)
    expect(await findDlNamesFile('OTRO', 27, home)).toBeNull()
    // sin carpeta de release concreta, vale cualquier CATSettingsRefV5R*
    const loose = path.join(home, 'MODLOCAL', 'OTRO', 'CATSettingsRefV5R25', 'OTRO_DLNames.txt')
    fs.mkdirSync(path.dirname(loose), { recursive: true })
    fs.writeFileSync(loose, 'x', 'utf8')
    expect(await findDlNamesFile('OTRO', null, home)).toBe(loose)
    fs.rmSync(dir, { recursive: true, force: true })
  })

  it('lee la línea Mmaterial;<ruta> (UTF-8, UTF-16 LE y formato real Windows;Unix;)', async () => {
    const dir = mk()
    const u8 = path.join(dir, 'a_DLNames.txt')
    fs.writeFileSync(u8, 'Otro;X:\\no\\vale\nMmaterial;R:\\cadlib\\MTAD\\Mmaterial\n', 'utf8')
    expect(await readMmaterialDir(u8)).toBe(path.normalize('R:\\cadlib\\MTAD\\Mmaterial'))
    const u16 = path.join(dir, 'b_DLNames.txt')
    fs.writeFileSync(u16, Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from('Mmaterial;R:\\cadlib\\MTAD\\Mmaterial', 'utf16le')]))
    expect(await readMmaterialDir(u16)).toBe(path.normalize('R:\\cadlib\\MTAD\\Mmaterial'))
    // formato real observado en producción: nombre;rutaWindows;rutaUnix;
    const real = path.join(dir, 'c_DLNames.txt')
    fs.writeFileSync(real, 'Mmaterial;R:\\cadlib\\MTAD\\Mmaterial;/r8/cadlib/MTAD/Mmaterial;\n', 'utf8')
    expect(await readMmaterialDir(real)).toBe(path.normalize('R:\\cadlib\\MTAD\\Mmaterial'))
    fs.rmSync(dir, { recursive: true, force: true })
  })

  it('catálogo automático desde MMaterial filtrado por tipo y programa', async () => {
    const dir = mk()
    const home = HOME(dir)
    const share = path.join(dir, 'share', 'Mmaterial')
    fs.mkdirSync(share, { recursive: true })
    const p1 = path.join(share, 'MECHANICAL-INI.CATPart')
    const p2 = path.join(share, 'SHEETMETAL-INI.CATPart')
    const prd = path.join(share, 'PRODUCT-INI.CATProduct')
    for (const f of [p1, p2, prd]) fs.writeFileSync(f, 'x')
    const dl = path.join(home, 'MODLOCAL', 'DERIVAIR', 'CATSettingsRefV5R27', 'DERIVAIR_DLNames.txt')
    fs.mkdirSync(path.dirname(dl), { recursive: true })
    fs.writeFileSync(dl, `Mmaterial;${share}`, 'utf8')

    const deriv = await listStartModels('DERIVAIR', 27, home)
    expect(deriv.mmaterialDir).toBe(path.normalize(share))
    expect(deriv.error).toBeUndefined()
    expect(deriv.models.map((m) => `${m.name}:${m.type}`)).toEqual([
      'MECHANICAL-INI:part',
      'SHEETMETAL-INI:part',
      'PRODUCT-INI:product',
    ])
    fs.rmSync(dir, { recursive: true, force: true })
  })

  it('sin MODLOCAL/DLNames no hay catálogo ni fallback (error explicativo)', async () => {
    const dir = mk()
    const cat = await listStartModels('DERIVAIR', 27, HOME(dir))
    expect(cat.models).toEqual([])
    expect(cat.error).toContain('No se encontró el DLNames')
    const noProg = await listStartModels(null, 27, HOME(dir))
    expect(noProg.models).toEqual([])
    expect(noProg.error).toContain('No se detectó el programa')
    fs.rmSync(dir, { recursive: true, force: true })
  })

  it('sin acceso a la carpeta MMaterial no hay fallback (error con la ruta)', async () => {
    const dir = mk()
    const home = HOME(dir)
    const dl = path.join(home, 'MODLOCAL', 'DERIVAIR', 'CATSettingsRefV5R27', 'DERIVAIR_DLNames.txt')
    fs.mkdirSync(path.dirname(dl), { recursive: true })
    fs.writeFileSync(dl, 'Mmaterial;R:\\cadlib\\no\\acceso', 'utf8')
    const cat = await listStartModels('DERIVAIR', 27, home)
    expect(cat.models).toEqual([])
    expect(cat.error).toContain('Sin acceso a la carpeta de modelos de inicio')
    expect(cat.error).toContain('R:\\cadlib\\no\\acceso')
    fs.rmSync(dir, { recursive: true, force: true })
  })
})

describe('logger de errores', () => {
  it('escribe líneas con nivel y ámbito en el fichero del día', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cima-logs-'))
    expect(initLogs(dir)).toBeTruthy()
    appLog('error', 'ai', 'falló la generación', new Error('boom'))
    appLog('info', 'catia', 'trabajo ok')
    const file = fs.readdirSync(logsDir()).find((f) => f.startsWith('cima-') && f.endsWith('.log'))!
    const content = fs.readFileSync(path.join(logsDir(), file), 'utf8')
    expect(content).toContain('[ERROR] [ai] falló la generación :: boom')
    expect(content).toContain('[INFO] [catia] trabajo ok')
    fs.rmSync(dir, { recursive: true, force: true })
  })
})
