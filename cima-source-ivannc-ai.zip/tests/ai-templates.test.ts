import { describe, expect, it } from 'vitest'
import { buildAnthropicParams } from '../src/main/ai/anthropic'
import { buildOpenAIParams, toOpenAIMessages } from '../src/main/ai/openai'
import { extractModelFromText } from '../src/main/ai/extract'
import { SYSTEM_PROMPT, buildSystemPrompt, systemPromptFor } from '../src/main/ai/prompt'
import { templateToolSchema } from '../src/main/ai/schema'
import { TEMPLATE_TOOL_NAME, instantiateTemplate } from '../src/shared/templates'
import { CAD_TOOL_NAME, type ChatMessage } from '../src/shared/ai/types'
import { DEFAULT_SETTINGS } from '../src/shared/settings'

const messages: ChatMessage[] = [{ role: 'user', content: [{ type: 'text', text: 'Brida de 200 mm con 8 taladros' }] }]
const off = { ...DEFAULT_SETTINGS.ai, templates: false, audit: false }
const on = { ...DEFAULT_SETTINGS.ai, templates: true, audit: true }

describe('templates and audit in AI requests', () => {
  it('disabled: requests are exactly the original ones', () => {
    expect(systemPromptFor(off)).toBe(SYSTEM_PROMPT)
    expect(buildSystemPrompt()).toBe(SYSTEM_PROMPT)
    const a = buildAnthropicParams({ model: 'claude-opus-5-5', messages, ai: off, strict: true, fallbacks: false, eager: true })
    expect(a.tools).toHaveLength(1)
    const o = buildOpenAIParams({ kind: 'gemini', model: 'g', messages, ai: off, strict: false, tools: true, reasoning: false, streamUsage: true })
    expect(o.tools).toHaveLength(1)
    expect(o.messages[0]).toEqual({ role: 'system', content: SYSTEM_PROMPT })
  })

  it('enabled: adds the template tool, the catalog and the audit protocol', () => {
    const prompt = systemPromptFor(on)
    expect(prompt).toContain(TEMPLATE_TOOL_NAME)
    expect(prompt).toContain('* flange:')
    expect(prompt).toContain('"AUDIT"')
    const a = buildAnthropicParams({ model: 'claude-opus-5-5', messages, ai: on, strict: true, fallbacks: false, eager: true })
    expect(a.tools!.map((t) => (t as { name: string }).name)).toEqual([CAD_TOOL_NAME, TEMPLATE_TOOL_NAME])
    const o = buildOpenAIParams({ kind: 'gemini', model: 'g', messages, ai: on, strict: false, tools: true, reasoning: false, streamUsage: true })
    expect(o.tools!.map((t) => (t as { function: { name: string } }).function.name)).toEqual([CAD_TOOL_NAME, TEMPLATE_TOOL_NAME])
    // Gemini / compat variant has no additionalProperties anywhere.
    expect(JSON.stringify(templateToolSchema('compat'))).not.toContain('additionalProperties')
    expect(JSON.stringify(templateToolSchema('anthropic')).length).toBeLessThan(2000)
    // Without tools, the addendum explains the template JSON form too.
    const noTools = toOpenAIMessages(messages, { kind: 'gemini', model: 'g', tools: false, ai: on })
    expect(String(noTools[1]!.content)).toContain('"template"')
  })

  it('a template request written as text becomes a template tool call that instantiates', () => {
    const text = 'Uso la plantilla.\n```json\n{"template": "flange", "name": "Brida_200", "params": [{"name": "outer_d", "value": 200}, {"name": "bolt_count", "value": 8}]}\n```'
    const found = extractModelFromText(text)!
    expect(found.kind).toBe('template')
    const inst = instantiateTemplate(String(found.model.template), found.model.params as Array<{ name: string; value: unknown }>, String(found.model.name))
    expect(inst.errors).toEqual([])
    expect(inst.model!.name).toBe('Brida_200')
    // A model in an invented format still reaches validation (so the repair loop can explain the format).
    expect(extractModelFromText('```json\n{"name": "Caja", "features": [{"type": "box"}]}\n```')!.kind).toBe('model')
  })
})
