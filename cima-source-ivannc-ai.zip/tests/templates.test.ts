import { beforeAll, describe, expect, it } from 'vitest'
import path from 'node:path'
import opencascade from 'replicad-opencascadejs'
import { setOC } from 'replicad'
import { buildModel } from '../src/kernel/builder'
import { validateModel } from '../src/shared/model/validate'
import { TEMPLATES, instantiateTemplate, templateCatalogText } from '../src/shared/templates'
import type { TemplateValue } from '../src/shared/templates'

beforeAll(async () => {
  const wasm = path.resolve('node_modules/replicad-opencascadejs/dist/replicad_single.wasm')
  const OC = await (opencascade as unknown as (o: object) => Promise<unknown>)({ locateFile: () => wasm })
  setOC(OC as Parameters<typeof setOC>[0])
}, 60_000)

/** All combinations of structural (bool / enum) options with default numeric values. */
function structuralVariants(id: string): Array<Record<string, TemplateValue>> {
  const t = TEMPLATES.find((x) => x.id === id)!
  let variants: Array<Record<string, TemplateValue>> = [{}]
  for (const p of t.params) {
    const opts: TemplateValue[] = p.kind === 'bool' ? [true, false] : p.kind === 'enum' ? (p.options ?? []) : []
    if (!opts.length) continue
    variants = variants.flatMap((v) => opts.map((o) => ({ ...v, [p.name]: o })))
  }
  return variants
}

function expectBuilds(id: string, values: Record<string, TemplateValue>) {
  const inst = instantiateTemplate(id, values)
  expect(inst.errors).toEqual([])
  const v = validateModel(inst.model)
  expect(v.issues.filter((i) => i.severity === 'error'), `${id} ${JSON.stringify(values)}`).toEqual([])
  const b = buildModel(v.model!)
  expect(b.errors).toEqual([])
  for (const p of b.parts) {
    const bad = p.features.filter((f) => f.status === 'error')
    expect(bad, `${id} ${JSON.stringify(values)}: ${JSON.stringify(bad)}`).toEqual([])
    expect(p.volume ?? 0).toBeGreaterThan(0)
  }
}

describe('template library', () => {
  for (const t of TEMPLATES) {
    it(`${t.id}: every structural variant builds`, () => {
      for (const v of structuralVariants(t.id)) expectBuilds(t.id, v)
    })
  }

  it('coerces, clamps and reports bad values', () => {
    const r = instantiateTemplate('flange', [
      { name: 'outer_d', value: '200' },
      { name: 'bolt_count', value: 6.4 },
      { name: 'thickness', value: 5000 },
      { name: 'hub', value: 'sí' },
      { name: 'color', value: 'red' },
    ])
    expect(r.errors).toEqual([])
    expect(r.values.outer_d).toBe(200)
    expect(r.values.bolt_count).toBe(6)
    expect(r.values.thickness).toBe(80)
    expect(r.values.hub).toBe(true)
    const w = r.warnings.join('\n')
    expect(w).toMatch(/rounded 6.4 to 6/)
    expect(w).toMatch(/thickness: 5000 is above the maximum/)
    expect(w).toMatch(/unknown parameter "color"/)
    expect(instantiateTemplate('nope', {}).errors[0]).toMatch(/unknown template/)
  })

  it('typical requests build', () => {
    expectBuilds('plate_holes', { L: 300, W: 150, T: 8, nx: 4, ny: 3, hole_d: 6.6, margin: 15, hole_kind: 'countersunk' })
    expectBuilds('plate_holes', { nx: 1, ny: 1 })
    expectBuilds('stepped_shaft', { sections: '3', d1: 25, l1: 50, d2: 40, l2: 80, d3: 30, l3: 40, keyway: true, key_w: 12, key_depth: 5, key_len: 60, groove: true })
    expectBuilds('l_bracket', { length: 120, height: 100, width: 60, t: 8, base_holes: 3, wall_holes: 2 })
    expectBuilds('enclosure', { L: 200, W: 150, H: 60, wall: 3, corner_r: 10 })
    expectBuilds('flange', { outer_d: 250, bore_d: 100, bolt_count: 12, bolt_d: 17.5, hub: true, hub_d: 140, hub_h: 30 })
    expectBuilds('plate_columns', { col_h: 300, col_d: 30, inset: 30 })
  })

  it('catalog text lists every template and stays compact', () => {
    const text = templateCatalogText()
    for (const t of TEMPLATES) expect(text).toContain(`* ${t.id}:`)
    expect(text.length).toBeLessThan(14000)
  })
})
