import { describe, expect, it } from 'vitest'
import { isNudgeMessage, looksLikeDesignWithoutModel } from '../src/renderer/src/lib/agent'
import { buildOpenAIParams, isToolNudge } from '../src/main/ai/openai'
import { DEFAULT_SETTINGS } from '../src/shared/settings'
import { TOOL_NUDGE_TEXT, type ChatMessage } from '../src/shared/ai/types'

describe('tool nudge when the model answers without emitting the CAD model', () => {
  it('detects a design description but not a clarifying question', () => {
    expect(
      looksLikeDesignWithoutModel(
        'He diseñado una caja rectangular completamente paramétrica de 120x80x40 mm con un espesor de pared de 2.5 mm.',
      ),
    ).toBe(true)
    expect(looksLikeDesignWithoutModel('¿Qué diámetro deben tener los taladros y cuántos necesitas?')).toBe(false)
    expect(looksLikeDesignWithoutModel('Puedo hacerla de aluminio o de acero. ¿Cuál prefieres para la pieza final?')).toBe(false)
    expect(looksLikeDesignWithoutModel('Hecho.')).toBe(false)
  })

  it('forces tool_choice only on the nudge turn', () => {
    const base: ChatMessage[] = [
      { role: 'user', content: [{ type: 'text', text: 'Caja de 120x80x40' }] },
      { role: 'assistant', text: 'He diseñado una caja…' },
    ]
    const nudged: ChatMessage[] = [...base, { role: 'user', content: [{ type: 'text', text: TOOL_NUDGE_TEXT }] }]
    expect(isToolNudge(base)).toBe(false)
    expect(isToolNudge(nudged)).toBe(true)
    expect(isNudgeMessage(nudged[2]!)).toBe(true)
    const opts = { kind: 'gemini' as const, model: 'gemini-flash-latest', ai: DEFAULT_SETTINGS.ai, strict: false, tools: true, reasoning: false, streamUsage: true }
    expect(buildOpenAIParams({ ...opts, messages: nudged }).tool_choice).toBe('required')
    expect(buildOpenAIParams({ ...opts, messages: [...base, { role: 'user', content: [{ type: 'text', text: 'otra' }] }] }).tool_choice).toBeUndefined()
    expect(buildOpenAIParams({ ...opts, messages: nudged, forceTool: false }).tool_choice).toBeUndefined()
  })
})
