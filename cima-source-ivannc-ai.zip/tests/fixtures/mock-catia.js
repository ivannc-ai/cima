// Minimal CATIA V5 automation mock (JScript, ES3) used to execute generated scripts end to end
// under cscript. It records what the script does and validates argument shapes. Out-parameter
// measurement methods are not mockable from JScript: they throw, so topology-based features
// (fillet, chamfer, shell) are expected to report "no match" errors in this harness.
var MOCK = { sketches: 0, features: [], formulas: [], params: [], problems: [], saved: [], positions: [], volume: 0 };

function mockProblem(msg) { MOCK.problems.push(msg); }
function toArr(a) { try { return new VBArray(a).toArray(); } catch (e) { return null; } }
function obj(props) { var o = {}; for (var k in props) o[k] = props[k]; return o; }
function param(v) { return obj({ Value: v, Name: 'p', Comment: '' }); }
function limit() { return obj({ LimitMode: 0, Dimension: param(0) }); }

function newPart(doc) {
  var bodyObj = obj({ Name: 'PartBody' });
  var sketchesObj = obj({});
  sketchesObj.Add = function (ref) {
    if (!ref || !ref.__ref) mockProblem('Sketches.Add without a reference');
    MOCK.sketches++;
    var sk = obj({ __sketch: true, CenterLine: null });
    sk.SetAbsoluteAxisData = function (a) {
      var v = toArr(a);
      if (!v || v.length !== 9) { mockProblem('SetAbsoluteAxisData expects 9 values'); return; }
      var u = [v[3], v[4], v[5]], w = [v[6], v[7], v[8]];
      var dot = u[0] * w[0] + u[1] * w[1] + u[2] * w[2];
      var lu = Math.sqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]);
      var lw = Math.sqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2]);
      if (Math.abs(dot) > 1e-6 || Math.abs(lu - 1) > 1e-6 || Math.abs(lw - 1) > 1e-6) mockProblem('axis not orthonormal');
    };
    sk.OpenEdition = function () {
      var f2 = obj({});
      f2.CreatePoint = function (x, y) { return obj({ __pt: true, x: x, y: y }); };
      f2.CreateLine = function (x1, y1, x2, y2) {
        if (arguments.length !== 4) mockProblem('CreateLine expects 4 args');
        return obj({ StartPoint: null, EndPoint: null, Construction: false });
      };
      f2.CreateCircle = function (cx, cy, r, a1, a2) {
        if (arguments.length !== 5) mockProblem('CreateCircle expects 5 args');
        if (!(r > 0)) mockProblem('CreateCircle radius <= 0');
        if (!(a2 > a1)) mockProblem('CreateCircle end angle must exceed start angle');
        return obj({ CenterPoint: null, StartPoint: null, EndPoint: null });
      };
      f2.CreateClosedCircle = function (cx, cy, r) {
        if (!(r > 0)) mockProblem('CreateClosedCircle radius <= 0');
        return obj({});
      };
      return f2;
    };
    sk.CloseEdition = function () {};
    return sk;
  };
  bodyObj.Sketches = sketchesObj;
  var refOf = function (o) { return obj({ __ref: true, target: o, DisplayName: 'ref' }); };
  function feature(kind, sk, val) {
    var f = obj({
      __feat: kind, Name: kind, DirectionOrientation: 0, IsSymmetric: false,
      FirstLimit: limit(), SecondLimit: limit(), FirstAngle: param(360), SecondAngle: param(0),
      Type: 0, Diameter: param(10), BottomLimit: limit(), HeadDiameter: param(0), HeadDepth: param(0), HeadAngle: param(90),
      ThreadingMode: 1, ThreadDepth: param(0), ThreadDiameter: param(0), Radius: param(val), Length1: param(val),
      InternalThickness: param(val)
    });
    f.Reverse = function () {};
    f.AddObjectToFillet = function () {};
    f.AddElementToChamfer = function () {};
    f.AddFaceToRemove = function () {};
    if (sk !== null && sk !== undefined && !sk.__sketch) mockProblem(kind + ' without sketch');
    MOCK.features.push(kind);
    return f;
  }
  var sf = obj({});
  sf.AddNewPad = function (sk, l) { return feature('pad', sk, l); };
  sf.AddNewPocket = function (sk, l) { return feature('pocket', sk, l); };
  sf.AddNewShaft = function (sk) { if (!sk.CenterLine) mockProblem('shaft without CenterLine'); return feature('shaft', sk, 0); };
  sf.AddNewGroove = function (sk) { if (!sk.CenterLine) mockProblem('groove without CenterLine'); return feature('groove', sk, 0); };
  sf.AddNewHoleFromSketch = function (sk, d) { return feature('hole', sk, d); };
  sf.AddNewSolidEdgeFilletWithConstantRadius = function (r, p, v) { return feature('fillet', null, v); };
  sf.AddNewEdgeFilletWithConstantRadius = function (r, p, v) { return feature('fillet', null, v); };
  sf.AddNewChamfer = function (r, a, b, c, d, e) { if (arguments.length !== 6) mockProblem('AddNewChamfer expects 6 args'); return feature('chamfer', null, d); };
  sf.AddNewShell = function (r, a, b) { return feature('shell', null, a); };
  sf.AddNewMirror = function (r) { if (!r || !r.__ref) mockProblem('mirror without plane reference'); return feature('mirror', null, 0); };

  var hsf = obj({});
  hsf.AddNewPlaneEquation = function (a, b, c, d) {
    if (arguments.length !== 4) mockProblem('AddNewPlaneEquation expects 4 args');
    return obj({ __plane: true });
  };
  var part = obj({
    MainBody: bodyObj, ShapeFactory: sf, HybridShapeFactory: hsf, InWorkObject: null,
    OriginElements: obj({ PlaneXY: obj({}), PlaneYZ: obj({}), PlaneZX: obj({}) })
  });
  part.CreateReferenceFromObject = function (o) { if (!o) mockProblem('CreateReferenceFromObject(null)'); return refOf(o); };
  part.UpdateObject = function (o) {
    if (o && o.__feat) {
      var k = o.__feat;
      if (k === 'pad' || k === 'shaft') MOCK.volume += 100;
      if (k === 'pocket' || k === 'groove' || k === 'hole') MOCK.volume -= 10;
    }
  };
  part.Update = function () {};
  var params = obj({});
  params.CreateDimension = function (n, kind, v) {
    if (kind !== 'LENGTH' && kind !== 'ANGLE') mockProblem('bad dimension kind ' + kind);
    MOCK.params.push(n); return param(v);
  };
  params.CreateReal = function (n, v) { MOCK.params.push(n); return param(v); };
  part.Parameters = params;
  var rel = obj({});
  rel.CreateFormula = function (name, comment, target, body) {
    if (arguments.length !== 4) mockProblem('CreateFormula expects 4 args');
    if (!target || target.Value === undefined) mockProblem('formula ' + name + ' target is not a parameter');
    MOCK.formulas.push(name + ' = ' + body);
    return obj({});
  };
  part.Relations = rel;
  var hbs = obj({});
  hbs.Add = function () { var hb = obj({ Name: '' }); hb.AppendHybridShape = function () {}; return hb; };
  part.HybridBodies = hbs;
  return part;
}

function newSelection() {
  var s = obj({ Count: 0 });
  s.Clear = function () { s.Count = 0; };
  s.Add = function () {};
  s.Search = function (q) { s.Count = 0; };
  s.Delete = function () { mockProblem('a feature was deleted after a failed update'); };
  s.Item = function (i) { return obj({ Reference: obj({ __ref: true }), Value: obj({}) }); };
  s.VisProperties = obj({});
  s.VisProperties.SetShow = function () {};
  s.VisProperties.SetRealColor = function (r, g, b, a) { if (arguments.length !== 4) mockProblem('SetRealColor expects 4 args'); };
  return s;
}

function newSpa() {
  var spa = obj({});
  spa.GetMeasurable = function (ref) {
    var m = obj({ Volume: MOCK.volume, Length: 1 });
    m.GetCOG = function () { throw new Error('out-params not mockable'); };
    m.GetPointsOnCurve = function () { throw new Error('out-params not mockable'); };
    return m;
  };
  return spa;
}

var docCount = 0;
function newDocument(kind) {
  docCount++;
  var d = obj({ Name: kind + docCount });
  d.Selection = newSelection();
  d.GetWorkbench = function (n) { if (n !== 'SPAWorkbench') mockProblem('unknown workbench ' + n); return newSpa(); };
  d.SaveAs = function (p) { MOCK.saved.push(p); };
  d.ExportData = function (p, fmt) { if (fmt !== 'stp') mockProblem('ExportData format ' + fmt); MOCK.saved.push(p); };
  var product = obj({ PartNumber: kind + docCount, Name: kind + docCount });
  product.ReferenceProduct = product;
  if (kind === 'Part') d.Part = newPart(d);
  if (kind === 'Product') {
    var items = [];
    var prods = obj({ Count: 0 });
    prods.AddComponent = function (ref) {
      if (!ref || ref.PartNumber === undefined) mockProblem('AddComponent without a product');
      var inst = obj({ Name: 'inst', ReferenceProduct: ref });
      inst.Position = obj({});
      inst.Position.SetComponents = function (a) {
        var v = toArr(a);
        if (!v || v.length !== 12) mockProblem('SetComponents expects 12 values');
        else MOCK.positions.push(v.join(','));
      };
      items.push(inst);
      prods.Count = items.length;
      return inst;
    };
    prods.Item = function (i) { return items[i - 1]; };
    prods.AddComponentsFromFiles = function () {};
    product.Products = prods;
    product.Connections = function (n) {
      if (n !== 'CATIAConstraints') mockProblem('Connections(' + n + ')');
      var c = obj({});
      c.AddMonoEltCst = function (t, r) { if (t !== 0) mockProblem('fix constraint type ' + t); };
      return c;
    };
    product.CreateReferenceFromName = function (s) { if (s.indexOf('!') < 0) mockProblem('bad reference name ' + s); return obj({}); };
    product.Update = function () {};
  }
  d.Product = product;
  return d;
}

function MockCATIA() {
  var app = obj({ Name: 'CNEXT', RefreshDisplay: true, DisplayFileAlerts: true, Visible: true });
  app.SystemConfiguration = obj({ Version: 5, Release: 28, ServicePack: 3 });
  app.GetSessionService = function () { throw new Error('Object doesn\'t support this property or method'); };
  var docs = obj({});
  docs.Add = function (kind) { if (kind !== 'Part' && kind !== 'Product') mockProblem('Documents.Add(' + kind + ')'); return newDocument(kind); };
  app.Documents = docs;
  return app;
}

function MockReport() {
  WScript.StdOut.WriteLine('@@MOCK@@' + '{"sketches":' + MOCK.sketches + ',"features":' + MOCK.features.length +
    ',"formulas":' + MOCK.formulas.length + ',"params":' + MOCK.params.length + ',"saved":' + MOCK.saved.length +
    ',"positions":' + MOCK.positions.length + ',"problems":["' + MOCK.problems.join('","').replace(/\\/g, '/') + '"]}');
}
