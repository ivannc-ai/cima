import { describe, expect, it } from 'vitest'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { ProxyAgent } from 'undici'
import { APIError, APIUserAbortError } from 'openai'
import { APIError as AnthropicAPIError } from '@anthropic-ai/sdk'
import type { ChatCompletionChunk, ChatCompletionCreateParamsStreaming } from 'openai/resources/chat/completions/completions'
import { buildOpenAIParams, clientConfig, toOpenAIMessages, type OpenAITransport } from '../src/main/ai/openai'
import { buildNetworkDispatcher, splitProxyUrl } from '../src/main/ai/proxy'
import { extractModelFromText } from '../src/main/ai/extract'
import { createAiServiceWithTransports, type AiTransports } from '../src/main/ai'
import { NO_TOOLS_ADDENDUM, SYSTEM_PROMPT } from '../src/main/ai/prompt'
import { cadToolSchema } from '../src/main/ai/schema'
import { CAD_TOOL_NAME, TOOL_NUDGE_TEXT, type ChatMessage, type ChatStreamEvent, type ProviderConfig } from '../src/shared/ai/types'
import { EXAMPLE_ASSEMBLY, EXAMPLE_FLANGE } from '../src/shared/model/examples'
import { DEFAULT_SETTINGS, type AppSettings } from '../src/shared/settings'

const provider = (id: string) => DEFAULT_SETTINGS.providers.find((p) => p.id === id)!

function chunk(delta: ChatCompletionChunk.Choice.Delta, finish: ChatCompletionChunk.Choice['finish_reason'] = null, extra: Partial<ChatCompletionChunk> = {}): ChatCompletionChunk {
  return { id: 'c', object: 'chat.completion.chunk', created: 0, model: 'gpt-5.1', choices: [{ index: 0, delta, finish_reason: finish }], ...extra }
}

function splitArgs(s: string, n = 200): string[] {
  return s.match(new RegExp(`.{1,${n}}`, 'gs')) ?? []
}

type Plan = { chunks: ChatCompletionChunk[]; throwFirst?: unknown; hang?: boolean }

function fakeTransports(script: (params: ChatCompletionCreateParamsStreaming) => Plan, calls: ChatCompletionCreateParamsStreaming[], configs: Array<{ apiKey: string; baseURL?: string }> = []): AiTransports {
  const make = (cfg: { apiKey: string; baseURL?: string }): OpenAITransport => {
    configs.push(cfg)
    return {
      async stream(params, { signal }) {
        calls.push(structuredClone(params))
        const plan = script(params)
        if (plan.throwFirst) throw plan.throwFirst
        return (async function* () {
          for (const c of plan.chunks) {
            await Promise.resolve()
            if (signal.aborted) throw new APIUserAbortError()
            yield c
          }
          if (plan.hang) {
            await new Promise<void>((resolve) => signal.addEventListener('abort', () => resolve(), { once: true }))
            throw new APIUserAbortError()
          }
        })()
      },
      async create(params) {
        return { id: 'x', object: 'chat.completion', created: 0, model: params.model, choices: [{ index: 0, finish_reason: 'stop', logprobs: null, message: { role: 'assistant', content: 'OK', refusal: null } }] }
      },
    }
  }
  return {
    anthropic: () => {
      throw new Error('not used')
    },
    openai: make,
  }
}

function settingsFor(): AppSettings {
  return { ...DEFAULT_SETTINGS, ai: { ...DEFAULT_SETTINGS.ai, templates: false, audit: false }, providers: DEFAULT_SETTINGS.providers.map((p) => ({ ...p, hasApiKey: true })) }
}

async function runChat(transports: AiTransports, providerId: string, opts: { messages?: ChatMessage[]; cancelAfterMs?: number; key?: string | null } = {}) {
  const events: ChatStreamEvent[] = []
  const service = createAiServiceWithTransports({ getSettings: settingsFor, getApiKey: () => (opts.key === undefined ? 'sk-test' : opts.key) }, transports)
  const p = service.chat(
    { requestId: 'r', providerId, messages: opts.messages ?? [{ role: 'user', content: [{ type: 'text', text: 'Una brida' }] }] },
    (e) => events.push(e),
  )
  if (opts.cancelAfterMs !== undefined) setTimeout(() => service.cancel('r'), opts.cancelAfterMs)
  await p
  return events
}

const terminal = (events: ChatStreamEvent[]) => events.filter((e) => e.type === 'done' || e.type === 'error')
const doneOf = (events: ChatStreamEvent[]) => {
  const t = terminal(events)
  expect(t).toHaveLength(1)
  return t[0] as Extract<ChatStreamEvent, { type: 'done' }>
}

// ---------------------------------------------------------------------------

describe('toOpenAIMessages', () => {
  const opts = { kind: 'openai' as const, model: 'gpt-5.1', tools: true }

  it('adds the system prompt, image data URLs before text, tool messages before the user turn', () => {
    const out = toOpenAIMessages(
      [
        { role: 'user', content: [{ type: 'text', text: 'Hola' }, { type: 'image', mediaType: 'image/jpeg', data: 'QUJD' }] },
        { role: 'assistant', text: 'Te propongo', toolCalls: [{ id: 'toolu_01', name: CAD_TOOL_NAME, input: { schemaVersion: 1 } }] },
        { role: 'user', content: [{ type: 'text', text: 'Ahora más alto' }], toolResults: [{ toolCallId: 'toolu_01', content: 'OK', isError: false }] },
      ],
      opts,
    )
    expect(out[0]).toEqual({ role: 'system', content: SYSTEM_PROMPT })
    expect(out[1]).toEqual({
      role: 'user',
      content: [
        { type: 'image_url', image_url: { url: 'data:image/jpeg;base64,QUJD' } },
        { type: 'text', text: 'Hola' },
      ],
    })
    expect(out[2]).toEqual({
      role: 'assistant',
      content: 'Te propongo',
      tool_calls: [{ id: 'toolu_01', type: 'function', function: { name: CAD_TOOL_NAME, arguments: '{"schemaVersion":1}' } }],
    })
    expect(out[3]).toEqual({ role: 'tool', tool_call_id: 'toolu_01', content: 'OK' })
    expect(out[4]).toEqual({ role: 'user', content: 'Ahora más alto' })
  })

  it('replays raw content (provider extras) only for the same kind and model', () => {
    const raw = {
      role: 'assistant',
      content: null,
      tool_calls: [{ id: 'gem_1', type: 'function', function: { name: CAD_TOOL_NAME, arguments: '{}' }, extra_content: { google: { thought_signature: 'SIG' } } }],
    }
    const history = (model: string): ChatMessage[] => [
      { role: 'user', content: [{ type: 'text', text: 'x' }] },
      { role: 'assistant', text: '', toolCalls: [{ id: 'gem_1', name: CAD_TOOL_NAME, input: {} }], raw: { providerKind: 'gemini', model, content: raw } },
      { role: 'user', content: [], toolResults: [{ toolCallId: 'gem_1', content: 'INVALID: x', isError: true }] },
    ]
    const same = toOpenAIMessages(history('gemini-2.5-pro'), { kind: 'gemini', model: 'gemini-2.5-pro', tools: true })
    expect(same[2]).toBe(raw)
    expect(same[3]).toEqual({ role: 'tool', tool_call_id: 'gem_1', content: 'INVALID: x' })
    expect(same).toHaveLength(4) // tool results only: no empty user message
    const other = toOpenAIMessages(history('gemini-2.5-flash'), { kind: 'gemini', model: 'gemini-2.5-pro', tools: true })
    expect(other[2]).toEqual({ role: 'assistant', content: null, tool_calls: [{ id: 'gem_1', type: 'function', function: { name: CAD_TOOL_NAME, arguments: '{}' } }] })
  })

  it('converts Anthropic history (ids kept, missing results synthesized)', () => {
    const out = toOpenAIMessages(
      [
        { role: 'user', content: [{ type: 'text', text: 'x' }] },
        { role: 'assistant', text: 'a', toolCalls: [{ id: 'toolu_01ABC', name: CAD_TOOL_NAME, input: {} }], raw: { providerKind: 'anthropic', model: 'claude-opus-5-5', content: [] } },
        { role: 'user', content: [{ type: 'text', text: 'y' }] },
      ],
      opts,
    )
    expect(out[3]).toEqual({ role: 'tool', tool_call_id: 'toolu_01ABC', content: 'No result was returned for this tool call.' })
    expect(out[4]).toEqual({ role: 'user', content: 'y' })
  })

  it('renders tool calls/results as text when tools are unavailable', () => {
    const out = toOpenAIMessages(
      [
        { role: 'user', content: [{ type: 'text', text: 'x' }] },
        { role: 'assistant', text: 'Modelo:', toolCalls: [{ id: 'c1', name: CAD_TOOL_NAME, input: { schemaVersion: 1 } }] },
        { role: 'user', content: [], toolResults: [{ toolCallId: 'c1', content: 'BUILD_ERRORS: fillet', isError: true }] },
      ],
      { kind: 'ollama', model: 'llama', tools: false },
    )
    expect(out[1]).toEqual({ role: 'system', content: NO_TOOLS_ADDENDUM })
    expect(out[3]).toEqual({ role: 'assistant', content: 'Modelo:\n\n```json\n{"schemaVersion":1}\n```' })
    expect(out[4]).toEqual({ role: 'user', content: 'Tool result (error):\nBUILD_ERRORS: fillet' })
    expect(out.some((m) => m.role === 'tool')).toBe(false)
  })
})

describe('buildOpenAIParams', () => {
  const base = { messages: [{ role: 'user', content: [{ type: 'text', text: 'x' }] }] as ChatMessage[], ai: { ...DEFAULT_SETTINGS.ai, templates: false, audit: false }, tools: true, reasoning: true, streamUsage: true }

  it('OpenAI: strict function with the strict schema, reasoning effort, no parallel calls', () => {
    const p = buildOpenAIParams({ ...base, kind: 'openai', model: 'gpt-5.1', strict: true })
    const tool = p.tools![0] as { type: string; function: { name: string; strict?: boolean; parameters: unknown } }
    expect(tool.function.name).toBe(CAD_TOOL_NAME)
    expect(tool.function.strict).toBe(true)
    expect(tool.function.parameters).toBe(cadToolSchema('openai-strict'))
    expect(p.parallel_tool_calls).toBe(false)
    expect(p.reasoning_effort).toBe('high')
    expect(p.stream_options).toEqual({ include_usage: true })
    const nonStrict = buildOpenAIParams({ ...base, kind: 'openai', model: 'gpt-4.1', strict: false })
    expect((nonStrict.tools![0] as { function: { strict?: boolean; parameters: unknown } }).function.strict).toBeUndefined()
    expect((nonStrict.tools![0] as { function: { parameters: unknown } }).function.parameters).toBe(cadToolSchema('openai'))
    expect(nonStrict.reasoning_effort).toBeUndefined()
  })

  it('Gemini / Ollama: non-strict compat schema, no reasoning params', () => {
    for (const kind of ['gemini', 'ollama', 'openai-compatible'] as const) {
      const p = buildOpenAIParams({ ...base, kind, model: 'm', strict: true })
      const fn = (p.tools![0] as { function: { strict?: boolean; parameters: unknown } }).function
      expect(fn.strict).toBeUndefined()
      expect(fn.parameters).toBe(cadToolSchema('compat'))
      expect(p.reasoning_effort).toBeUndefined()
      expect(p.parallel_tool_calls).toBeUndefined()
    }
  })

  it('client config: placeholder key for keyless servers and default Ollama URL', () => {
    expect(clientConfig({ ...provider('ollama'), baseURL: undefined }, null)).toEqual({ apiKey: 'not-needed', baseURL: 'http://localhost:11434/v1' })
    expect(clientConfig(provider('gemini'), 'g-key')).toEqual({ apiKey: 'g-key', baseURL: 'https://generativelanguage.googleapis.com/v1beta/openai/' })
  })
})

describe('extractModelFromText', () => {
  it('finds fenced JSON models and strips them from the text', () => {
    const text = `Aquí tienes la brida.\n\n\`\`\`json\n${JSON.stringify(EXAMPLE_FLANGE, null, 2)}\n\`\`\`\n`
    const r = extractModelFromText(text)!
    expect(r.model).toEqual(EXAMPLE_FLANGE)
    expect(r.text).toBe('Aquí tienes la brida.')
  })

  it('handles bare JSON, unfenced JSON after prose, and ignores other JSON', () => {
    expect(extractModelFromText(JSON.stringify(EXAMPLE_ASSEMBLY))!.model).toEqual(EXAMPLE_ASSEMBLY)
    expect(extractModelFromText(`Modelo: ${JSON.stringify(EXAMPLE_FLANGE)}`)!.text).toBe('Modelo:')
    expect(extractModelFromText('```json\n{"a": 1}\n```')).toBeUndefined()
    expect(extractModelFromText('```json\n{"schemaVersion": 1, broken\n```')).toBeUndefined()
    expect(extractModelFromText('```python\n{"schemaVersion": 1}\n```')).toBeUndefined()
    expect(extractModelFromText('sin modelo')).toBeUndefined()
  })
})

describe('OpenAI-compatible streaming chat', () => {
  it('accumulates tool-call argument deltas and maps usage', async () => {
    const args = JSON.stringify(EXAMPLE_FLANGE)
    const pieces = splitArgs(args)
    const chunks = [
      chunk({ role: 'assistant', content: 'Diseño ' }),
      chunk({ content: 'la brida.' }),
      chunk({ tool_calls: [{ index: 0, id: 'call_1', type: 'function', function: { name: CAD_TOOL_NAME, arguments: '' } }] }),
      ...pieces.map((p) => chunk({ tool_calls: [{ index: 0, function: { arguments: p } }] })),
      chunk({}, 'tool_calls'),
      { id: 'c', object: 'chat.completion.chunk', created: 0, model: 'gpt-5.1', choices: [], usage: { prompt_tokens: 9000, completion_tokens: 800, total_tokens: 9800, prompt_tokens_details: { cached_tokens: 8000 } } } as ChatCompletionChunk,
    ]
    const calls: ChatCompletionCreateParamsStreaming[] = []
    const events = await runChat(fakeTransports(() => ({ chunks }), calls), 'openai')
    expect(events[0]).toMatchObject({ type: 'start', model: 'gpt-5.1' })
    expect(events.filter((e) => e.type === 'text_delta').map((e) => (e as { text: string }).text).join('')).toBe('Diseño la brida.')
    expect(events.filter((e) => e.type === 'tool_progress').length).toBeGreaterThan(1)
    const done = doneOf(events)
    expect(done.stopReason).toBe('tool_use')
    expect(done.message.text).toBe('Diseño la brida.')
    expect(done.message.toolCalls).toEqual([{ id: 'call_1', name: CAD_TOOL_NAME, input: EXAMPLE_FLANGE }])
    expect(done.usage).toEqual({ inputTokens: 9000, outputTokens: 800, cacheReadTokens: 8000 })
    expect(done.message.raw).toMatchObject({ providerKind: 'openai', model: 'gpt-5.1', content: { role: 'assistant', tool_calls: [{ id: 'call_1', function: { arguments: args } }] } })
    expect(calls[0]!.model).toBe('gpt-5.1')
  })

  it('handles Gemini-style tool calls (no index, finish "stop", extras kept for replay) and reasoning deltas', async () => {
    const chunks = [
      chunk({ reasoning_content: 'pensando…' } as ChatCompletionChunk.Choice.Delta),
      chunk({ tool_calls: [{ id: 'g1', type: 'function', function: { name: CAD_TOOL_NAME, arguments: JSON.stringify(EXAMPLE_FLANGE) }, extra_content: { google: { thought_signature: 'S' } } } as unknown as ChatCompletionChunk.Choice.Delta.ToolCall] }, 'stop'),
    ]
    const events = await runChat(fakeTransports(() => ({ chunks }), []), 'gemini')
    expect(events.filter((e) => e.type === 'thinking_delta')).toHaveLength(1)
    const done = doneOf(events)
    expect(done.stopReason).toBe('tool_use')
    expect(done.message.thinking).toBe('pensando…')
    expect(done.message.toolCalls![0]!.input).toEqual(EXAMPLE_FLANGE)
    const raw = done.message.raw!.content as { tool_calls: Array<Record<string, unknown>> }
    expect(raw.tool_calls[0]!.extra_content).toEqual({ google: { thought_signature: 'S' } })
  })

  it('converts a fenced JSON model in plain text into a synthetic tool call', async () => {
    const text = `Te propongo esta brida.\n\`\`\`json\n${JSON.stringify(EXAMPLE_FLANGE)}\n\`\`\``
    const chunks = [...splitArgs(text, 50).map((p) => chunk({ content: p })), chunk({}, 'stop')]
    const configs: Array<{ apiKey: string; baseURL?: string }> = []
    const calls: ChatCompletionCreateParamsStreaming[] = []
    const events = await runChat(fakeTransports(() => ({ chunks }), calls, configs), 'ollama', { key: null })
    expect(configs[0]).toEqual({ apiKey: 'not-needed', baseURL: 'http://localhost:11434/v1' })
    expect(calls[0]!.stream_options).toEqual({ include_usage: true })
    const done = doneOf(events)
    expect(done.stopReason).toBe('tool_use')
    expect(done.message.text).toBe('Te propongo esta brida.')
    expect(done.message.toolCalls).toHaveLength(1)
    expect(done.message.toolCalls![0]!.name).toBe(CAD_TOOL_NAME)
    expect(done.message.toolCalls![0]!.input).toEqual(EXAMPLE_FLANGE)
  })

  it('passes invalid argument JSON through as a string (renderer reports INVALID)', async () => {
    const chunks = [chunk({ tool_calls: [{ index: 0, id: 'c', function: { name: CAD_TOOL_NAME, arguments: '{"schemaVersion":1,' } }] }), chunk({}, 'tool_calls')]
    const done = doneOf(await runChat(fakeTransports(() => ({ chunks }), []), 'openai'))
    expect(done.message.toolCalls![0]!.input).toBe('{"schemaVersion":1,')
  })

  it('reports an error when the output is cut while generating the tool call', async () => {
    const chunks = [chunk({ tool_calls: [{ index: 0, id: 'c', function: { name: CAD_TOOL_NAME, arguments: '{"schemaVersion":1,' } }] }), chunk({}, 'length')]
    const events = await runChat(fakeTransports(() => ({ chunks }), []), 'openai')
    const t = terminal(events)
    expect(t).toHaveLength(1)
    expect((t[0] as Extract<ChatStreamEvent, { type: 'error' }>).error.code).toBe('max_tokens')
  })

  it('retries without strict when OpenAI rejects the schema, and without tools when the model has none', async () => {
    const calls: ChatCompletionCreateParamsStreaming[] = []
    const ok = { chunks: [chunk({ content: 'hola' }, 'stop')] }
    const events = await runChat(
      fakeTransports((p) => {
        const fn = (p.tools?.[0] as { function: { strict?: boolean } } | undefined)?.function
        if (fn?.strict) return { chunks: [], throwFirst: APIError.generate(400, { error: { message: "Invalid schema for function 'emit_cad_model': too many nested levels" } }, undefined, new Headers()) }
        return ok
      }, calls),
      'openai',
    )
    expect(calls).toHaveLength(2)
    expect((calls[1]!.tools![0] as { function: { strict?: boolean } }).function.strict).toBeUndefined()
    expect(doneOf(events).stopReason).toBe('end_turn')

    const calls2: ChatCompletionCreateParamsStreaming[] = []
    const events2 = await runChat(
      fakeTransports((p) => {
        if (p.tools) return { chunks: [], throwFirst: APIError.generate(400, { error: { message: 'registry.ollama.ai/library/gemma:2b does not support tools' } }, undefined, new Headers()) }
        return ok
      }, calls2),
      'ollama',
    )
    expect(calls2).toHaveLength(2)
    expect(calls2[1]!.tools).toBeUndefined()
    expect(calls2[1]!.messages[1]).toEqual({ role: 'system', content: NO_TOOLS_ADDENDUM })
    expect(doneOf(events2).message.text).toBe('hola')
  })

  it('nudge turn: when Gemini cannot force the tool ("too many states"), retries without tools and extracts the JSON', async () => {
    const calls: ChatCompletionCreateParamsStreaming[] = []
    const text = `Aquí está.\n\`\`\`json\n${JSON.stringify(EXAMPLE_FLANGE)}\n\`\`\``
    const messages: ChatMessage[] = [
      { role: 'user', content: [{ type: 'text', text: 'Una brida' }] },
      { role: 'assistant', text: 'He diseñado una brida de 160 mm con seis taladros.' },
      { role: 'user', content: [{ type: 'text', text: TOOL_NUDGE_TEXT }] },
    ]
    const events = await runChat(
      fakeTransports((p) => {
        if (p.tool_choice === 'required') {
          return {
            chunks: [],
            throwFirst: APIError.generate(400, { error: { message: 'The specified schema produces a constraint that has too many states for serving.' } }, undefined, new Headers()),
          }
        }
        return { chunks: [...splitArgs(text, 80).map((c) => chunk({ content: c })), chunk({}, 'stop')] }
      }, calls),
      'gemini',
      { messages },
    )
    expect(calls).toHaveLength(2)
    expect(calls[0]!.tool_choice).toBe('required')
    expect(calls[1]!.tools).toBeUndefined()
    expect(calls[1]!.messages[1]).toEqual({ role: 'system', content: NO_TOOLS_ADDENDUM })
    const done = doneOf(events)
    expect(done.message.toolCalls![0]!.input).toEqual(EXAMPLE_FLANGE)
    // The model written as text is replayed as text, never as a function call Gemini did not issue.
    const raw = done.message.raw!.content as { tool_calls?: unknown; content: string }
    expect(raw.tool_calls).toBeUndefined()
    expect(raw.content).toContain('```json')
    const replay = toOpenAIMessages([...messages, done.message, { role: 'user', content: [{ type: 'text', text: 'más alta' }], toolResults: [{ toolCallId: done.message.toolCalls![0]!.id, content: 'OK', isError: false }] }], {
      kind: 'gemini',
      model: 'other-model',
      tools: true,
    })
    expect(replay.some((m) => m.role === 'tool')).toBe(false)
    expect(JSON.stringify(replay.at(-1))).toContain('Tool result')
  })

  it('maps errors and content filter, cancels cleanly', async () => {
    const err = await runChat(fakeTransports(() => ({ chunks: [], throwFirst: APIError.generate(401, { error: { message: 'bad key' } }, undefined, new Headers()) }), []), 'openai')
    expect(terminal(err)).toHaveLength(1)
    expect((terminal(err)[0] as Extract<ChatStreamEvent, { type: 'error' }>).error).toMatchObject({ code: 'auth', retryable: false })

    const conn = await runChat(fakeTransports(() => ({ chunks: [], throwFirst: APIError.generate(undefined, undefined, 'Connection error.', undefined) }), []), 'ollama', { key: null })
    expect((terminal(conn)[0] as Extract<ChatStreamEvent, { type: 'error' }>).error).toMatchObject({ code: 'network', retryable: true })
    expect((terminal(conn)[0] as Extract<ChatStreamEvent, { type: 'error' }>).error.message).toMatch(/Ollama/)

    const filtered = doneOf(await runChat(fakeTransports(() => ({ chunks: [chunk({ content: 'x' }, 'content_filter')] }), []), 'openai'))
    expect(filtered.stopReason).toBe('refusal')
    expect(filtered.message.toolCalls).toBeUndefined()

    const cancelled = doneOf(await runChat(fakeTransports(() => ({ chunks: [chunk({ content: 'parcial' })], hang: true }), []), 'openai', { cancelAfterMs: 30 }))
    expect(cancelled.stopReason).toBe('cancelled')
    expect(cancelled.message.text).toBe('parcial')
  })
})

describe('AI service', () => {
  const okTransports = () => fakeTransports(() => ({ chunks: [chunk({ content: 'hola' }, 'stop')] }), [])

  it('refuses missing keys, disabled and unknown providers with exactly one error event', async () => {
    const missing = await runChat(okTransports(), 'openai', { key: null })
    expect(missing).toHaveLength(1)
    expect((missing[0] as Extract<ChatStreamEvent, { type: 'error' }>).error.code).toBe('auth')

    const events: ChatStreamEvent[] = []
    const settings = settingsFor()
    settings.providers = settings.providers.map((p) => (p.id === 'gemini' ? { ...p, enabled: false } : p))
    const service = createAiServiceWithTransports({ getSettings: () => settings, getApiKey: () => 'k' }, okTransports())
    await service.chat({ requestId: 'z', providerId: 'gemini', messages: [] }, (e) => events.push(e))
    await service.chat({ requestId: 'z2', providerId: 'nope', messages: [] }, (e) => events.push(e))
    expect(events.map((e) => (e as Extract<ChatStreamEvent, { type: 'error' }>).error.code)).toEqual(['disabled', 'unknown_provider'])
  })

  it('never throws even if emit throws', async () => {
    const service = createAiServiceWithTransports({ getSettings: settingsFor, getApiKey: () => 'k' }, okTransports())
    await expect(
      service.chat({ requestId: 'q', providerId: 'openai', messages: [{ role: 'user', content: [{ type: 'text', text: 'x' }] }] }, () => {
        throw new Error('renderer gone')
      }),
    ).resolves.toBeUndefined()
  })

  it('testProvider: missing key, success and failure', async () => {
    const service = createAiServiceWithTransports({ getSettings: settingsFor, getApiKey: (id) => (id === 'openai' ? null : 'k') }, okTransports())
    expect(await service.testProvider('openai')).toEqual({ ok: false, message: 'Falta la clave API' })
    const ok = await service.testProvider('ollama')
    expect(ok.ok).toBe(true)
    expect(ok.message).toMatch(/Conexión correcta/)
    expect(typeof ok.latencyMs).toBe('number')

    const failing: AiTransports = {
      anthropic: () => ({
        stream: () => {
          throw new Error('unused')
        },
        create: async () => {
          throw AnthropicAPIError.generate(401, { error: { type: 'authentication_error', message: 'invalid x-api-key' } }, undefined, new Headers())
        },
      }),
      openai: okTransports().openai,
    }
    const svc2 = createAiServiceWithTransports({ getSettings: settingsFor, getApiKey: () => 'k' }, failing)
    const bad = await svc2.testProvider('anthropic')
    expect(bad.ok).toBe(false)
    expect(bad.message).toMatch(/clave API/)
  })

  it('uses a custom provider baseURL and requires it', async () => {
    const custom: ProviderConfig = { id: 'custom-1', kind: 'openai-compatible', label: 'LM Studio', baseURL: 'http://127.0.0.1:1234/v1', model: 'qwen', models: [], hasApiKey: false, requiresApiKey: false, enabled: true }
    const settings = { ...settingsFor(), providers: [...settingsFor().providers, custom, { ...custom, id: 'custom-2', baseURL: '' }] }
    const configs: Array<{ apiKey: string; baseURL?: string }> = []
    const calls: ChatCompletionCreateParamsStreaming[] = []
    const service = createAiServiceWithTransports({ getSettings: () => settings, getApiKey: () => null }, fakeTransports(() => ({ chunks: [chunk({ content: 'hola' }, 'stop')] }), calls, configs))
    const events: ChatStreamEvent[] = []
    await service.chat({ requestId: 'c1', providerId: 'custom-1', messages: [{ role: 'user', content: [{ type: 'text', text: 'x' }] }] }, (e) => events.push(e))
    await service.chat({ requestId: 'c2', providerId: 'custom-2', messages: [] }, (e) => events.push(e))
    expect(configs[0]).toEqual({ apiKey: 'not-needed', baseURL: 'http://127.0.0.1:1234/v1' })
    expect(calls[0]!.stream_options).toBeUndefined()
    expect(calls[0]!.model).toBe('qwen')
    expect(terminal(events).map((e) => e.type)).toEqual(['done', 'error'])
  })
})

describe('proxy / certificado CA (proveedores OpenAI-compatibles)', () => {
  const PEM = '-----BEGIN CERTIFICATE-----\nabc\n-----END CERTIFICATE-----\n'

  it('clientConfig propaga proxy y certificado', () => {
    const p: ProviderConfig = { ...provider('openai'), proxy: 'http://pxy:3128', caCertificate: 'C:\\ca.pem' }
    expect(clientConfig(p, 'k')).toEqual({ apiKey: 'k', baseURL: undefined, proxy: 'http://pxy:3128', caCertificate: 'C:\\ca.pem' })
    expect(clientConfig(provider('openai'), 'k')).toEqual({ apiKey: 'k', baseURL: undefined, proxy: undefined, caCertificate: undefined })
  })

  it('sin proxy ni CA no hay dispatcher (red por defecto)', () => {
    expect(buildNetworkDispatcher(undefined, undefined)).toBeUndefined()
    expect(buildNetworkDispatcher('  ', '  ')).toBeUndefined()
  })

  it('CA inline PEM o desde ruta', async () => {
    const inline = buildNetworkDispatcher(undefined, PEM)
    expect(inline).toBeDefined()
    await inline!.close()
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cima-ca-'))
    const file = path.join(dir, 'ca.pem')
    fs.writeFileSync(file, PEM, 'utf8')
    const fromFile = buildNetworkDispatcher(undefined, file)
    expect(fromFile).toBeDefined()
    await fromFile!.close()
    fs.rmSync(dir, { recursive: true, force: true })
  })

  it('ruta de CA inexistente -> error claro', () => {
    expect(() => buildNetworkDispatcher(undefined, 'Z:/no/existe.pem')).toThrow(/No se pudo leer el certificado CA/)
  })

  it('proxy con credenciales (incluidas sin codificar) -> uri limpia + token Basic', async () => {
    expect(splitProxyUrl('http://u:p@pxy:3128')).toEqual({ uri: 'http://pxy:3128', token: 'Basic ' + Buffer.from('u:p').toString('base64') })
    expect(splitProxyUrl('http://u:p%40q@pxy:3128').token).toBe('Basic ' + Buffer.from('u:p@q').toString('base64'))
    expect(splitProxyUrl('http://u:p%q@pxy:3128').token).toBe('Basic ' + Buffer.from('u:p%q').toString('base64'))
    expect(splitProxyUrl('http://pxy:3128')).toEqual({ uri: 'http://pxy:3128' })
    const d = buildNetworkDispatcher('http://u:p@pxy:3128')
    expect(d).toBeDefined()
    await d!.close()
  })

  it('proxy + CA -> ProxyAgent con TLS del objetivo', async () => {
    const d = buildNetworkDispatcher('http://pxy:3128', PEM)
    expect(d).toBeInstanceOf(ProxyAgent)
    await d!.close()
  })
})
