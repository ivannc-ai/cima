# CIMA - CATIA 3DEXPERIENCE (native client) automation via COM / VBScript

Research date: 2026-11-21. Scope: the native CATIA app of the 3DEXPERIENCE platform, R2022x to R2026x (builds B424 to B428), driven from outside by COM (`cscript.exe` + VBScript, launched by the Electron main process) to build the same parametric parts and assemblies as the CIMA V5 connector. CATIA is not installed on the dev machine. Every statement below comes from the official automation reference (as reproduced verbatim by pycatia3dx), from open-source code whose authors report running it live on 3DEXPERIENCE, or from forum and blog reports. Nothing here was run against a real CATIA by us.

Confidence tags (same convention as `product.md`):

- **[H]** high: two or more independent sources agree, at least one of them primary (official DSYAutomation text, or code its authors ran live on 3DEXPERIENCE).
- **[M]** medium: one good source, or a well-supported inference from several weaker ones.
- **[L]** low: inference, an old or uncorroborated report, or anything that must be validated on a real install before CIMA relies on it.

Source keys used in the text (full URLs in [Sources](#sources)):

| Key | What it is | Release it speaks for |
|---|---|---|
| **DSY25** | `DSYAutomation.chm`, the official 3DEXPERIENCE automation reference shipped in `win_b64\code\bin`, as reproduced verbatim in the docstrings of pycatia3dx (generated from the R2025x files, 2025-09 to 2026-02) | R2025x |
| **P3DX** | pycatia3dx (evereux, author of pycatia): code, examples, GitHub issues #1, #12, #14, #16, #18 | R2025x / R2026x (incl. student edition) |
| **CB** | catia-bridge: MCP server driving CATIA V5 and 3DEXPERIENCE; live smoke test "51 passed, 2 expected skips" on 3DEXPERIENCE R428 SP6 (`B428_Cloud`), English and French sessions, plus live assembly probes | R2026x live |
| **A3** | auto-3dx: Python SDK for 3DEXPERIENCE; live probes on `B428_Cloud` with pywin32 and Dassault's `com3dx.py`; type-library dumps | R2026x live |
| **R3D** | Rand 3D blog series "Transitioning Macros from CATIA V5 to 3DEXPERIENCE" (7 parts, 2024-2025), by a CATIA certified instructor | recent 3DX |
| **S4V5** | scripting4v5.com V6 articles and their reader comments (2017-2018) | R2017x-R2018x |
| **CW** | catiawidgets.net 3DX posts (VBA, Python, token launch) | R2020x (B422) - R2022x |
| **KS** | kai-shek.com "Create a new file" (3DX VBA snippet) | recent 3DX |
| **JUS** | github.com/jussi-code/CATIA-R2018x-VBScripts (VBScript macros run in 3DX) | R2018x |
| **GMZ** | goermezer.de "CATIA V6 automatisieren mit Python" | V6 |
| **V6DOC** | V6 user documentation mirror (catiahelp.azurewebsites.net): macros concepts, VPMInstance PLM class | V6 (2013x era) |

---

## 0. Key conclusions (TL;DR)

1. **The 3DEXPERIENCE native app registers the same COM ProgID as V5, `CATIA.Application`**, as an out-of-process server (`3DEXPERIENCE.exe` in `<install>\win_b64\code\bin`). `GetObject(, "CATIA.Application")` from cscript attaches to a running, logged-in session exactly as with V5 [H]. Registration can be missing after an upgrade (one R2026x user got "Invalid class string") [M]. With V5 and 3DX both installed, the ProgID points to whichever registered last [M].
2. **Platform detection:** `CATIA.Name` is `"CNEXT"` on V5 [H] and `"3DEXPERIENCE"` on 3DX [M-H]. Confirm by probing a 3DX-only member (`CATIA.GetSessionService`, `CATIA.ActiveEditor`): V5 raises VBScript error 438 [H]. Do not rely on `SystemConfiguration.Version/Release` on 3DX (values undocumented) [L].
3. **Creating content:** `CATIA.GetSessionService("PLMNewService").PLMCreate userType, oEditor`. `"3DShape"` and `"Drawing"` are documented and always allowed. `"3DPart"` and `"VPMReference"` (Physical Product) also work, but only with an extra licence (reported as **E70 or VMX**). Without it CATIA opens a **modal "Operation not authorized" (Licensing) dialog that blocks the automation** until a human closes it [H].
4. **Getting the `Part`:** right after `PLMCreate "3DShape"`, `oEditor.ActiveObject` is the `Part` [H]. When an editor shows a 3D Part or Physical Product at product level, `ActiveObject` is a `VPMRootOccurrence`, and the Part is `ActiveObject.ReferenceRootOccurrenceOf.RepInstances.Item(1).ReferenceInstanceOf.GetItem("Part")` [H]. From a Part: `Part.Parent` is the `VPMRepReference` (the 3D Shape), and `.Father` of that is the `VPMReference` (the 3D Part, only for a shape that lives inside a 3D Part) [H].
5. **Once you hold the Part, the V5 modelling APIs are unchanged:** ShapeFactory, HybridShapeFactory, Sketches/Factory2D, Parameters, Relations [H]. **Part Design enum numeric values are identical to V5**; 3DX only appends new members at the end of a few enums [H]. Live R2026x differences exist (hole depth ignored by `AddNewHoleFromSketch`, `GetCOfG` instead of `GetCOG`, no `GetPointsOnCurve`, topology must be searched from the body, localized search keywords) [M-H].
6. **Assemblies are the weak point.** Since 2014x the documented API has no method to add instances: `VPMInstances` documents only `Count`/`Item` [H]. `VPMInstances.Add(iReference, oInstance)` is still in the R2026x type library and was reported working in 2018 [M], but it is undocumented and unverified on R2022x+ [L]. `VPMRepInstances.Add` exists in the type library but was refused live on R2026x [M]. Copy/Paste through `Editor.Selection` still works [M]. Placement is solid: `VPMInstance.Position.SetComponents arr12` (relative to the parent, mm), verified live [H]. Titles are set with `SetAttributeValue "V_Name", ...` [H].
7. **Save** = `GetSessionService("PLMPropagateService").PLMPropagate`. It saves the active editor's content to 3DSpace; `Save` is deprecated since V6R2011x [H]. **No file export exists in the automation API:** `ExportData` on PLM-backed content fails with E_FAIL on R2026x (two independent live tests) [H]. CIMA must write STEP itself (replicad/OpenCascade) and never depend on CATIA 3DX for export.
8. **Scripting model:** there is no `Editor.Close`; close with `CATIA.ActiveWindow.Close` [M]. External automation is possible (COM out-of-proc, used from Python, Excel VBA, MCP servers) [H]. In-CATIA macros live in PLM macro libraries (VBScript `.catvbs`, CATScript, VBA, VSTA C#/VB.NET) [H]. **`CATIA.SystemService.Evaluate(code, 0, "Fn", params)` runs VBScript inside CATIA** and is the live-proven way to call methods with out-parameters [H]. 3DX `SystemService` has **no `ExecuteScript`**; stored scripts run through `PLMScriptService.ExecuteScriptV6` [H].
9. **3DSpace REST web services** (Engineering Items `dseng`, documents/FCS, xCAD) can create product-structure metadata and attach files, but **cannot author native CATIA geometry** [M]. The CIMA 3DX connector must go through the native client.

---

## 1. Release and build numbers [M]

| Release | Install folder / build | Evidence |
|---|---|---|
| R2020x | `B422` | CW token post: `C:\Program Files\Dassault Systemes\B422\win_b64\code\bin\3DEXPERIENCE.exe` |
| R2022x | `B424` | inferred (one build number per yearly release) |
| R2023x | `B425` | inferred |
| R2024x | `B426` | inferred |
| R2025x | `B427` | inferred; DSY25 is this release |
| R2026x | `B428` (cloud: `B428_Cloud`) | P3DX #1 ("since updating to 3DX 2026x") and #14 (`D:\Program Files\Dassault Systemes\B428_Cloud\...`, same user); CB and A3 say "R428" |

Executable: `<install>\win_b64\code\bin\3DEXPERIENCE.exe` [H: P3DX, CW, A3]. Dassault also ships a Python COM helper at `<install>\win_b64\code\python3dx\lib\com3dx.py` (`get3dxClient()`), which resolves the running session through the Running Object Table [H: P3DX #1/#14, A3, CW].

---

## A. Detection

### A.1 Does the 3DEXPERIENCE native app register `CATIA.Application`? Yes [H]

| Source | Evidence | Release |
|---|---|---|
| CB `connection.py` | `GetActiveObject("CATIA.Application")`, then detect; comment: "Both CATIA V5 and 3DEXPERIENCE register this ProgID" | R428 SP6, live |
| A3 `transport/windows_com.py` | finds the install by reading `HKCR\CATIA.Application\CLSID`, then `HKCR\CLSID\{clsid}\LocalServer32` -> exe path -> `..\..\python3dx\lib\com3dx.py` (so LocalServer32 points at the 3DX exe in `code\bin`) | B428_Cloud, live |
| P3DX `base_application.py` | falls back to `Dispatch('CATIA.Application')`; issues #16 and #18 run with `catia3dx(com3dx=False)`, i.e. plain Dispatch | R2026x student, live |
| GMZ | `win32com.client.GetActiveObject('CATIA.Application')` on CATIA V6 | V6 |
| S4V5 comment (2018) | Excel VBA `CreateObject("Catia.application")` reaches V6 | R2017x/18x |

Counter-evidence [M]: P3DX issue #1. After upgrading to R2026x, `Dispatch('CATIA.Application')` failed with `-2147221005 Invalid class string` (`CO_E_CLASSSTRING`: the ProgID is not in the registry). The user worked around it with `com3dx.get3dxClient()`, which goes through the Running Object Table. The maintainer suspected a broken upgrade.

How the registration is created: no public document found for a `3DEXPERIENCE.exe /regserver` switch [L]. CB tells users to "start the native app once from the launcher". The V5 equivalent is `CNEXT.exe /regserver` run as administrator.

CIMA rule: if `GetObject` fails with error 429 or `-2147221005` while `3DEXPERIENCE.exe` is running, report "CATIA 3DEXPERIENCE is running but its COM registration is missing: repair the installation or ask IT". CIMA must not write to the registry itself.

### A.2 Attaching from cscript

```vb
' VBScript run by cscript.exe (64-bit: C:\Windows\System32\cscript.exe)
Option Explicit
Dim CATIA
On Error Resume Next
Set CATIA = GetObject(, "CATIA.Application")
If Err.Number <> 0 Then
  WScript.StdErr.WriteLine "CIMA_ERR attach " & Err.Number & " " & Err.Description
  WScript.Quit 2
End If
On Error GoTo 0
```

- **Never `CreateObject` on 3DX** [H: CB, CW]. A fresh 3DEXPERIENCE.exe needs an interactive 3DPassport login, the launcher's environment and a chosen collaborative space. CB runs its tree builder with `allow_launch=False`. (Scripts can start 3DX with `3DEXPERIENCE.exe -Url=https://<server>/3dspace/ -Tk=<login ticket>`, CW; CIMA should not.)
- **One CATIA at a time.** With several CATIA processes (or V5 and 3DX together), `GetObject` may attach to the wrong one. CB refuses to connect when several CATIA processes run [M]. CIMA's Node side should list processes first (`CNEXT.exe`, `3DEXPERIENCE.exe`).
- The user must be logged in and have the target collaborative space selected. `PLMCreate` creates in the current security context, and saving needs an Author or Leader role in it (R3D part 7) [H].

### A.3 Telling V5 from 3DEXPERIENCE at runtime

| Probe | CATIA V5 | CATIA 3DEXPERIENCE | Confidence |
|---|---|---|---|
| `CATIA.Name` | `"CNEXT"` (pycatia test asserts `Application(name="CNEXT")`) | `"3DEXPERIENCE"` (P3DX `check_catia_version`: `if application.name != "3DEXPERIENCE"` -> warning) | V5 [H], 3DX [M-H] |
| `CATIA.GetSessionService(...)`, `CATIA.ActiveEditor`, `CATIA.Editors` | not members: VBScript runtime error **438** ("Object doesn't support this property or method") | documented members (DSY25) | [H] (V5 member list from pycatia; 3DX from DSY25) |
| `CATIA.Documents` / `CATIA.ActiveDocument` | normal file-based documents | `Documents` exists in the type library (Count = 2 in a live session), but `ActiveDocument` fails with "The method ActiveDocument failed". Not usable. | V5 [H], 3DX [M] (A3 live) |
| Process / `CATIA.FullName` | `...\code\bin\CNEXT.exe` | `...\win_b64\code\bin\3DEXPERIENCE.exe` | process name [H]; FullName value inferred [M] |
| `SystemConfiguration.Version` | `5` | undocumented: DSY25 copies the V5 text "usually version 5". CB uses `Version >= 6` only as a last fallback. | 3DX value [L] |
| `SystemConfiguration.Release`, `.ServicePack` | e.g. 28 / 33 | undocumented values (could be 428, 26 or something else) | [L]; log them for diagnostics only |
| `CATIA.Caption` | contains the active document name | | do not use: CB removed caption detection because a V5 file named "3DEXPERIENCE_bracket.CATPart" switched it to 3DX |

Recommended VBScript (name first, member probe as the tie-breaker):

```vb
Function CimaDetectPlatform(app)
  Dim nm, svc
  nm = ""
  On Error Resume Next
  nm = UCase(CStr(app.Name))
  Err.Clear
  Set svc = app.GetSessionService("PLMNewService")   ' 3DX-only member
  If Err.Number = 0 Then
    CimaDetectPlatform = "3DX"
  ElseIf Err.Number = 438 Then                        ' member unknown -> V5
    CimaDetectPlatform = "V5"
  ElseIf nm = "3DEXPERIENCE" Then
    CimaDetectPlatform = "3DX"
  ElseIf nm = "CNEXT" Then
    CimaDetectPlatform = "V5"
  Else
    CimaDetectPlatform = "UNKNOWN:" & nm
  End If
  Err.Clear
  On Error GoTo 0
End Function
```

Also print `app.SystemConfiguration.Version`, `.Release`, `.ServicePack` and `app.Caption` into the log so the first real 3DX run tells us the actual values.

---

## B. Creating a 3D Shape, 3D Part or Physical Product, and getting the `Part`

### B.1 `PLMNewService` (DSY25) [H]

```
Sub PLMCreate(CATBSTR iUserType, Editor oEditor)
    Creates a new PLM entity corresponding to a given user type.
    The PLM Attributes of the created object are initialized using the Initialization
    Business Logic Rule. The creation will fail if all the mandatory attributes are not
    filled by the Business Logic Rule. [...]
    iUserType  Legal values: 3DShape: to create a 3D Representation,
               Drawing: to create a Drawing Representation
    oEditor    The resulting editor on the newly created data.

Sub SetAttributeValue(CATBSTR iAttributeID, CATVariant iAttributeValue)
    PreSets the PLM Attribute value for the next entity creation (PLMCreate).
    After next creation, values are flushed. [...] Date as "mm/dd/yyyy";
    list attributes NOT SUPPORTED.
```

Class remark (DSY25): "In case this product is not granted the PLMCreate method of the interface fails." A3's type-library dump (B428) also shows `getLastError(oErrorMessage, oErrorCode)` on PLMNewService. After a licensing refusal it returned `('', 0)`, so it is useless for diagnosis [M].

| `iUserType` | Creates | `oEditor.ActiveObject` right after creation | Licence | Sources |
|---|---|---|---|---|
| `"3DShape"` | standalone 3D Shape (`VPMRepReference`, PLM_ExternalID like `3sh-...`) | **`Part`** | none extra, always allowed | DSY25, P3DX example, CW, KS, R3D, CB live [H] |
| `"Drawing"` | Drawing representation | `DrawingRoot` | none | DSY25, R3D [H] |
| `"3DPart"` | Physical Product flagged as 3D Part (`VPMReference`), with its own 3D Shape stored inside it | `Part` in 2017-2018 field code (two S4V5 readers); CB handles both `Part` and `VPMRootOccurrence` | **E70 or VMX** | R3D, S4V5, CB, P3DX #12 [H for licence; M for ActiveObject] |
| `"VPMReference"` | Physical Product (assembly node, PLM_ExternalID like `prd-...`) | `VPMRootOccurrence` | **E70 or VMX** | R3D, A3 (refused without licence), CB [H] |

Notes:

- The user-type strings are the `GetCustomType()` values of existing objects: a `VPMRepReference` returns `"3DShape"`, a `VPMReference` returns `"VPMReference"` (A3 live) [M].
- The licence names come from R3D ("either VMX or E70"), the S4V5 article ("E70") and CB (live on R428 student role: `PLMCreate "VPMReference"` -> "Gestion des licences: Opération non autorisée"; E70 and VMX not authorized, PDG authorized). A3 got `[Licensing] Operation not authorized` on an education account, and the COM error `(-2147352567, ..., 'CATIAPLMNewService', 'The method PLMCreate failed', ..., -2147467259)` [H].
- **The refusal is a modal dialog.** CB: "the refusal is a blocking dialog on many roles". Its default therefore creates a 3D Shape, and a 3D Part only when a probe proved the licence. CIMA must do the same [H].
- The new content opens in a **new editor and window, which become `CATIA.ActiveEditor` / `CATIA.ActiveWindow`** [H: CB; S4V5 code closes `CATIA.ActiveWindow` after creation].
- "3DPart vs Physical Product + 3D Shape": a 3D Part is a `VPMReference` meant for a single detail part. Its 3D Shape is stored inside it and cannot be released without it, and it cannot take further child shapes (P3DX #12, maintainer and contributor) [M].
- Some 2017-2019 forum macros use `CATIA.GetSessionService("PLMNewService2")` [L]. It is not in DSY25; ignore it.
- Licence pre-check: `CATIA.SystemConfiguration.IsProductAuthorized(name)` exists (DSY25), but the name format is uncertain. CB tried `"E70"` then `"E70.prd"` and records which form ever answers True. Treat `False` as proof only if some other product (for example `PDG`) answered `True` with the same name form [M].

### B.2 VBScript: create a 3D Shape (or a 3D Part when allowed) and get its Part

```vb
' Returns the new Editor, or Nothing. userType: "3DShape" | "3DPart" | "VPMReference" | "Drawing"
Function CimaPlmCreate(app, userType, title)
  Dim svc, ed, nBefore
  Set CimaPlmCreate = Nothing
  Set svc = app.GetSessionService("PLMNewService")
  If Len(title) > 0 Then svc.SetAttributeValue "V_Name", title   ' Title of the next created object
  nBefore = app.Editors.Count
  ed = Empty
  On Error Resume Next
  svc.PLMCreate userType, ed                                      ' ed is an out-parameter
  If Err.Number <> 0 Then
    WScript.StdErr.WriteLine "CIMA_ERR PLMCreate " & userType & " " & Err.Number & " " & Err.Description
    Err.Clear
    On Error GoTo 0
    If app.Editors.Count > nBefore Then Set CimaPlmCreate = app.ActiveEditor   ' created, out-param lost
    Exit Function
  End If
  On Error GoTo 0
  If IsObject(ed) Then
    Set CimaPlmCreate = ed
  Else
    Set CimaPlmCreate = app.ActiveEditor        ' the new editor is the active one (CB fallback)
  End If
End Function

' Part behind an editor: 3D Shape level (ActiveObject is the Part) or
' product level (ActiveObject is a VPMRootOccurrence). Returns Nothing if none.
Function CimaPartFromEditor(ed)
  Dim obj, ref, reps, i, repRef, p, sf
  Set CimaPartFromEditor = Nothing
  Set obj = ed.ActiveObject
  On Error Resume Next
  Set sf = obj.ShapeFactory                     ' only a Part has ShapeFactory
  If Err.Number = 0 Then
    Set CimaPartFromEditor = obj
    On Error GoTo 0
    Exit Function
  End If
  Err.Clear
  Set ref = obj.ReferenceRootOccurrenceOf       ' VPMRootOccurrence -> VPMReference
  If Err.Number <> 0 Then
    Err.Clear
    Set ref = obj                               ' maybe already a VPMReference
  End If
  Set reps = ref.RepInstances
  For i = 1 To reps.Count
    Set repRef = reps.Item(i).ReferenceInstanceOf   ' VPMRepReference (3D Shape)
    Set p = repRef.GetItem("Part")
    If Err.Number = 0 Then
      Set sf = p.ShapeFactory
      If Err.Number = 0 Then
        Set CimaPartFromEditor = p
        Exit For
      End If
    End If
    Err.Clear
  Next
  On Error GoTo 0
End Function
```

Navigation facts used above:

| Step | Member | Evidence |
|---|---|---|
| 3D Shape level -> Part | `Editor.ActiveObject` | DSY25 (P3DX example `Part(editor.active_com_object)`), CW ("ActiveObject - Part"), KS, R3D part 5, CB [H] |
| Product level -> root occurrence | `Editor.ActiveObject` is a `VPMRootOccurrence` (or `Editor.GetService("PLMProductService").RootOccurrence`) | R3D part 5, CB, JUS, S4V5 (Antoine) [H] |
| Root occurrence -> reference | `VPMRootOccurrence.ReferenceRootOccurrenceOf` (read-only property) | DSY25, R3D, JUS, P3DX example [H] |
| Reference -> its representations | `VPMReference.RepInstances` (collection of `VPMRepInstance`, `Item(1)`-based) | DSY25, R3D, JUS, CB [H] |
| Rep instance -> rep reference | `VPMRepInstance.ReferenceInstanceOf` | DSY25, R3D, JUS [H] |
| Rep reference -> Part | `VPMRepReference.GetItem("Part")` | R3D part 5 ("finally, get the Part object"), JUS, P3DX example, CB (live) [H] |
| Session-wide alternative | `CATIA.GetSessionService("ProductSessionService").Shape3Ds.Item(i).Part` | DSY25 only [M] |
| Part -> 3D Shape PLM object | `Part.Parent` = `VPMRepReference` | S4V5 article and Antoine's code, P3DX #18 (sets `V_Name` on it), CB [H] |
| 3D Shape -> 3D Part | `VPMRepReference.Father` = `VPMReference` ("only works for a once instantiable" representation, i.e. a shape inside a 3D Part) | DSY25, S4V5 [H] |

In VBScript the navigation members (`ReferenceRootOccurrenceOf`, `ReferenceInstanceOf`, `InstanceOccurrenceOf`) are read without parentheses. DSY25 declares them as read-only properties. R3D writes `ReferenceRootOccurrenceOf()` with parentheses in VBA, which also works.

### B.3 Same modelling APIs once you have the Part [H]

| Area | Status on 3DX | Evidence |
|---|---|---|
| `Part.Bodies`, `MainBody`, `HybridBodies`, `OriginElements.PlaneXY/YZ/ZX`, `CreateReferenceFromObject`, `InWorkObject`, `Update`, `UpdateObject`, `Parameters`, `Relations` | same members as V5 | DSY25 (pycatia3dx `mmr_automation_interfaces.part`), A3 type-library listing of `Part` methods, P3DX examples, CB live |
| `Sketches.Add`, `OpenEdition`/`CloseEdition`, `Factory2D.Create*`, sketch `Constraints` | same | CB live (constrained sketches, slots, polygons on R428) |
| `ShapeFactory.AddNewPad/Pocket/Shaft/Groove/Hole*/EdgeFillet*/Chamfer/Shell/RectPattern/CircPattern/Mirror/Add/Remove/Intersect/Split/Loft/Rib/ThickSurface` | same | CB live R428 (pads, pockets, holes, patterns, fillets, chamfers, shells, shafts, grooves, mirror, booleans, lofts, ribs), P3DX example (`AddNewThickSurface`, `AddNewAdd`) |
| `HybridShapeFactory` (points, lines, planes, extrude, spline, direction) | same | P3DX example, CB live (GSD) |
| User parameters and formulas | same | CB live R428 (each literal becomes a user parameter, values driven by formulas; editability checked by editing a parameter and a sketch dimension); JUS reads `part.Parameters` |
| `Selection` | moved from `Document` to **`Editor.Selection`**; `SelectElement2/3` replaced by `SelectElement` / `SelectMultipleElements`; `Copy/Cut/Delete/Paste/Search` unchanged | R3D part 6, DSY25, CB [H] |
| Measurement | not `SPAWorkbench`: `Editor.GetService("MeasurableService")` / `GetService("InertiaService")` | R3D services, CB live [H] |

Live check reported by CB on R428 (build inside an imported part from the product window), as VBScript:

```vb
Set body = part.Bodies.Add()
Set sk = body.Sketches.Add(part.CreateReferenceFromObject(part.OriginElements.PlaneXY))
Set f2d = sk.OpenEdition()
f2d.CreateClosedCircle 0, 0, 3
sk.CloseEdition
part.InWorkObject = body
Set pad = part.ShapeFactory.AddNewPad(sk, 5)
part.UpdateObject pad
' measured 141.3717 mm3 = pi * 3^2 * 5  -> lengths in mm, same as V5
```

#### Enum numeric values: 3DX R2025x vs V5 [H]

Method: pycatia (V5) and pycatia3dx (R2025x) both derive enum values from the declaration order in the official docs. I compared all 77 enums present in the downloaded pycatia3dx modules (`part`, `mmr_automation_interfaces`, `sketcher`, `system`, `interfaces`, `os`, `knowledge_interfaces`, `plm_access`) with pycatia's `enumeration_types.py`. 67 are identical, 0 have a changed value, 7 only gained members at the end, and 10 are 3DX-only. HybridShape enums are not exposed by pycatia3dx and were not compared. CB reads `CatHoleThreadingMode` and `CATMeasurableType` from the live type library instead of trusting docs, which is the safe practice for anything critical.

| Enum | Values (identical on V5 and 3DX unless noted) |
|---|---|
| `CatLimitMode` | 0 catOffsetLimit, 1 catUpToNextLimit, 2 catUpToLastLimit, 3 catUpToPlaneLimit, 4 catUpToSurfaceLimit, 5 catUpThruNextLimit; **3DX adds 6 catUntilLimit** |
| `CatPrismOrientation` | 0 catRegularOrientation, 1 catInverseOrientation |
| `CatPrismExtrusionDirection` | 0 catNormalToSketchDirection, 1 catNotNormalToSketchDirection |
| `CatFilletEdgePropagation` | 0 catMinimalFilletEdgePropagation, 1 catTangencyFilletEdgePropagation |
| `CatFilletVariation` | 0 catLinearFilletVariation, 1 catCubicFilletVariation |
| `CatChamferMode` | 0 catTwoLengthChamfer, 1 catLengthAngleChamfer |
| `CatChamferPropagation` | 0 catTangencyChamfer, 1 catMinimalChamfer |
| `CatChamferOrientation` | 0 catNoReverseChamfer, 1 catReverseChamfer |
| `CatHoleType` | 0 catSimpleHole, 1 catTaperedHole, 2 catCounterboredHole, 3 catCountersunkHole, 4 catCounterdrilledHole |
| `CatHoleBottomType` | 0 catFlatHoleBottom, 1 catVHoleBottom, 2 catTrimmedHoleBottom |
| `CatHoleAnchorMode` | 0 catExtremPointHoleAnchor, 1 catMiddlePointHoleAnchor |
| `CatHoleThreadingMode` | 0 catThreadedHoleThreading, 1 catSmoothHoleThreading |
| `CatSplitSide` | 0 catPositiveSide, 1 catNegativeSide |
| `CatCircularPatternParameters` | 0 catInstancesandAngularSpacing, 1 catCompleteCrown, 2 catUnequalAngularSpacing |
| `CatRectangularPatternParameters` | 0 catInstancesandSpacing, 1 catUnequalSpacing |
| `CatDraftMode` | 0 standard, 1 reflect keep face, 2 reflect keep edge |
| `CatConstraintType` | 0 catCstTypeReference, 1 Distance, 2 On, 3 Concentricity, 4 Tangency, 5 Length, 6 Angle, 7 PlanarAngle, 8 Parallelism, 9 AxisParallelism, 10 Horizontality, 11 Perpendicularity, 12 AxisPerpendicularity, 13 Verticality, 14 Radius, 15 Symmetry, 16 MidPoint, 17 Equidistance, 18 MajorRadius, 19 MinorRadius, 20 SurfContact, ... 30 SdShape; **3DX adds 31 catCstTypeCurvilinearDistance** |
| `CatConstraintMode` | 0 catCstModeDrivingDimension, 1 catCstModeDrivenDimension |
| `CatConstraintRefType` | 0 catCstRefTypeRelative, 1 catCstRefTypeFixInSpace |
| `CATScriptLanguage` | 0 CATVBScriptLanguage, 1 CATVBALanguage, 2 CATBasicScriptLanguage, 3 CATJavaLanguage, 4 CATJScriptLanguage; **3DX adds 5 CATCSharpLanguage, 6 CATVBNetLanguage** |
| `CatScriptLibraryType` | 0 catScriptLibraryTypeDocument, 1 catScriptLibraryTypeDirectory, 2 catScriptLibraryTypeVBAProject; **3DX adds 3 catScriptLibraryTypeVSTAProject** |
| `CatCompareOccurrenceResult` (3DX only) | 0 catDifferentObjects, 1 catIdenticalOccurrence, 2 catIdenticalReference |

Consequence: **CIMA's V5 VBScript generator can be reused unchanged for features**. Only the document layer (create/open/save, getting the Part, selection, measurement, assemblies) needs a 3DX variant.

### B.4 3DX-specific gotchas found live on R2026x (mostly CB, R428 SP6) [M-H]

1. **`ShapeFactory.AddNewHoleFromSketch` ignores its depth argument** (the bottom limit stays 10 mm). Set `hole.BottomLimit.Dimension.Value = depth` after creation and read it back. CB now does this on V5 too.
2. **Topology searches must run on the body, not the last feature.** A last-shape search returns only the cells that feature created (2 faces for a Hole) or none after a boolean. Fillet and chamfer edge selection by `Selection.Search` therefore needs the body as the search root.
3. **Search keywords are localized.** On a French session `"Topology.Face,sel"` fails with E_FAIL; French needs `Topologie.Face`, `Topologie.Arête`, `Topologie.Sommet`. Name searches (`Name=...,all`) need no translation. `GeometricElements.Item("AbsoluteAxis")` fails on French sessions: use `Sketch.AbsoluteAxis.VerticalReference` / `.HorizontalReference` instead of names.
4. **No `GetPointsOnCurve`** on 3DX measurables. **`GetCOfG`** replaces V5 `GetCOG`. Measurement goes through `Editor.GetService("MeasurableService")` / `"InertiaService"`. Units (live): coordinates in mm; CB reports volume and area with the same MKS convention as V5 and converts.
5. `UserPattern` of a sketch-positioned Hole is rejected on update. The `AnchorPoint` recipe is not documented in DSYAutomation R428.
6. Symmetric Pad/Pocket: the length is **per side** (a 20 mm symmetric pad is 40 mm thick). This is the same on V5 and was checked live on R428.
7. Fresh parts: solid features can fail with E_FAIL when the in-work object is a Geometrical Set. Always set `part.InWorkObject = body` before Pad/Pocket/Hole/Shaft/Groove. Field evidence from V5-6R2020 by CB; apply on both platforms.
8. `Application.Documents` / `ActiveDocument`, `Document.GetWorkbench("SPAWorkbench")` and `Document.Selection` belong to the V5 model and must not be used on 3DX (see A.3).
9. **No `Dim x As Type` in generated code.** cscript's VBScript rejects it. CATIA's own `.catvbs` engine tolerates it (JUS macros use `Language="VBSCRIPT"` plus `Dim x As Type`), but keep one dialect that runs everywhere.

### B.5 Out-parameters, and where the generated script should run

- `PLMCreate`, `PLMOpen`, `Position.GetComponents`, `PLMPropagateService.getLastError` and similar return values **through parameters**. VBScript passes every variable by reference as a VARIANT, which is how CATScript macros call them.
- Python/pywin32 cannot do this (it passes by value). CB and P3DX therefore run small VBScript functions **inside CATIA** with `CATIA.SystemService.Evaluate(code, 0 (CATVBScriptLanguage), "FnName", Array(params...))`. CB does this live on R428 for `PLMCreate`, `PLMOpen`, `GetComponents`, `GetCOfG` and `GetProductNames`; the P3DX #14 contributor shows `GetInertiaMatrix` through `Evaluate` on B428 [H].
- From cscript the direct call (`svc.PLMCreate "3DShape", ed`) should work, because cscript's VBScript sends the same `VT_BYREF|VT_VARIANT` arguments through the standard IDispatch proxy that in-CATIA VBScript sends in process. **This is not verified on 3DX** [M]. Two fallbacks make it safe:
  1. After `PLMCreate`, use `CATIA.ActiveEditor`, since the new editor becomes active (CB does this when the out-parameter is lost) [H].
  2. Wrap the call in `Evaluate`.
- **Recommended design for the CIMA 3DX connector** [M]:
  - Generate the whole build as one VBScript function `CimaMain(app, args)` with no `CATIA` global and no `As` clauses.
  - Have a tiny cscript launcher attach and call `CATIA.SystemService.Evaluate(code, 0, "CimaMain", Array(CATIA, payload))`.
  - Benefits: one cross-process call instead of thousands, no out-parameter marshalling questions, and the same text can be pasted into a 3DX macro library as a `.catvbs`.
  - Risks: Evaluate's maximum script size is unknown [L]. A runtime error inside comes back as one opaque COM error, so the generated code should collect a step log and return it (or write it with `CATIA.FileSystem` / `Scripting.FileSystemObject`). Modal dialogs still block.
  - Keep the direct out-of-process mode, the one the V5 connector uses, as a fallback and for debugging.
- `SystemService` on 3DX (DSY25): `Environ`, `Evaluate`, `ExecuteBackgroundProcessus`, `ExecuteProcessus`, `GetMessage`, `Print`, `PrintToStdout`. **No `ExecuteScript`** (V5 has it). To run a script stored in a PLM macro library: `CATIA.GetSessionService("PLMScriptService").ExecuteScriptV6 iPLMEntity, iLibraryType, "Macro1.catvbs", "CATMain", params` [H for existence (DSY25); untested].

---

## C. Assemblies

### C.1 Object model [H] (DSY25, R3D part 4, CB, JUS)

```
Editor --GetService("PLMProductService")--> PLMProductService
   .RootOccurrence  : VPMRootOccurrence      (session-only occurrence tree; = Editor.ActiveObject at product level)
   .EditedContent   : PLMEntities            (root entities; first is the root product)
VPMRootOccurrence
   .ReferenceRootOccurrenceOf : VPMReference (the root Physical Product)
   .Occurrences    : VPMOccurrences          (children occurrences)
   .RepOccurrences : VPMRepOccurrences
VPMOccurrence
   .InstanceOccurrenceOf : VPMInstance
   .Occurrences, .Position (also aggregated on occurrences per R3D)
VPMReference  (Physical Product / 3D Part, persistent)
   .Instances    : VPMInstances     (child product instances)   -- documented members: Count, Item
   .RepInstances : VPMRepInstances  (representation instances: 3D Shapes, drawings)
   .Publications : VPMPublications
   GetItem("CATEngConnections") -> EngConnections (Add / Item / Remove)   (R3D)
VPMInstance
   .ReferenceInstanceOf : VPMReference   (the instantiated reference)
   .Parent              : VPMReference   (the owning reference)
   .Position            : Position       (read-only property returning the Position object)
VPMRepInstance -> .ReferenceInstanceOf : VPMRepReference -> GetItem("Part") / .Father / .ParentRepInstances
All PLM objects: GetAttributeValue(name), SetAttributeValue(name, value), GetCustomType()
```

Navigation example (JUS, R2018x VBScript run in CATIA, `As` removed):

```vb
Set rootOcc = CATIA.ActiveEditor.ActiveObject            ' VPMRootOccurrence
Set rootRef = rootOcc.ReferenceRootOccurrenceOf          ' VPMReference
Set repRef  = rootRef.RepInstances.Item(1).ReferenceInstanceOf
Set part1   = repRef.GetItem("Part")
```

From an occurrence to its part (CB live on R428):
`occ.InstanceOccurrenceOf.ReferenceInstanceOf.RepInstances.Item(1).ReferenceInstanceOf.GetItem("Part")`. Features can be built in that Part from the product's window (live: body + pad created, measured, deleted).

### C.2 Adding components: what exists

| Route | Status | Evidence | Confidence |
|---|---|---|---|
| `VPMInstances.Add iReference, oInstance` | **Not in the documentation since 2014x** ("The earlier (2013x and before) 3DX API had methods to add or remove components [...] removed [...] you can't manipulate the product structure [...] in 2014x or later", R3D part 4; DSY25 lists no method on `VPMInstances`). **Still present in the type library on B428** (A3 dump: `VPMInstances.Add(iProductReference, oProductInstance)`). A 2018 S4V5 reader (Antoine) posted working code that inserts a new 3D Part under the current product with it; a 2017 reader got "Add method fail" when he read `Instances` after the active editor had changed. | R3D, DSY25, A3, S4V5 | present [H]; works on R2022x+ [L] |
| `VPMRepInstances.Add iRepInstanceName, iRepReference, oRepInstance` | in the B428 type library, undocumented, **refused live** on R428 SP6 (also pasting a shape under a product root was refused) | A3, CB | [M] |
| Copy / Paste with `Editor.Selection` | "Copy/Paste, however, still works" (R3D part 4); CB implements insert-existing and add-new-part this way: open the component in its own editor, `Selection.Add rootOccurrence`, `Copy`, activate the product window, `Selection.Add targetRootOccurrence`, `Paste`, check the child count went up by exactly one | R3D, CB | [M] (CB could not run it live: product creation was refused by the licence) |
| Create the product itself (`PLMCreate "VPMReference"`) | needs E70/VMX, modal refusal otherwise | R3D, A3, CB | [H] |
| Assembly constraints | 3DX uses engineering connections; no documented automation to create them (`EngConnections.Add` exists per R3D; untested) | CB, R3D | [M] |

Antoine's 2018 code (S4V5 comment) converted to cscript-compatible VBScript. **Unverified on R2022x+ [L]**; needs E70/VMX:

```vb
' Active editor shows the target Physical Product.
Set rootOcc   = CATIA.ActiveEditor.ActiveObject                ' VPMRootOccurrence
Set instances = rootOcc.ReferenceRootOccurrenceOf.Instances    ' read BEFORE PLMCreate (active editor changes)
Set svc = CATIA.GetSessionService("PLMNewService")
svc.SetAttributeValue "V_Name", "Bolt"
svc.PLMCreate "3DPart", ed3dp                                  ' new editor + window for the 3D Part
Set part   = ed3dp.ActiveObject                                ' Part
Set repRef = part.Parent                                       ' VPMRepReference (3D Shape)
Set ref    = repRef.Father                                     ' VPMReference (the 3D Part)
Set win3dp = CATIA.ActiveWindow
instances.Add ref, newInst                                     ' undocumented since 2014x
win3dp.Close
' newInst is the VPMInstance; reuse the same `ref` for every further instance of this part
```

### C.3 Instance placement [H]

DSY25 `Position` (inherits `Move`):

- `Sub GetComponents(CATSafeArrayVariant oAxisComponentsArray)` and `Sub SetComponents(iAxisComponentsArray)`: position **relative to the parent** ("in the coordinate space of the context").
- `GetAbsComponents` / `SetAbsComponents`: position in the global (root) context.
- `Move.Apply(iTransformationArray)`: applies a relative transformation to a movable object (R3D: "rotates and/or moves the component from its current location").
- Array layout (12 doubles, same as V5): `0-2` X axis, `3-5` Y axis, `6-8` Z axis (unit vectors expressed in the parent frame), `9-11` origin. **Lengths in mm.**

Live evidence (CB on R428 SP6): `Position.SetComponents` moved an instance 10 mm along X (`after[9] - before[9] = 10.0`), read back, and restored exactly. After a STEP import, every `GetComponents` matched the STEP instance placements, including a rotated bolt.

```vb
' m = 12 numbers: X axis(3), Y axis(3), Z axis(3), origin(3) in mm, relative to the parent product.
Sub CimaSetInstancePosition(inst, m)
  Dim a(11), i
  For i = 0 To 11
    a(i) = CDbl(m(i))
  Next
  inst.Position.SetComponents a          ' inst: VPMInstance (or occurrence.InstanceOccurrenceOf)
End Sub
```

Mapping from a CIMA placement (rotation matrix R whose columns are the child's axes in the parent frame, translation t in mm): `a = [R00,R10,R20, R01,R11,R21, R02,R12,R22, tx,ty,tz]`, the columns of R in order [H; same as V5 `Product.Position`].

Reading back (`GetComponents` with a `Dim r(11)` array) is an out-parameter call. Run it through `Evaluate` if the direct cscript call returns zeros [M].

### C.4 Naming and PLM attributes [H]

| Attribute | Meaning | Notes |
|---|---|---|
| `V_Name` | **Title** (what the user sees) | Set it before creation with `PLMNewService.SetAttributeValue "V_Name", t`, or after with `obj.SetAttributeValue "V_Name", t`. Search by Title with `AddEasyCriteria "V_Name", "x*"` (R3D, CB, P3DX #16/#18) |
| `PLM_ExternalID` | **Name** (unique id, generated by business rules: `prd-R1132100891411-00394022`, `3sh-...`) | do not try to set it (A3, P3DX #16) |
| `V_description`, `revision`, `current` (maturity), `owner`, `project`, `organization`, `originated`, `modified`, `V_discipline`, `V_usage`, `physicalid` | standard read attributes | CB `STANDARD_ATTRIBUTES`, A3 |

Where to set them:

- `VPMReference` for a 3D Part or Physical Product.
- `VPMRepReference` (= `Part.Parent`) for a standalone 3D Shape. P3DX #18 working code: `part.Parent.SetAttributeValue "V_Name", "Purple Monkeys"`.
- `VPMInstance` for the instance (V6 class doc: instance "Name" = `PLM_ExternalID`).

DSY25 rules: dates as `"mm/dd/yyyy"`, list values as `"v1;v2;"`. In an authoring editor all public R/W attributes can be modified. Writes stay in session until saved, and the role or data model decides what is writable. Quirk: `GetAttributeValue("Name")` returned the Title in P3DX #16, so always use the internal names above.

### C.5 Recommended CIMA assembly strategy on 3DX

1. **Default (no special licence):** build every distinct part as its own **3D Shape**, in its own frame and titled with the part name, then save. Also write the assembly STEP from replicad, with names and placements, so the user can import it in 3DX. Optionally, if the user imported that STEP, "adopt" it the way CB does: walk the imported product's occurrences, match names and positions, and rebuild each part natively inside the imported part's Part, replacing the dead solid. CB did this live on R428 in 2.3 s for a 3-instance bracket.
2. **Licensed mode** (user setting "I have E70/VMX", or `IsProductAuthorized` proves it):
   - `PLMCreate "VPMReference"` for the root, with its title preset.
   - For each distinct part, `PLMCreate "3DPart"`, build the features, then insert it with `VPMInstances.Add` (try) or Copy/Paste (fallback), checking the child count.
   - Place every instance with `Position.SetComponents`, read it back and compare.
3. Never save implicitly. Show "Save to 3DEXPERIENCE" as an explicit action (see D.1).

---

## D. Saving, exporting, closing, macro and scripting limits

### D.1 Save [H]

```vb
Set ps = CATIA.GetSessionService("PLMPropagateService")
ps.PLMPropagate              ' DSY25: "Propagate CATIAEditor modifications to the PLM provider repository."
```

- R3D: "only saves content of the Active Editor!" A3 warns it may commit other unsaved session changes; it never ran it [M]. Activate the right window before calling, and save each created part's editor in turn.
- `PLMPropagateService.Save()` is "Deprecated: V6R2011x" (DSY25).
- `getLastError(oErrorMessage, oErrorCode)` returns the diagnosis of the last save (out-parameters: use VBScript variables or Evaluate). Code 0 means success.
- Saving writes to the shared 3DSpace database, visible according to the collaborative space. It needs Author, Leader or Owner role (R3D part 7) and passes through business-rule checks (mandatory attributes).

### D.2 Close [M]

- DSY25 `Editor` exposes only `ActiveObject`, `Selection` and `GetService`; A3's type library adds `GetItem`. **There is no `Editor.Close`.**
- Close the window instead: `CATIA.ActiveWindow.Close` (S4V5 Antoine's code; CB uses `Window.Close` to drop the source editor).
- CB: "Closes the active window; unsaved changes are discarded unless save=true". Whether a confirmation dialog can appear on some setups is unverified [L]. Close only after saving or when discarding is intended.
- `CATIA.DisplayFileAlerts` exists on 3DX (DSY25); whether it suppresses PLM prompts is unknown [L].

### D.3 Export to STEP: not available through automation [H]

- DSY25 documents no export service. The pycatia3dx service list has no export service. A3 grepped the whole R2026x type library: the only `ExportData` is on the V5-compatible `Document` / `PartDocument` classes.
- **Live R2026x, two independent tests:**
  - A3: `PartDocument.ExportData(path, "stp")` and `(path, "stl")`, reached through `Application.Documents`, both failed with `E_FAIL` on PLM-backed content (empty `Path`, opaque `FullName`). No file was written.
  - CB: "on R428 the compatibility document refuses `ExportData`". Its `catia_export` returns `UNSUPPORTED_CAPABILITY` on 3DX.
- Interactive export (File/Me menu > Export) needs the ST1 licence for STEP (CB). `CATIA.StartCommand` could open the dialog but not drive it.
- **CIMA consequence:** STEP/STL come from CIMA's own replicad model. A STEP of a 3DX-built part would need the user's manual export, or server-side Derived Outputs (see E) [L].

### D.4 Macros inside 3DEXPERIENCE [H]

- Languages: CATScript, VBScript (`.catvbs`, "we recommend that you prefer VB Script to CATScript"), VBA (Windows only, has a debugger and forms), and VSTA (VB.NET / C#). Sources: V6DOC macros concepts, R3D part 1 ("you can use VBScript, CATScript, or VBA"; also VB.NET or C#).
- Macro libraries are **stored in the PLM database**, as PLM Directories (VBScript/CATScript), PLM VBA projects or PLM VSTA projects. Tools > Macro > Macros (Alt+F8) > Macro libraries > Create new library / Add existing library / Create new library from files (import V5 macro files). They need a role allowed to create content in the collaborative space; one S4V5 reader without rights could neither create a library nor record macros.
- **The 3DX equivalent of the V5 ".CATScript export"** is to paste the generated VBScript (header line `Language="VBSCRIPT"`, `Sub CATMain()`) into a new VBScript macro in a PLM Directory library. R3D recommends Copy/Paste for VBScript between libraries. CIMA can offer "Copy macro for 3DEXPERIENCE" plus instructions. A `.catvbs` file on disk can also go through "Create new library from files".
- Deployment: develop in a private "local" library, then copy to a public "global" library. Macros can be assigned to Action Bar icons per user (R3D part 7).
- Recent releases also bundle Python (`python3dx` + `com3dx`) and Simulation apps that can run Python scripts (P3DX #14) [M].

### D.5 External automation from cscript: allowed, with constraints [H]

- Evidence of external clients: Python pywin32 (`GetActiveObject` / `Dispatch` on `CATIA.Application`: CB, P3DX, GMZ), Dassault's own `com3dx.py`, Excel VBA (S4V5 reader). No source mentions a policy blocking external COM clients. An R2019x user reported a broken macro tool (`ScriptingERR-122`) and could not add the COM reference in Visual Studio, which points to registration and install issues.
- Constraints:
  1. CATIA must be started from the launcher and logged in.
  2. Only one CATIA instance should run.
  3. **Modal dialogs block every COM call** (licence refusal, update errors). CB runs calls on a guarded worker with a watchdog that reports the dialog text. CIMA's Electron main should time out the cscript child and tell the user to look at CATIA.
  4. Cross-process calls are slow. Prefer `RefreshDisplay = False` during builds, and the `Evaluate` single-call design (B.5).
  5. Use 64-bit `cscript.exe`.

### D.6 Open existing content (for completeness) [H]

```vb
Set ss = CATIA.GetSessionService("Search")
Set q = ss.DatabaseSearch
q.BaseType = "VPMReference"              ' Physical Product / 3D Part; "3DShape" for shapes
q.AddEasyCriteria "V_Name", "CIMA_*"     ' Title, wildcards allowed
ss.Search
Set found = q.Results                    ' PLMEntities, Item(1)-based
Set os = CATIA.GetSessionService("PLMOpenService")
os.PLMOpen found.Item(1), ed             ' ed: out-parameter Editor (also PLMOpenInNewWindow)
```

Sources: R3D part 2, CB `plm.py`, P3DX #16 (search on `3DShape` by `V_Name` works; on `PLM_ExternalID` too). The old V6 API (`GetSessionService("PLMSearch")`, `.Searches.Add`, `.Type = "ProductDS"`, `AddAttributeCriteria`; GMZ, S4V5) fails on newer releases ("The method Type failed") [M].

---

## E. 3DSpace web services (REST): brief [M/L]

Not verified in depth in this session (web search budget exhausted). From the vendor developer documentation structure and general knowledge; the Engineering Item reference page exists at `media.3ds.com/.../CAAEngItemWS/dseng_v1.htm`, behind a 3DPassport login.

- The platform exposes REST "web services" on 3DSpace, under `https://<3dspace>/resources/v1/modeler/...`. Examples: Engineering (`dseng:EngItem` create/read/modify Physical Products, `dseng:EngInstance` for child instances), documents with FCS file check-in/check-out, xCAD (third-party CAD files), lifecycle/maturity, classification, and Derived Outputs (server-generated derivatives such as STEP/3DXML when the admin configured them).
- Authentication: 3DPassport (CAS ticket, or an OAuth/agent for integrations), a CSRF token from `/resources/v1/application/CSRF` (`ENO_CSRF_TOKEN` header), and a `SecurityContext` header ("ctx::Role.Organization.Collaborative Space").
- What a desktop app could do: create Engineering Items (product structure, titles, attributes) and upload files (e.g. CIMA's STEP as an attached document) without the native client.
- What it cannot do: author **native CATIA geometry**. A 3D Shape's content is a CATIA authoring stream produced only by the native client (or server-side batch/EKL, not a public geometry API). An uploaded STEP stays a file until a CATIA user imports it.
- Other server-side automation (EKL in Engineering Rules Capture, Python3DX, batch) needs specific roles. P3DX #12 discusses EKL creating 3D Parts, but the licence gating still applies.
- **Recommendation:** out of scope for CIMA v1. A later "publish to 3DEXPERIENCE" (Engineering Item + STEP document via REST) is possible but would not give a parametric native part.

---

## F. Suggested CIMA 3DX connector flow

```
Node (Electron main)
  1. tasklist: CNEXT.exe / 3DEXPERIENCE.exe -> none: "start CATIA"; both or several: ask the user.
  2. spawn 64-bit cscript //nologo cima_3dx.vbs <jobfile>   (timeout + "check CATIA for a dialog" message)
cima_3dx.vbs
  3. GetObject(, "CATIA.Application"); CimaDetectPlatform -> "3DX"; log Name/Version/Release/ServicePack/Caption.
  4. For each part definition:
       ed = CimaPlmCreate(CATIA, licensed ? "3DPart" : "3DShape", title)
       part = CimaPartFromEditor(ed)
       part.Parent.SetAttributeValue "V_Name", title     (if the preset did not stick)
       body = part.MainBody ; part.InWorkObject = body
       user parameters + formulas, sketches, features  <- SAME generator as V5 (B.3, B.4 shims)
       part.Update
       optional: verify volume through Editor.GetService("InertiaService")
  5. Assembly: see C.5 (licensed: product + instances + SetComponents; else parts + replicad STEP).
  6. If the user asked to save: activate each editor's window -> PLMPropagateService.PLMPropagate.
  7. Print a JSON result (created titles, PLM_ExternalIDs, warnings) on stdout.
Optional in-process mode: steps 4-6 generated as one Function and run with
  CATIA.SystemService.Evaluate(code, 0, "CimaMain", Array(CATIA, payload)).
```

---

## G. Open risks and things to validate on a real 3DEXPERIENCE install

1. **COM registration** on each target release (R2022x-R2026x): does `GetObject(, "CATIA.Application")` work after upgrades? (P3DX #1 says not always.) Is there a supported re-register command for `3DEXPERIENCE.exe`? [L]
2. **Out-parameters from cscript:** does `svc.PLMCreate "3DShape", ed` fill `ed` out of process, and does `Position.GetComponents a` fill `a`? If not, use `Evaluate` (proven) [M].
3. **`SystemService.Evaluate` limits** for a large generated script (size, error reporting, whether `CATIA` is a global inside it) [L].
4. **`CATIA.Name` = "3DEXPERIENCE"** comes from one source (P3DX), and the `SystemConfiguration.Version/Release` values on 3DX are unknown [M/L].
5. **3DPart/VPMReference licence:** exact product names for `IsProductAuthorized` ("E70" vs "E70.prd"), and whether `DisplayFileAlerts = False` avoids the modal refusal (probably not) [L].
6. **Adding instances:** whether `VPMInstances.Add` still works on R2022x+ (in the type library on R2026x, undocumented), and whether Copy/Paste insertion works from a script on the user's role [L/M].
7. **`PLMPropagate` scope** (active editor only, R3D, vs. the whole session, A3's caution) and behaviour on business-rule failures (`getLastError`) [M].
8. **Window.Close with unsaved content:** silent discard or prompt [L].
9. **Localization:** any `Selection.Search` or name-based lookup must handle non-English sessions (B.4) [H that it matters].
10. Live R2026x feature quirks (hole depth, GetCOfG, topology on body) were seen by one project (CB) on one release. Re-check on R2022x-R2025x [M].
11. 3DX enum values for HybridShape enums were not compared (not exposed by pycatia3dx). Read them from the type library on first contact if CIMA uses any [M].

---

## Sources

Primary or code run live on 3DEXPERIENCE:

- pycatia3dx (DSYAutomation R2025x docstrings, examples, `base_application.py`, enums): https://github.com/evereux/pycatia3dx. Files read: `pycatia3dx/plm_session_builder/plm_new_service.py`, `plm_propagate_service.py`, `plm_open_service.py`; `product_structure_client/vpm_reference.py`, `vpm_instance.py`, `vpm_instances.py`, `vpm_rep_reference.py`, `vpm_rep_instance.py`, `vpm_root_occurrence.py`, `shape_3d.py`, `shape_3ds.py`; `vpm_editor_context/plm_product_service.py`, `product_session_service.py`; `interfaces/application.py`, `editor.py`; `mode/position.py`, `move.py`; `os/system_configuration.py`; `system/system_service.py`; `plm_access/plm_script_service.py`; `examples/example__3DShape__001.py`, `example__3DPart__001.py`, `example__hybrid_shape_factory__shape_factory__001.py`; enum modules `part`, `mmr_automation_interfaces`, `sketcher`, `system`, `interfaces`, `os`, `knowledge_interfaces`, `plm_access` (raw.githubusercontent.com/evereux/pycatia3dx/main/...)
- pycatia3dx issues: #1 "Invalid class string" after 2026x, #12 EKL/3DPart, #14 SystemService.Evaluate on B428, #16 SearchService/V_Name, #18 setting Title: https://github.com/evereux/pycatia3dx/issues
- pycatia (V5 enums `enumeration_types.py`, V5 Application, test asserting `CNEXT`): https://github.com/evereux/pycatia
- catia-bridge (connection/detection, PLM session, assembly tools, `docs/3dexperience.md`, `docs/assemblies.md`, `CHANGELOG.md` live R428 findings, `scripts/probe_assembly.py`, `catia_mcp/automation.py` Evaluate helpers, `capabilities.py` licence probe): https://github.com/maximedns5/catia-bridge
- auto-3dx (live probes on B428_Cloud: `docs/plm_object_creation.md`, `docs/api-design.md` section 12, `scripts/probes/15_plm_create.py`, `39_export.py`, `src/auto_3dx/transport/windows_com.py`): GitHub repository "auto3dx" (Korean contributor notes); snapshot read from the scratch clone
- Developer documentation page (login-gated, existence only): https://media.3ds.com/support/documentation/developer/Cloud/en/English/CAAEngItemWS/dseng_v1.htm

Secondary (blogs, forums, mirrors):

- Rand 3D, "Transitioning Macros from CATIA V5 to 3DEXPERIENCE":
  - Framework/getting started: https://resources.rand3d.com/insights-from-within/transitioning-macros-from-catia-v5-to-3dexperience-framework
  - Creating, opening and saving: https://resources.rand3d.com/insights-from-within/transitioning-macros-from-catia-v5-to-3dexperience-creating-opening-and-saving-files
  - Services: https://resources.rand3d.com/insights-from-within/transitioning-macros-from-catia-v5-to-3dexperience-services
  - Product modeler: https://resources.rand3d.com/insights-from-within/transitioning-macros-from-catia-v5-to-the-3dexperience-product-modeler
  - Part modeling and drafting: https://resources.rand3d.com/insights-from-within/transitioning-macros-from-catia-v5-to-3dexperience-part-5-part-modeling-and-drafting
  - Selections: https://resources.rand3d.com/insights-from-within/transitioning-macros-part-6-selections
  - Deployment: https://resources.rand3d.com/insights-from-within/transitioning-macros-part-7-deployment
- scripting4v5:
  - CATIA V6 macro programming (incl. 2017-2018 reader code for `Instances.Add`, `PLMCreate "3DPart"`, Excel `CreateObject`): https://www.scripting4v5.com/additional-articles/catia-v6-macro-programming/
  - New part V6 vs V5 (E70 licence, `ActiveObject.Parent`, `V_Name`): https://www.scripting4v5.com/create-a-new-part-with-v6-macro-vs-v5-macro/
- catiawidgets:
  - VBA 3DShape creation: https://www.catiawidgets.net/2022/12/16/vba/
  - Python + com3dx: https://catiawidgets.net/2022/10/01/setting-up-python-for-3dx-catia-scripting/
  - Token launch, B422 path: https://www.catiawidgets.net/2023/02/08/using-a-token-to-launch-3dx-catia-from-console-or-script/
  - Walking the V6 product structure: https://www.catiawidgets.net/2022/04/08/walk-the-catia-v6-product-structure-with-vba/
- Kai-Shek, "Create a new file" (PLMCreate "3DShape", ActiveObject -> Part): https://www.kai-shek.com/en/dateiop/create-a-new-file/
- jussi-code, CATIA R2018x VBScripts (VBScript navigation to the Part): https://github.com/jussi-code/CATIA-R2018x-VBScripts
- goermezer.de, CATIA V6 with Python (`GetActiveObject('CATIA.Application')`): https://www.goermezer.de/product-lifecycle-management/cad/536-catia-v6-automatisieren-mit-python-unter-windows.html
- HardWare.fr forum, "Create the (Product+3DShape) couple Catia V6 VBA" (2019, `PLMNewService2`)
- V6 documentation mirror:
  - Macro concepts and VSTA: https://catiahelp.azurewebsites.net/English/ (ComUserMap macros pages)
  - VPMInstance PLM class: CAADocPLMPackage
  - Product Modeler: https://catiahelp.azurewebsites.net/English/CAADocPLMModeler/CAAProduct.htm
- 3DSwym CATIA User Community questions (login-gated bodies): "3dexperience automation error" (R2019x ScriptingERR-122), "Creation of a 3D part inside an existing product using VBA", "Best Practice - Getting Started with Automation R2017x/R2020x"
- Eng-Tips threads 474363 ("3DExperience part creation macro") and 420485 ("CATIA V6 Macro - Insert new 3DPart under Product") were found by search but are behind a bot check and could not be read. Their content is known only from search-engine summaries ("Operation not authorized" for 3DPart; `Instances.Add` needing a VPMReference argument) [L].
