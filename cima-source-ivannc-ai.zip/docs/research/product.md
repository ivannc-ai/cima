# CIMA - Product research: adam.new / CADAM, Adam's CAD connectors, and the meaning of "CATIA y 3DModeler"

Research date: 2026-11-21. Scope: product and UX analysis to guide CIMA (Electron + React + replicad + CATIA connectors). This is not the CATIA automation API reference; API facts appear only where they shape a product decision. All CATIA statements here are documentation-derived; CATIA is not installed on the dev machine.

Second verification pass (same date): CADAM source re-read at commit `e339e3a` (GitHub API), Adam's docs, blog and landing page re-fetched, Dassault and Anthropic claims re-checked. Corrections and additions are folded into the text; the "Revision notes" at the end list what changed.

Confidence tags used below:

- **[H]** high: primary source read directly (source code, vendor docs, official API docstrings).
- **[M]** medium: secondary source (search-engine summary, mirror, forum) or a well-supported inference.
- **[L]** low: inference or unverified; must be validated before relying on it.

---

## 0. Key conclusions (TL;DR)

1. **adam.new today is "Adam", an AI CAD agent/copilot company (YC W25)** with three layers [H]:
   - **CADAM**: the open-source (GPL-3.0) browser text-to-CAD app (hosted at adam.new/cadam). It turns text and images into parametric OpenSCAD. This is the "prompt, model, sliders, iterate" experience people associate with adam.new.
   - **Adam Copilot / Adam agent**: a commercial product that reads and edits native models inside host CAD apps. It ships as an Onshape App Store extension, a Fusion add-in, and **Adam Desktop** with bundled bridges for SOLIDWORKS, NX, Inventor and **CATIA V5**, plus a separate **CATIA V6 / 3DEXPERIENCE** connector. It also offers an MCP server and a REST API, and is expanding into CAE and ECAD (KiCad, Altium).
   - **Positioning in Nov 2026**: the landing page now sells Adam as an AI *mechanical engineer* that works inside the customer's CAD, PLM and simulation tools. CATIA is in its list of supported CAD platforms. The five showcased jobs are prompt-to-CAD, 3D-to-2D drawings, a CAD-to-FEA loop, editing existing models, and DFM checks (section 1.3) [H].
2. **CADAM's core loop** [H]:
   - The LLM calls a tool with a *complete* OpenSCAD program.
   - The browser compiles it with OpenSCAD WASM.
   - A 7-view orthographic "inspection sheet" image (ISO/FRONT/BACK/LEFT/RIGHT/TOP/BOTTOM) goes back to the model.
   - The model rebuilds until every view looks right, with a 60-step cap, then sends a short final answer through a second tool.
   - Parameters are *parsed from the code* (OpenSCAD Customizer comments). Slider edits rewrite the code deterministically, with no LLM call.
3. **UX to replicate** [H]:
   - Layout: left app sidebar, then three resizable panels: **Chat (30%, 384-550 px) | 3D viewport (45%) | Parameters (30%, 320-384 px)**.
   - Visual style: dark neutral palette (#191A1A / #212121 / #2D2D2D / #3B3B3B, text #E5E5E5 / #949494), a single accent (#00A6FF), Inter font, shadcn/Radix components.
   - Chat elements: versioned artifact cards in the chat, branch navigation, retry with another model, two follow-up suggestion pills.
   - Viewport: orthographic by default, with a view cube.
   - Download: a split button (STL / SCAD / DXF).
4. **Adam's own CATIA connectors validate CIMA's architecture** [H for the facts, M for the mechanism]:
   - They target a *running* CATIA on the same Windows PC, with no CATIA plug-in. Their listed capabilities are: read the active document, edit parts/products, run CATIA Automation scripts, capture the viewer, and exchange CAD files.
   - For 3DEXPERIENCE they require `3DEXPERIENCE.exe` signed in, running under the same Windows account and elevation as the connector, with `DSYAutomation.chm` present for API lookup. This strongly suggests COM automation plus local API-doc retrieval.
   - Their operating rules are worth copying: read-only inspection first, explicit target document, verify after every edit, and inspect before retrying an interrupted edit.
5. **Dassault's native AI (the LEO / AURA "virtual companions", generative experiences) is delivered on the 3DEXPERIENCE public cloud (2026x), not on-premise, and consumes Blue Tokens. It is not available in CATIA V5** [H, GoEngineer "AI in CATIA" + 3DSwym]. CIMA's clearest niche is **CATIA V5 (and on-premise 3DX) users with bring-your-own LLM**, including local Ollama for confidentiality.
6. **"3DModeler" is not a Dassault product or role name that I could find** [M; searches are not exhaustive]. Dassault itself uses "3D modeler" generically (its 3D-modeling FAQ defines it as a *profession*), and the trade press calls CATIA "Dassault's Catia 3D modeler" [H]. Most likely meanings, in order (section 5.2):
   - (1) ~50%: the 3D-modeling side of adam.new, meaning an in-app modeler that generates parts and assemblies, as opposed to Adam's ECAD/CAE features. The user's own clarification ("generar partes y assemblies ... y conectores con la aplicación de CATIA") maps "3DModeler" to generation and "CATIA" to the connectors.
   - (2) ~25%: CATIA on 3DEXPERIENCE (V6/3DX), whose CAD apps Dassault grouped in the "3D Modeling" quadrant of the Compass.
   - (3) ~10%: the browser modeling roles "3D Creator" / "3D Sculptor" (SOLIDWORKS xDesign/xShape) or CATIA "3D Shape Designer" (cloud-only).
   - (4) ~10%: Adam's own two modes, CAD (parametric) plus "AI 3D model generator" (mesh/Creative mode), i.e. the user also wants free-form mesh generation.
   - (5) ~5%: an unrelated product literally named "3D Modeler" (Ansys Electronics Desktop's modeler window, Adobe Substance 3D Modeler, Spatial's 3D ACIS Modeler kernel).

   Recommendation: build the in-app modeler plus a connector abstraction (V5 first, 3DX second), and ask the user one clarifying question (section 5.3).
7. **Feature plan**: 15 features, 10 MVP and 5 later (section 6). The MVP spine is chat agent, validate/build/repair, visual and numeric self-check, parameter sliders, CATIA-style tree, versions, assemblies v1, CATIA V5 push and exports.
8. **Licensing caution** [H]: CADAM is GPL-3.0 and bundles GPL OpenSCAD WASM. CIMA, distributed as a closed .exe, must **not copy CADAM code or prompt text**. It should reimplement the ideas and avoid Adam's brand assets.
9. **Architecture signal from Adam** [H]: in "The Bitter Lesson of AI CAD" (2026-05-24) Adam's CEO says they deleted their CAD DSL, plane resolver and hundreds of feature-specific tools. Their agent is now two capabilities: write CAD as code, and look at screenshots of the result. CIMA's JSON feature tree is a DSL of exactly that kind, but it is still justified for CIMA: it must map 1:1 onto native CATIA features and drive sliders deterministically, and CATIA is not available to render previews during development. Keep the IR expressive and keep the "build, look, fix" loop (section 2.12).

---

## 1. What adam.new is (as of Nov 2026)

### 1.1 Timeline

| When | Event | Conf. |
|---|---|---|
| 2025 (YC W25) | Adam starts as a viral text-to-3D/CAD app for makers. Founders are Zach Dive (CEO) and Aaron Li (CPO), both UC Berkeley Master of Design graduates. | [H] TechCrunch |
| 2025-09-01 | GitHub repo Adam-CAD/CADAM created. | [H] GitHub API |
| 2025-09-05 | Show HN: Adam open-sources its browser text-to-CAD app (later named CADAM). The post describes React + Supabase, OpenSCAD WASM, sliders, STL/SCAD export, and regex-based parameter updates without the LLM. | [H] HN |
| 2025-10-31 | $4.1M seed round (TQ Ventures). Plans a copilot for professional CAD, starting with Onshape. Plans were then $5.99 / $17.99 per month. | [H] TechCrunch |
| 2026 (H1, exact date not shown to the fetcher) | "Adam AI" appears in the Onshape App Store as a free open beta. It works inside Part Studios on feature-tree cleanup, variables and fillet edits. | [H] facts, [M] date; Onshape blog |
| 2026-05-24 | Blog post "The Bitter Lesson of AI CAD": the agent is reduced to code generation plus view screenshots; the DSL and feature-specific tools are removed. | [H] adam.new/blog |
| ~2026-06 | Launch HN "Open-Source AI CAD": CADAM relaunched with an agentic write-render-inspect loop. The team says the paid product uses OpenCascade + build123d for STEP. | [M] HN mirror |
| 2026-10-15 (UTC) | Latest CADAM commit inspected for this report (`e339e3a`, "swap Gemini 3.1 Pro for Gemini 4 Argon"). The repo has 5,448 stars and 673 forks (GitHub API, 2026-11-21). | [H] GitHub |
| 2026 (current) | Adam Desktop (macOS/Windows x64) with bridges for SOLIDWORKS, NX, Inventor, CATIA V5, Solid Edge, AutoCAD, Rhino, Revit, SketchUp, Blender and Unreal, plus a CATIA V6/3DX connector, an MCP server, a REST API, KiCad/Altium, simulation workflows, and Free/Pro/Max/Team/Enterprise plans. | [H] docs.adam.new |

### 1.2 Product map

- **CADAM** (open source): text and/or image in, a parametric OpenSCAD program out, then a preview, sliders, and STL/SCAD/DXF downloads. A "Creative" mode generates meshes through fal.ai models. CADAM is aimed at makers and 3D printing. The team calls it "not a revenue driver" [M].
- **Adam** (commercial, adam.new): an engineering agent organised around **Tasks** (a conversation plus its files). Tasks connect to host CAD through integrations. The company's stated positioning is that the copilot works best when **editing an existing feature tree**, with text-to-CAD from scratch as a secondary strength [M]. Other workflows include drawing-to-model, mesh-to-CAD, drawing review, manufacturing review, tolerance analysis, batch operations, model repair and simulation setup [H, docs index].

### 1.3 The adam.new landing page today (HTML fetched 2026-11-21) [H]

- **Positioning**: an AI mechanical engineer that works in the customer's CAD, PLM and simulation tools and returns finished work. The page title is "Adam | AI CAD for Mechanical Engineers". CTAs: "Try Adam" and "Book a demo".
- **Five showcased jobs**, each with an example part: generate CAD from a description (truck differential), 3D CAD to 2D drawings (end cover), CAD-to-FEA loop (lower control arm), edit existing CAD models through an ECO (ring gear Rev 03 to 04), and DFM checks that ingest company documents (switch chassis).
- **Integration categories**:
  - CAD: Fusion, Inventor, Onshape, Creo, Solid Edge, SOLIDWORKS, Siemens NX, **CATIA**.
  - PLM: Arena, Windchill, SOLIDWORKS PDM, Teamcenter (BOM kept in sync, part-number/quantity/revision mismatches flagged).
  - CAE: Ansys, Abaqus, COMSOL, Simcenter.
  - Docs and data: Google Drive/Sheets, Notion, Airtable. Team tools: Slack, Teams, Gmail, Jira, Linear.
- **Trust claims**: SOC 2 Type I; TLS 1.2+ and AES-256; per-user agent sandboxes; inputs not used for training; approval before sending or changing anything.
- **Plans**: Free ($0), Pro, Max, Team (per seat), Enterprise. Prices are not in the static HTML.
- **FAQ stance on CAD**: "all professional CAD" is claimed, but setup differs per platform (SOLIDWORKS through the Windows connector, Fusion through connector plus add-in, Onshape through the account) and the user brings the CAD licences.
- **Marketing theme** (from `adam-v1.css`, for reference only; do not copy): near-black/white neutrals (#0a0a0a, #161616, #fafafa, line #2b2b2b), a hot-pink brand accent **#ff2d92**, an additional "Klein blue" scale (#002fa7), 4 px radius, Geist/Inter-style grotesk fonts. CADAM's in-app accent is a different one (#00A6FF). CIMA should use neither.

---

## 2. CADAM in depth (source code read at commit e339e3a)

### 2.1 Stack [H]

| Layer | Tech |
|---|---|
| Frontend | React 19 + TypeScript + TanStack Start + Vite; Tailwind v3 + shadcn/ui (Radix); lucide-react icons; Streamdown for markdown |
| 3D | three.js + React Three Fiber + drei (OrbitControls, GizmoViewcube) |
| CAD engine | OpenSCAD compiled to WASM, run in a Web Worker; libraries BOSL, BOSL2 and MCAD; Geist font for text |
| AI | Vercel AI SDK (`ai`) with `@ai-sdk/anthropic`, `@ai-sdk/google`, and OpenRouter for everything else |
| Backend | TanStack Start server routes + Supabase (Postgres, Auth, Storage) |
| Mesh mode | fal.ai: Meshy v6 (preview) image-to-3D, SAM-3 image/3D objects, Tripo v2.5, Hunyuan3D v2 mini turbo, Moondream3 captioning. Picker tiers: "Max Quality" (ultra), "Draft" (quality), "Textureless" (fast) |

### 2.2 Core user flow (prompt, model, iterate) [H]

1. **Landing (`/`)**:
   - A time-of-day greeting with the user's first name (for example "Good afternoon!") above a centered composer (max width about 768 px).
   - The composer contains a mode toggle (Parametric vs Creative), a model picker, an attach-image button, and a "prompt generator" wand. The wand asks a small model (Claude Haiku 4.5) to write a prompt for a practical, dimensioned part, or to improve the text already typed.
   - It also has a send button.
2. **Submit**:
   - The conversation and the first user message are persisted, and the app navigates to `/editor/<id>`.
   - The **conversation title is generated in parallel** by a small model (Claude Haiku 4.5, 80 characters or fewer). It arrives as a transient stream part, so the header updates without a refetch.
3. **Streaming turn**:
   - Optional model reasoning appears as a collapsible "Thinking..." block that auto-scrolls.
   - A tool card titled "Building CAD..." follows. While the tool input streams, the card live-types the OpenSCAD code.
   - Meanwhile the viewport shows a loader (exact label not re-verified in the second pass).
4. **Client-side build** (once the tool input is complete), in a Web Worker:
   - Compile the code to STL plus a colored OFF.
   - Render a 1000x1000 isometric thumbnail for the chat card.
   - Render a **1536x1536 inspection sheet**: a 3x3 grid of 512 px tiles, orthographic camera, scene background #3B3B3B, sheet background #2B2B2B, each tile labelled ISO, FRONT, BACK, LEFT, RIGHT, TOP or BOTTOM. Two tiles stay empty.
   - Upload both images.
   - Persist the tool result.
   - Hand the result back to the agent with the sheet attached as an image.
   - A compile error goes back to the model as a tool error ("Compilation failed: ...").
   - If a compile fails and there is no geometry to show, the viewport shows an "Error Compiling Model" state with a **"Fix with AI"** button that sends the error back as a new turn.
5. **Agent self-review**:
   - The model compares each view with the request.
   - It either calls the build tool again with a corrected *complete* program, or ends with `answer_user`, a short past-tense message such as "Done - I made...".
   - Hard cap: 60 steps per turn.
6. **Result**:
   - The viewport mounts the compiled model.
   - The **Parameters panel auto-expands**. It collapses to zero width when there is no artifact.
   - **Two follow-up suggestion pills** (3 words or fewer each, generated by a small model after each finished turn) appear above the composer.
7. **Iterate**:
   - Type in the composer ("Keep iterating with Adam...").
   - Drag sliders. This recompiles locally, debounced 200 ms, with no LLM call.
   - Retry the last answer with a different model.
   - Edit an earlier prompt, which creates a branch.
   - Restore an older version.
   - Rate an answer thumbs up or down.
   - Download STL, SCAD or DXF.
   - Share a public or private link.

### 2.3 How models are represented [H]

- **The artifact** is the input of the `build_parametric_model` tool:
  - Shape: `{ title, version, code }`.
  - `code` is a complete raw OpenSCAD program.
  - The model always re-emits the whole program; there are no diffs.
  - `version` is in practice always "v1". Real versioning comes from the message tree (2.5).
- **Parameters are not a separate list from the LLM.** The client parses them from variable declarations at the top of the file (before the first `module` or `function`), using the OpenSCAD *Customizer* comment conventions:
  - `name = 10; // [1:50]` gives min:max; `// [1:1:50]` gives min:step:max.
  - `name = "a"; // [a, b, c]` gives an enum.
  - A trailing number gives the string maxLength or the numeric step.
  - `/* [Group Name] */` starts a group.
  - A comment line above a variable becomes its description.
  - Supported types: number, boolean, string, and arrays of those.
  - Variables named `*_color` render as a color picker.
  - Display names are humanised from snake_case ("wall_thickness" becomes "Wall Thickness").
- **Why parse instead of asking the LLM for a list?** The code comments explain it: different providers (Claude vs Gemini) returned *differently shaped parameter arrays for the same code*, which produced divergent UIs. Deriving the UI from one canonical artifact makes it provider-independent. **Lesson for CIMA:** one canonical JSON schema, strict validation, and the UI derived from that schema only.
- **Slider edits**:
  - A regex rewrites the single `name = value;` line, so the code file stays the canonical state.
  - The edit is persisted back into the message.
  - The model's original code is stashed once in message metadata (`originalCode`). As a result, "Reset all parameters" and the auto slider ranges keep the *original* defaults.
- **Auto slider ranges** (when no annotation is given):
  - Max is the next "nice" number (1/2/5/10 x 10^n) above the default's magnitude.
  - Min is 0, or a symmetric negative range for negative defaults.
  - Step is about 1% of the range, rounded to a nice number.
  - A "mm" unit is shown for measurement-like names.
- **"Assemblies"** are a single program with several colored solids (V8 engine, planetary gear stage). There is no product structure, no instances and no mates.

### 2.4 The agent loop [H]

- **Tools (Zod schemas)**:
  - `build_parametric_model(title, version, code)` returns `{status, message, inspection:{views[], imageAttached}}`.
  - `answer_user(message)` carries the only user-facing final text.
  - `create_mesh(...)` exists only in Creative mode.
  - The parametric tools have **no server-side execute**. The browser is the authority for their results.
- **First step is restricted to the build tool.**
  - Models that accept a forced `tool_choice` get it pinned. Thinking is switched off for that step on Anthropic models, because Anthropic rejects forced tool use while thinking is on.
  - The newest Claude models (Opus/Sonnet 5.5+, Fable/Mythos) reject forced tool choice. For them CADAM falls back to `auto` plus prompt steering, and **logs turns that finish without a build** as a degraded outcome.
- **System prompt themes** (paraphrased; do not copy, GPL):
  - Pass the user's intent through faithfully, with no embellishment.
  - Never claim a model was created unless the build tool ran.
  - Loop write, then inspect all views, then rewrite. Finalize because the views look right, not because the code compiled.
  - Per-object checklists (for example, a phone case needs every cutout).
  - Code quality: manifold, connected and printable geometry; use modules; use BOSL2 for threads, sweeps and Beziers.
  - Parameter conventions: descriptive snake_case names, Customizer annotations, groups.
  - Colors exposed as `*_color` parameters.
  - Rules for STL imports: import the attached model, modify around it, and expose rotation parameters.
  - Never mention tools or implementation to the user.
- **Model routing**:
  - Anthropic and Google are called directly; everything else goes through OpenRouter.
  - Per-model capability gates cover vision, thinking and forced tool choice.
  - Default model for a new parametric chat: Gemini 3.8 Flash.
  - The picker also offers Gemini 4 Argon, Claude Fable 5.1 / Opus 5.5 / Sonnet 5.5, GPT-6 Astra / 6.1 Sol, Grok 4.7, Kimi K3, DeepSeek V4 Pro (no vision), GLM 5.3 (no vision) and GLM 5.3 Flash.
  - Image attachment is disabled for non-vision models.
- **Limits**:
  - Up to 64k output tokens per parametric request.
  - Words are re-chunked for smooth streaming (about every 30 ms).
  - Credits are metered at USD 0.01 of inference per credit (`USD_PER_BILLING_TOKEN = 0.01` in `aiChat.ts`), with a pre-flight balance check.

### 2.5 Conversation and version model [H]

- Messages form a **tree**: each has a `parent_message_id`, and the conversation stores a `current_message_leaf_id`.
- How each action changes the tree:
  - A new turn adds a child.
  - **Retry** (optionally with another model from a dropdown next to the retry button) adds a sibling assistant message.
  - **Edit** of a user message adds a sibling user message.
  - **Restore** copies an old assistant message as the new leaf.
- A **branch navigator** ("< 4/4 >") switches between siblings.
- Per-message metadata stores the model used, the cost, `originalCode`, and a rating (-1/0/1).
- The server reads the active branch **from the database only**, so the client cannot inject context.
- Ordering rule: the client persists the tool result *before* letting the SDK auto-continue the loop. If that write fails, the loop pauses and a toast asks the user to retry.

### 2.6 Inputs [H]

- **Text.**
- **Images**:
  - Formats: PNG, JPEG, WEBP; at least 256x256 px and at most 100 MB (toasts: "Image too small", "Image too large", "Invalid image format").
  - Entry points: attach button, drag-and-drop onto a drop zone above the composer ("Drop images and 3D models here"), or paste into the textarea.
  - The image button is hidden in Parametric mode when the selected model has no vision.
  - The server sniffs the real MIME type from the image bytes, because providers reject a mismatched declared type.
- **STL (Parametric mode)**: the model must `import("file.stl")` and model the requested modification *around* the imported mesh. The attachment's bounding box (in mm) is passed to the model, which should expose rotation parameters.
- **Meshes (Creative mode)**: GLB/STL/OBJ/FBX up to 100 MB, plus topology and polygon-count preferences.

### 2.7 Outputs and exports [H]

- **Parametric downloads** use a split button whose main part shows the selected format, with a chevron menu:
  - **STL**, labelled "3D Printing".
  - **SCAD**, the source code.
  - **DXF**, a 2D projection onto the XY plane, computed on demand.
- **Creative mode** downloads: STL ("3D Printing"), OBJ + MTL ("Universal"), GLB ("Web & XR"), FBX (quad-topology models only), an animated GIF turntable, a ZIP with PBR textures, and a "Print Service" (beta) hand-off that sends the STL to a print bureau.
- **Sharing**: public or private conversation links with a thumbnail, plus a "Creations" history grid.
- **No STEP export in CADAM**: OpenSCAD cannot write B-rep STEP. Per the team's HN replies [M], the paid product uses OpenCascade/build123d to produce STEP. CIMA's replicad (OpenCascade) gives STEP natively, which is a direct advantage for CATIA users.

### 2.8 UI layout, precisely [H] (code + official screenshots)

**App shell**

- **Left app sidebar**, collapsible to an icon rail of 46 px buttons; the state is remembered:
  - "adam" logo.
  - A pill button "+ New Creation" with an accent-blue border (216 px wide when expanded).
  - "Creations", with recent conversation titles nested under it.
  - At the bottom: GitHub, Discord, and an avatar menu (Settings, plan).
- **Landing**:
  - The content sits on a #212121 card with rounded corners, inset 24 px from the window edges while the sidebar is open.
  - A large centered greeting (about 36 px).
  - The composer below it: an Adam icon and placeholder on the top row; on the bottom row, an image button on the left and the model dropdown plus send arrow on the right.

**Editor (desktop, wider than 1024 px)**: `react-resizable-panels`, horizontal, sizes persisted under the key "editor-panels".

| Panel | Size | Contents |
|---|---|---|
| Chat | default 30%, min 384 px, max 550 px, collapsible | Header: sidebar toggle, conversation title, "Share" popover. Messages: the user message shows a gradient avatar and plain text. The assistant message shows the Adam avatar, a bubble (#2D2D2D) with markdown, and a tool card (cube icon, artifact title, "v1" badge, blue border when active, expandable code, thumbnail). Under it: retry with a model dropdown and the branch navigator "< i/n >". Rating, copy and restore buttons appear on hover. Footer: two suggestion pills, then the composer. |
| Viewport | default 45%, min 20% | Background #3B3B3B. The model is accent blue #00A6FF, metallic (metalness 0.6, roughness 0.3), with an HDR environment and a ground contact shadow. **Orthographic by default.** Bottom right: drei `GizmoViewcube` (margin 80 px) plus an orthographic/perspective switch. During streaming: a loader. Compile error: "Error Compiling Model" with a "Fix with AI" button. Empty state: "Send a message to start creating". OrbitControls with damping 0.05; no grid (commented out); OpenSCAD's Z-up model is rotated -90 deg about X, so the scene is Y-up. |
| Parameters | default 30%, min 320 px, max 384 px, collapsible, **auto-collapsed to 0 with no artifact** | Header: "Parameters" and a reset icon ("Reset all parameters"). Two collapsible sections with count badges, "Dimensions (n)" and "Colors (n)" (the Customizer `/* [Group] */` labels are parsed but this panel does not render them as accordions). Each row: label in an 80 px column, slider, 56 px numeric box, unit "mm" (only for measurement-like names). Booleans render as switches; **enums render as a segmented toggle group, not a dropdown**; strings that parse as CSS colors render as color pickers; arrays render one control per item. Commit on slider release or field blur, debounced 200 ms. Footer: the split download button (STL / SCAD / DXF). |

- Collapse handles appear on hover over the resize handle.
- A collapsed panel becomes a vertical tab labelled "Chat" or "Parameters", with a chevron, on the screen edge.
- Container background: #292828. Borders: #3B3B3B.

**Mobile/tablet (1024 px or narrower)**: chat goes full screen, and preview plus parameters open in a bottom sheet (rounded top corners, swipe down to dismiss).

**Theme tokens (CADAM's Tailwind config)**

| Token | Hex | Use |
|---|---|---|
| bg-dark / background-2 | #191A1A | html/app background |
| bg-secondary-dark / background-1 | #212121 | chat panel, parameters panel, landing card, sidebar |
| (container) | #292828 | panel group background |
| neutral-950 / 900 | #111111 / #171818 | hover states, darkest surfaces |
| neutral-800 | #2D2D2D | assistant bubbles, inputs, menus |
| neutral-700 | #3B3B3B | viewport background, separators, borders |
| neutral-500 / 400 / 300 | #5A5A5A / #676767 / #949494 | muted icons and text |
| text primary / secondary / tertiary | #E5E5E5 / #949494 / #676767 | text |
| accent ("adam-blue") | #00A6FF | brand, selection, active card border, default model color, glow rgba(0,166,255,0.24) |
| fonts | Inter (UI), JetBrains Mono (code) | |
| radius | 0.5 rem (lg), md = lg - 2 px, sm = lg - 4 px; pills fully rounded | |

**Wireframe (CADAM editor)**

```
+-------------+---------------------------+-------------------------------+--------------------+
| adam        | [|] Twisting Vase  [Share]|                               | Parameters     [R] |
| (+ New      |                           |                               | v Dimensions (7)   |
|  Creation)  | (o) Create a parametric...|        blue metallic model    |  Vase Height       |
| [] Creations| (A) I'll create a ...     |        orthographic, Z-up     |  [====|----] 120 mm|
|   Twisting..|   +---------------------+ |        rendered Y-up          |  Base Radius       |
|   Parametr..|   | [cube] Title    v1  | |                               |  [=|-------]  25 mm|
|             |   | (thumbnail)         | |                               | v Colors (1)       |
|             |   +---------------------+ |                               |                    |
|             |   [retry][Model v][<4/4>] |                    [ViewCube] |--------------------|
|             | [pill 1] [pill 2]         |              [persp o-- ortho]| [ Download STL |^] |
| GitHub      | +-----------------------+ |                               |                    |
| (avatar)    | | Keep iterating...     | |                               |                    |
|             | | [img]     Model v [^] | |                               |                    |
+-------------+---------------------------+-------------------------------+--------------------+
```

### 2.9 Engineering lessons embedded in CADAM (reuse as ideas, not code)

1. **Single canonical artifact plus a derived UI** keeps different providers from producing different UIs.
2. **Deterministic parameter edits** (no LLM) are instant, free and predictable, and the artifact stays canonical.
3. **Visual self-inspection with a fixed multi-view sheet**: finalize when the views look right, not when the build succeeds.
4. **Steer the first step to the build tool and detect "no build" turns.** This matters more now that the newest Claude models reject forced tool choice (section 8).
5. **Persist tool results before auto-continuing.** Also resolve dangling tool calls, and normalize parts that stay in "streaming" state when a provider omits closing events.
6. **Carry provider metadata with tool calls.** Gemini rejects a replayed function call that lacks its thought signature.
7. **Sniff image MIME types from bytes.**
8. **Use a cheap model for side tasks**: title, suggestions, prompt improver.
9. **Keep chat clean.** They drop free text from turns that contain a build, so the final user-facing text comes only from `answer_user`, and they strip leaked metadata and filenames from assistant text.

### 2.10 Licensing [H]

- CADAM is GPL-3.0. It includes unmodified OpenSCAD WASM binaries (GPLv2+) and portions derived from openscad-web-gui (GPLv3).
- If CIMA is distributed as a proprietary .exe, copying CADAM source (including its system prompt text) would oblige CIMA to be GPL.
- **Reimplement the concepts with original code and prompts. Do not reuse the Adam/CADAM name, logo or brand assets.** The UX patterns themselves (panel layout, sliders, version cards) are ideas and can be reused.

### 2.11 Slider UX lessons (Adam blog "How we improved the slider experience", 2025, plus CADAM code) [H]

Adam's usability sessions found four problems with a stock shadcn slider, and the fixes are worth copying as ideas:

1. **Hit zone too small**: users missed the thumb on first try. Make the whole track (and some padding) grabbable.
2. **No feedback**: add hover and active states (scale/opacity transitions) so the control visibly "arms".
3. **No sense of scale**: every slider started centred, so nobody could tell whether 6 mm was small or large. The default value now sits at its true position inside a range derived from the value (6 mm on a 0-10 scale sits at 60%).
4. **Cramped layout**: consistent spacing and alignment.

Two further decisions:

- **Reset without a button**: a thin vertical tick marks the original (AI-generated) value on the track instead of a per-row reset button. A panel-level "reset all" icon remains.
- **Desktop vs touch**: on desktop a click on the track jumps to that value (users expected it); on touch the track uses relative dragging (finger precision is low). The switch is a CSS media query on pointer type.

**How CADAM derives a range when the code gives none** (described, not copied): round the absolute default up to a "nice" number (1, 2, 5 or 10 times a power of ten); if the default is more than half of that number, go one nice step higher (2 to 5, 5 to 10), except at the 10x level, which is kept. Worked through the code: 94 gives 0-100, 23 gives 0-50, 6 gives 0-10, 2.7 gives 0-10, 0.5 gives 0-1. So the default lands anywhere between about 20% and 100% of the track (the blog's "23 on 0-100" example does not match the current code). The min is 0 (or the mirrored negative max for negative defaults), and values at or below 0.001 get 0-1. The step is about 1% of the range, rounded to 1/2/5 times a power of ten. The range is computed from the *original* default, so it does not run away while dragging.

**For CIMA**: the JSON schema should let the LLM give explicit `min`/`max`/`step` and units per parameter (engineers care about real limits such as wall thickness above 1.5 mm), and fall back to the nice-number rule only when they are missing. Angles need a degree unit and a 0-360 or -180..180 default range.

### 2.12 Adam's "Bitter Lesson of AI CAD" (2026-05-24) and what it means for CIMA [H for the post, judgement for the implications]

- **What the post says** (paraphrased): the first Adam agent wrapped the model in thousands of lines of spatial-reasoning abstractions: a text DSL describing 3D state, a plane resolver, and hundreds of feature-specific tools such as `create_sketch`. Each abstraction became a failure mode the model had to fight. Adam deleted them. The current agent has two capabilities: write CAD as code, and take a screenshot of the part, then loop. The stated reasons are that frontier models are trained heavily on code and can now *see* (for example, notice that a hole is on the wrong face), and that general models keep improving faster than domain-specific harnesses. The post's hero example is a robot arm generated in the Fusion extension.
- **Consistency with the CATIA connector**: Adam's CATIA V5 bridge advertises "run CATIA Automation scripts" and "capture the viewer". That is the same two-tool pattern applied to CATIA: the model writes automation code against the live COM API and checks screenshots.
- **Implications for CIMA**:
  - CIMA cannot run CATIA during development or in the in-app preview, so a pure "write VBScript, screenshot CATIA" loop is not viable as the *core*. The JSON feature IR plus replicad preview plus deterministic code generation (to replicad and to CATIA VBScript) remains the right MVP choice: it gives sliders without an LLM call, offline previews, and a translation to CATIA that can be tested.
  - Lower the cost of the DSL, as Adam's experience warns: keep it close to CATIA's own vocabulary (Pad, Pocket, Shaft, Groove, Hole, EdgeFillet, Chamfer, Shell, patterns, Mirror, user parameters and formulas) so the model does not need a custom mental model; prefer a few general tools (`build_cad_model`, `answer_user`, `ask_user`) over many fine-grained ones; feed back screenshots *and* measurements.
  - Plan a later **expert mode** (L5): with a live CATIA attached, the agent may write CATIA automation directly, run it on a *new* document, capture CATIA's viewer and iterate, behind explicit approval. This is where Adam is heading and where future models will be strongest.

---

## 3. Adam's CAD integrations and how the connectors work

### 3.1 Onshape [H facts; M mechanism]

- **Two surfaces**:
  - A web "account connection": Integrations > Onshape > Connect, sign in, approve access. Onshape does not need to stay open.
  - An **Onshape App Store extension**, launched from inside a Part Studio, which adds the open document and **current selection** as context. The Onshape tab must stay open.
- **Mechanism**: per the developers' beta post (seen only via a search summary; the forum is login-walled) [M], the agent calls tools through the **Onshape REST API** and **writes FeatureScript** to act natively.
- **Operations** (Onshape blog, Adam docs):
  - Inspect Part Studios, features, variables and assemblies.
  - Explain dependencies.
  - Rename features descriptively.
  - Merge redundant extrudes.
  - **Extract hard-coded values into named variables.**
  - Find and update fillets across a part.
  - Change dimensions or variables after explaining the change.
- **Review**: the vendor does not label its own edits. Users review them through Onshape's history and can roll back there [M].

### 3.2 Autodesk Fusion [H]

- Adam Desktop installs the Fusion add-in. A toolbar button opens an **in-product panel**; if the button is missing, run the "AdamFusion" add-in from Scripts and Add-Ins.
- The add-in uses the **active design plus the user's selection** as context.
- Example task: cut a centered 12 x 6 mm opening 3 mm above the floor of a rear wall.
- Recommended checks: verify the active component and bodies, state which dimensions must stay fixed, and inspect the timeline and the affected geometry after the edit.

### 3.3 Adam Desktop and bridges [H facts; M mechanism]

- Install Adam Desktop on the machine that runs the CAD app. It pairs that workstation with the user's Adam account (cloud agent). Then pick an app under Integrations and verify access with a **read-only request** that reports the active document, application version, units and errors.
- **Bundled bridges** (no separate plug-in) cover SOLIDWORKS, NX, Inventor and **CATIA V5**. Solid Edge and AutoCAD connect but are "awaiting qualification". Rhino, SketchUp and Blender get add-ons. Revit uses Autodesk's MCP preview, and Unreal its built-in MCP.
- **Custom local MCP servers** are accepted if they expose Streamable HTTP.
- **Shared tasks** run on the *task owner's* workstation.
- Their docs explicitly state that being connected does not mean every command in the application's interface is automated.

### 3.4 CATIA V5 connector [H]

- **Requirements**:
  - A Windows PC with CATIA V5 installed and licensed.
  - The target document open, with its references accessible.
  - No separate plug-in; the bridge ships with Adam Desktop.
- **Listed capabilities**:
  - Read the active document.
  - Edit parts and products.
  - **Run CATIA Automation scripts.**
  - **Capture the viewer.**
  - Exchange CAD files.
- **Guidance**:
  - Name the target part or product, the feature to change, and the geometry to preserve.
  - Ask for the update *and* a check of the resulting dimensions.
  - Resolve unresolved product references first.
  - If an edit was interrupted, **inspect before retrying**, because the operation may already have changed the model.
  - Evaluate on a *copy* of a representative model with measurable acceptance criteria. Their example: find the parameter that drives plate thickness, propose the change, and list the features to re-check.
- **Verification**: a viewport image alone does not prove that references survived or that the part is releasable. Check the spec tree, the update state, the changed geometry and the assembly references.
- **Scope**: the V5 page says V6/3DX is out of scope for this connection, which has its own page.
- **Mechanism**: not documented. COM automation of the running CATIA is the evident mechanism, given "run CATIA Automation scripts", "no plug-in" and the Windows-only scope [M].

### 3.5 CATIA V6 / 3DEXPERIENCE connector [H]

- **Requirements**:
  - A licensed **3DEXPERIENCE desktop app launched as `3DEXPERIENCE.exe`**, open, signed in, with the design open. A browser session or the launcher alone is not enough.
  - The older standalone `CATIA.exe` is not supported for this connection.
- **Process and elevation**: CATIA and the connector must run **under the same Windows account and at the same elevation** (both normal, or both "Run as administrator").
  - This matches how COM's Running Object Table behaves across integrity levels [M].
  - **CIMA gotcha:** `cscript.exe` launched by a non-elevated Electron app will not find an elevated CATIA, and vice versa.
- **API lookup**: the matching **`DSYAutomation.chm`** must sit next to `3DEXPERIENCE.exe`. This suggests the agent looks APIs up in the local automation help. **Idea for CIMA:** index the local `V5Automation.chm` / `DSYAutomation.chm` (or the pycatia docstrings) for retrieval when the agent needs an API outside the JSON schema.
- **Behaviour**:
  - Check which design is active before editing.
  - With several sessions open, list them and choose one.
  - **Save to 3DEXPERIENCE, replace a design or export only when the user explicitly asks.**
  - If an edit failed, inspect before retrying.
  - On a timeout, ask for status and do not resubmit.

### 3.6 Commercial Adam app UX [H, docs-level only]

- **Tasks** are conversations plus their files. Task status is one of Running, Needs input, Completed or Scheduled. The agent can ask questions or wait for approval.
- A **right-hand file panel** shows task outputs, and a global Files page lets users search, preview and export.
- **Model families** Lite / Pro / Ultra are chosen with a preset slider, with an "Advanced > Model" picker for a specific model.
- Other areas:
  - **Projects** hold shared context.
  - **Memory** (personal and team) and **Skills** (reusable workflows).
  - **Scheduled** runs.
  - An **Integrations** page with Connect / Connected states.
- I could not access the logged-in UI, so I cannot describe its exact layout.

### 3.7 What CIMA should adopt from Adam's connector practice

- A connection status that distinguishes "CATIA not running", "running but no document", and "running with a document of type X".
- A read-only "Inspeccionar documento activo" action, run before any edit.
- **Non-destructive by default**:
  - Push into a *new* CATPart or CATProduct.
  - Never save, overwrite or modify an existing document without an explicit confirmation that names it.
- After every push or edit: run `Update`, read back the parameters and measures, and report any differences.
- On any interruption or timeout, re-inspect before retrying. Never auto-resubmit.
- Detect and explain these environment problems:
  - Elevation mismatch.
  - Several CATIA sessions open: `GetObject` attaches to one of them, so ask the user to keep one session.
  - A modal dialog blocking CATIA.
- Optional local API-documentation retrieval, so the agent can propose custom automation that a human approves.

### 3.8 How Adam exposes connector operations to agents (MCP "direct tools") and what CIMA's CATIA job runner should copy [H]

Adam's MCP documentation describes how an external AI client drives a connected CAD application without starting Adam's own agent. The mechanics are a good template for CIMA's main-process "CATIA job runner", even though CIMA is local:

- **Named operations per application**, each with a declared input schema. Fusion has five generic ones (`adam_fusion_read`, `_create`, `_update`, `_delete`, `_execute`). Desktop connectors (SOLIDWORKS, NX, Inventor, Creo, CATIA V5, CATIA V6, Solid Edge, Rhino) publish "named operations from each connector's contracts" and take a `deviceId`.
- **Every mutating call carries an `idempotencyKey`**: a new key for a new operation, the same key and input when retrying. The call returns a tool-call id that is polled for status.
- **Statuses**: `queued`, `running`, `succeeded`, `failed`, and **`unknown`**. On `unknown` the operation may already have taken effect: inspect the model before doing anything, and never auto-repeat with a new key.
- **Rules**: launching the application is separate from inspecting the document (a "ready" launch is not a document check); a screenshot does not prove model validity; do not switch silently to another application or to a file-based workaround when a native operation is missing.
- **Fusion add-in**: Adam Desktop installs an add-in called "AdamFusion" (visible under Scripts and Add-Ins, Shift+S) that opens an in-product panel from the toolbar; the founder said on HN that Fusion is driven through its Python API and Onshape through FeatureScript [M for the mechanism].

**CIMA mapping**: every "Enviar a CATIA" or "Inspeccionar" action becomes a job with an id, an idempotency key, a target (CATIA session plus document), a timeout, and a final state among those five. If `cscript` times out or the process dies, the state is `unknown`, and the UI offers "Inspeccionar CATIA" instead of "Reintentar".

---

## 4. Competitive context for CATIA users

| Player | What | Relevance to CIMA |
|---|---|---|
| **Dassault "virtual companions"** (AURA business, **LEO engineering**, MARIE science) and CATIA "Generative experiences" | "LEO \| Mechanical Engineering" (listed under R2026x FD03 on 3DSwym) helps understand existing designs and modify geometric parameters, relations, wireframes and product structures. The same page lists focus areas without saying which have shipped: solid feature creation (Pad, Pocket, Hole from sketch profiles), part generation from multimodal inputs, and assembly generation that predicts mechanical interfaces. Other generative features (GoEngineer): Command Intelligence, Generative Assembly (beta), Generative Tolerancing (ASME Y14.5 defaults), Generative Sketch Constraints / Auto Constraint (2025x, improved 2026x), Generative Shape Convergence (2025x), Generative Mesh from Image (beta, 10 models per day). | **Companions run on the 3DEXPERIENCE public cloud (SaaS) only; on-premise deployments do not get them; they consume Blue Tokens; none of these AI features exist in CATIA V5** [H, GoEngineer "AI in CATIA" + 3DSwym]. The large V5 installed base and on-premise 3DX are underserved. |
| **Adam** | CATIA V5 and V6 connectors through Desktop; evaluated case by case with the team | The closest direct competitor. It is cloud-agent based, and CIMA can differ through local-first operation and bring-your-own LLM (including Ollama). |
| **MecAgent** | SOLIDWORKS-first copilot (V2 adds text-to-CAD, image-to-CAD and multi-stage tasks, with 35k+ installs). CATIA V5 has been "planned" in interviews. | CATIA support is unverified, so it is a potential future competitor [M]. |

**Positioning suggestion:** "the adam.new experience for CATIA V5 (and 3DEXPERIENCE), on your PC, with your choice of AI provider, producing native parametric features (parameters plus formulas) rather than dumb geometry."

---

## 5. "CATIA y 3DModeler" - what the user most likely means

### 5.1 Findings

- **No Dassault product, app or role literally named "3D Modeler" or "3DModeler" was found** in 3ds.com, the 3DSwym wikis, or the role lists [M; searches are not exhaustive].
- Dassault does use the phrase generically:
  - 3ds.com's 3D-modeling page defines a "3D modeler" as a *professional* who creates 3D models, and frames CATIA, SOLIDWORKS and the 3DEXPERIENCE platform as 3D-modeling software [H].
  - The trade press calls CATIA "Dassault's Catia 3D modeler" when explaining the CGM kernel [H].
  - The 3DEXPERIENCE **Compass** historically had a **"3D Modeling"** apps quadrant (West: CATIA, SOLIDWORKS, 3DPlay and other design apps), alongside Social and Collaborative (North), Information Intelligence (East) and Simulation (South) [H, Engineers Rule]. Since R2021x the Compass lists all apps in one place [M, reseller blogs].
  - Spatial (a Dassault subsidiary since 2000) sells the **"3D ACIS Modeler"** kernel and the **"CGM Modeler"** ("CGM Core Modeler"), described as the 3D modeling kernel of the 3DEXPERIENCE platform [H, Wikipedia]. These are developer SDKs, not end-user apps.
- **Role names on the 3DEXPERIENCE cloud follow a "3D ___" pattern** [H]:
  - **3D Creator** (SOLIDWORKS xDesign, browser parametric modeling).
  - **3D Sculptor** (xShape, subdivision surfaces).
  - 3D SheetMetal Creator, 3D Structure Creator, 3D Mold Creator. These are now consolidated into a single "SOLIDWORKS xDesign" role.
  - The CATIA-branded **3D Shape Designer** role (CATIA xDesign + xShape Design + xGenerative Design) is browser-based and cloud-only.
  - Also seen: "[CATIA] Heavy Machinery Digital Modeler" and "3D Innovator" (education).
- **Literal "3D Modeler" products outside Dassault** [H]:
  - Adobe **Substance 3D Modeler** (VR/desktop sculpting for artists).
  - The **Ansys Electronics Desktop** geometry editor is literally called **"3D Modeler"**; its VBScript/IronPython scripts call `oDesign.SetActiveEditor("3D Modeler")` (HFSS/Maxwell/Q3D).
  - **FreeCAD**'s tagline is "Your own 3D parametric modeler".
  - **Spatial's CGM Modeler**, derived from CATIA's kernel, and the 3D ACIS Modeler are geometric modeling kernels.
- **adam.new now spans many domains**: mechanical CAD, ECAD (KiCad, Altium), CAE/simulation, drawings and PLM (llms.txt).
- **CADAM itself is marketed as "open-source text-to-CAD and AI 3D model generator"** and has two modes in the composer: Parametric (CAD code) and Creative, toggled by a button labelled "Mesh" (mesh generation through fal.ai) [H]. So "adam.new" can mean both a CAD generator and a free-form 3D model generator.
- **How the market names CATIA generations**: Adam's docs split "CATIA V5" (CATIA.exe, CATIA Automation) from "CATIA V6 / 3DEXPERIENCE" (the `3DEXPERIENCE.exe` desktop app) [H]. Spanish job ads for CATIA designers (Airbus Getafe, Stellantis suppliers in Vigo, rail interiors in Barcelona) talk about "modelado 3D" / "modelos 3D y planos 2D" in "CATIA V5 o 3DEXPERIENCE" [M, search-engine summary of InfoJobs/Indeed/Jooble listings]. "Modelador/modelado 3D" is ordinary Spanish for 3D modeling work.
- The user's own explanation is: *"que sea capaz de generar partes y assemblies a traves de un proveedor de IA y tenga conectores con la aplicacion de CATIA"* ("that it can generate parts and assemblies through an AI provider and has connectors to the CATIA application").

### 5.2 Ranked interpretations (subjective likelihood)

| # | Interpretation | Likelihood | Evidence | Product implication |
|---|---|---|---|---|
| 1 | **"The CATIA and 3D-modeling part of adam.new"**: an in-app *3D modeler* that generates parts and assemblies (generation, preview, parameters), connected to CATIA. The user is excluding Adam's ECAD, PLM and simulation features. | ~50% | The user's own gloss maps one-to-one: "generar partes y assemblies a través de un proveedor de IA" = the modeler; "conectores con la aplicación de CATIA" = CATIA. "La parte de" reads as choosing a slice of adam.new's broad scope. "3D modeler" is a generic term, even in Dassault's own copy. | Matches the current CIMA plan: replicad modeler plus CATIA connectors. |
| 2 | **3DEXPERIENCE CATIA** (CATIA V6 / 3DX native app), with "3DModeler" as a garbled "3DEXPERIENCE" or the "3D Modeling" apps | ~25% | Dassault grouped CATIA in the "3D Modeling" Compass quadrant. Spanish job ads pair "CATIA V5 o 3DEXPERIENCE". Adam itself ships separate V5 and V6/3DX connectors. Against: the user names only "la aplicación de catia" (singular). | The 3DX native connector (COM on `3DEXPERIENCE.exe`, PLM objects, saving to the platform) becomes MVP-critical rather than "later". |
| 3 | **Browser modeling roles on 3DEXPERIENCE**: "3D Creator" / SOLIDWORKS xDesign, "3D Sculptor" / xShape, or CATIA "3D Shape Designer" (CATIA xDesign + xShape Design + xGenerative Design, browser apps offered on the cloud only) | ~10% | Role names follow a "3D ___" pattern, and "3D Creator" sounds close to "3D Modeler". | These are browser apps with no COM automation. Integration would go through file exchange (STEP) or platform web services, which is much harder. Confirm before investing. |
| 4 | **Adam's two modes**: CAD generation for CATIA *plus* Adam's "AI 3D model generator" (Creative/mesh mode) | ~10% | CADAM's tagline names both, and the composer toggles Parametric and "Mesh". | A mesh generator (image/text to GLB/STL through a hosted model) would be a separate, later feature; it does not produce CATIA features. |
| 5 | **An unrelated product literally named "3D Modeler"**: Ansys Electronics Desktop's "3D Modeler" window, Adobe Substance 3D Modeler, Spatial's 3D ACIS Modeler / CGM kernels, FreeCAD's "3D parametric modeler" tagline | ~5% combined | Exact name matches, but none is typically paired with CATIA for "parts and assemblies". | Out of scope unless the user confirms it. |

### 5.3 Recommendation

- Keep the architecture interpretation-agnostic:
  - `CadConnector` interface with `CatiaV5Connector` (MVP) and `Catia3dxConnector` (when needed).
  - The in-app modeler (replicad) is the core either way.
- Ask the user one question (Spanish): **"Cuando dices '3DModeler', te refieres a (a) el modelador 3D de la propia app (generar piezas/ensamblajes y verlas), (b) CATIA en 3DEXPERIENCE (V6/3DX), (c) otro programa concreto (p. ej. SOLIDWORKS xDesign/3D Creator, Ansys 3D Modeler), o (d) además generar mallas 3D libres como el modo 'Mesh' de Adam? ¿Y qué versión de CATIA usáis (p. ej. V5-6R2022 o 3DEXPERIENCE R2025x)?"**

  (English: "When you say '3DModeler', do you mean (a) the app's own 3D modeler (generate and view parts and assemblies), (b) CATIA on 3DEXPERIENCE (V6/3DX), (c) another specific program (for example SOLIDWORKS xDesign/3D Creator, Ansys 3D Modeler), or (d) also free-form 3D mesh generation like Adam's 'Mesh' mode? And which CATIA release do you use (for example V5-6R2022 or 3DEXPERIENCE R2025x)?")
- Until the answer arrives, nothing in the MVP depends on it except the priority of the 3DX connector (L3).

---

## 6. Features CIMA should implement (MVP vs later)

Goal: deliver adam.new's value to CATIA users. That value is going from intent to an editable parametric model in minutes, exploring variants instantly with sliders, refining conversationally with history, trusting the result through self-verification, and landing the model natively in CATIA with parameters and formulas intact.

### MVP (v0.x)

| ID | Feature | adam.new analog | Acceptance criteria / notes |
|---|---|---|---|
| **M1** | **Workbench layout**: Electron window with custom title bar; left sidebar (Nueva pieza/ensamblaje, Proyectos with thumbnails, Plantillas, Ajustes); **3 resizable, collapsible panels Chat, Vista 3D, Parametros/Arbol** with persisted sizes; bottom log drawer; dark theme; ES/EN i18n. | ConversationView + Sidebar + greeting landing | Works at 1280x720. Chat panel 360-560 px. Right panel 300-400 px. Collapsed panels become vertical tabs. |
| **M2** | **Multi-provider CAD agent with streaming**: provider/model picker (Claude default; OpenAI, Gemini, Ollama, any OpenAI-compatible endpoint); canonical tools `build_cad_model(model JSON)`, `answer_user(text)` and `ask_user(question, options)` for missing critical dimensions; streamed reasoning summary and a **live feature list** as the JSON streams; final answer lists **assumptions** ("Asumi espesor 5 mm..."); auto title and **2 suggestion pills** from a cheap model; "Mejorar prompt" wand; keys stored with Electron `safeStorage`, never sent to the renderer. | build_parametric_model / answer_user; title and suggestions; prompt generator | The same 10 benchmark prompts give schema-valid JSON on at least 3 providers, or a clear error. A stop button cancels the stream. |
| **M3** | **Validate, build, repair loop**: Zod schema validation, then semantic checks (closed sketches, references and parameter names resolve, units), then a replicad build in a Worker with **per-feature error capture** (feature id plus OCC message), returned to the LLM as structured tool errors; at most N (about 5) auto repairs; never report success without a successful build. When the repair budget is exhausted, the failed feature is highlighted and a **"Reparar con IA"** button (CADAM's "Fix with AI") sends the structured error back as a new turn. | Compile errors become tool errors and the loop continues | Fault-injected models are repaired, or the UI shows exactly which feature failed and why. |
| **M4** | **Visual + numeric self-verification**: after each build, render a 3x3 inspection sheet (ISO, FRONT, BACK, LEFT, RIGHT, TOP, BOTTOM, **plus a section view and a metrics tile**, using CADAM's two empty slots); compute bbox (mm), volume, area, solid count, feature count and failed features; send image plus metrics in the tool result; non-vision models get metrics only; users can open the sheet. | Inspection sheet loop (Adam's docs: screenshots explain, measurements establish) | On the benchmark set, the final bbox matches stated envelope dimensions within tolerance. Turn cost is shown. |
| **M5** | **Parameter panel with instant regeneration**: grouped sliders, numeric fields and units (mm/deg), description tooltips, switches, and segmented toggles for enums. Apply Adam's slider lessons (section 2.11): large hit zone, hover/active feedback, a tick marking the AI's original value, explicit or value-proportional ranges, click-to-jump on desktop; **derived parameters shown read-only with their formula**; reset one or all; edits re-evaluate formulas and rebuild locally (debounce 150-200 ms) **without the LLM**; slider edits create a "manual" version with undo/redo. | ParameterSection + deterministic updates + originalCode | Simple part: about 300 ms or less from slider release to new mesh (target). Defaults always come from the AI's original version. |
| **M6** | **CATIA-style feature tree**: Part > Parameters, Relations, PartBody > Sketch.n / Pad.n / Pocket.n / EdgeFillet.n..., plus a geometrical set for references; click highlights the feature in the viewport; error badges on failed features; rename and visibility toggle. | None in CADAM (Adam's commercial product works on native trees) | What the user sees is what CATIA will get. Names are reused verbatim in the CATIA push. |
| **M7** | **Versions, branches and local projects**: each build is a **version card** (thumbnail, title, vN, model used); click to load it; restore; **retry with another model**; editing an earlier prompt creates a branch with "< i/n >" navigation; projects stored locally (SQLite or JSON under userData) with images and exports; export/import a `.cima` project file. | Message tree, retry/edit/restore, history grid | No data leaves the PC except LLM calls. Projects survive restarts and updates. |
| **M8** | **Assemblies v1**: part definitions plus instances (placement as translation + rotation or 4x4 matrix), product tree, per-part colors, a visual-only explode slider, and a BOM table (part number, quantity); pushed to CATIA as a CATProduct with positioned components (first component fixed). | None in CADAM (multi-solid single program only) | Required by the user ("partes y assemblies"). Constraints come in L4. |
| **M9** | **CATIA V5 connector v1 ("Enviar a CATIA")**: status chip (CATIA detected or not, version, active doc); push to a **new** CATPart/CATProduct; create **user parameters + formulas** so the model stays parametric in CATIA; named features; constrained sketches where feasible; `Part.Update`; errors mapped back to feature ids; script log; **"Exportar .CATScript"** for Tools > Macro; detection of elevation mismatch, multiple sessions and modal-dialog blocking. Every push runs as a job with an id, idempotency key, timeout and final state (`succeeded` / `failed` / `unknown`); `unknown` (timeout, killed `cscript`) leads to "inspect before retry", never an automatic resend (section 3.8). | Adam's CATIA V5 bridge (edit parts/products, run automation scripts) | The 10 benchmark parts rebuild in CATIA with matching bbox and volume (within tolerance), and their parameters are editable in CATIA's tree. |
| **M10** | **Inputs and exports**: images, sketches, photos and drawing screenshots (drag-drop, paste, file; PDF pages rasterized) for vision models. Exports: **STEP** (replicad/OCCT), STL, model JSON, .CATScript/.vbs, PNG snapshot; "open folder". | Image references; STL/SCAD/DXF split button | STEP opens in CATIA as B-rep (not a mesh). Image prompts work with vision models and are disabled with a tooltip otherwise. |

### Later

| ID | Feature | Why / analog | Notes |
|---|---|---|---|
| **L1** | **Copilot on existing CATIA models**: read the active CATPart/CATProduct (spec tree, parameters, relations, bodies), summarize it, and let the AI propose parameter changes, descriptive renames, **conversion of hard-coded dimensions into parameters**, and tree cleanup; show a diff, apply after approval, then Update and verify. | Adam's main value for professionals (Onshape: rename, merge, variables, fillets) | Destructive potential. Default to working on a copy and require explicit approval for each change. |
| **L2** | **Native verification inside CATIA**: after a push or edit, capture CATIA viewer images from fixed viewpoints, read the update status and measures, and feed them to the LLM; compare with CIMA's preview. | Adam's "Capture the viewer" capability | See Appendix A for the API sketch and its open questions. |
| **L3** | **3DEXPERIENCE native connector**: attach to `3DEXPERIENCE.exe`, create a 3D Part / Physical Product, save to the platform **only on explicit request**. | Adam's CATIA V6/3DX connector | Becomes MVP if the "3DModeler" answer is (b). Needs its own API research (PLM object model differs from V5). |
| **L4** | **Engineering depth**: selection as context (pick faces or edges in the viewer to anchor edits); assembly constraints (coincidence, contact, offset, angle); CATDrawing generation with views and dimensions; materials and mass properties; standard parts (ISO screws, nuts, holes, threads, fits). | Adam Copilot "selected geometry as context"; drawing workflows | Raises fidelity from concept to engineering. |
| **L5** | **Knowledge and automation**: company templates and standards as reusable "skills"; preference memory; **batch operations** across files; local API-doc retrieval (V5Automation.chm / DSYAutomation.chm / pycatia docs) so the agent can draft custom automation that a human approves (dry-run on a new document); an **expert mode** (section 2.12) in which, with a live CATIA, the agent writes automation directly, runs it on a new document, captures CATIA's viewer and iterates; optional MCP server exposing CIMA tools to other AI clients. | Adam skills, memory, scheduled and batch work, MCP; Adam's "code + screenshot" agent | Gate every custom script behind review and approval. |

Optional, only if the user answers (d) in section 5.3: text/image-to-mesh generation (Adam's "Mesh" mode) as *reference geometry* (GLB/STL shown in the viewport, importable into CATIA as a mesh), clearly separated from the parametric features that CIMA pushes to CATIA.

### MVP end-to-end story (for demos and tests)

1. The user types *"Brida DN50 PN16 con 4 taladros M16, espesor 18 mm"* (a DN50 PN16 flange with four M16 holes, 18 mm thick).
2. The agent builds the JSON model, which streams as a feature list.
3. Validation and the replicad build run.
4. The 7-view sheet plus metrics come back to the agent, which self-corrects if needed.
5. The 3D preview appears, with parameters grouped as Brida (flange), Taladros (holes) and Material, and a CATIA-style tree.
6. The user drags the thickness slider and sees an instant rebuild.
7. The user clicks "Enviar a CATIA" to get a new CATPart with user parameters, formulas and named features, with the CATIA log shown.
8. The user exports STEP.
9. A follow-up prompt, "anade un resalte de 3 mm" (add a 3 mm raised face), creates version v2. The user can go back to v1 at any time.

---

## 7. Proposed CIMA UX specification (adapted to Electron + CATIA)

```
+-- CIMA - Brida DN50 ------------------ [Claude Opus 5.5 v] [* CATIA V5 conectado] [ajustes] --+
| Side   | CHAT                       | VISTA 3D (replicad + three.js)   | [Parametros|Arbol|Info] |
| +Nueva | (user) prompt              | toolbar: Iso Frente Sup ... |    | v Brida                 |
| Proyec.| (CIMA) Pensando... (fold)  |   Orto/Persp | Aristas | Corte | |   Diametro ext [==|] mm |
|  - P1  |  [card: Brida DN50   v2]   |   Medir                          |   Espesor      [=| ] mm |
|  - P2  |   thumbnail, assumptions   |                                  | v Taladros              |
| Plant. |  [retry][modelo v][<2/2>]  |          part (gray metal,       |   Numero         [4]    |
|        | [pill] [pill]              |          dark edges, Z-up)       |   Metrica       [M16 v] |
|        | +------------------------+ |                     [ViewCube]   |-------------------------|
|        | | Describe la pieza...   | | status: OK | bbox 165x165x18 mm  | [Enviar a CATIA >][v]   |
|        | | [adj] [img] [mejorar]  | |                                  | [Exportar v]            |
+--------+----------------------------+----------------------------------+-------------------------+
| v Registro: build OK (12 features) | CATIA: script OK, Update OK, 3 parametros, 2 formulas      |
+-----------------------------------------------------------------------------------------------+
```

- **Palette**:
  - Reuse the generic dark neutral scale (#191A1A, #212121, #2D2D2D, #3B3B3B; text #E5E5E5 / #949494 / #676767).
  - **Pick CIMA's own accent** (for example teal #2BB3A3 or amber #F59E0B) instead of CADAM's #00A6FF or the adam.new marketing pink #ff2d92, to avoid mimicking the Adam brand.
  - Use the accent for selection, the active version card, the primary button and focus rings.
- **Viewport look for CATIA users**:
  - Shading with edges: a neutral light-gray metal part with dark edge lines (replicad can mesh edges separately).
  - Per-part colors in assemblies.
  - Z-up axis triad.
  - Optional CATIA-like gradient background.
  - Orthographic by default (as in CADAM).
- **Microcopy (ES)**:
  - "Construyendo CAD..." (Building CAD...).
  - "Verificando vistas..." (Checking views...).
  - "Listo: v3 (12 operaciones)" (Done: v3, 12 operations).
  - "CATIA no esta abierto" (CATIA is not open).
  - "CATIA se ejecuta como administrador: abre CIMA tambien como administrador" (CATIA runs as administrator: open CIMA as administrator too).
  - "Se creara un documento nuevo; tu documento activo no se modifica" (A new document will be created; your active document is not modified).
- **Keyboard**:
  - Enter sends; Shift+Enter inserts a newline.
  - Ctrl+Z / Ctrl+Y undo and redo parameter edits.
  - F to fit all.
  - 1-7 switch standard views.

---

## 8. Notes for the AI-integration track (from CADAM + current Anthropic docs)

Sources: CADAM `src/server/modelCapabilities.ts` and `aiChat.ts`, and the bundled Anthropic claude-api reference (models table cached 2026-11-03; every bullet below re-checked against it on 2026-11-21) [H].

- **Default model id**: `claude-opus-5-5` (USD 4 / 20 per million input/output tokens, 1M context, 128K output).
  - Side tasks (conversation title, the two suggestion pills, the prompt improver): use the current Haiku, `claude-haiku-5-5`. CADAM still calls `claude-haiku-4-5` for these, which is the previous generation.
  - Other current ids: `claude-sonnet-5-5`, and `claude-fable-5-2` as the most capable (and most expensive) model.
  - Set `output_config.effort` explicitly. Opus 5.5 defaults to `medium`; use `high` for complex parts.
  - Thinking **cannot be disabled** on Opus 5.5; sending `thinking: {type: "disabled"}` returns a 400.
  - To show a "Pensando..." summary like CADAM's reasoning block, request `thinking: {type: "adaptive", display: "summarized"}`. The default display is omitted.
- **Forced `tool_choice` (`any` / `tool`) returns HTTP 400** on Claude Opus 5.5, Sonnet 5.5 and Fable/Mythos 5.1+.
  - Use `tool_choice: auto`, a system-prompt instruction that names the build tool, and `strict: true` on the tool schema.
  - Detect turns that end without a build and nudge once, as CADAM logs it.
  - OpenAI-compatible providers may still support forcing the tool (`required`); keep this behaviour configurable per provider.
- **Live feature list while streaming**: set `eager_input_streaming: true` on the CAD tool so the JSON arrives incrementally.
  - With this flag the API does not validate the streamed input, so always validate the final parsed input with Zod before building.
  - The input can also be truncated at `max_tokens`; check `stop_reason` before running the tool.
- **Refusals**: Anthropic recommends opting into server-side fallbacks for Opus 5.5 (beta `server-side-fallback-2026-07-01`, `fallbacks: "default"`).
  - Check `stop_reason === "refusal"` in any case.
  - Likelihood for CAD prompts is low, but it matters for robustness.
- **Verification images**: return the inspection PNG as an image block inside the `tool_result` (supported: computer-use screenshots travel the same way).
  - Cache the system prompt and tool definitions (prompt caching) because the loop repeats them on every step.
  - For non-vision models (some Ollama models, DeepSeek/GLM via OpenAI-compatible endpoints), send metrics only.
- **Provider normalization**: CADAM's main lesson. Accept one schema, validate strictly, and render the UI only from validated data.

---

## 9. Open risks and uncertainties

1. **Meaning of "3DModeler"** (section 5). If it means 3DEXPERIENCE, the 3DX connector moves into the MVP, and its object model (PLM services, editors) needs dedicated research. **Ask the user.** [M]
2. **GPL contamination** if anyone copies CADAM code or prompt text into CIMA. Use clean-room reimplementation. [H]
3. **Adam connector internals are undocumented.** "COM automation of the running CATIA" is an inference, although a strong one. [M]
4. **Parameter units in V5 automation**: the official help text for `Parameters.CreateDimension(iName, iMagnitude, iValue)` says LENGTH is in **meters** and ANGLE in **radians**, while recorded macros are commonly reported to pass model units.
   - Safest approach: create the parameter, then set its value with an explicit-unit string such as `ValuateFromString("18mm")` or `"30deg"`.
   - Verify on a real CATIA. [M]
   - Hand this to the CATIA-API track.
5. **Viewer capture details (L2)**: method names and enum ordinals come from pycatia/CAA docstrings [H for names, M for numeric values]. Still unverified:
   - Whether the spec-tree or compass overlay appears in captures.
   - The behaviour when the CATIA window is minimized.
   - `StartCommand` names are localized, so avoid command-name automation in Spanish CATIA installs.
6. **LLM spatial reasoning is still weak.** HN users reported disconnected parts, hallucinated library calls, and output that is not manufacturable. Mitigations:
   - Set expectations as "concept to parametric draft".
   - Keep verification and engineering checks.
   - Support many small, verifiable features rather than freeform geometry. [H]
7. **Visual verification requires vision models.** Many local Ollama models lack vision, which leaves a metrics-only loop with weaker self-correction. [H]
8. **Sources quality**: several Adam pages return only short Markdown summaries to automated fetchers. The Onshape forum post is behind a login, and the Launch HN content came via a mirror. Facts tagged [M] above should be rechecked if they become decision-critical. [H]
9. **Competitive movement**: Dassault's LEO roadmap (Pad/Pocket/Hole creation, multimodal part and assembly generation) could reach on-premise 3DX later. Adam already lists CATIA V5 and V6. CIMA's durable edges are V5 support, local-first operation, bring-your-own LLM, and transparent native parametric output. [M]
10. **Adam is already in CIMA's niche.** Its docs describe a bundled CATIA V5 bridge (read the active document, edit parts and products, run CATIA Automation scripts, capture the viewer, exchange files) and a separate CATIA V6/3DEXPERIENCE connector; its marketing page still frames CATIA V5 as a per-customer evaluation with V6/3DX outside that evaluation. The two pages disagree on maturity, so the real availability is unclear [H for the text, M for the status]. CIMA should differentiate explicitly: no cloud account, the user's own LLM key or a local model, previews and STEP export without CATIA, and generated parametric features with user parameters and formulas.
11. **IR rigidity versus model progress** (Adam's "bitter lesson"). A narrow JSON feature schema can cap what stronger models could do, and every new feature type costs schema, validator, replicad and CATIA code. Mitigations: keep the schema close to CATIA's vocabulary and generic (sketch + feature + references + formulas), measure failure categories on a benchmark set, and plan the approval-gated expert mode (L5). [judgement]

---

## 10. Sources

**Adam / CADAM**
- https://adam.new/ (home and navigation)
- https://adam.new/llms.txt (product index: integrations, MCP, API)
- https://adam.new/copilot
- https://adam.new/opensource
- https://adam.new/onshape
- https://adam.new/fusion-360
- https://adam.new/ai-cad/catia
- https://adam.new/install
- https://adam.new/learn
- https://docs.adam.new (index)
- https://docs.adam.new/integrations/catia (CATIA V5)
- https://docs.adam.new/integrations/catia-v6 (CATIA V6 / 3DEXPERIENCE)
- https://docs.adam.new/integrations/desktop-connector (Adam Desktop, bridges)
- https://docs.adam.new/integrations/onshape
- https://docs.adam.new/supported-software
- https://docs.adam.new/cad/modeling
- https://docs.adam.new/guides/core-concepts
- https://docs.adam.new/mcp/tools
- https://github.com/Adam-CAD/CADAM (commit e339e3ad85601bb1e23a5ff9c7f33b51ddf602f5, 2026-10-15 UTC). Files read:
  - README.md
  - .cursor/rules/*.mdc
  - shared/chatAi.ts
  - shared/types.ts
  - shared/parametricParts.ts
  - shared/parseParameters.ts
  - shared/models.ts
  - src/server/aiChat.ts
  - src/server/modelCapabilities.ts
  - src/views/EditorView.tsx
  - src/views/ConversationView.tsx
  - src/views/PromptView.tsx
  - src/components/chat/ChatSession.tsx
  - src/components/chat/MessageBubble.tsx
  - src/components/parameter/ParameterSection.tsx
  - src/utils/parameterUtils.ts
  - src/utils/meshUtils.ts
  - src/lib/utils.ts
  - src/components/viewer/*
  - tailwind.config.js
  - src/index.css
  - public/screenshot-1..3.jpeg
- https://news.ycombinator.com/item?id=45140921 (Show HN, 2025-09-05)
- https://hn.nuxt.dev/item/48572553 (Launch HN mirror, ~2026-06)
- https://techcrunch.com/2025/10/31/yc-alum-adam-raises-4-1m-to-turn-viral-text-to-3d-tool-into-ai-copilot/
- https://onshape.com/en/blog/adam-ai-app-store-cad-co-pilot
- https://forum.onshape.com/discussion/29558/ai-copilot-for-onshape-beta-testers-wanted (login-walled; content seen via a search summary)
- Added in the second pass:
  - https://adam.new/ (HTML version: positioning, use cases, integration categories, plans) and https://adam.new/marketing/shared/adam-v1.css (theme tokens)
  - https://adam.new/blog, https://adam.new/blog/bitter-lesson-ai-cad (2026-05-24), https://adam.new/blog/sliders (2025)
  - https://adam.new/pricing (plan names; prices only in the rendered page)
  - https://docs.adam.new/llms.txt (docs index)
  - https://docs.adam.new/integrations/fusion, https://docs.adam.new/integrations/solidworks
  - https://docs.adam.new/mcp/direct-tools (named operations, idempotency keys, `unknown` status)
  - https://docs.adam.new/guides/workflows, https://docs.adam.new/setup
  - https://api.github.com/repos/Adam-CAD/CADAM and https://api.github.com/repos/Adam-CAD/CADAM/commits (stars, creation date, latest commit)
  - https://raw.githubusercontent.com/Adam-CAD/CADAM/master/ (`src/utils/parameterUtils.ts`, `src/utils/meshUtils.ts`, `src/server/aiChat.ts`, `src/server/mesh.ts`, `src/components/parameter/ParameterInput.tsx`, `src/components/viewer/ThreeScene.tsx`, `src/components/viewer/OpenSCADViewer.tsx`, `src/components/TextAreaChat.tsx`, `src/components/Sidebar.tsx`, `src/views/ConversationView.tsx`)
  - https://marketplace.autodesk.com/apps/f1745e6f-3f3b-4ad6-9f8f-4852ddfb8a20 (Adam for Fusion listing)
  - https://www.ycombinator.com/companies/adam
  - https://hn.svelte.dev/item/45140921 (Show HN mirror), https://hn.nuxt.dev/item/48572553 (Launch HN mirror)

**Dassault / 3DEXPERIENCE / "3D Modeler"**
- https://www.3ds.com/technologies/cad-software/3d-modeling
- https://www.3ds.com/store/cad/3d-modeling-software
- https://3dswym.3dexperience.3ds.com/wiki/catia-user-community/catia-3d-shape-designer_Dc-87OhbTK2Oodd3XctVSg
- https://3dswym.3dexperience.3ds.com/wiki/makers-support/introducing-the-all-in-one-solidworks-xdesign-role_seE2OfJpSma1LnGYLaF_vQ
- https://www.cadimensions.com/products/software/solidworks-3dexperience/roles/3d-creator/
- https://www.javelin-tech.com/blog/2020/06/the-3dexperience-compass/ (returned 403 to the fetcher; content seen via a search summary)
- https://3dswym.3dexperience.3ds.com/post/3dexperience-platform-user-s-community/3dexperience-r2021x-what-s-new-discover-the-compass-experience_RuxHEyUbTy25AGC1umD4Kw
- https://3dswym.3dexperience.3ds.com/wiki/3dexperience-platform-user-s-community/catia-what-s-new-generative-experience-virtual-companions_vneuxLA1Qyqx9lCBqMqBqg
- https://www.goengineer.com/blog/ai-in-catia
- https://3dswym.3dexperience.3ds.com/post/catia-user-community/best-practice-getting-started-with-automation-3dexperience-r2020x_YkHTYfqUQYO4cVMO1ydOlg
- https://gfxspeak.com/newswatch/spatial-continues-expand/
- https://www.spatial.com/glossary/geometric-modeling-kernel
- https://www.freecad.org/
- https://en.wikipedia.org/wiki/Substance_3D_Modeler
- https://arrc.ou.edu/~cody/hfsslib/hfss_examples (HFSS "3D Modeler" scripting examples)
- https://develop3d.com/cad/mecagent-targets-complex-cad-tasks-with-gpt-6-astra-powered-v2/
- Added in the second pass:
  - https://www.engineersrule.com/the-3dexperience-platform-the-compass-explained/ (Compass quadrants: West = 3D Modeling)
  - https://en.wikipedia.org/wiki/ACIS and https://en.wikipedia.org/wiki/Spatial_Corp (3D ACIS Modeler, CGM Modeler, Dassault ownership since 2000)
  - https://www.3ds.com/products/catia/3dexperience-catia (CATIA packaged as roles; R2026x)
  - https://trimech.com/3d-creator/ (3D Creator = xDesign, browser-based)
  - https://3dswym.3dexperience.3ds.com/wiki/3dexperience-platform-user-s-community/enhanced-roles_thK3-QsiQWCvD75cER9mmQ (role list: 3D Creator, 3D Sculptor, 3D SheetMetal Creator, Collaborative Designer for CATIA V5, ...)
  - Spanish CATIA job listings seen through a search-engine summary only: https://www.infojobs.net/ofertas-trabajo/catia-v5, https://es.indeed.com/q-catia-empleos.html

**CATIA automation (pycatia docstrings copied from CAA V5 Visual Basic Help)**
- https://github.com/evereux/pycatia/blob/master/pycatia/enumeration/enumeration_types.py
- https://github.com/evereux/pycatia/blob/master/pycatia/in_interfaces/viewer.py
- https://github.com/evereux/pycatia/blob/master/pycatia/in_interfaces/viewpoint_3d.py
- https://github.com/evereux/pycatia/blob/master/pycatia/knowledge_interfaces/parameters.py
- https://github.com/evereux/pycatia/blob/master/pycatia/knowledge_interfaces/relations.py

**Anthropic API behaviour**: Claude API skill reference bundled with Claude Code (models table cached 2026-11-03, re-read 2026-11-21): forced tool choice, thinking/effort, eager input streaming, server-side refusal fallbacks and model ids for `claude-opus-5-5`, `claude-sonnet-5-5`, `claude-haiku-5-5`.

---

## Appendix A - Native CATIA viewer capture sketch (for L2; not run on CATIA)

Verified names come from the CAA V5 VB Help text reproduced in pycatia:

- `Viewer.CaptureToFile(CatCaptureFormat iFormat, CATBSTR iFile)`
- `Viewer.Reframe()`, `Viewer.Update()`
- `Viewer3D.Viewpoint3D`
- `Viewpoint3D.PutSightDirection(Array)`, `PutUpDirection(Array)`, `PutOrigin(Array)`
- `Viewpoint3D.ProjectionMode`

The sight direction is "the line passing by the origin of the viewpoint and by the target", that is, from the eye toward the target.

| Enum | Members (0-based ordinal per pycatia's tuple order) | Conf. |
|---|---|---|
| CatCaptureFormat | 0 catCaptureFormatCGM, 1 catCaptureFormatEMF, 2 catCaptureFormatTIFF, 3 catCaptureFormatTIFFGreyScale, **4 catCaptureFormatBMP**, **5 catCaptureFormatJPEG** | [M] ordinal values; names [H] |
| CatProjectionMode | **0 catProjectionConic** (perspective), **1 catProjectionCylindric** (parallel), 2 catProjectionUndefined | [M] |

```vbscript
' Sketch: capture an isometric, parallel-projection image of the active CATIA V5 3D window.
' External VBScript (cscript) has no CATIA enum constants -> use numeric values.
Option Explicit
Dim CATIA, viewer, vp
Set CATIA  = GetObject(, "CATIA.Application")   ' fails (err 429) if CATIA not running or elevation differs
Set viewer = CATIA.ActiveWindow.ActiveViewer    ' a Viewer3D for a 3D window (late bound)
Set vp     = viewer.Viewpoint3D
vp.ProjectionMode = 1                           ' 1 = catProjectionCylindric (parallel)
vp.PutSightDirection Array(-1, -1, -1)          ' eye at +X+Y+Z looking at the target
vp.PutUpDirection    Array(-1, -1, 2)           ' Z-up projected to be orthogonal to the sight direction
viewer.Reframe                                  ' "fit all in"
viewer.Update
viewer.CaptureToFile 5, "C:\Temp\cima_iso.jpg"  ' 5 = catCaptureFormatJPEG
```

Open questions to verify on a real CATIA:

- Whether the specification-tree overlay is included in the capture.
- Whether `Reframe` keeps the requested direction.
- Behaviour with a minimized window or an invisible session (`CATIA.Visible`).
- Image size, which equals the viewer's size (`viewer.Width` / `viewer.Height`).

## Appendix B - Inspection sheet for CIMA's own viewer (original code sketch, three.js)

```ts
import * as THREE from 'three';

// Z-up like CATIA/OCCT. 'eye' = direction from the model centre to the camera.
// TODO: align FRONT/RIGHT/... with CATIA's standard view definitions once verified.
const VIEWS = [
  { name: 'ISO',    eye: [ 1,  1,  1], up: [0, 0, 1] },
  { name: 'FRONT',  eye: [ 0, -1,  0], up: [0, 0, 1] },
  { name: 'BACK',   eye: [ 0,  1,  0], up: [0, 0, 1] },
  { name: 'LEFT',   eye: [-1,  0,  0], up: [0, 0, 1] },
  { name: 'RIGHT',  eye: [ 1,  0,  0], up: [0, 0, 1] },
  { name: 'TOP',    eye: [ 0,  0,  1], up: [0, 1, 0] },
  { name: 'BOTTOM', eye: [ 0,  0, -1], up: [0, 1, 0] },
] as const;

export function renderInspectionSheet(root: THREE.Object3D, tile = 512): string {
  const box = new THREE.Box3().setFromObject(root);
  const center = box.getCenter(new THREE.Vector3());
  const diag = box.getSize(new THREE.Vector3()).length() || 1;
  const half = (diag / 2) * 1.05;

  const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
  renderer.setSize(tile, tile);
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x3b3b3b);
  scene.add(new THREE.HemisphereLight(0xffffff, 0x444444, 1.0));
  const sun = new THREE.DirectionalLight(0xffffff, 1.0);
  sun.position.set(1, 1, 2);
  scene.add(sun, root);

  const cam = new THREE.OrthographicCamera(-half, half, half, -half, 0.01, diag * 10);
  const sheet = document.createElement('canvas');
  sheet.width = tile * 3;
  sheet.height = tile * 3;
  const ctx = sheet.getContext('2d')!;
  ctx.fillStyle = '#2b2b2b';
  ctx.fillRect(0, 0, sheet.width, sheet.height);
  ctx.font = '600 28px system-ui, sans-serif';
  ctx.textBaseline = 'top';

  VIEWS.forEach((v, i) => {
    cam.up.set(v.up[0], v.up[1], v.up[2]);
    cam.position.copy(center).addScaledVector(new THREE.Vector3(...v.eye).normalize(), diag * 2);
    cam.lookAt(center);
    cam.updateProjectionMatrix();
    renderer.render(scene, cam);
    const x = (i % 3) * tile;
    const y = Math.floor(i / 3) * tile;
    ctx.drawImage(renderer.domElement, x, y, tile, tile);
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.fillRect(x + 12, y + 12, 140, 40);
    ctx.fillStyle = '#fff';
    ctx.fillText(v.name, x + 22, y + 18);
  });
  // Tiles 8-9: section view (material.clippingPlanes + renderer.localClippingEnabled) and a metrics text tile.
  renderer.dispose();
  return sheet.toDataURL('image/png');
}
```

## Appendix C - CADAM file map (to re-check details quickly)

| Concern | File |
|---|---|
| Tool schemas, message parts, metadata | `shared/chatAi.ts`, `shared/types.ts` |
| Parameter grammar and parser | `shared/parseParameters.ts`; regex updater `updateParameter` (present in both `src/lib/utils.ts` and `src/utils/parameterUtils.ts`); ranges, steps, "mm" detection and CSS-color detection in `src/utils/parameterUtils.ts`; model picker list `PARAMETRIC_MODELS` in `src/lib/utils.ts` |
| Agent loop, system prompt, model routing, title and suggestions | `src/server/aiChat.ts`, `src/server/modelCapabilities.ts` |
| Client tool execution, inspection upload, auto-continue | `src/components/chat/ChatSession.tsx` |
| Inspection sheet and thumbnails | `src/utils/meshUtils.ts` |
| Three-panel layout | `src/views/ConversationView.tsx`; editor state in `src/views/EditorView.tsx` |
| Landing | `src/views/PromptView.tsx`, `src/components/TextAreaChat.tsx` |
| Parameters panel and downloads | `src/components/parameter/ParameterSection.tsx`, `ParameterInput.tsx` |
| Theme | `tailwind.config.js`, `src/index.css` |
| Slider ranges and color detection | `src/utils/parameterUtils.ts` (`calculateParameterRange`, `calculateParameterStep`, `isMeasurementParameter`, `cssToHex`, `isColorParameter`) |
| Mesh (Creative) generation | `src/server/mesh.ts` (fal.ai queue), `src/components/viewer/DownloadMenu.tsx` |

## Revision notes (second pass, 2026-11-21)

Corrected:

- Enum parameters render as a **segmented toggle group**, not a select. The parameter panel shows two sections ("Dimensions", "Colors"); Customizer group labels are parsed but not rendered as accordions.
- Latest CADAM commit `e339e3a` is dated 2026-10-15 UTC (not 10-14); 5,448 stars; repo created 2025-09-01.
- Removed unverified details: the slider track color, a 56 px header height, and the "Rendering.." loader label.
- The Onshape App Store date is approximate (blog undated in the fetch).
- LEO: the Pad/Pocket/Hole and multimodal part/assembly items are listed as focus areas under R2026x FD03, without a shipped/planned label. The cloud-only, Blue Token and "not in CATIA V5" claims are now confirmed from GoEngineer [H].
- Slider range examples: 23 gives 0-50 in the current code (the Adam blog's "0-100" example is older).

Added:

- Section 1.3 (adam.new landing page today), 2.11 (slider UX lessons), 2.12 (the "Bitter Lesson" post and its consequences for CIMA's JSON IR), 3.8 (Adam's direct-tool semantics as a template for CIMA's CATIA job runner).
- "Fix with AI" on compile errors; composer limits; mesh download formats; CADAM model picker contents.
- Re-ranked "3DModeler" interpretations (five options, including Adam's CAD + mesh dual mode), with new evidence (Compass quadrant naming, Spatial kernels, Spanish job-ad usage).
- Risks 10 (Adam already targets CATIA V5/V6) and 11 (IR rigidity).
- Verified Anthropic notes: Haiku 5.5 for side tasks, model ids, images inside `tool_result`.
