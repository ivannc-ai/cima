# Validación del conector CATIA en un equipo con CATIA

El generador de scripts se ha probado compilando cada script con el motor VBScript de Windows y
ejecutándolo contra un CATIA simulado. Esta lista sirve para la **primera prueba real** y para
localizar rápidamente cualquier diferencia de API en tu versión de CATIA.

## 1. Preparación

1. Abre CATIA V5 (o 3DEXPERIENCE con sesión iniciada). Sin documentos abiertos es lo más limpio.
2. En CIMA → pestaña **CATIA** → «Actualizar». Debe mostrar la versión (p. ej. `CNEXT V5 R28 SP3`).
   - Si aparece «CATIA no está abierto»: CATIA no está registrado para COM. En V5, desde una consola
     de administrador: `"<instalación>\win_b64\code\bin\CNEXT.exe" /regserver`.
3. Opcional: elige una carpeta de guardado para obtener los CATPart/CATProduct y el STEP.

## 2. Pruebas recomendadas (ejemplos incluidos)

| Ejemplo | Qué valida |
|---|---|
| Brida | parámetros + fórmula derivada, pad con agujero interior, 6 taladros (`AddNewHoleFromSketch`), redondeo por radio |
| Escuadra en L | boceto en ZX (ejes forzados con `SetAbsoluteAxisData`), redondeo por caja, taladros avellanados, taladro en sentido inverso |
| Eje escalonado | `AddNewShaft`/`AddNewGroove` con `Sketch.CenterLine`, chaflanes por plano |
| Caja vaciada | rectángulo con esquinas redondeadas (arcos), redondeo inferior, `AddNewShell` |
| Mesa con columnas | CATProduct, `AddComponent`, `Position.SetComponents`, restricción de fijación |

Tras cada envío, el registro de la pestaña CATIA indica el estado de cada operación. Si algo falla,
el script queda guardado (ruta en el resultado: `%TEMP%\cima\cima-push-*.vbs`) y puede ejecutarse a
mano con:

```powershell
cscript //nologo //U "$env:TEMP\cima\<script>.vbs"
```

## 3. Puntos de la API a confirmar

| Punto | Dónde | Si falla |
|---|---|---|
| `Sketch.CenterLine = linea` | shaft / groove | la revolución falla con error de eje |
| `HybridShapeFactory.AddNewPlaneEquation` | bocetos en planos desplazados | error «sketch» en operaciones con offset |
| Dirección por defecto de `Pocket` / `Hole` | cajeras y taladros | CIMA invierte automáticamente si no quita material (mensaje «direccion invertida») |
| `Hole.Reverse` | taladros | taladro marcado como «no quita material» |
| `Selection.Search "Topology.CGMEdge,sel"` (y variantes por idioma) | redondeos, chaflanes, vaciado | «Ninguna arista/cara coincide…» |
| `Measurable.GetPointsOnCurve / GetPlane / GetCOG / Radius` | filtros de aristas y caras | igual que la fila anterior |
| `AddNewSolidEdgeFilletWithConstantRadius` | redondeos | se intenta `AddNewEdgeFilletWithConstantRadius` |
| `Products.AddComponent(PartDocument.Product)` | ensamblajes | si hay carpeta de guardado se usa `AddComponentsFromFiles` |

Si tu CATIA está en un idioma cuya palabra clave de búsqueda topológica no está en la lista
(`src/main/catia/vbs-runtime.ts`, función `CimaSearch`), graba una macro de «Edición → Buscar» de
aristas y añade la palabra clave que aparezca.
