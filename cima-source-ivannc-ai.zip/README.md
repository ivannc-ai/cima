# CIMA — modelado CAD con IA para CATIA

CIMA es una aplicación de escritorio (Electron, Windows) inspirada en [adam.new](https://adam.new):
describes una pieza o un ensamblaje en lenguaje natural, un proveedor de IA genera un **modelo
paramétrico**, lo ves al instante en 3D con deslizadores para cada cota y lo **envías a CATIA**,
donde se reconstruye como un árbol de operaciones nativo (bocetos, Pad, Pocket, Shaft, Groove,
Hole, EdgeFillet, Chamfer, Shell, Mirror) con **parámetros de usuario y fórmulas**.

```
 Chat (Claude / OpenAI / Gemini / Ollama)
        │  herramienta emit_cad_model → JSON paramétrico (src/shared/model/schema.ts)
        ▼
 Validación (Zod + semántica) ──► Motor geométrico OpenCascade (replicad, WASM, Web Worker)
        │                                     │  vista 3D, STEP, STL
        ▼                                     ▼
 Conector CATIA (VBScript + cscript.exe, COM)  ──►  CATIA V5 / 3DEXPERIENCE
```

## Funciones

- **Chat de diseño** con streaming, imágenes de referencia (boceto/foto), razonamiento resumido e
  historial de versiones restaurables. Si el modelo generado no es válido o alguna operación falla al
  construirse, CIMA devuelve el error a la IA y ésta lo corrige automáticamente (reintentos
  configurables).
- **Modelo paramétrico**: parámetros con rango, paso y descripción; parámetros derivados por
  expresión (`(outer_d + bore_d) / 2`); operaciones con cotas expresadas en función de parámetros.
- **Vista 3D** (three.js): aristas, rejilla, vistas estándar, selección de instancias, ensamblajes.
- **Pestañas**: Parámetros (deslizadores), Árbol (estado de cada operación), CATIA, JSON (edición directa).
- **Exportación**: STEP (con nombres y colores, ensamblajes posicionados), STL, JSON, macro de CATIA
  (`.catvbs`) y script externo (`.vbs`).
- **Conector CATIA**:
  - Detecta la sesión abierta (V5 o 3DEXPERIENCE), versión y documento activo (ruta completa, programa, departamento y usuario a partir del caption de la ventana, como el puente interno).
  - **Modelos de inicio** (V5): en lugar de un documento vacío, parte de plantillas locales
    `.CATPart` / `.CATProduct` descubiertas automáticamente por programa desde el `DLNames` de
    MODLOCAL (línea `Mmaterial;<ruta>` de
    `%USERPROFILE%\MODLOCAL\{programa}\CATSettingsRefV5R{xx}\{programa}_DLNames.txt`). El desplegable
    filtra por naturaleza del modelo: piezas → CATPart, ensamblajes → CATProduct. Al elegir una
    plantilla puedes **poner el nombre que quieras** al Part/Product resultante: se usa como
    PartNumber y como nombre de archivo al guardar. **Sin fallback**: sin acceso a
    MODLOCAL/DLNames o a la carpeta de red no se muestran plantillas, y si la plantilla elegida no
    abre al generar, el trabajo falla con un error claro en el registro.
  - **Enviar a CATIA**: crea pieza(s), parámetros de usuario, fórmulas, bocetos con ejes explícitos,
    operaciones nativas, colores; en V5 también el CATProduct con las instancias posicionadas y la
    instancia fija; guardado opcional de CATPart/CATProduct y STEP en una carpeta.
  - **Leer documento activo**: lista los parámetros del documento abierto en CATIA y permite
    **enviar valores** a los parámetros con el mismo nombre (bidireccional).
- **Proveedores de IA**: Anthropic Claude (por defecto `claude-opus-5-5`), OpenAI, Google Gemini,
  Ollama (local, sin clave) y cualquier endpoint compatible con OpenAI. Las claves se guardan
  cifradas con `safeStorage` de Electron y nunca salen del proceso principal. Cada proveedor admite
  la **lista de modelos disponibles** que quieras (todos comparten endpoint, proxy y clave y
  aparecen en el selector de modelo del chat), y la familia OpenAI admite además **proxy HTTP** y
  **certificado CA** propios (Ajustes → Proveedores).
- **Modo demo**: sin clave API puedes cargar los ejemplos (brida, escuadra, eje, caja, ensamblaje)
  y probar la vista 3D, las exportaciones y el envío a CATIA.
- **Registros**: todo lo que falla (generación de IA, construcción del modelo, trabajos de CATIA,
  errores internos y del renderer) queda en `%APPDATA%\CIMA\logs\cima-AAAA-MM-DD.log` (retención de
  14 días). La ayuda incluye un botón para abrir la carpeta.

## Instalación

Ejecuta `release/CIMA-Setup-<versión>.exe` (instalador) o `release/CIMA-<versión>-portable.exe`
(sin instalación). Los ejecutables no están firmados: Windows SmartScreen puede pedir
confirmación («Más información → Ejecutar de todas formas»).

Primer uso: **Ajustes (⚙)** → pega la clave API del proveedor → «Probar conexión».

## Uso con CATIA

1. Abre CATIA V5 o CATIA 3DEXPERIENCE (con sesión iniciada) en el mismo equipo.
2. En la pestaña **CATIA** pulsa «Actualizar»: debe aparecer la versión detectada.
3. Elige opciones (crear parámetros, fórmulas, colores, carpeta de guardado, STEP) y pulsa
   **Enviar a CATIA**. El registro muestra el resultado de cada operación.

Alternativas sin conexión directa: «Exportar macro» genera un `.catvbs` (Herramientas → Macro →
Macros → bibliotecas VBScript → `CATMain`) o un `.vbs` que puedes ejecutar con
`cscript //nologo //U archivo.vbs` con CATIA abierto.

### Cómo traduce CIMA el modelo a CATIA

| CIMA | CATIA |
|---|---|
| parámetro mm / deg / none | `Parameters.CreateDimension(…,"LENGTH"/"ANGLE")` / `CreateReal` + `Relations.CreateFormula` |
| boceto en plano XY/YZ/ZX (+ offset) o plano libre | `Sketches.Add` sobre el plano de origen o un plano por ecuación (set `CIMA_Construccion`), con `SetAbsoluteAxisData` (ejes H/V idénticos a CIMA) |
| pad / pocket | `AddNewPad` / `AddNewPocket` (+ simétrico, inverso, «hasta el último») |
| shaft / groove | `AddNewShaft` / `AddNewGroove` con eje = línea de construcción `CenterLine` |
| hole (simple, avellanado, abocardado, rosca) | `AddNewHoleFromSketch` por posición |
| fillet / chamfer / shell | búsqueda topológica del cuerpo + filtro geométrico (`SPAWorkbench` / `Measurable`) |
| mirror | `AddNewMirror` sobre plano de origen |
| patrones lineal/circular | copias explícitas de las operaciones patronadas |
| ensamblaje | CATProduct + `AddComponent` + `Position.SetComponents` + restricción de fijación |

Comprobaciones automáticas: tras cada operación que añade o quita material se mide el volumen del
cuerpo; si un Pocket o un taladro no quita material se invierte la dirección una vez, y si aun así
falla la operación se marca con error. Las operaciones que no se pueden actualizar se eliminan para
que la pieza quede consistente.

### Estado de validación y limitaciones conocidas

- El generador se prueba compilando cada script con el motor VBScript de Windows y ejecutándolo de
  principio a fin contra un **CATIA simulado** (`tests/fixtures/mock-catia.js`). Las llamadas a la API
  de CATIA siguen la documentación de automatización V5/3DEXPERIENCE (valores numéricos de enums
  incluidos), pero **no se han ejecutado aún contra un CATIA real**: la primera prueba en tu equipo
  debe confirmar en particular `Sketch.CenterLine`, `AddNewPlaneEquation`, `Hole.Reverse`, la
  búsqueda topológica (`Selection.Search "Topology.CGMEdge,sel"`; CIMA prueba también las palabras
  clave en español, francés, alemán e italiano) y las medidas `GetPointsOnCurve`/`GetPlane`.
- Redondeos, chaflanes y vaciados dependen de la búsqueda topológica; si tu CATIA usa otro idioma o
  la búsqueda falla, la operación aparecerá con error y el resto de la pieza se construirá igualmente.
- 3DEXPERIENCE: cada pieza se crea como *3D Shape*; crear el *Physical Product* del ensamblaje
  requiere licencias de autor (E70/VMX), así que CIMA no lo crea: usa el STEP exportado o coloca las
  piezas manualmente. La exportación STEP desde 3DEXPERIENCE no está disponible por automatización.
- Las cotas de los bocetos se escriben como valores numéricos (las fórmulas se aplican a las cotas de
  las operaciones: longitudes, profundidades, diámetros, radios, espesores, ángulos).

## Incorporar vuestros casos (plantillas y macros VBA)

Guía completa: [docs/casos-propios-y-macros-vba.md](docs/casos-propios-y-macros-vba.md).

1. **Piezas tipo → plantillas (disponible).** Añadid vuestras piezas normalizadas en
   `src/shared/templates/catalog.ts`. Cada una define parámetros, rangos y cómo se construye. La IA
   las usa rellenando valores, que es mucho más fiable con modelos pequeños, y el usuario las tiene en
   la galería «Plantillas». Validadlas con `npx vitest run tests/templates.test.ts`.
2. **Macros VBA → catálogo de herramientas (en preparación).** El ejecutor de macros aún no está
   implementado, pero el formato está definido para que el trabajo de revisión sirva tal cual:
   1. Inventariad y clasificad cada macro: útil / necesita adaptación / descartable; V5 o 3DX;
      solo lectura o modifica.
   2. Adaptadla: un punto de entrada `CimaEntry(...)` sin `UserForm`/`MsgBox`, con los datos como
      parámetros y el resultado escrito en un archivo.
   3. Escribid su ficha `macro.yaml`: qué hace, cuándo usarla, entradas, efecto y cómo se ejecuta.
   4. Guardadlas en una carpeta `macros/v5/<id>/` en un repositorio interno o privado, **nunca en
      uno público**.

   Con las primeras 10–20 macros preparadas se implementa el catálogo: formulario en la pestaña
   CATIA, uso por la IA y servidor MCP.

## Montarlo en otro equipo (desde GitHub)

```powershell
git clone https://github.com/sp-ivanovich/cima.git
```

```powershell
cd cima; npm ci
```

```powershell
npm run dist
```

El instalador (`CIMA-Setup-<versión>.exe`) y el portable (`CIMA-<versión>-portable.exe`) quedan en
`release/`. El repositorio no incluye ejecutables ni `node_modules`: `npm ci` instala las versiones
exactas de `package-lock.json` y `npm run dist` compila y empaqueta. La primera vez electron-builder
descarga Electron y NSIS (requiere Internet).

- **Logotipo de Airbus**: no está en el repositorio (marca registrada). Copia el logo oficial blanco a
  `src/renderer/src/branding/assets/airbus-logo.svg` (o `.png`) antes de `npm run dist`; sin él se
  muestra el texto «AIRBUS».
- **Modelos de prueba** (`examples/`): `soporte-rodamiento.json`, `conjunto-eje-soportes.json` y
  `seccion-ala-costillas.json`. Se pegan en la pestaña **JSON** → «Validar» → «Aplicar».

## Desarrollo

Requisitos: Windows 10/11 x64, **Node.js ≥ 22.12** (con Node 22.11 ejecuta antes
`$env:NODE_OPTIONS="--experimental-require-module"` en PowerShell), Python 3 + Pillow solo para
regenerar el icono.

```powershell
npm install
```

```powershell
npm run dev
```

```powershell
npm test
```

```powershell
npm run dist
```

| Script | Qué hace |
|---|---|
| `npm run dev` | Electron + Vite con recarga en caliente |
| `npm run build` | compila main, preload y renderer en `out/` |
| `npm test` | 109 pruebas: modelo, motor geométrico, generador CATIA + simulador, proveedores de IA, lógica de la interfaz |
| `npm run typecheck` | TypeScript estricto |
| `npm run smoke` | abre la app compilada con Playwright, captura pantalla y falla si hay errores de consola |
| `npm run dist` | instalador NSIS + ejecutable portable en `release/` |

### Estructura

```
src/shared/model/     contrato del modelo: schema.ts (Zod), expr.ts (expresiones), evaluate.ts,
                      geometry.ts (bocetos → líneas/arcos, transformaciones, selectores), validate.ts, examples.ts
src/kernel/           modelo → sólidos OpenCascade (replicad), STEP
src/main/             proceso principal: ventana, protocolo app://, IPC, ajustes cifrados, archivos
src/main/ai/          proveedores de IA, prompt de sistema, esquema de la herramienta
src/main/catia/       generador VBScript, runtime VBScript, ejecución con cscript, estado/inspección
src/preload/          puente tipado window.cima
src/renderer/         interfaz React + three.js, worker del motor geométrico
tests/                vitest (incluye el CATIA simulado)
```
