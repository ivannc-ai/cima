"""Generates build/icon.png (1024) and build/icon.ico (16..256) for CIMA: a stylised mountain
peak ("cima") drawn as an isometric CAD wireframe on a dark rounded tile."""
from pathlib import Path
from PIL import Image, ImageDraw

S = 1024
out = Path(__file__).resolve().parent.parent / "build"
out.mkdir(exist_ok=True)

img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
d.rounded_rectangle((32, 32, S - 32, S - 32), radius=200, fill=(18, 22, 30, 255))

accent = (79, 140, 255, 255)
light = (150, 190, 255, 255)
# Peak faces
d.polygon([(512, 210), (230, 760), (512, 640)], fill=(42, 70, 130, 255))
d.polygon([(512, 210), (512, 640), (800, 760)], fill=(70, 115, 210, 255))
d.polygon([(230, 760), (512, 640), (800, 760), (512, 850)], fill=(28, 44, 80, 255))
# Edges
w = 18
for a, b in [((512, 210), (230, 760)), ((512, 210), (800, 760)), ((512, 210), (512, 640)),
             ((230, 760), (512, 850)), ((800, 760), (512, 850)), ((230, 760), (512, 640)), ((512, 640), (800, 760))]:
    d.line([a, b], fill=light, width=w)
# Snow cap
d.polygon([(512, 210), (440, 350), (512, 330), (585, 352)], fill=(235, 242, 255, 255))
# Small accent node at the summit
d.ellipse((482, 180, 542, 240), fill=accent)

img.save(out / "icon.png")
img.save(out / "icon.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print("icons written to", out)
