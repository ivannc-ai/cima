/**
 * Smoke test: launches the built app (out/) or a packaged exe with Playwright, waits for the UI,
 * saves a screenshot and fails on renderer console errors.
 *
 *   SMOKE_EXE=<packaged exe, optional> SMOKE_SHOT=<png> SMOKE_TEXT=<text to wait for> node scripts/smoke.mjs
 *
 * Optional: SMOKE_CLICK="text 1;text 2" clicks those texts in order (after SMOKE_TEXT appears),
 * waiting SMOKE_CLICK_WAIT ms (default 1500) after each click.
 * Optional: SMOKE_USER_DATA=<dir> runs with a separate profile (lets the smoke run while another CIMA is open).
 * Optional: SMOKE_KEY="F1" presses those keys (";"-separated, Playwright names) after the clicks.
 */
import { _electron as electron } from 'playwright-core'
import path from 'node:path'
import fs from 'node:fs'

const exe = process.env.SMOKE_EXE
const shot = path.resolve(process.env.SMOKE_SHOT ?? 'smoke.png')
const waitText = process.env.SMOKE_TEXT ?? 'CIMA'
const require = (await import('node:module')).createRequire(import.meta.url)

const extraArgs = process.env.SMOKE_USER_DATA ? [`--user-data-dir=${path.resolve(process.env.SMOKE_USER_DATA)}`] : []
const app = exe
  ? await electron.launch({ executablePath: exe, args: extraArgs })
  : await electron.launch({ executablePath: require('electron'), args: ['.', ...extraArgs], cwd: process.cwd() })

const errors = []
const page = await app.firstWindow()
page.on('console', (m) => {
  if (m.type() === 'error') errors.push(m.text())
})
page.on('pageerror', (e) => errors.push(String(e)))
await page.waitForLoadState('domcontentloaded')
try {
  await page.getByText(waitText, { exact: false }).first().waitFor({ timeout: 30000 })
} catch {
  /* screenshot anyway */
}
for (const t of (process.env.SMOKE_CLICK ?? '').split(';').map((x) => x.trim()).filter(Boolean)) {
  try {
    await page.getByText(t, { exact: false }).first().click({ timeout: 10000 })
  } catch (e) {
    errors.push(`SMOKE_CLICK failed for "${t}": ${String(e.message).split('\n')[0]}`)
  }
  await page.waitForTimeout(Number(process.env.SMOKE_CLICK_WAIT ?? 1500))
}
for (const k of (process.env.SMOKE_KEY ?? '').split(';').map((x) => x.trim()).filter(Boolean)) {
  await page.keyboard.press(k)
  await page.waitForTimeout(Number(process.env.SMOKE_CLICK_WAIT ?? 1500))
}
await page.waitForTimeout(Number(process.env.SMOKE_WAIT ?? 4000))
fs.mkdirSync(path.dirname(shot), { recursive: true })
await page.screenshot({ path: shot })
const body = await page.evaluate(() => document.body.innerText.slice(0, 2000))
console.log('--- page text ---\n' + body)
console.log('--- console errors ---\n' + (errors.join('\n') || '(none)'))
await app.close()
process.exit(errors.length ? 1 : 0)
